/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ class TableArrayValueWriter
/*    */   extends ArrayValueWriter
/*    */ {
/*  8 */   static final ValueWriter TABLE_ARRAY_VALUE_WRITER = new TableArrayValueWriter();
/*    */ 
/*    */   
/*    */   public boolean canWrite(Object value) {
/* 12 */     return (isArrayish(value) && !isArrayOfPrimitive(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object from, WriterContext context) {
/* 17 */     Collection<?> values = normalize(from);
/*    */     
/* 19 */     WriterContext subContext = context.pushTableFromArray();
/*    */     
/* 21 */     for (Object value : values) {
/* 22 */       ValueWriters.WRITERS.findWriterFor(value).write(value, subContext);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 30 */     return "table-array";
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\TableArrayValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */