/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ abstract class ArrayValueWriter
/*    */   implements ValueWriter
/*    */ {
/*    */   protected static boolean isArrayish(Object value) {
/* 12 */     return (value instanceof Collection || value.getClass().isArray());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPrimitiveType() {
/* 17 */     return false;
/*    */   }
/*    */   
/*    */   static boolean isArrayOfPrimitive(Object array) {
/* 21 */     Object first = peek(array);
/* 22 */     if (first != null) {
/* 23 */       ValueWriter valueWriter = ValueWriters.WRITERS.findWriterFor(first);
/* 24 */       return (valueWriter.isPrimitiveType() || isArrayish(first));
/*    */     } 
/*    */     
/* 27 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Collection<?> normalize(Object value) {
/*    */     Collection<Object> collection;
/* 34 */     if (value.getClass().isArray()) {
/*    */ 
/*    */       
/* 37 */       collection = new ArrayList(Array.getLength(value));
/* 38 */       for (int i = 0; i < Array.getLength(value); i++) {
/* 39 */         Object elem = Array.get(value, i);
/* 40 */         collection.add(elem);
/*    */       } 
/*    */     } else {
/* 43 */       collection = (Collection<Object>)value;
/*    */     } 
/*    */     
/* 46 */     return collection;
/*    */   }
/*    */   
/*    */   private static Object peek(Object value) {
/* 50 */     if (value.getClass().isArray()) {
/* 51 */       if (Array.getLength(value) > 0) {
/* 52 */         return Array.get(value, 0);
/*    */       }
/* 54 */       return null;
/*    */     } 
/*    */     
/* 57 */     Collection<?> collection = (Collection)value;
/* 58 */     if (collection.size() > 0) {
/* 59 */       return collection.iterator().next();
/*    */     }
/*    */ 
/*    */     
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ArrayValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */