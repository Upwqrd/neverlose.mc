/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ class TomlParser
/*    */ {
/*    */   static Results run(String tomlString) {
/* 10 */     Results results = new Results();
/*    */     
/* 12 */     if (tomlString.isEmpty()) {
/* 13 */       return results;
/*    */     }
/*    */     
/* 16 */     AtomicInteger index = new AtomicInteger();
/* 17 */     boolean inComment = false;
/* 18 */     AtomicInteger line = new AtomicInteger(1);
/* 19 */     Identifier identifier = null;
/* 20 */     Object value = null;
/*    */     int i;
/* 22 */     for (i = index.get(); i < tomlString.length(); i = index.incrementAndGet()) {
/* 23 */       char c = tomlString.charAt(i);
/*    */       
/* 25 */       if (results.errors.hasErrors()) {
/*    */         break;
/*    */       }
/*    */       
/* 29 */       if (c == '#' && !inComment) {
/* 30 */         inComment = true;
/* 31 */       } else if (!Character.isWhitespace(c) && !inComment && identifier == null) {
/* 32 */         Identifier id = IdentifierConverter.IDENTIFIER_CONVERTER.convert(tomlString, index, new Context(null, line, results.errors));
/*    */         
/* 34 */         if (id != Identifier.INVALID) {
/* 35 */           if (id.isKey()) {
/* 36 */             identifier = id;
/* 37 */           } else if (id.isTable()) {
/* 38 */             results.startTables(id, line);
/* 39 */           } else if (id.isTableArray()) {
/* 40 */             results.startTableArray(id, line);
/*    */           } 
/*    */         }
/* 43 */       } else if (c == '\n') {
/* 44 */         inComment = false;
/* 45 */         identifier = null;
/* 46 */         value = null;
/* 47 */         line.incrementAndGet();
/* 48 */       } else if (!inComment && identifier != null && identifier.isKey() && value == null && !Character.isWhitespace(c)) {
/* 49 */         value = ValueReaders.VALUE_READERS.convert(tomlString, index, new Context(identifier, line, results.errors));
/*    */         
/* 51 */         if (value instanceof Results.Errors) {
/* 52 */           results.errors.add((Results.Errors)value);
/*    */         } else {
/* 54 */           results.addValue(identifier.getName(), value, line);
/*    */         } 
/* 56 */       } else if (value != null && !inComment && !Character.isWhitespace(c)) {
/* 57 */         results.errors.invalidTextAfterIdentifier(identifier, c, line.get());
/*    */       } 
/*    */     } 
/*    */     
/* 61 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\TomlParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */