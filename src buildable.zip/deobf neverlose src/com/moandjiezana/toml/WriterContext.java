/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ class WriterContext {
/*   8 */   private String arrayKey = null;
/*     */   private boolean isArrayOfTable = false;
/*     */   private boolean empty = true;
/*     */   private final String key;
/*     */   private final String currentTableIndent;
/*     */   private final String currentFieldIndent;
/*     */   private final Writer output;
/*     */   private final IndentationPolicy indentationPolicy;
/*     */   private final DatePolicy datePolicy;
/*     */   
/*     */   WriterContext(IndentationPolicy indentationPolicy, DatePolicy datePolicy, Writer output) {
/*  19 */     this("", "", output, indentationPolicy, datePolicy);
/*     */   }
/*     */   
/*     */   WriterContext pushTable(String newKey) {
/*  23 */     String newIndent = "";
/*  24 */     if (!this.key.isEmpty()) {
/*  25 */       newIndent = growIndent(this.indentationPolicy);
/*     */     }
/*     */     
/*  28 */     String fullKey = this.key.isEmpty() ? newKey : (this.key + "." + newKey);
/*     */     
/*  30 */     WriterContext subContext = new WriterContext(fullKey, newIndent, this.output, this.indentationPolicy, this.datePolicy);
/*  31 */     if (!this.empty) {
/*  32 */       subContext.empty = false;
/*     */     }
/*     */     
/*  35 */     return subContext;
/*     */   }
/*     */   
/*     */   WriterContext pushTableFromArray() {
/*  39 */     WriterContext subContext = new WriterContext(this.key, this.currentTableIndent, this.output, this.indentationPolicy, this.datePolicy);
/*  40 */     if (!this.empty) {
/*  41 */       subContext.empty = false;
/*     */     }
/*  43 */     subContext.setIsArrayOfTable(true);
/*     */     
/*  45 */     return subContext;
/*     */   }
/*     */   
/*     */   WriterContext write(String s) {
/*     */     try {
/*  50 */       this.output.write(s);
/*  51 */       if (this.empty && !s.isEmpty()) {
/*  52 */         this.empty = false;
/*     */       }
/*     */       
/*  55 */       return this;
/*  56 */     } catch (IOException e) {
/*  57 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void write(char[] chars) {
/*  62 */     for (char c : chars) {
/*  63 */       write(c);
/*     */     }
/*     */   }
/*     */   
/*     */   WriterContext write(char c) {
/*     */     try {
/*  69 */       this.output.write(c);
/*  70 */       this.empty = false;
/*     */       
/*  72 */       return this;
/*  73 */     } catch (IOException e) {
/*  74 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void writeKey() {
/*  79 */     if (this.key.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  83 */     if (!this.empty) {
/*  84 */       write('\n');
/*     */     }
/*     */     
/*  87 */     write(this.currentTableIndent);
/*     */     
/*  89 */     if (this.isArrayOfTable) {
/*  90 */       write("[[").write(this.key).write("]]\n");
/*     */     } else {
/*  92 */       write('[').write(this.key).write("]\n");
/*     */     } 
/*     */   }
/*     */   
/*     */   void writeArrayDelimiterPadding() {
/*  97 */     for (int i = 0; i < this.indentationPolicy.getArrayDelimiterPadding(); i++) {
/*  98 */       write(' ');
/*     */     }
/*     */   }
/*     */   
/*     */   void indent() {
/* 103 */     if (!this.key.isEmpty()) {
/* 104 */       write(this.currentFieldIndent);
/*     */     }
/*     */   }
/*     */   
/*     */   DatePolicy getDatePolicy() {
/* 109 */     return this.datePolicy;
/*     */   }
/*     */   
/*     */   WriterContext setIsArrayOfTable(boolean isArrayOfTable) {
/* 113 */     this.isArrayOfTable = isArrayOfTable;
/* 114 */     return this;
/*     */   }
/*     */   
/*     */   WriterContext setArrayKey(String arrayKey) {
/* 118 */     this.arrayKey = arrayKey;
/* 119 */     return this;
/*     */   }
/*     */   
/*     */   String getContextPath() {
/* 123 */     return this.key.isEmpty() ? this.arrayKey : (this.key + "." + this.arrayKey);
/*     */   }
/*     */   
/*     */   private String growIndent(IndentationPolicy indentationPolicy) {
/* 127 */     return this.currentTableIndent + fillStringWithSpaces(indentationPolicy.getTableIndent());
/*     */   }
/*     */   
/*     */   private String fillStringWithSpaces(int count) {
/* 131 */     char[] chars = new char[count];
/* 132 */     Arrays.fill(chars, ' ');
/*     */     
/* 134 */     return new String(chars);
/*     */   }
/*     */   
/*     */   private WriterContext(String key, String tableIndent, Writer output, IndentationPolicy indentationPolicy, DatePolicy datePolicy) {
/* 138 */     this.key = key;
/* 139 */     this.output = output;
/* 140 */     this.indentationPolicy = indentationPolicy;
/* 141 */     this.currentTableIndent = tableIndent;
/* 142 */     this.datePolicy = datePolicy;
/* 143 */     this.currentFieldIndent = tableIndent + fillStringWithSpaces(this.indentationPolicy.getKeyValueIndent());
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\WriterContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */