/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomlWriter
/*     */ {
/*     */   private final IndentationPolicy indentationPolicy;
/*     */   private final DatePolicy datePolicy;
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private int keyIndentation;
/*     */     private int tableIndentation;
/*  41 */     private int arrayDelimiterPadding = 0;
/*  42 */     private TimeZone timeZone = TimeZone.getTimeZone("UTC");
/*     */     private boolean showFractionalSeconds = false;
/*     */     
/*     */     public Builder indentValuesBy(int spaces) {
/*  46 */       this.keyIndentation = spaces;
/*     */       
/*  48 */       return this;
/*     */     }
/*     */     
/*     */     public Builder indentTablesBy(int spaces) {
/*  52 */       this.tableIndentation = spaces;
/*     */       
/*  54 */       return this;
/*     */     }
/*     */     
/*     */     public Builder timeZone(TimeZone timeZone) {
/*  58 */       this.timeZone = timeZone;
/*     */       
/*  60 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder padArrayDelimitersBy(int spaces) {
/*  68 */       this.arrayDelimiterPadding = spaces;
/*     */       
/*  70 */       return this;
/*     */     }
/*     */     
/*     */     public TomlWriter build() {
/*  74 */       return new TomlWriter(this.keyIndentation, this.tableIndentation, this.arrayDelimiterPadding, this.timeZone, this.showFractionalSeconds);
/*     */     }
/*     */     
/*     */     public Builder showFractionalSeconds() {
/*  78 */       this.showFractionalSeconds = true;
/*  79 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TomlWriter() {
/*  90 */     this(0, 0, 0, TimeZone.getTimeZone("UTC"), false);
/*     */   }
/*     */   
/*     */   private TomlWriter(int keyIndentation, int tableIndentation, int arrayDelimiterPadding, TimeZone timeZone, boolean showFractionalSeconds) {
/*  94 */     this.indentationPolicy = new IndentationPolicy(keyIndentation, tableIndentation, arrayDelimiterPadding);
/*  95 */     this.datePolicy = new DatePolicy(timeZone, showFractionalSeconds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String write(Object from) {
/*     */     try {
/* 106 */       StringWriter output = new StringWriter();
/* 107 */       write(from, output);
/*     */       
/* 109 */       return output.toString();
/* 110 */     } catch (IOException e) {
/* 111 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object from, File target) throws IOException {
/* 123 */     OutputStream outputStream = new FileOutputStream(target);
/*     */     try {
/* 125 */       write(from, outputStream);
/*     */     } finally {
/* 127 */       outputStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object from, OutputStream target) throws IOException {
/* 139 */     OutputStreamWriter writer = new OutputStreamWriter(target, "UTF-8");
/* 140 */     write(from, writer);
/* 141 */     writer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object from, Writer target) throws IOException {
/* 153 */     ValueWriter valueWriter = ValueWriters.WRITERS.findWriterFor(from);
/* 154 */     if (valueWriter == MapValueWriter.MAP_VALUE_WRITER || valueWriter == ObjectValueWriter.OBJECT_VALUE_WRITER) {
/* 155 */       WriterContext context = new WriterContext(this.indentationPolicy, this.datePolicy, target);
/* 156 */       valueWriter.write(from, context);
/*     */     } else {
/* 158 */       throw new IllegalArgumentException("An object of class " + from.getClass().getSimpleName() + " cannot produce valid TOML. Please pass in a Map or a custom type.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\TomlWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */