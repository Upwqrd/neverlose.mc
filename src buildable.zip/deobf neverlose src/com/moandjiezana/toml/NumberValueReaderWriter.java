/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ class NumberValueReaderWriter implements ValueReader, ValueWriter {
/*   6 */   static final NumberValueReaderWriter NUMBER_VALUE_READER_WRITER = new NumberValueReaderWriter();
/*     */ 
/*     */   
/*     */   public boolean canRead(String s) {
/*  10 */     char firstChar = s.charAt(0);
/*     */     
/*  12 */     return (firstChar == '+' || firstChar == '-' || Character.isDigit(firstChar));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object read(String s, AtomicInteger index, Context context) {
/*  17 */     boolean signable = true;
/*  18 */     boolean dottable = false;
/*  19 */     boolean exponentable = false;
/*  20 */     boolean terminatable = false;
/*  21 */     boolean underscorable = false;
/*  22 */     String type = "";
/*  23 */     StringBuilder sb = new StringBuilder();
/*     */     int i;
/*  25 */     for (i = index.get(); i < s.length(); i = index.incrementAndGet()) {
/*  26 */       char c = s.charAt(i);
/*  27 */       boolean notLastChar = (s.length() > i + 1);
/*     */       
/*  29 */       if (Character.isDigit(c)) {
/*  30 */         sb.append(c);
/*  31 */         signable = false;
/*  32 */         terminatable = true;
/*  33 */         if (type.isEmpty()) {
/*  34 */           type = "integer";
/*  35 */           dottable = true;
/*     */         } 
/*  37 */         underscorable = notLastChar;
/*  38 */         exponentable = !type.equals("exponent");
/*  39 */       } else if ((c == '+' || c == '-') && signable && notLastChar) {
/*  40 */         signable = false;
/*  41 */         terminatable = false;
/*  42 */         if (c == '-') {
/*  43 */           sb.append('-');
/*     */         }
/*  45 */       } else if (c == '.' && dottable && notLastChar) {
/*  46 */         sb.append('.');
/*  47 */         type = "float";
/*  48 */         terminatable = false;
/*  49 */         dottable = false;
/*  50 */         exponentable = false;
/*  51 */         underscorable = false;
/*  52 */       } else if ((c == 'E' || c == 'e') && exponentable && notLastChar) {
/*  53 */         sb.append('E');
/*  54 */         type = "exponent";
/*  55 */         terminatable = false;
/*  56 */         signable = true;
/*  57 */         dottable = false;
/*  58 */         exponentable = false;
/*  59 */         underscorable = false;
/*  60 */       } else if (c == '_' && underscorable && notLastChar && Character.isDigit(s.charAt(i + 1))) {
/*  61 */         underscorable = false;
/*     */       } else {
/*  63 */         if (!terminatable) {
/*  64 */           type = "";
/*     */         }
/*  66 */         index.decrementAndGet();
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  71 */     if (type.equals("integer"))
/*  72 */       return Long.valueOf(sb.toString()); 
/*  73 */     if (type.equals("float"))
/*  74 */       return Double.valueOf(sb.toString()); 
/*  75 */     if (type.equals("exponent")) {
/*  76 */       String[] exponentString = sb.toString().split("E");
/*     */       
/*  78 */       return Double.valueOf(Double.parseDouble(exponentString[0]) * Math.pow(10.0D, Double.parseDouble(exponentString[1])));
/*     */     } 
/*  80 */     Results.Errors errors = new Results.Errors();
/*  81 */     errors.invalidValue(context.identifier.getName(), sb.toString(), context.line.get());
/*  82 */     return errors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(Object value) {
/*  88 */     return Number.class.isInstance(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Object value, WriterContext context) {
/*  93 */     context.write(value.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimitiveType() {
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return "number";
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\NumberValueReaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */