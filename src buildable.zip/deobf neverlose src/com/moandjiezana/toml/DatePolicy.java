/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ class DatePolicy
/*    */ {
/*    */   private final TimeZone timeZone;
/*    */   private final boolean showFractionalSeconds;
/*    */   
/*    */   DatePolicy(TimeZone timeZone, boolean showFractionalSeconds) {
/* 11 */     this.timeZone = timeZone;
/* 12 */     this.showFractionalSeconds = showFractionalSeconds;
/*    */   }
/*    */   
/*    */   TimeZone getTimeZone() {
/* 16 */     return this.timeZone;
/*    */   }
/*    */   
/*    */   boolean isShowFractionalSeconds() {
/* 20 */     return this.showFractionalSeconds;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\DatePolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */