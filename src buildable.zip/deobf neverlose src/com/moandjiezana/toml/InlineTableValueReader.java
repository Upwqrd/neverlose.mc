/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ class InlineTableValueReader
/*    */   implements ValueReader
/*    */ {
/* 10 */   static final InlineTableValueReader INLINE_TABLE_VALUE_READER = new InlineTableValueReader();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 14 */     return s.startsWith("{");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger sharedIndex, Context context) {
/* 19 */     AtomicInteger line = context.line;
/* 20 */     int startLine = line.get();
/* 21 */     int startIndex = sharedIndex.get();
/* 22 */     boolean inKey = true;
/* 23 */     boolean inValue = false;
/* 24 */     boolean terminated = false;
/* 25 */     StringBuilder currentKey = new StringBuilder();
/* 26 */     HashMap<String, Object> results = new HashMap<String, Object>();
/* 27 */     Results.Errors errors = new Results.Errors();
/*    */     int i;
/* 29 */     for (i = sharedIndex.incrementAndGet(); sharedIndex.get() < s.length(); i = sharedIndex.incrementAndGet()) {
/* 30 */       char c = s.charAt(i);
/*    */       
/* 32 */       if (inValue && !Character.isWhitespace(c))
/* 33 */       { Object converted = ValueReaders.VALUE_READERS.convert(s, sharedIndex, context.with(Identifier.from(currentKey.toString(), context)));
/*    */         
/* 35 */         if (converted instanceof Results.Errors) {
/* 36 */           errors.add((Results.Errors)converted);
/* 37 */           return errors;
/*    */         } 
/*    */         
/* 40 */         String currentKeyTrimmed = currentKey.toString().trim();
/* 41 */         Object previous = results.put(currentKeyTrimmed, converted);
/*    */         
/* 43 */         if (previous != null) {
/* 44 */           errors.duplicateKey(currentKeyTrimmed, context.line.get());
/* 45 */           return errors;
/*    */         } 
/*    */         
/* 48 */         currentKey = new StringBuilder();
/* 49 */         inValue = false; }
/* 50 */       else if (c == ',')
/* 51 */       { inKey = true;
/* 52 */         inValue = false;
/* 53 */         currentKey = new StringBuilder(); }
/* 54 */       else if (c == '=')
/* 55 */       { inKey = false;
/* 56 */         inValue = true; }
/* 57 */       else { if (c == '}') {
/* 58 */           terminated = true; break;
/*    */         } 
/* 60 */         if (inKey) {
/* 61 */           currentKey.append(c);
/*    */         } }
/*    */     
/*    */     } 
/* 65 */     if (!terminated) {
/* 66 */       errors.unterminated(context.identifier.getName(), s.substring(startIndex), startLine);
/*    */     }
/*    */     
/* 69 */     if (errors.hasErrors()) {
/* 70 */       return errors;
/*    */     }
/*    */     
/* 73 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\InlineTableValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */