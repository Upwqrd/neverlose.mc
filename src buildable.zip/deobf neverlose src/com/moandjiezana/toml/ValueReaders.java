/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValueReaders
/*    */ {
/* 17 */   static final ValueReaders VALUE_READERS = new ValueReaders();
/*    */   
/*    */   Object convert(String value, AtomicInteger index, Context context) {
/* 20 */     String substring = value.substring(index.get());
/* 21 */     for (ValueReader valueParser : READERS) {
/* 22 */       if (valueParser.canRead(substring)) {
/* 23 */         return valueParser.read(value, index, context);
/*    */       }
/*    */     } 
/*    */     
/* 27 */     Results.Errors errors = new Results.Errors();
/* 28 */     errors.invalidValue(context.identifier.getName(), substring, context.line.get());
/* 29 */     return errors;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 34 */   private static final ValueReader[] READERS = new ValueReader[] { MultilineStringValueReader.MULTILINE_STRING_VALUE_READER, MultilineLiteralStringValueReader.MULTILINE_LITERAL_STRING_VALUE_READER, LiteralStringValueReader.LITERAL_STRING_VALUE_READER, StringValueReaderWriter.STRING_VALUE_READER_WRITER, DateValueReaderWriter.DATE_VALUE_READER_WRITER, NumberValueReaderWriter.NUMBER_VALUE_READER_WRITER, BooleanValueReaderWriter.BOOLEAN_VALUE_READER_WRITER, ArrayValueReader.ARRAY_VALUE_READER, InlineTableValueReader.INLINE_TABLE_VALUE_READER };
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ValueReaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */