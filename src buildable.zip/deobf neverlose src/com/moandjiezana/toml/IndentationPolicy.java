/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IndentationPolicy
/*    */ {
/*    */   private final int tableIndent;
/*    */   private final int keyValueIndent;
/*    */   private final int arrayDelimiterPadding;
/*    */   
/*    */   IndentationPolicy(int keyIndentation, int tableIndentation, int arrayDelimiterPadding) {
/* 14 */     this.keyValueIndent = keyIndentation;
/* 15 */     this.tableIndent = tableIndentation;
/* 16 */     this.arrayDelimiterPadding = arrayDelimiterPadding;
/*    */   }
/*    */   
/*    */   int getTableIndent() {
/* 20 */     return this.tableIndent;
/*    */   }
/*    */   
/*    */   int getKeyValueIndent() {
/* 24 */     return this.keyValueIndent;
/*    */   }
/*    */   
/*    */   int getArrayDelimiterPadding() {
/* 28 */     return this.arrayDelimiterPadding;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\IndentationPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */