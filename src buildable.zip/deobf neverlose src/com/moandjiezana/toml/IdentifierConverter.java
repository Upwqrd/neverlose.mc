/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class IdentifierConverter
/*    */ {
/*  7 */   static final IdentifierConverter IDENTIFIER_CONVERTER = new IdentifierConverter();
/*    */   
/*    */   Identifier convert(String s, AtomicInteger index, Context context) {
/* 10 */     boolean quoted = false;
/* 11 */     StringBuilder name = new StringBuilder();
/* 12 */     boolean terminated = false;
/* 13 */     boolean isKey = (s.charAt(index.get()) != '[');
/* 14 */     boolean isTableArray = (!isKey && s.length() > index.get() + 1 && s.charAt(index.get() + 1) == '[');
/* 15 */     boolean inComment = false;
/*    */     int i;
/* 17 */     for (i = index.get(); i < s.length(); i = index.incrementAndGet()) {
/* 18 */       char c = s.charAt(i);
/* 19 */       if (Keys.isQuote(c) && (i == 0 || s.charAt(i - 1) != '\\'))
/* 20 */       { quoted = !quoted;
/* 21 */         name.append(c); }
/* 22 */       else { if (c == '\n') {
/* 23 */           index.decrementAndGet(); break;
/*    */         } 
/* 25 */         if (quoted)
/* 26 */         { name.append(c); }
/* 27 */         else { if (c == '=' && isKey) {
/* 28 */             terminated = true; break;
/*    */           } 
/* 30 */           if (c == ']' && !isKey)
/* 31 */           { if (!isTableArray || (s.length() > index.get() + 1 && s.charAt(index.get() + 1) == ']')) {
/* 32 */               terminated = true;
/* 33 */               name.append(']');
/* 34 */               if (isTableArray) {
/* 35 */                 name.append(']');
/*    */               }
/*    */             }  }
/* 38 */           else if (terminated && c == '#')
/* 39 */           { inComment = true; }
/* 40 */           else { if (terminated && !Character.isWhitespace(c) && !inComment) {
/* 41 */               terminated = false; break;
/*    */             } 
/* 43 */             if (!terminated)
/* 44 */               name.append(c);  }
/*    */            }
/*    */          }
/*    */     
/* 48 */     }  if (!terminated) {
/* 49 */       if (isKey) {
/* 50 */         context.errors.unterminatedKey(name.toString(), context.line.get());
/*    */       } else {
/* 52 */         context.errors.invalidKey(name.toString(), context.line.get());
/*    */       } 
/*    */       
/* 55 */       return Identifier.INVALID;
/*    */     } 
/*    */     
/* 58 */     return Identifier.from(name.toString(), context);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\IdentifierConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */