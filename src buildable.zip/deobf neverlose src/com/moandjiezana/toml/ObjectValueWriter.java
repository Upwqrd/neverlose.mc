/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ class ObjectValueWriter
/*    */   implements ValueWriter
/*    */ {
/* 15 */   static final ValueWriter OBJECT_VALUE_WRITER = new ObjectValueWriter();
/*    */ 
/*    */   
/*    */   public boolean canWrite(Object value) {
/* 19 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object value, WriterContext context) {
/* 24 */     Map<String, Object> to = new LinkedHashMap<String, Object>();
/* 25 */     Set<Field> fields = getFields(value.getClass());
/* 26 */     for (Field field : fields) {
/* 27 */       to.put(field.getName(), getFieldValue(field, value));
/*    */     }
/*    */     
/* 30 */     MapValueWriter.MAP_VALUE_WRITER.write(to, context);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPrimitiveType() {
/* 35 */     return false;
/*    */   }
/*    */   
/*    */   private static Set<Field> getFields(Class<?> cls) {
/* 39 */     Set<Field> fields = new LinkedHashSet<Field>(Arrays.asList(cls.getDeclaredFields()));
/* 40 */     while (cls != Object.class) {
/* 41 */       fields.addAll(Arrays.asList(cls.getDeclaredFields()));
/* 42 */       cls = cls.getSuperclass();
/*    */     } 
/* 44 */     removeConstantsAndSyntheticFields(fields);
/*    */     
/* 46 */     return fields;
/*    */   }
/*    */   
/*    */   private static void removeConstantsAndSyntheticFields(Set<Field> fields) {
/* 50 */     Iterator<Field> iterator = fields.iterator();
/* 51 */     while (iterator.hasNext()) {
/* 52 */       Field field = iterator.next();
/* 53 */       if ((Modifier.isFinal(field.getModifiers()) && Modifier.isStatic(field.getModifiers())) || field.isSynthetic() || Modifier.isTransient(field.getModifiers())) {
/* 54 */         iterator.remove();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private static Object getFieldValue(Field field, Object o) {
/* 60 */     boolean isAccessible = field.isAccessible();
/* 61 */     field.setAccessible(true);
/* 62 */     Object value = null;
/*    */     try {
/* 64 */       value = field.get(o);
/* 65 */     } catch (IllegalAccessException illegalAccessException) {}
/*    */     
/* 67 */     field.setAccessible(isAccessible);
/*    */     
/* 69 */     return value;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ObjectValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */