/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ class StringValueReaderWriter
/*     */   implements ValueReader, ValueWriter
/*     */ {
/*  11 */   static final StringValueReaderWriter STRING_VALUE_READER_WRITER = new StringValueReaderWriter();
/*  12 */   private static final Pattern UNICODE_REGEX = Pattern.compile("\\\\[uU](.{4})");
/*     */   
/*  14 */   private static final String[] specialCharacterEscapes = new String[93];
/*     */   
/*     */   static {
/*  17 */     specialCharacterEscapes[8] = "\\b";
/*  18 */     specialCharacterEscapes[9] = "\\t";
/*  19 */     specialCharacterEscapes[10] = "\\n";
/*  20 */     specialCharacterEscapes[12] = "\\f";
/*  21 */     specialCharacterEscapes[13] = "\\r";
/*  22 */     specialCharacterEscapes[34] = "\\\"";
/*  23 */     specialCharacterEscapes[92] = "\\\\";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(String s) {
/*  28 */     return s.startsWith("\"");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object read(String s, AtomicInteger index, Context context) {
/*  33 */     int startIndex = index.incrementAndGet();
/*  34 */     int endIndex = -1;
/*     */     int i;
/*  36 */     for (i = index.get(); i < s.length(); i = index.incrementAndGet()) {
/*  37 */       char ch = s.charAt(i);
/*  38 */       if (ch == '"' && s.charAt(i - 1) != '\\') {
/*  39 */         endIndex = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  44 */     if (endIndex == -1) {
/*  45 */       Results.Errors errors = new Results.Errors();
/*  46 */       errors.unterminated(context.identifier.getName(), s.substring(startIndex - 1), context.line.get());
/*  47 */       return errors;
/*     */     } 
/*     */     
/*  50 */     String raw = s.substring(startIndex, endIndex);
/*  51 */     s = replaceUnicodeCharacters(raw);
/*  52 */     s = replaceSpecialCharacters(s);
/*     */     
/*  54 */     if (s == null) {
/*  55 */       Results.Errors errors = new Results.Errors();
/*  56 */       errors.invalidValue(context.identifier.getName(), raw, context.line.get());
/*  57 */       return errors;
/*     */     } 
/*     */     
/*  60 */     return s;
/*     */   }
/*     */   
/*     */   String replaceUnicodeCharacters(String value) {
/*  64 */     Matcher unicodeMatcher = UNICODE_REGEX.matcher(value);
/*     */     
/*  66 */     while (unicodeMatcher.find()) {
/*  67 */       value = value.replace(unicodeMatcher.group(), new String(Character.toChars(Integer.parseInt(unicodeMatcher.group(1), 16))));
/*     */     }
/*  69 */     return value;
/*     */   }
/*     */   
/*     */   String replaceSpecialCharacters(String s) {
/*  73 */     for (int i = 0; i < s.length() - 1; i++) {
/*  74 */       char ch = s.charAt(i);
/*  75 */       char next = s.charAt(i + 1);
/*     */       
/*  77 */       if (ch == '\\' && next == '\\') {
/*  78 */         i++;
/*  79 */       } else if (ch == '\\' && next != 'b' && next != 'f' && next != 'n' && next != 't' && next != 'r' && next != '"' && next != '\\') {
/*  80 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     return s.replace("\\n", "\n")
/*  85 */       .replace("\\\"", "\"")
/*  86 */       .replace("\\t", "\t")
/*  87 */       .replace("\\r", "\r")
/*  88 */       .replace("\\\\", "\\")
/*  89 */       .replace("\\/", "/")
/*  90 */       .replace("\\b", "\b")
/*  91 */       .replace("\\f", "\f");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Object value) {
/*  96 */     return (value instanceof String || value instanceof Character || value instanceof java.net.URL || value instanceof java.net.URI || value instanceof Enum);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Object value, WriterContext context) {
/* 101 */     context.write('"');
/* 102 */     escapeUnicode(value.toString(), context);
/* 103 */     context.write('"');
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimitiveType() {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   private void escapeUnicode(String in, WriterContext context) {
/* 112 */     for (int i = 0; i < in.length(); i++) {
/* 113 */       int codePoint = in.codePointAt(i);
/* 114 */       if (codePoint < specialCharacterEscapes.length && specialCharacterEscapes[codePoint] != null) {
/* 115 */         context.write(specialCharacterEscapes[codePoint]);
/*     */       } else {
/* 117 */         context.write(in.charAt(i));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return "string";
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\StringValueReaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */