/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ class Keys
/*    */ {
/*    */   static class Key {
/*    */     final String name;
/*    */     final int index;
/*    */     final String path;
/*    */     
/*    */     Key(String name, int index, Key next) {
/* 14 */       this.name = name;
/* 15 */       this.index = index;
/* 16 */       if (next != null) {
/* 17 */         this.path = name + "." + next.path;
/*    */       } else {
/* 19 */         this.path = name;
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   static Key[] split(String key) {
/* 25 */     List<Key> splitKey = new ArrayList<Key>();
/* 26 */     StringBuilder current = new StringBuilder();
/* 27 */     boolean quoted = false;
/* 28 */     boolean indexable = true;
/* 29 */     boolean inIndex = false;
/* 30 */     int index = -1;
/*    */     
/* 32 */     for (int i = key.length() - 1; i > -1; i--) {
/* 33 */       char c = key.charAt(i);
/* 34 */       if (c == ']' && indexable) {
/* 35 */         inIndex = true;
/*    */       } else {
/*    */         
/* 38 */         indexable = false;
/* 39 */         if (c == '[' && inIndex) {
/* 40 */           inIndex = false;
/* 41 */           index = Integer.parseInt(current.toString());
/* 42 */           current = new StringBuilder();
/*    */         } else {
/*    */           
/* 45 */           if (isQuote(c) && (i == 0 || key.charAt(i - 1) != '\\')) {
/* 46 */             quoted = !quoted;
/* 47 */             indexable = false;
/*    */           } 
/* 49 */           if (c != '.' || quoted) {
/* 50 */             current.insert(0, c);
/*    */           } else {
/* 52 */             splitKey.add(0, new Key(current.toString(), index, !splitKey.isEmpty() ? splitKey.get(0) : null));
/* 53 */             indexable = true;
/* 54 */             index = -1;
/* 55 */             current = new StringBuilder();
/*    */           } 
/*    */         } 
/*    */       } 
/* 59 */     }  splitKey.add(0, new Key(current.toString(), index, !splitKey.isEmpty() ? splitKey.get(0) : null));
/*    */     
/* 61 */     return splitKey.<Key>toArray(new Key[0]);
/*    */   }
/*    */   
/*    */   static boolean isQuote(char c) {
/* 65 */     return (c == '"' || c == '\'');
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Keys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */