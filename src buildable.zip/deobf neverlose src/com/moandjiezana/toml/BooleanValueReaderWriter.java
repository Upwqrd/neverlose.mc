/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class BooleanValueReaderWriter
/*    */   implements ValueReader, ValueWriter
/*    */ {
/*  8 */   static final BooleanValueReaderWriter BOOLEAN_VALUE_READER_WRITER = new BooleanValueReaderWriter();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 12 */     return (s.startsWith("true") || s.startsWith("false"));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger index, Context context) {
/* 17 */     s = s.substring(index.get());
/* 18 */     Boolean b = s.startsWith("true") ? Boolean.TRUE : Boolean.FALSE;
/*    */     
/* 20 */     int endIndex = (b == Boolean.TRUE) ? 4 : 5;
/*    */     
/* 22 */     index.addAndGet(endIndex - 1);
/*    */     
/* 24 */     return b;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canWrite(Object value) {
/* 29 */     return Boolean.class.isInstance(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object value, WriterContext context) {
/* 34 */     context.write(value.toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPrimitiveType() {
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return "boolean";
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\BooleanValueReaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */