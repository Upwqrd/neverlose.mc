/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class MultilineStringValueReader
/*    */   implements ValueReader {
/*  7 */   static final MultilineStringValueReader MULTILINE_STRING_VALUE_READER = new MultilineStringValueReader();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 11 */     return s.startsWith("\"\"\"");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger index, Context context) {
/* 16 */     AtomicInteger line = context.line;
/* 17 */     int startLine = line.get();
/* 18 */     int originalStartIndex = index.get();
/* 19 */     int startIndex = index.addAndGet(3);
/* 20 */     int endIndex = -1;
/*    */     
/* 22 */     if (s.charAt(startIndex) == '\n') {
/* 23 */       startIndex = index.incrementAndGet();
/* 24 */       line.incrementAndGet();
/*    */     } 
/*    */     int i;
/* 27 */     for (i = startIndex; i < s.length(); i = index.incrementAndGet()) {
/* 28 */       char c = s.charAt(i);
/*    */       
/* 30 */       if (c == '\n') {
/* 31 */         line.incrementAndGet();
/* 32 */       } else if (c == '"' && s.length() > i + 2 && s.charAt(i + 1) == '"' && s.charAt(i + 2) == '"') {
/* 33 */         endIndex = i;
/* 34 */         index.addAndGet(2);
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 39 */     if (endIndex == -1) {
/* 40 */       Results.Errors errors = new Results.Errors();
/* 41 */       errors.unterminated(context.identifier.getName(), s.substring(originalStartIndex), startLine);
/* 42 */       return errors;
/*    */     } 
/*    */     
/* 45 */     s = s.substring(startIndex, endIndex);
/* 46 */     s = s.replaceAll("\\\\\\s+", "");
/* 47 */     s = StringValueReaderWriter.STRING_VALUE_READER_WRITER.replaceUnicodeCharacters(s);
/* 48 */     s = StringValueReaderWriter.STRING_VALUE_READER_WRITER.replaceSpecialCharacters(s);
/*    */     
/* 50 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\MultilineStringValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */