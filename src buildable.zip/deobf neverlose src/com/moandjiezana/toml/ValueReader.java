package com.moandjiezana.toml;

import java.util.concurrent.atomic.AtomicInteger;

interface ValueReader {
  boolean canRead(String paramString);
  
  Object read(String paramString, AtomicInteger paramAtomicInteger, Context paramContext);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */