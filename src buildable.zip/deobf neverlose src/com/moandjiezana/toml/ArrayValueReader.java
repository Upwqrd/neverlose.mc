/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ class ArrayValueReader
/*    */   implements ValueReader
/*    */ {
/* 11 */   static final ArrayValueReader ARRAY_VALUE_READER = new ArrayValueReader();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 15 */     return s.startsWith("[");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger index, Context context) {
/* 20 */     AtomicInteger line = context.line;
/* 21 */     int startLine = line.get();
/* 22 */     int startIndex = index.get();
/* 23 */     List<Object> arrayItems = new ArrayList();
/* 24 */     boolean terminated = false;
/* 25 */     boolean inComment = false;
/* 26 */     Results.Errors errors = new Results.Errors();
/*    */     int i;
/* 28 */     for (i = index.incrementAndGet(); i < s.length(); i = index.incrementAndGet()) {
/*    */       
/* 30 */       char c = s.charAt(i);
/*    */       
/* 32 */       if (c == '#' && !inComment) {
/* 33 */         inComment = true;
/* 34 */       } else if (c == '\n') {
/* 35 */         inComment = false;
/* 36 */         line.incrementAndGet();
/* 37 */       } else if (!inComment && !Character.isWhitespace(c) && c != ',') {
/*    */         
/* 39 */         if (c == '[') {
/* 40 */           Object converted = read(s, index, context);
/* 41 */           if (converted instanceof Results.Errors) {
/* 42 */             errors.add((Results.Errors)converted);
/* 43 */           } else if (!isHomogenousArray(converted, arrayItems)) {
/* 44 */             errors.heterogenous(context.identifier.getName(), line.get());
/*    */           } else {
/* 46 */             arrayItems.add(converted);
/*    */           } 
/*    */         } else {
/* 49 */           if (c == ']') {
/* 50 */             terminated = true;
/*    */             break;
/*    */           } 
/* 53 */           Object converted = ValueReaders.VALUE_READERS.convert(s, index, context);
/* 54 */           if (converted instanceof Results.Errors) {
/* 55 */             errors.add((Results.Errors)converted);
/* 56 */           } else if (!isHomogenousArray(converted, arrayItems)) {
/* 57 */             errors.heterogenous(context.identifier.getName(), line.get());
/*    */           } else {
/* 59 */             arrayItems.add(converted);
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 64 */     if (!terminated) {
/* 65 */       errors.unterminated(context.identifier.getName(), s.substring(startIndex, s.length()), startLine);
/*    */     }
/*    */     
/* 68 */     if (errors.hasErrors()) {
/* 69 */       return errors;
/*    */     }
/*    */     
/* 72 */     return arrayItems;
/*    */   }
/*    */   
/*    */   private boolean isHomogenousArray(Object o, List<?> values) {
/* 76 */     return (values.isEmpty() || values.get(0).getClass().isAssignableFrom(o.getClass()) || o.getClass().isAssignableFrom(values.get(0).getClass()));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ArrayValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */