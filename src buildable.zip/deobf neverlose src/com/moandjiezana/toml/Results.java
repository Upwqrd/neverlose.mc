/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ class Results
/*     */ {
/*     */   static class Errors
/*     */   {
/*  15 */     private final StringBuilder sb = new StringBuilder();
/*     */     
/*     */     void duplicateTable(String table, int line) {
/*  18 */       this.sb.append("Duplicate table definition on line ")
/*  19 */         .append(line)
/*  20 */         .append(": [")
/*  21 */         .append(table)
/*  22 */         .append("]");
/*     */     }
/*     */     
/*     */     public void tableDuplicatesKey(String table, AtomicInteger line) {
/*  26 */       this.sb.append("Key already exists for table defined on line ")
/*  27 */         .append(line.get())
/*  28 */         .append(": [")
/*  29 */         .append(table)
/*  30 */         .append("]");
/*     */     }
/*     */     
/*     */     public void keyDuplicatesTable(String key, AtomicInteger line) {
/*  34 */       this.sb.append("Table already exists for key defined on line ")
/*  35 */         .append(line.get())
/*  36 */         .append(": ")
/*  37 */         .append(key);
/*     */     }
/*     */     
/*     */     void emptyImplicitTable(String table, int line) {
/*  41 */       this.sb.append("Invalid table definition due to empty implicit table name: ")
/*  42 */         .append(table);
/*     */     }
/*     */     
/*     */     void invalidTable(String table, int line) {
/*  46 */       this.sb.append("Invalid table definition on line ")
/*  47 */         .append(line)
/*  48 */         .append(": ")
/*  49 */         .append(table)
/*  50 */         .append("]");
/*     */     }
/*     */     
/*     */     void duplicateKey(String key, int line) {
/*  54 */       this.sb.append("Duplicate key");
/*  55 */       if (line > -1) {
/*  56 */         this.sb.append(" on line ")
/*  57 */           .append(line);
/*     */       }
/*  59 */       this.sb.append(": ")
/*  60 */         .append(key);
/*     */     }
/*     */     
/*     */     void invalidTextAfterIdentifier(Identifier identifier, char text, int line) {
/*  64 */       this.sb.append("Invalid text after key ")
/*  65 */         .append(identifier.getName())
/*  66 */         .append(" on line ")
/*  67 */         .append(line)
/*  68 */         .append(". Make sure to terminate the value or add a comment (#).");
/*     */     }
/*     */     
/*     */     void invalidKey(String key, int line) {
/*  72 */       this.sb.append("Invalid key on line ")
/*  73 */         .append(line)
/*  74 */         .append(": ")
/*  75 */         .append(key);
/*     */     }
/*     */     
/*     */     void invalidTableArray(String tableArray, int line) {
/*  79 */       this.sb.append("Invalid table array definition on line ")
/*  80 */         .append(line)
/*  81 */         .append(": ")
/*  82 */         .append(tableArray);
/*     */     }
/*     */     
/*     */     void invalidValue(String key, String value, int line) {
/*  86 */       this.sb.append("Invalid value on line ")
/*  87 */         .append(line)
/*  88 */         .append(": ")
/*  89 */         .append(key)
/*  90 */         .append(" = ")
/*  91 */         .append(value);
/*     */     }
/*     */     
/*     */     void unterminatedKey(String key, int line) {
/*  95 */       this.sb.append("Key is not followed by an equals sign on line ")
/*  96 */         .append(line)
/*  97 */         .append(": ")
/*  98 */         .append(key);
/*     */     }
/*     */     
/*     */     void unterminated(String key, String value, int line) {
/* 102 */       this.sb.append("Unterminated value on line ")
/* 103 */         .append(line)
/* 104 */         .append(": ")
/* 105 */         .append(key)
/* 106 */         .append(" = ")
/* 107 */         .append(value.trim());
/*     */     }
/*     */     
/*     */     public void heterogenous(String key, int line) {
/* 111 */       this.sb.append(key)
/* 112 */         .append(" becomes a heterogeneous array on line ")
/* 113 */         .append(line);
/*     */     }
/*     */     
/*     */     boolean hasErrors() {
/* 117 */       return (this.sb.length() > 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 122 */       return this.sb.toString();
/*     */     }
/*     */     
/*     */     public void add(Errors other) {
/* 126 */       this.sb.append(other.sb);
/*     */     }
/*     */   }
/*     */   
/* 130 */   final Errors errors = new Errors();
/* 131 */   private final Set<String> tables = new HashSet<String>();
/* 132 */   private final Deque<Container> stack = new ArrayDeque<Container>();
/*     */   
/*     */   Results() {
/* 135 */     this.stack.push(new Container.Table(""));
/*     */   }
/*     */   
/*     */   void addValue(String key, Object value, AtomicInteger line) {
/* 139 */     Container currentTable = this.stack.peek();
/*     */     
/* 141 */     if (value instanceof Map) {
/* 142 */       String path = getInlineTablePath(key);
/* 143 */       if (path == null) {
/* 144 */         startTable(key, line);
/* 145 */       } else if (path.isEmpty()) {
/* 146 */         startTables(Identifier.from(key, null), line);
/*     */       } else {
/* 148 */         startTables(Identifier.from(path, null), line);
/*     */       } 
/*     */       
/* 151 */       Map<String, Object> valueMap = (Map<String, Object>)value;
/* 152 */       for (Map.Entry<String, Object> entry : valueMap.entrySet()) {
/* 153 */         addValue(entry.getKey(), entry.getValue(), line);
/*     */       }
/* 155 */       this.stack.pop();
/* 156 */     } else if (currentTable.accepts(key)) {
/* 157 */       currentTable.put(key, value);
/*     */     }
/* 159 */     else if (currentTable.get(key) instanceof Container) {
/* 160 */       this.errors.keyDuplicatesTable(key, line);
/*     */     } else {
/* 162 */       this.errors.duplicateKey(key, (line != null) ? line.get() : -1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void startTableArray(Identifier identifier, AtomicInteger line) {
/* 168 */     String tableName = identifier.getBareName();
/* 169 */     while (this.stack.size() > 1) {
/* 170 */       this.stack.pop();
/*     */     }
/*     */     
/* 173 */     Keys.Key[] tableParts = Keys.split(tableName);
/* 174 */     for (int i = 0; i < tableParts.length; i++) {
/* 175 */       String tablePart = (tableParts[i]).name;
/* 176 */       Container currentContainer = this.stack.peek();
/*     */       
/* 178 */       if (currentContainer.get(tablePart) instanceof Container.TableArray) {
/* 179 */         Container.TableArray currentTableArray = (Container.TableArray)currentContainer.get(tablePart);
/* 180 */         this.stack.push(currentTableArray);
/*     */         
/* 182 */         if (i == tableParts.length - 1) {
/* 183 */           currentTableArray.put(tablePart, new Container.Table());
/*     */         }
/*     */         
/* 186 */         this.stack.push(currentTableArray.getCurrent());
/* 187 */         currentContainer = this.stack.peek();
/* 188 */       } else if (currentContainer.get(tablePart) instanceof Container.Table && i < tableParts.length - 1) {
/* 189 */         Container nextTable = (Container)currentContainer.get(tablePart);
/* 190 */         this.stack.push(nextTable);
/* 191 */       } else if (currentContainer.accepts(tablePart)) {
/* 192 */         Container newContainer = (i == tableParts.length - 1) ? new Container.TableArray() : new Container.Table();
/* 193 */         addValue(tablePart, newContainer, line);
/* 194 */         this.stack.push(newContainer);
/*     */         
/* 196 */         if (newContainer instanceof Container.TableArray) {
/* 197 */           this.stack.push(((Container.TableArray)newContainer).getCurrent());
/*     */         }
/*     */       } else {
/* 200 */         this.errors.duplicateTable(tableName, line.get());
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void startTables(Identifier id, AtomicInteger line) {
/* 207 */     String tableName = id.getBareName();
/*     */     
/* 209 */     while (this.stack.size() > 1) {
/* 210 */       this.stack.pop();
/*     */     }
/*     */     
/* 213 */     Keys.Key[] tableParts = Keys.split(tableName);
/* 214 */     for (int i = 0; i < tableParts.length; i++) {
/* 215 */       String tablePart = (tableParts[i]).name;
/* 216 */       Container currentContainer = this.stack.peek();
/* 217 */       if (currentContainer.get(tablePart) instanceof Container) {
/* 218 */         Container nextTable = (Container)currentContainer.get(tablePart);
/* 219 */         if (i == tableParts.length - 1 && !nextTable.isImplicit()) {
/* 220 */           this.errors.duplicateTable(tableName, line.get());
/*     */           return;
/*     */         } 
/* 223 */         this.stack.push(nextTable);
/* 224 */         if (this.stack.peek() instanceof Container.TableArray) {
/* 225 */           this.stack.push(((Container.TableArray)this.stack.peek()).getCurrent());
/*     */         }
/* 227 */       } else if (currentContainer.accepts(tablePart)) {
/* 228 */         startTable(tablePart, (i < tableParts.length - 1), line);
/*     */       } else {
/* 230 */         this.errors.tableDuplicatesKey(tablePart, line);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, Object> consume() {
/* 240 */     Container values = this.stack.getLast();
/* 241 */     this.stack.clear();
/*     */     
/* 243 */     return ((Container.Table)values).consume();
/*     */   }
/*     */   
/*     */   private Container startTable(String tableName, AtomicInteger line) {
/* 247 */     Container newTable = new Container.Table(tableName);
/* 248 */     addValue(tableName, newTable, line);
/* 249 */     this.stack.push(newTable);
/*     */     
/* 251 */     return newTable;
/*     */   }
/*     */   
/*     */   private Container startTable(String tableName, boolean implicit, AtomicInteger line) {
/* 255 */     Container newTable = new Container.Table(tableName, implicit);
/* 256 */     addValue(tableName, newTable, line);
/* 257 */     this.stack.push(newTable);
/*     */     
/* 259 */     return newTable;
/*     */   }
/*     */   
/*     */   private String getInlineTablePath(String key) {
/* 263 */     Iterator<Container> descendingIterator = this.stack.descendingIterator();
/* 264 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 266 */     while (descendingIterator.hasNext()) {
/* 267 */       Container next = descendingIterator.next();
/* 268 */       if (next instanceof Container.TableArray) {
/* 269 */         return null;
/*     */       }
/*     */       
/* 272 */       Container.Table table = (Container.Table)next;
/*     */       
/* 274 */       if (table.name == null) {
/*     */         break;
/*     */       }
/*     */       
/* 278 */       if (sb.length() > 0) {
/* 279 */         sb.append('.');
/*     */       }
/*     */       
/* 282 */       sb.append(table.name);
/*     */     } 
/*     */     
/* 285 */     if (sb.length() > 0) {
/* 286 */       sb.append('.');
/*     */     }
/*     */     
/* 289 */     sb.append(key)
/* 290 */       .insert(0, '[')
/* 291 */       .append(']');
/*     */     
/* 293 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Results.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */