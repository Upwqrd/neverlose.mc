/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ class Identifier
/*     */ {
/*   5 */   static final Identifier INVALID = new Identifier("", null);
/*     */   
/*     */   private static final String ALLOWED_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_-";
/*     */   
/*     */   private final String name;
/*     */   private final Type type;
/*     */   
/*     */   static Identifier from(String name, Context context) {
/*     */     Type type;
/*     */     boolean valid;
/*  15 */     name = name.trim();
/*  16 */     if (name.startsWith("[[")) {
/*  17 */       type = Type.TABLE_ARRAY;
/*  18 */       valid = isValidTableArray(name, context);
/*  19 */     } else if (name.startsWith("[")) {
/*  20 */       type = Type.TABLE;
/*  21 */       valid = isValidTable(name, context);
/*     */     } else {
/*  23 */       type = Type.KEY;
/*  24 */       valid = isValidKey(name, context);
/*     */     } 
/*     */     
/*  27 */     if (!valid) {
/*  28 */       return INVALID;
/*     */     }
/*     */     
/*  31 */     return new Identifier(extractName(name), type);
/*     */   }
/*     */   
/*     */   private Identifier(String name, Type type) {
/*  35 */     this.name = name;
/*  36 */     this.type = type;
/*     */   }
/*     */   
/*     */   String getName() {
/*  40 */     return this.name;
/*     */   }
/*     */   
/*     */   String getBareName() {
/*  44 */     if (isKey()) {
/*  45 */       return this.name;
/*     */     }
/*     */     
/*  48 */     if (isTable()) {
/*  49 */       return this.name.substring(1, this.name.length() - 1);
/*     */     }
/*     */     
/*  52 */     return this.name.substring(2, this.name.length() - 2);
/*     */   }
/*     */   
/*     */   boolean isKey() {
/*  56 */     return (this.type == Type.KEY);
/*     */   }
/*     */   
/*     */   boolean isTable() {
/*  60 */     return (this.type == Type.TABLE);
/*     */   }
/*     */   
/*     */   boolean isTableArray() {
/*  64 */     return (this.type == Type.TABLE_ARRAY);
/*     */   }
/*     */   
/*     */   private enum Type {
/*  68 */     KEY, TABLE, TABLE_ARRAY;
/*     */   }
/*     */   
/*     */   private static String extractName(String raw) {
/*  72 */     boolean quoted = false;
/*  73 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  75 */     for (int i = 0; i < raw.length(); i++) {
/*  76 */       char c = raw.charAt(i);
/*  77 */       if (c == '"' && (i == 0 || raw.charAt(i - 1) != '\\')) {
/*  78 */         quoted = !quoted;
/*  79 */         sb.append('"');
/*  80 */       } else if (quoted || !Character.isWhitespace(c)) {
/*  81 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     return StringValueReaderWriter.STRING_VALUE_READER_WRITER.replaceUnicodeCharacters(sb.toString());
/*     */   }
/*     */   
/*     */   private static boolean isValidKey(String name, Context context) {
/*  89 */     if (name.trim().isEmpty()) {
/*  90 */       context.errors.invalidKey(name, context.line.get());
/*  91 */       return false;
/*     */     } 
/*     */     
/*  94 */     boolean quoted = false;
/*  95 */     for (int i = 0; i < name.length(); i++) {
/*  96 */       char c = name.charAt(i);
/*     */       
/*  98 */       if (c == '"' && (i == 0 || name.charAt(i - 1) != '\\')) {
/*  99 */         if (!quoted && i > 0 && name.charAt(i - 1) != '.') {
/* 100 */           context.errors.invalidKey(name, context.line.get());
/* 101 */           return false;
/*     */         } 
/* 103 */         quoted = !quoted;
/* 104 */       } else if (!quoted && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_-".indexOf(c) == -1) {
/* 105 */         context.errors.invalidKey(name, context.line.get());
/* 106 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isValidTable(String name, Context context) {
/* 114 */     boolean valid = true;
/*     */     
/* 116 */     if (!name.endsWith("]")) {
/* 117 */       valid = false;
/*     */     }
/*     */     
/* 120 */     String trimmed = name.substring(1, name.length() - 1).trim();
/* 121 */     if (trimmed.isEmpty() || trimmed.charAt(0) == '.' || trimmed.endsWith(".")) {
/* 122 */       valid = false;
/*     */     }
/*     */     
/* 125 */     if (!valid) {
/* 126 */       context.errors.invalidTable(name, context.line.get());
/* 127 */       return false;
/*     */     } 
/*     */     
/* 130 */     boolean quoted = false;
/* 131 */     boolean dotAllowed = false;
/* 132 */     boolean quoteAllowed = true;
/* 133 */     boolean charAllowed = true;
/*     */     
/* 135 */     for (int i = 0; i < trimmed.length(); i++) {
/* 136 */       char c = trimmed.charAt(i);
/*     */       
/* 138 */       if (!valid) {
/*     */         break;
/*     */       }
/*     */       
/* 142 */       if (Keys.isQuote(c)) {
/* 143 */         if (!quoteAllowed) {
/* 144 */           valid = false;
/* 145 */         } else if (quoted && trimmed.charAt(i - 1) != '\\') {
/* 146 */           charAllowed = false;
/* 147 */           dotAllowed = true;
/* 148 */           quoteAllowed = false;
/* 149 */         } else if (!quoted) {
/* 150 */           quoted = true;
/* 151 */           quoteAllowed = true;
/*     */         } 
/* 153 */       } else if (!quoted) {
/*     */         
/* 155 */         if (c == '.') {
/* 156 */           if (dotAllowed) {
/* 157 */             charAllowed = true;
/* 158 */             dotAllowed = false;
/* 159 */             quoteAllowed = true;
/*     */           } else {
/* 161 */             context.errors.emptyImplicitTable(name, context.line.get());
/* 162 */             return false;
/*     */           } 
/* 164 */         } else if (Character.isWhitespace(c)) {
/* 165 */           char prev = trimmed.charAt(i - 1);
/* 166 */           if (!Character.isWhitespace(prev) && prev != '.') {
/* 167 */             charAllowed = false;
/* 168 */             dotAllowed = true;
/* 169 */             quoteAllowed = true;
/*     */           }
/*     */         
/* 172 */         } else if (charAllowed && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_-".indexOf(c) > -1) {
/* 173 */           charAllowed = true;
/* 174 */           dotAllowed = true;
/* 175 */           quoteAllowed = false;
/*     */         } else {
/* 177 */           valid = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     if (!valid) {
/* 183 */       context.errors.invalidTable(name, context.line.get());
/* 184 */       return false;
/*     */     } 
/*     */     
/* 187 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isValidTableArray(String line, Context context) {
/* 191 */     boolean valid = true;
/*     */     
/* 193 */     if (!line.endsWith("]]")) {
/* 194 */       valid = false;
/*     */     }
/*     */     
/* 197 */     String trimmed = line.substring(2, line.length() - 2).trim();
/* 198 */     if (trimmed.isEmpty() || trimmed.charAt(0) == '.' || trimmed.endsWith(".")) {
/* 199 */       valid = false;
/*     */     }
/*     */     
/* 202 */     if (!valid) {
/* 203 */       context.errors.invalidTableArray(line, context.line.get());
/* 204 */       return false;
/*     */     } 
/*     */     
/* 207 */     boolean quoted = false;
/* 208 */     boolean dotAllowed = false;
/* 209 */     boolean quoteAllowed = true;
/* 210 */     boolean charAllowed = true;
/*     */     
/* 212 */     for (int i = 0; i < trimmed.length(); i++) {
/* 213 */       char c = trimmed.charAt(i);
/*     */       
/* 215 */       if (!valid) {
/*     */         break;
/*     */       }
/*     */       
/* 219 */       if (c == '"') {
/* 220 */         if (!quoteAllowed) {
/* 221 */           valid = false;
/* 222 */         } else if (quoted && trimmed.charAt(i - 1) != '\\') {
/* 223 */           charAllowed = false;
/* 224 */           dotAllowed = true;
/* 225 */           quoteAllowed = false;
/* 226 */         } else if (!quoted) {
/* 227 */           quoted = true;
/* 228 */           quoteAllowed = true;
/*     */         } 
/* 230 */       } else if (!quoted) {
/*     */         
/* 232 */         if (c == '.') {
/* 233 */           if (dotAllowed) {
/* 234 */             charAllowed = true;
/* 235 */             dotAllowed = false;
/* 236 */             quoteAllowed = true;
/*     */           } else {
/* 238 */             context.errors.emptyImplicitTable(line, context.line.get());
/* 239 */             return false;
/*     */           } 
/* 241 */         } else if (Character.isWhitespace(c)) {
/* 242 */           char prev = trimmed.charAt(i - 1);
/* 243 */           if (!Character.isWhitespace(prev) && prev != '.' && prev != '"') {
/* 244 */             charAllowed = false;
/* 245 */             dotAllowed = true;
/* 246 */             quoteAllowed = true;
/*     */           }
/*     */         
/* 249 */         } else if (charAllowed && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_-".indexOf(c) > -1) {
/* 250 */           charAllowed = true;
/* 251 */           dotAllowed = true;
/* 252 */           quoteAllowed = false;
/*     */         } else {
/* 254 */           valid = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 259 */     if (!valid) {
/* 260 */       context.errors.invalidTableArray(line, context.line.get());
/* 261 */       return false;
/*     */     } 
/*     */     
/* 264 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Identifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */