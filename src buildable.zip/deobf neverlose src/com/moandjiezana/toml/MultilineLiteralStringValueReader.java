/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class MultilineLiteralStringValueReader
/*    */   implements ValueReader {
/*  7 */   static final MultilineLiteralStringValueReader MULTILINE_LITERAL_STRING_VALUE_READER = new MultilineLiteralStringValueReader();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 11 */     return s.startsWith("'''");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger index, Context context) {
/* 16 */     AtomicInteger line = context.line;
/* 17 */     int startLine = line.get();
/* 18 */     int originalStartIndex = index.get();
/* 19 */     int startIndex = index.addAndGet(3);
/* 20 */     int endIndex = -1;
/*    */     
/* 22 */     if (s.charAt(startIndex) == '\n') {
/* 23 */       startIndex = index.incrementAndGet();
/* 24 */       line.incrementAndGet();
/*    */     } 
/*    */     int i;
/* 27 */     for (i = startIndex; i < s.length(); i = index.incrementAndGet()) {
/* 28 */       char c = s.charAt(i);
/*    */       
/* 30 */       if (c == '\n') {
/* 31 */         line.incrementAndGet();
/*    */       }
/*    */       
/* 34 */       if (c == '\'' && s.length() > i + 2 && s.charAt(i + 1) == '\'' && s.charAt(i + 2) == '\'') {
/* 35 */         endIndex = i;
/* 36 */         index.addAndGet(2);
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 41 */     if (endIndex == -1) {
/* 42 */       Results.Errors errors = new Results.Errors();
/* 43 */       errors.unterminated(context.identifier.getName(), s.substring(originalStartIndex), startLine);
/* 44 */       return errors;
/*    */     } 
/*    */     
/* 47 */     return s.substring(startIndex, endIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\MultilineLiteralStringValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */