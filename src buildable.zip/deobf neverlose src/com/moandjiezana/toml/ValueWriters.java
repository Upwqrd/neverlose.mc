/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValueWriters
/*    */ {
/* 15 */   static final ValueWriters WRITERS = new ValueWriters();
/*    */   
/*    */   ValueWriter findWriterFor(Object value) {
/* 18 */     for (ValueWriter valueWriter : VALUE_WRITERS) {
/* 19 */       if (valueWriter.canWrite(value)) {
/* 20 */         return valueWriter;
/*    */       }
/*    */     } 
/*    */     
/* 24 */     return ObjectValueWriter.OBJECT_VALUE_WRITER;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static DateValueReaderWriter getPlatformSpecificDateConverter() {
/* 30 */     String specificationVersion = Runtime.class.getPackage().getSpecificationVersion();
/* 31 */     return (specificationVersion != null && specificationVersion.startsWith("1.6")) ? DateValueReaderWriter.DATE_PARSER_JDK_6 : DateValueReaderWriter.DATE_VALUE_READER_WRITER;
/*    */   }
/*    */   
/* 34 */   private static final ValueWriter[] VALUE_WRITERS = new ValueWriter[] { StringValueReaderWriter.STRING_VALUE_READER_WRITER, NumberValueReaderWriter.NUMBER_VALUE_READER_WRITER, BooleanValueReaderWriter.BOOLEAN_VALUE_READER_WRITER, 
/* 35 */       getPlatformSpecificDateConverter(), MapValueWriter.MAP_VALUE_WRITER, PrimitiveArrayValueWriter.PRIMITIVE_ARRAY_VALUE_WRITER, TableArrayValueWriter.TABLE_ARRAY_VALUE_WRITER };
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ValueWriters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */