/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Container
/*     */ {
/*     */   static class Table
/*     */     extends Container
/*     */   {
/*  16 */     private final Map<String, Object> values = new HashMap<String, Object>();
/*     */     final String name;
/*     */     final boolean implicit;
/*     */     
/*     */     Table() {
/*  21 */       this(null, false);
/*     */     }
/*     */     
/*     */     public Table(String name) {
/*  25 */       this(name, false);
/*     */     }
/*     */     
/*     */     public Table(String tableName, boolean implicit) {
/*  29 */       this.name = tableName;
/*  30 */       this.implicit = implicit;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean accepts(String key) {
/*  35 */       return (!this.values.containsKey(key) || this.values.get(key) instanceof Container.TableArray);
/*     */     }
/*     */ 
/*     */     
/*     */     void put(String key, Object value) {
/*  40 */       this.values.put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     Object get(String key) {
/*  45 */       return this.values.get(key);
/*     */     }
/*     */     
/*     */     boolean isImplicit() {
/*  49 */       return this.implicit;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map<String, Object> consume() {
/*  60 */       for (Map.Entry<String, Object> entry : this.values.entrySet()) {
/*  61 */         if (entry.getValue() instanceof Table) {
/*  62 */           entry.setValue(((Table)entry.getValue()).consume()); continue;
/*  63 */         }  if (entry.getValue() instanceof Container.TableArray) {
/*  64 */           entry.setValue(((Container.TableArray)entry.getValue()).getValues());
/*     */         }
/*     */       } 
/*     */       
/*  68 */       return this.values;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  73 */       return this.values.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static class TableArray extends Container {
/*  78 */     private final List<Container.Table> values = new ArrayList<Container.Table>();
/*     */     
/*     */     TableArray() {
/*  81 */       this.values.add(new Container.Table());
/*     */     }
/*     */ 
/*     */     
/*     */     boolean accepts(String key) {
/*  86 */       return getCurrent().accepts(key);
/*     */     }
/*     */ 
/*     */     
/*     */     void put(String key, Object value) {
/*  91 */       this.values.add((Container.Table)value);
/*     */     }
/*     */ 
/*     */     
/*     */     Object get(String key) {
/*  96 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     boolean isImplicit() {
/* 100 */       return false;
/*     */     }
/*     */     
/*     */     List<Map<String, Object>> getValues() {
/* 104 */       ArrayList<Map<String, Object>> unwrappedValues = new ArrayList<Map<String, Object>>();
/* 105 */       for (Container.Table table : this.values) {
/* 106 */         unwrappedValues.add(table.consume());
/*     */       }
/* 108 */       return unwrappedValues;
/*     */     }
/*     */     
/*     */     Container.Table getCurrent() {
/* 112 */       return this.values.get(this.values.size() - 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 117 */       return this.values.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private Container() {}
/*     */   
/*     */   abstract boolean isImplicit();
/*     */   
/*     */   abstract Object get(String paramString);
/*     */   
/*     */   abstract void put(String paramString, Object paramObject);
/*     */   
/*     */   abstract boolean accepts(String paramString);
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Container.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */