/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class LiteralStringValueReader
/*    */   implements ValueReader
/*    */ {
/*  8 */   static final LiteralStringValueReader LITERAL_STRING_VALUE_READER = new LiteralStringValueReader();
/*    */ 
/*    */   
/*    */   public boolean canRead(String s) {
/* 12 */     return s.startsWith("'");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object read(String s, AtomicInteger index, Context context) {
/* 17 */     int startLine = context.line.get();
/* 18 */     boolean terminated = false;
/* 19 */     int startIndex = index.incrementAndGet();
/*    */     int i;
/* 21 */     for (i = index.get(); i < s.length(); i = index.incrementAndGet()) {
/* 22 */       char c = s.charAt(i);
/*    */       
/* 24 */       if (c == '\'') {
/* 25 */         terminated = true;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 30 */     if (!terminated) {
/* 31 */       Results.Errors errors = new Results.Errors();
/* 32 */       errors.unterminated(context.identifier.getName(), s.substring(startIndex), startLine);
/* 33 */       return errors;
/*    */     } 
/*    */     
/* 36 */     String substring = s.substring(startIndex, index.get());
/*    */     
/* 38 */     return substring;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\LiteralStringValueReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */