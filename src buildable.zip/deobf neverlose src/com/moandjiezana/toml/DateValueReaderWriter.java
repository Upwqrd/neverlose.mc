/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ class DateValueReaderWriter
/*     */   implements ValueReader, ValueWriter
/*     */ {
/*  12 */   static final DateValueReaderWriter DATE_VALUE_READER_WRITER = new DateValueReaderWriter();
/*  13 */   static final DateValueReaderWriter DATE_PARSER_JDK_6 = new DateConverterJdk6();
/*  14 */   private static final Pattern DATE_REGEX = Pattern.compile("(\\d{4}-[0-1][0-9]-[0-3][0-9]T[0-2][0-9]:[0-5][0-9]:[0-5][0-9])(\\.\\d*)?(Z|(?:[+\\-]\\d{2}:\\d{2}))(.*)");
/*     */ 
/*     */   
/*     */   public boolean canRead(String s) {
/*  18 */     if (s.length() < 5) {
/*  19 */       return false;
/*     */     }
/*     */     
/*  22 */     for (int i = 0; i < 5; i++) {
/*  23 */       char c = s.charAt(i);
/*     */       
/*  25 */       if (i < 4) {
/*  26 */         if (!Character.isDigit(c)) {
/*  27 */           return false;
/*     */         }
/*  29 */       } else if (c != '-') {
/*  30 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/*  34 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object read(String original, AtomicInteger index, Context context) {
/*  39 */     StringBuilder sb = new StringBuilder();
/*     */     int i;
/*  41 */     for (i = index.get(); i < original.length(); i = index.incrementAndGet()) {
/*  42 */       char c = original.charAt(i);
/*  43 */       if (Character.isDigit(c) || c == '-' || c == '+' || c == ':' || c == '.' || c == 'T' || c == 'Z') {
/*  44 */         sb.append(c);
/*     */       } else {
/*  46 */         index.decrementAndGet();
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  51 */     String s = sb.toString();
/*  52 */     Matcher matcher = DATE_REGEX.matcher(s);
/*     */     
/*  54 */     if (!matcher.matches()) {
/*  55 */       Results.Errors errors = new Results.Errors();
/*  56 */       errors.invalidValue(context.identifier.getName(), s, context.line.get());
/*  57 */       return errors;
/*     */     } 
/*     */     
/*  60 */     String dateString = matcher.group(1);
/*  61 */     String zone = matcher.group(3);
/*  62 */     String fractionalSeconds = matcher.group(2);
/*  63 */     String format = "yyyy-MM-dd'T'HH:mm:ss";
/*  64 */     if (fractionalSeconds != null && !fractionalSeconds.isEmpty()) {
/*  65 */       format = format + ".SSS";
/*  66 */       dateString = dateString + fractionalSeconds;
/*     */     } 
/*  68 */     format = format + "Z";
/*  69 */     if ("Z".equals(zone)) {
/*  70 */       dateString = dateString + "+0000";
/*  71 */     } else if (zone.contains(":")) {
/*  72 */       dateString = dateString + zone.replace(":", "");
/*     */     } 
/*     */     
/*     */     try {
/*  76 */       SimpleDateFormat dateFormat = new SimpleDateFormat(format);
/*  77 */       dateFormat.setLenient(false);
/*  78 */       return dateFormat.parse(dateString);
/*  79 */     } catch (Exception e) {
/*  80 */       Results.Errors errors = new Results.Errors();
/*  81 */       errors.invalidValue(context.identifier.getName(), s, context.line.get());
/*  82 */       return errors;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Object value) {
/*  88 */     return value instanceof java.util.Date;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Object value, WriterContext context) {
/*  93 */     DateFormat formatter = getFormatter(context.getDatePolicy());
/*  94 */     context.write(formatter.format(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimitiveType() {
/*  99 */     return true;
/*     */   }
/*     */   private DateFormat getFormatter(DatePolicy datePolicy) {
/*     */     String format;
/* 103 */     boolean utc = "UTC".equals(datePolicy.getTimeZone().getID());
/*     */ 
/*     */     
/* 106 */     if (utc && datePolicy.isShowFractionalSeconds()) {
/* 107 */       format = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
/* 108 */     } else if (utc) {
/* 109 */       format = "yyyy-MM-dd'T'HH:mm:ss'Z'";
/* 110 */     } else if (datePolicy.isShowFractionalSeconds()) {
/* 111 */       format = getTimeZoneAndFractionalSecondsFormat();
/*     */     } else {
/* 113 */       format = getTimeZoneFormat();
/*     */     } 
/* 115 */     SimpleDateFormat formatter = new SimpleDateFormat(format);
/* 116 */     formatter.setTimeZone(datePolicy.getTimeZone());
/*     */     
/* 118 */     return formatter;
/*     */   }
/*     */   
/*     */   String getTimeZoneFormat() {
/* 122 */     return "yyyy-MM-dd'T'HH:mm:ssXXX";
/*     */   }
/*     */   
/*     */   String getTimeZoneAndFractionalSecondsFormat() {
/* 126 */     return "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
/*     */   }
/*     */   
/*     */   private DateValueReaderWriter() {}
/*     */   
/*     */   private static class DateConverterJdk6 extends DateValueReaderWriter { private DateConverterJdk6() {}
/*     */     
/*     */     public void write(Object value, WriterContext context) {
/* 134 */       DateFormat formatter = getFormatter(context.getDatePolicy());
/* 135 */       String date = formatter.format(value);
/*     */       
/* 137 */       if ("UTC".equals(context.getDatePolicy().getTimeZone().getID())) {
/* 138 */         context.write(date);
/*     */       } else {
/* 140 */         int insertionIndex = date.length() - 2;
/* 141 */         context.write(date.substring(0, insertionIndex)).write(':').write(date.substring(insertionIndex));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     String getTimeZoneAndFractionalSecondsFormat() {
/* 147 */       return "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
/*     */     }
/*     */ 
/*     */     
/*     */     String getTimeZoneFormat() {
/* 152 */       return "yyyy-MM-dd'T'HH:mm:ssZ";
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 158 */     return "datetime";
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\DateValueReaderWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */