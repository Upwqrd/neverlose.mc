package com.moandjiezana.toml;

interface ValueWriter {
  boolean canWrite(Object paramObject);
  
  void write(Object paramObject, WriterContext paramWriterContext);
  
  boolean isPrimitiveType();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\ValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */