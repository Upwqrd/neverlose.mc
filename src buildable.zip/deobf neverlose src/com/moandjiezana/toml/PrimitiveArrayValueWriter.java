/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ class PrimitiveArrayValueWriter
/*    */   extends ArrayValueWriter
/*    */ {
/*  8 */   static final ValueWriter PRIMITIVE_ARRAY_VALUE_WRITER = new PrimitiveArrayValueWriter();
/*    */ 
/*    */   
/*    */   public boolean canWrite(Object value) {
/* 12 */     return (isArrayish(value) && isArrayOfPrimitive(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object o, WriterContext context) {
/* 17 */     Collection<?> values = normalize(o);
/*    */     
/* 19 */     context.write('[');
/* 20 */     context.writeArrayDelimiterPadding();
/*    */     
/* 22 */     boolean first = true;
/* 23 */     ValueWriter firstWriter = null;
/*    */     
/* 25 */     for (Object value : values) {
/* 26 */       if (first) {
/* 27 */         firstWriter = ValueWriters.WRITERS.findWriterFor(value);
/* 28 */         first = false;
/*    */       } else {
/* 30 */         ValueWriter writer = ValueWriters.WRITERS.findWriterFor(value);
/* 31 */         if (writer != firstWriter) {
/* 32 */           throw new IllegalStateException(context
/* 33 */               .getContextPath() + ": cannot write a heterogeneous array; first element was of type " + firstWriter + " but found " + writer);
/*    */         }
/*    */ 
/*    */ 
/*    */         
/* 38 */         context.write(", ");
/*    */       } 
/*    */       
/* 41 */       ValueWriters.WRITERS.findWriterFor(value).write(value, context);
/*    */     } 
/*    */     
/* 44 */     context.writeArrayDelimiterPadding();
/* 45 */     context.write(']');
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return "primitive-array";
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\PrimitiveArrayValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */