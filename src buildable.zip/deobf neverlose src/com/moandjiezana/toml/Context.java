/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ class Context {
/*    */   final Identifier identifier;
/*    */   final AtomicInteger line;
/*    */   final Results.Errors errors;
/*    */   
/*    */   public Context(Identifier identifier, AtomicInteger line, Results.Errors errors) {
/* 11 */     this.identifier = identifier;
/* 12 */     this.line = line;
/* 13 */     this.errors = errors;
/*    */   }
/*    */   
/*    */   public Context with(Identifier identifier) {
/* 17 */     return new Context(identifier, this.line, this.errors);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Context.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */