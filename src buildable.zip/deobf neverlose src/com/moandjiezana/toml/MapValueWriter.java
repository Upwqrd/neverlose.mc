/*    */ package com.moandjiezana.toml;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ class MapValueWriter
/*    */   implements ValueWriter
/*    */ {
/* 12 */   static final ValueWriter MAP_VALUE_WRITER = new MapValueWriter();
/*    */   
/* 14 */   private static final Pattern REQUIRED_QUOTING_PATTERN = Pattern.compile("^.*[^A-Za-z\\d_-].*$");
/*    */ 
/*    */   
/*    */   public boolean canWrite(Object value) {
/* 18 */     return value instanceof Map;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(Object value, WriterContext context) {
/* 23 */     Map<?, ?> from = (Map<?, ?>)value;
/*    */     
/* 25 */     if (hasPrimitiveValues(from, context)) {
/* 26 */       context.writeKey();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 31 */     for (Map.Entry<?, ?> entry : from.entrySet()) {
/* 32 */       Object key = entry.getKey();
/* 33 */       Object fromValue = entry.getValue();
/* 34 */       if (fromValue == null) {
/*    */         continue;
/*    */       }
/*    */       
/* 38 */       ValueWriter valueWriter = ValueWriters.WRITERS.findWriterFor(fromValue);
/* 39 */       if (valueWriter.isPrimitiveType()) {
/* 40 */         context.indent();
/* 41 */         context.write(quoteKey(key)).write(" = ");
/* 42 */         valueWriter.write(fromValue, context);
/* 43 */         context.write('\n'); continue;
/* 44 */       }  if (valueWriter == PrimitiveArrayValueWriter.PRIMITIVE_ARRAY_VALUE_WRITER) {
/* 45 */         context.setArrayKey(key.toString());
/* 46 */         context.write(quoteKey(key)).write(" = ");
/* 47 */         valueWriter.write(fromValue, context);
/* 48 */         context.write('\n');
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 53 */     for (Object key : from.keySet()) {
/* 54 */       Object fromValue = from.get(key);
/* 55 */       if (fromValue == null) {
/*    */         continue;
/*    */       }
/*    */       
/* 59 */       ValueWriter valueWriter = ValueWriters.WRITERS.findWriterFor(fromValue);
/* 60 */       if (valueWriter == this || valueWriter == ObjectValueWriter.OBJECT_VALUE_WRITER || valueWriter == TableArrayValueWriter.TABLE_ARRAY_VALUE_WRITER) {
/* 61 */         valueWriter.write(fromValue, context.pushTable(quoteKey(key)));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPrimitiveType() {
/* 68 */     return false;
/*    */   }
/*    */   
/*    */   private static String quoteKey(Object key) {
/* 72 */     String stringKey = key.toString();
/* 73 */     Matcher matcher = REQUIRED_QUOTING_PATTERN.matcher(stringKey);
/* 74 */     if (matcher.matches()) {
/* 75 */       stringKey = "\"" + stringKey + "\"";
/*    */     }
/*    */     
/* 78 */     return stringKey;
/*    */   }
/*    */   
/*    */   private static boolean hasPrimitiveValues(Map<?, ?> values, WriterContext context) {
/* 82 */     for (Object key : values.keySet()) {
/* 83 */       Object fromValue = values.get(key);
/* 84 */       if (fromValue == null) {
/*    */         continue;
/*    */       }
/*    */       
/* 88 */       ValueWriter valueWriter = ValueWriters.WRITERS.findWriterFor(fromValue);
/* 89 */       if (valueWriter.isPrimitiveType() || valueWriter == PrimitiveArrayValueWriter.PRIMITIVE_ARRAY_VALUE_WRITER) {
/* 90 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 94 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\MapValueWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */