/*     */ package com.moandjiezana.toml;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonElement;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Toml
/*     */ {
/*  44 */   private static final Gson DEFAULT_GSON = new Gson();
/*     */   
/*  46 */   private Map<String, Object> values = new HashMap<String, Object>();
/*     */ 
/*     */   
/*     */   private final Toml defaults;
/*     */ 
/*     */   
/*     */   public Toml() {
/*  53 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml(Toml defaults) {
/*  60 */     this(defaults, new HashMap<String, Object>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml read(File file) {
/*     */     try {
/*  72 */       return read(new InputStreamReader(new FileInputStream(file), "UTF8"));
/*  73 */     } catch (Exception e) {
/*  74 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml read(InputStream inputStream) {
/*  86 */     return read(new InputStreamReader(inputStream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml read(Reader reader) {
/*  97 */     BufferedReader bufferedReader = null;
/*     */     try {
/*  99 */       bufferedReader = new BufferedReader(reader);
/*     */       
/* 101 */       StringBuilder w = new StringBuilder();
/* 102 */       String line = bufferedReader.readLine();
/* 103 */       while (line != null) {
/* 104 */         w.append(line).append('\n');
/* 105 */         line = bufferedReader.readLine();
/*     */       } 
/* 107 */       read(w.toString());
/* 108 */     } catch (IOException e) {
/* 109 */       throw new RuntimeException(e);
/*     */     } finally {
/*     */       try {
/* 112 */         bufferedReader.close();
/* 113 */       } catch (IOException iOException) {}
/*     */     } 
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml read(Toml otherToml) {
/* 125 */     this.values = otherToml.values;
/*     */     
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml read(String tomlString) throws IllegalStateException {
/* 138 */     Results results = TomlParser.run(tomlString);
/* 139 */     if (results.errors.hasErrors()) {
/* 140 */       throw new IllegalStateException(results.errors.toString());
/*     */     }
/*     */     
/* 143 */     this.values = results.consume();
/*     */     
/* 145 */     return this;
/*     */   }
/*     */   
/*     */   public String getString(String key) {
/* 149 */     return (String)get(key);
/*     */   }
/*     */   
/*     */   public String getString(String key, String defaultValue) {
/* 153 */     String val = getString(key);
/* 154 */     return (val == null) ? defaultValue : val;
/*     */   }
/*     */   
/*     */   public Long getLong(String key) {
/* 158 */     return (Long)get(key);
/*     */   }
/*     */   
/*     */   public Long getLong(String key, Long defaultValue) {
/* 162 */     Long val = getLong(key);
/* 163 */     return (val == null) ? defaultValue : val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> getList(String key) {
/* 173 */     List<T> list = (List<T>)get(key);
/*     */     
/* 175 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> List<T> getList(String key, List<T> defaultValue) {
/* 185 */     List<T> list = getList(key);
/*     */     
/* 187 */     return (list != null) ? list : defaultValue;
/*     */   }
/*     */   
/*     */   public Boolean getBoolean(String key) {
/* 191 */     return (Boolean)get(key);
/*     */   }
/*     */   
/*     */   public Boolean getBoolean(String key, Boolean defaultValue) {
/* 195 */     Boolean val = getBoolean(key);
/* 196 */     return (val == null) ? defaultValue : val;
/*     */   }
/*     */   
/*     */   public Date getDate(String key) {
/* 200 */     return (Date)get(key);
/*     */   }
/*     */   
/*     */   public Date getDate(String key, Date defaultValue) {
/* 204 */     Date val = getDate(key);
/* 205 */     return (val == null) ? defaultValue : val;
/*     */   }
/*     */   
/*     */   public Double getDouble(String key) {
/* 209 */     return (Double)get(key);
/*     */   }
/*     */   
/*     */   public Double getDouble(String key, Double defaultValue) {
/* 213 */     Double val = getDouble(key);
/* 214 */     return (val == null) ? defaultValue : val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Toml getTable(String key) {
/* 223 */     Map<String, Object> map = (Map<String, Object>)get(key);
/*     */     
/* 225 */     return (map != null) ? new Toml(null, map) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Toml> getTables(String key) {
/* 234 */     List<Map<String, Object>> tableArray = (List<Map<String, Object>>)get(key);
/*     */     
/* 236 */     if (tableArray == null) {
/* 237 */       return null;
/*     */     }
/*     */     
/* 240 */     ArrayList<Toml> tables = new ArrayList<Toml>();
/*     */     
/* 242 */     for (Map<String, Object> table : tableArray) {
/* 243 */       tables.add(new Toml(null, table));
/*     */     }
/*     */     
/* 246 */     return tables;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(String key) {
/* 254 */     return (get(key) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPrimitive(String key) {
/* 262 */     Object object = get(key);
/*     */     
/* 264 */     return (object != null && !(object instanceof Map) && !(object instanceof List));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTable(String key) {
/* 272 */     Object object = get(key);
/*     */     
/* 274 */     return (object != null && object instanceof Map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsTableArray(String key) {
/* 282 */     Object object = get(key);
/*     */     
/* 284 */     return (object != null && object instanceof List);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 288 */     return this.values.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T to(Class<T> targetClass) {
/* 317 */     JsonElement json = DEFAULT_GSON.toJsonTree(toMap());
/*     */     
/* 319 */     if (targetClass == JsonElement.class) {
/* 320 */       return targetClass.cast(json);
/*     */     }
/*     */     
/* 323 */     return (T)DEFAULT_GSON.fromJson(json, targetClass);
/*     */   }
/*     */   
/*     */   public Map<String, Object> toMap() {
/* 327 */     HashMap<String, Object> valuesCopy = new HashMap<String, Object>(this.values);
/*     */     
/* 329 */     if (this.defaults != null) {
/* 330 */       for (Map.Entry<String, Object> entry : this.defaults.values.entrySet()) {
/* 331 */         if (!valuesCopy.containsKey(entry.getKey())) {
/* 332 */           valuesCopy.put(entry.getKey(), entry.getValue());
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 337 */     return valuesCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 344 */     Set<Map.Entry<String, Object>> entries = new LinkedHashSet<Map.Entry<String, Object>>();
/*     */     
/* 346 */     for (Map.Entry<String, Object> entry : this.values.entrySet()) {
/* 347 */       Class<? extends Object> entryClass = (Class)entry.getValue().getClass();
/*     */       
/* 349 */       if (Map.class.isAssignableFrom(entryClass)) {
/* 350 */         entries.add(new Entry(entry.getKey(), getTable(entry.getKey()))); continue;
/* 351 */       }  if (List.class.isAssignableFrom(entryClass)) {
/* 352 */         List<?> value = (List)entry.getValue();
/* 353 */         if (!value.isEmpty() && value.get(0) instanceof Map) {
/* 354 */           entries.add(new Entry(entry.getKey(), getTables(entry.getKey()))); continue;
/*     */         } 
/* 356 */         entries.add(new Entry(entry.getKey(), value));
/*     */         continue;
/*     */       } 
/* 359 */       entries.add(new Entry(entry.getKey(), entry.getValue()));
/*     */     } 
/*     */ 
/*     */     
/* 363 */     return entries;
/*     */   }
/*     */   
/*     */   private class Entry
/*     */     implements Map.Entry<String, Object>
/*     */   {
/*     */     private final String key;
/*     */     private final Object value;
/*     */     
/*     */     public String getKey() {
/* 373 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue() {
/* 378 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setValue(Object value) {
/* 383 */       throw new UnsupportedOperationException("TOML entry values cannot be changed.");
/*     */     }
/*     */     
/*     */     private Entry(String key, Object value) {
/* 387 */       this.key = key;
/* 388 */       this.value = value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Object get(String key) {
/* 394 */     if (this.values.containsKey(key)) {
/* 395 */       return this.values.get(key);
/*     */     }
/*     */     
/* 398 */     Object<String, Object> current = (Object<String, Object>)new HashMap<String, Object>(this.values);
/*     */     
/* 400 */     Keys.Key[] keys = Keys.split(key);
/*     */     
/* 402 */     for (Keys.Key k : keys) {
/* 403 */       if (k.index == -1 && current instanceof Map && ((Map)current).containsKey(k.path)) {
/* 404 */         return ((Map)current).get(k.path);
/*     */       }
/*     */       
/* 407 */       current = (Object<String, Object>)((Map)current).get(k.name);
/*     */       
/* 409 */       if (k.index > -1 && current != null) {
/* 410 */         if (k.index >= ((List)current).size()) {
/* 411 */           return null;
/*     */         }
/*     */         
/* 414 */         current = ((List)current).get(k.index);
/*     */       } 
/*     */       
/* 417 */       if (current == null) {
/* 418 */         return (this.defaults != null) ? this.defaults.get(key) : null;
/*     */       }
/*     */     } 
/*     */     
/* 422 */     return current;
/*     */   }
/*     */   
/*     */   private Toml(Toml defaults, Map<String, Object> values) {
/* 426 */     this.values = values;
/* 427 */     this.defaults = defaults;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\moandjiezana\toml\Toml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */