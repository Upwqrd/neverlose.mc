package com.mojang.brigadier;

public interface Message {
  String getString();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\mojang\brigadier\Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */