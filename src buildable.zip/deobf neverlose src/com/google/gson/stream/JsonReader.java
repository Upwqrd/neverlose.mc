/*      */ package com.google.gson.stream;
/*      */ 
/*      */ import com.google.gson.internal.JsonReaderInternalAccess;
/*      */ import com.google.gson.internal.bind.JsonTreeReader;
/*      */ import java.io.Closeable;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonReader
/*      */   implements Closeable
/*      */ {
/*  193 */   private static final char[] NON_EXECUTE_PREFIX = ")]}'\n".toCharArray();
/*      */   
/*      */   private static final long MIN_INCOMPLETE_INTEGER = -922337203685477580L;
/*      */   
/*      */   private static final int PEEKED_NONE = 0;
/*      */   
/*      */   private static final int PEEKED_BEGIN_OBJECT = 1;
/*      */   
/*      */   private static final int PEEKED_END_OBJECT = 2;
/*      */   
/*      */   private static final int PEEKED_BEGIN_ARRAY = 3;
/*      */   
/*      */   private static final int PEEKED_END_ARRAY = 4;
/*      */   
/*      */   private static final int PEEKED_TRUE = 5;
/*      */   
/*      */   private static final int PEEKED_FALSE = 6;
/*      */   
/*      */   private static final int PEEKED_NULL = 7;
/*      */   
/*      */   private static final int PEEKED_SINGLE_QUOTED = 8;
/*      */   
/*      */   private static final int PEEKED_DOUBLE_QUOTED = 9;
/*      */   
/*      */   private static final int PEEKED_UNQUOTED = 10;
/*      */   
/*      */   private static final int PEEKED_BUFFERED = 11;
/*      */   
/*      */   private static final int PEEKED_SINGLE_QUOTED_NAME = 12;
/*      */   
/*      */   private static final int PEEKED_DOUBLE_QUOTED_NAME = 13;
/*      */   
/*      */   private static final int PEEKED_UNQUOTED_NAME = 14;
/*      */   private static final int PEEKED_LONG = 15;
/*      */   private static final int PEEKED_NUMBER = 16;
/*      */   private static final int PEEKED_EOF = 17;
/*      */   private static final int NUMBER_CHAR_NONE = 0;
/*      */   private static final int NUMBER_CHAR_SIGN = 1;
/*      */   private static final int NUMBER_CHAR_DIGIT = 2;
/*      */   private static final int NUMBER_CHAR_DECIMAL = 3;
/*      */   private static final int NUMBER_CHAR_FRACTION_DIGIT = 4;
/*      */   private static final int NUMBER_CHAR_EXP_E = 5;
/*      */   private static final int NUMBER_CHAR_EXP_SIGN = 6;
/*      */   private static final int NUMBER_CHAR_EXP_DIGIT = 7;
/*      */   private final Reader in;
/*      */   private boolean lenient = false;
/*  239 */   private final char[] buffer = new char[1024];
/*  240 */   private int pos = 0;
/*  241 */   private int limit = 0;
/*      */   
/*  243 */   private int lineNumber = 0;
/*  244 */   private int lineStart = 0;
/*      */   
/*  246 */   int peeked = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long peekedLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int peekedNumberLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String peekedString;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  270 */   private int[] stack = new int[32];
/*  271 */   private int stackSize = 0; private String[] pathNames; private int[] pathIndices;
/*      */   public JsonReader(Reader in) {
/*  273 */     this.stack[this.stackSize++] = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  284 */     this.pathNames = new String[32];
/*  285 */     this.pathIndices = new int[32];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  291 */     if (in == null) {
/*  292 */       throw new NullPointerException("in == null");
/*      */     }
/*  294 */     this.in = in;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setLenient(boolean lenient) {
/*  327 */     this.lenient = lenient;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isLenient() {
/*  334 */     return this.lenient;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginArray() throws IOException {
/*  342 */     int p = this.peeked;
/*  343 */     if (p == 0) {
/*  344 */       p = doPeek();
/*      */     }
/*  346 */     if (p == 3) {
/*  347 */       push(1);
/*  348 */       this.pathIndices[this.stackSize - 1] = 0;
/*  349 */       this.peeked = 0;
/*      */     } else {
/*  351 */       throw new IllegalStateException("Expected BEGIN_ARRAY but was " + peek() + locationString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endArray() throws IOException {
/*  360 */     int p = this.peeked;
/*  361 */     if (p == 0) {
/*  362 */       p = doPeek();
/*      */     }
/*  364 */     if (p == 4) {
/*  365 */       this.stackSize--;
/*  366 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  367 */       this.peeked = 0;
/*      */     } else {
/*  369 */       throw new IllegalStateException("Expected END_ARRAY but was " + peek() + locationString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginObject() throws IOException {
/*  378 */     int p = this.peeked;
/*  379 */     if (p == 0) {
/*  380 */       p = doPeek();
/*      */     }
/*  382 */     if (p == 1) {
/*  383 */       push(3);
/*  384 */       this.peeked = 0;
/*      */     } else {
/*  386 */       throw new IllegalStateException("Expected BEGIN_OBJECT but was " + peek() + locationString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endObject() throws IOException {
/*  395 */     int p = this.peeked;
/*  396 */     if (p == 0) {
/*  397 */       p = doPeek();
/*      */     }
/*  399 */     if (p == 2) {
/*  400 */       this.stackSize--;
/*  401 */       this.pathNames[this.stackSize] = null;
/*  402 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  403 */       this.peeked = 0;
/*      */     } else {
/*  405 */       throw new IllegalStateException("Expected END_OBJECT but was " + peek() + locationString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNext() throws IOException {
/*  413 */     int p = this.peeked;
/*  414 */     if (p == 0) {
/*  415 */       p = doPeek();
/*      */     }
/*  417 */     return (p != 2 && p != 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken peek() throws IOException {
/*  424 */     int p = this.peeked;
/*  425 */     if (p == 0) {
/*  426 */       p = doPeek();
/*      */     }
/*      */     
/*  429 */     switch (p) {
/*      */       case 1:
/*  431 */         return JsonToken.BEGIN_OBJECT;
/*      */       case 2:
/*  433 */         return JsonToken.END_OBJECT;
/*      */       case 3:
/*  435 */         return JsonToken.BEGIN_ARRAY;
/*      */       case 4:
/*  437 */         return JsonToken.END_ARRAY;
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*  441 */         return JsonToken.NAME;
/*      */       case 5:
/*      */       case 6:
/*  444 */         return JsonToken.BOOLEAN;
/*      */       case 7:
/*  446 */         return JsonToken.NULL;
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*  451 */         return JsonToken.STRING;
/*      */       case 15:
/*      */       case 16:
/*  454 */         return JsonToken.NUMBER;
/*      */       case 17:
/*  456 */         return JsonToken.END_DOCUMENT;
/*      */     } 
/*  458 */     throw new AssertionError();
/*      */   }
/*      */ 
/*      */   
/*      */   int doPeek() throws IOException {
/*  463 */     int peekStack = this.stack[this.stackSize - 1];
/*  464 */     if (peekStack == 1)
/*  465 */     { this.stack[this.stackSize - 1] = 2; }
/*  466 */     else if (peekStack == 2)
/*      */     
/*  468 */     { int i = nextNonWhitespace(true);
/*  469 */       switch (i) {
/*      */         case 93:
/*  471 */           return this.peeked = 4;
/*      */         case 59:
/*  473 */           checkLenient(); break;
/*      */         case 44:
/*      */           break;
/*      */         default:
/*  477 */           throw syntaxError("Unterminated array");
/*      */       }  }
/*  479 */     else { if (peekStack == 3 || peekStack == 5) {
/*  480 */         this.stack[this.stackSize - 1] = 4;
/*      */         
/*  482 */         if (peekStack == 5) {
/*  483 */           int j = nextNonWhitespace(true);
/*  484 */           switch (j) {
/*      */             case 125:
/*  486 */               return this.peeked = 2;
/*      */             case 59:
/*  488 */               checkLenient(); break;
/*      */             case 44:
/*      */               break;
/*      */             default:
/*  492 */               throw syntaxError("Unterminated object");
/*      */           } 
/*      */         } 
/*  495 */         int i = nextNonWhitespace(true);
/*  496 */         switch (i) {
/*      */           case 34:
/*  498 */             return this.peeked = 13;
/*      */           case 39:
/*  500 */             checkLenient();
/*  501 */             return this.peeked = 12;
/*      */           case 125:
/*  503 */             if (peekStack != 5) {
/*  504 */               return this.peeked = 2;
/*      */             }
/*  506 */             throw syntaxError("Expected name");
/*      */         } 
/*      */         
/*  509 */         checkLenient();
/*  510 */         this.pos--;
/*  511 */         if (isLiteral((char)i)) {
/*  512 */           return this.peeked = 14;
/*      */         }
/*  514 */         throw syntaxError("Expected name");
/*      */       } 
/*      */       
/*  517 */       if (peekStack == 4) {
/*  518 */         this.stack[this.stackSize - 1] = 5;
/*      */         
/*  520 */         int i = nextNonWhitespace(true);
/*  521 */         switch (i) {
/*      */           case 58:
/*      */             break;
/*      */           case 61:
/*  525 */             checkLenient();
/*  526 */             if ((this.pos < this.limit || fillBuffer(1)) && this.buffer[this.pos] == '>') {
/*  527 */               this.pos++;
/*      */             }
/*      */             break;
/*      */           default:
/*  531 */             throw syntaxError("Expected ':'");
/*      */         } 
/*  533 */       } else if (peekStack == 6) {
/*  534 */         if (this.lenient) {
/*  535 */           consumeNonExecutePrefix();
/*      */         }
/*  537 */         this.stack[this.stackSize - 1] = 7;
/*  538 */       } else if (peekStack == 7) {
/*  539 */         int i = nextNonWhitespace(false);
/*  540 */         if (i == -1) {
/*  541 */           return this.peeked = 17;
/*      */         }
/*  543 */         checkLenient();
/*  544 */         this.pos--;
/*      */       }
/*  546 */       else if (peekStack == 8) {
/*  547 */         throw new IllegalStateException("JsonReader is closed");
/*      */       }  }
/*      */     
/*  550 */     int c = nextNonWhitespace(true);
/*  551 */     switch (c) {
/*      */       case 93:
/*  553 */         if (peekStack == 1) {
/*  554 */           return this.peeked = 4;
/*      */         }
/*      */ 
/*      */       
/*      */       case 44:
/*      */       case 59:
/*  560 */         if (peekStack == 1 || peekStack == 2) {
/*  561 */           checkLenient();
/*  562 */           this.pos--;
/*  563 */           return this.peeked = 7;
/*      */         } 
/*  565 */         throw syntaxError("Unexpected value");
/*      */       
/*      */       case 39:
/*  568 */         checkLenient();
/*  569 */         return this.peeked = 8;
/*      */       case 34:
/*  571 */         return this.peeked = 9;
/*      */       case 91:
/*  573 */         return this.peeked = 3;
/*      */       case 123:
/*  575 */         return this.peeked = 1;
/*      */     } 
/*  577 */     this.pos--;
/*      */ 
/*      */     
/*  580 */     int result = peekKeyword();
/*  581 */     if (result != 0) {
/*  582 */       return result;
/*      */     }
/*      */     
/*  585 */     result = peekNumber();
/*  586 */     if (result != 0) {
/*  587 */       return result;
/*      */     }
/*      */     
/*  590 */     if (!isLiteral(this.buffer[this.pos])) {
/*  591 */       throw syntaxError("Expected value");
/*      */     }
/*      */     
/*  594 */     checkLenient();
/*  595 */     return this.peeked = 10;
/*      */   }
/*      */   private int peekKeyword() throws IOException {
/*      */     String keyword, keywordUpper;
/*      */     int peeking;
/*  600 */     char c = this.buffer[this.pos];
/*      */ 
/*      */ 
/*      */     
/*  604 */     if (c == 't' || c == 'T') {
/*  605 */       keyword = "true";
/*  606 */       keywordUpper = "TRUE";
/*  607 */       peeking = 5;
/*  608 */     } else if (c == 'f' || c == 'F') {
/*  609 */       keyword = "false";
/*  610 */       keywordUpper = "FALSE";
/*  611 */       peeking = 6;
/*  612 */     } else if (c == 'n' || c == 'N') {
/*  613 */       keyword = "null";
/*  614 */       keywordUpper = "NULL";
/*  615 */       peeking = 7;
/*      */     } else {
/*  617 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/*  621 */     int length = keyword.length();
/*  622 */     for (int i = 1; i < length; i++) {
/*  623 */       if (this.pos + i >= this.limit && !fillBuffer(i + 1)) {
/*  624 */         return 0;
/*      */       }
/*  626 */       c = this.buffer[this.pos + i];
/*  627 */       if (c != keyword.charAt(i) && c != keywordUpper.charAt(i)) {
/*  628 */         return 0;
/*      */       }
/*      */     } 
/*      */     
/*  632 */     if ((this.pos + length < this.limit || fillBuffer(length + 1)) && 
/*  633 */       isLiteral(this.buffer[this.pos + length])) {
/*  634 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*  638 */     this.pos += length;
/*  639 */     return this.peeked = peeking;
/*      */   }
/*      */   
/*      */   private int peekNumber() throws IOException {
/*      */     int j;
/*  644 */     char[] buffer = this.buffer;
/*  645 */     int p = this.pos;
/*  646 */     int l = this.limit;
/*      */     
/*  648 */     long value = 0L;
/*  649 */     boolean negative = false;
/*  650 */     boolean fitsInLong = true;
/*  651 */     int last = 0;
/*      */     
/*  653 */     int i = 0;
/*      */ 
/*      */     
/*  656 */     for (;; i++) {
/*  657 */       if (p + i == l) {
/*  658 */         if (i == buffer.length)
/*      */         {
/*      */           
/*  661 */           return 0;
/*      */         }
/*  663 */         if (!fillBuffer(i + 1)) {
/*      */           break;
/*      */         }
/*  666 */         p = this.pos;
/*  667 */         l = this.limit;
/*      */       } 
/*      */       
/*  670 */       char c = buffer[p + i];
/*  671 */       switch (c) {
/*      */         case '-':
/*  673 */           if (last == 0) {
/*  674 */             negative = true;
/*  675 */             last = 1; break;
/*      */           } 
/*  677 */           if (last == 5) {
/*  678 */             last = 6;
/*      */             break;
/*      */           } 
/*  681 */           return 0;
/*      */         
/*      */         case '+':
/*  684 */           if (last == 5) {
/*  685 */             last = 6;
/*      */             break;
/*      */           } 
/*  688 */           return 0;
/*      */         
/*      */         case 'E':
/*      */         case 'e':
/*  692 */           if (last == 2 || last == 4) {
/*  693 */             last = 5;
/*      */             break;
/*      */           } 
/*  696 */           return 0;
/*      */         
/*      */         case '.':
/*  699 */           if (last == 2) {
/*  700 */             last = 3;
/*      */             break;
/*      */           } 
/*  703 */           return 0;
/*      */         
/*      */         default:
/*  706 */           if (c < '0' || c > '9') {
/*  707 */             if (!isLiteral(c)) {
/*      */               break;
/*      */             }
/*  710 */             return 0;
/*      */           } 
/*  712 */           if (last == 1 || last == 0) {
/*  713 */             value = -(c - 48);
/*  714 */             last = 2; break;
/*  715 */           }  if (last == 2) {
/*  716 */             if (value == 0L) {
/*  717 */               return 0;
/*      */             }
/*  719 */             long newValue = value * 10L - (c - 48);
/*  720 */             j = fitsInLong & ((value > -922337203685477580L || (value == -922337203685477580L && newValue < value)) ? 1 : 0);
/*      */             
/*  722 */             value = newValue; break;
/*  723 */           }  if (last == 3) {
/*  724 */             last = 4; break;
/*  725 */           }  if (last == 5 || last == 6) {
/*  726 */             last = 7;
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*  732 */     if (last == 2 && j != 0 && (value != Long.MIN_VALUE || negative) && (value != 0L || false == negative)) {
/*  733 */       this.peekedLong = negative ? value : -value;
/*  734 */       this.pos += i;
/*  735 */       return this.peeked = 15;
/*  736 */     }  if (last == 2 || last == 4 || last == 7) {
/*      */       
/*  738 */       this.peekedNumberLength = i;
/*  739 */       return this.peeked = 16;
/*      */     } 
/*  741 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isLiteral(char c) throws IOException {
/*  746 */     switch (c) {
/*      */       case '#':
/*      */       case '/':
/*      */       case ';':
/*      */       case '=':
/*      */       case '\\':
/*  752 */         checkLenient();
/*      */       case '\t':
/*      */       case '\n':
/*      */       case '\f':
/*      */       case '\r':
/*      */       case ' ':
/*      */       case ',':
/*      */       case ':':
/*      */       case '[':
/*      */       case ']':
/*      */       case '{':
/*      */       case '}':
/*  764 */         return false;
/*      */     } 
/*  766 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextName() throws IOException {
/*      */     String result;
/*  778 */     int p = this.peeked;
/*  779 */     if (p == 0) {
/*  780 */       p = doPeek();
/*      */     }
/*      */     
/*  783 */     if (p == 14) {
/*  784 */       result = nextUnquotedValue();
/*  785 */     } else if (p == 12) {
/*  786 */       result = nextQuotedValue('\'');
/*  787 */     } else if (p == 13) {
/*  788 */       result = nextQuotedValue('"');
/*      */     } else {
/*  790 */       throw new IllegalStateException("Expected a name but was " + peek() + locationString());
/*      */     } 
/*  792 */     this.peeked = 0;
/*  793 */     this.pathNames[this.stackSize - 1] = result;
/*  794 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextString() throws IOException {
/*      */     String result;
/*  806 */     int p = this.peeked;
/*  807 */     if (p == 0) {
/*  808 */       p = doPeek();
/*      */     }
/*      */     
/*  811 */     if (p == 10) {
/*  812 */       result = nextUnquotedValue();
/*  813 */     } else if (p == 8) {
/*  814 */       result = nextQuotedValue('\'');
/*  815 */     } else if (p == 9) {
/*  816 */       result = nextQuotedValue('"');
/*  817 */     } else if (p == 11) {
/*  818 */       result = this.peekedString;
/*  819 */       this.peekedString = null;
/*  820 */     } else if (p == 15) {
/*  821 */       result = Long.toString(this.peekedLong);
/*  822 */     } else if (p == 16) {
/*  823 */       result = new String(this.buffer, this.pos, this.peekedNumberLength);
/*  824 */       this.pos += this.peekedNumberLength;
/*      */     } else {
/*  826 */       throw new IllegalStateException("Expected a string but was " + peek() + locationString());
/*      */     } 
/*  828 */     this.peeked = 0;
/*  829 */     this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  830 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextBoolean() throws IOException {
/*  841 */     int p = this.peeked;
/*  842 */     if (p == 0) {
/*  843 */       p = doPeek();
/*      */     }
/*  845 */     if (p == 5) {
/*  846 */       this.peeked = 0;
/*  847 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  848 */       return true;
/*  849 */     }  if (p == 6) {
/*  850 */       this.peeked = 0;
/*  851 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  852 */       return false;
/*      */     } 
/*  854 */     throw new IllegalStateException("Expected a boolean but was " + peek() + locationString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextNull() throws IOException {
/*  865 */     int p = this.peeked;
/*  866 */     if (p == 0) {
/*  867 */       p = doPeek();
/*      */     }
/*  869 */     if (p == 7) {
/*  870 */       this.peeked = 0;
/*  871 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*      */     } else {
/*  873 */       throw new IllegalStateException("Expected null but was " + peek() + locationString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double nextDouble() throws IOException {
/*  887 */     int p = this.peeked;
/*  888 */     if (p == 0) {
/*  889 */       p = doPeek();
/*      */     }
/*      */     
/*  892 */     if (p == 15) {
/*  893 */       this.peeked = 0;
/*  894 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  895 */       return this.peekedLong;
/*      */     } 
/*      */     
/*  898 */     if (p == 16) {
/*  899 */       this.peekedString = new String(this.buffer, this.pos, this.peekedNumberLength);
/*  900 */       this.pos += this.peekedNumberLength;
/*  901 */     } else if (p == 8 || p == 9) {
/*  902 */       this.peekedString = nextQuotedValue((p == 8) ? 39 : 34);
/*  903 */     } else if (p == 10) {
/*  904 */       this.peekedString = nextUnquotedValue();
/*  905 */     } else if (p != 11) {
/*  906 */       throw new IllegalStateException("Expected a double but was " + peek() + locationString());
/*      */     } 
/*      */     
/*  909 */     this.peeked = 11;
/*  910 */     double result = Double.parseDouble(this.peekedString);
/*  911 */     if (!this.lenient && (Double.isNaN(result) || Double.isInfinite(result))) {
/*  912 */       throw new MalformedJsonException("JSON forbids NaN and infinities: " + result + 
/*  913 */           locationString());
/*      */     }
/*  915 */     this.peekedString = null;
/*  916 */     this.peeked = 0;
/*  917 */     this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  918 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLong() throws IOException {
/*  932 */     int p = this.peeked;
/*  933 */     if (p == 0) {
/*  934 */       p = doPeek();
/*      */     }
/*      */     
/*  937 */     if (p == 15) {
/*  938 */       this.peeked = 0;
/*  939 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  940 */       return this.peekedLong;
/*      */     } 
/*      */     
/*  943 */     if (p == 16) {
/*  944 */       this.peekedString = new String(this.buffer, this.pos, this.peekedNumberLength);
/*  945 */       this.pos += this.peekedNumberLength;
/*  946 */     } else if (p == 8 || p == 9 || p == 10) {
/*  947 */       if (p == 10) {
/*  948 */         this.peekedString = nextUnquotedValue();
/*      */       } else {
/*  950 */         this.peekedString = nextQuotedValue((p == 8) ? 39 : 34);
/*      */       } 
/*      */       try {
/*  953 */         long l = Long.parseLong(this.peekedString);
/*  954 */         this.peeked = 0;
/*  955 */         this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  956 */         return l;
/*  957 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     else {
/*      */       
/*  961 */       throw new IllegalStateException("Expected a long but was " + peek() + locationString());
/*      */     } 
/*      */     
/*  964 */     this.peeked = 11;
/*  965 */     double asDouble = Double.parseDouble(this.peekedString);
/*  966 */     long result = (long)asDouble;
/*  967 */     if (result != asDouble) {
/*  968 */       throw new NumberFormatException("Expected a long but was " + this.peekedString + locationString());
/*      */     }
/*  970 */     this.peekedString = null;
/*  971 */     this.peeked = 0;
/*  972 */     this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/*  973 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String nextQuotedValue(char quote) throws IOException {
/*  988 */     char[] buffer = this.buffer;
/*  989 */     StringBuilder builder = null;
/*      */     while (true) {
/*  991 */       int p = this.pos;
/*  992 */       int l = this.limit;
/*      */       
/*  994 */       int start = p;
/*  995 */       while (p < l) {
/*  996 */         int c = buffer[p++];
/*      */         
/*  998 */         if (c == quote) {
/*  999 */           this.pos = p;
/* 1000 */           int len = p - start - 1;
/* 1001 */           if (builder == null) {
/* 1002 */             return new String(buffer, start, len);
/*      */           }
/* 1004 */           builder.append(buffer, start, len);
/* 1005 */           return builder.toString();
/*      */         } 
/* 1007 */         if (c == 92) {
/* 1008 */           this.pos = p;
/* 1009 */           int len = p - start - 1;
/* 1010 */           if (builder == null) {
/* 1011 */             int estimatedLength = (len + 1) * 2;
/* 1012 */             builder = new StringBuilder(Math.max(estimatedLength, 16));
/*      */           } 
/* 1014 */           builder.append(buffer, start, len);
/* 1015 */           builder.append(readEscapeCharacter());
/* 1016 */           p = this.pos;
/* 1017 */           l = this.limit;
/* 1018 */           start = p; continue;
/* 1019 */         }  if (c == 10) {
/* 1020 */           this.lineNumber++;
/* 1021 */           this.lineStart = p;
/*      */         } 
/*      */       } 
/*      */       
/* 1025 */       if (builder == null) {
/* 1026 */         int estimatedLength = (p - start) * 2;
/* 1027 */         builder = new StringBuilder(Math.max(estimatedLength, 16));
/*      */       } 
/* 1029 */       builder.append(buffer, start, p - start);
/* 1030 */       this.pos = p;
/* 1031 */       if (!fillBuffer(1)) {
/* 1032 */         throw syntaxError("Unterminated string");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String nextUnquotedValue() throws IOException {
/* 1042 */     StringBuilder builder = null;
/* 1043 */     int i = 0;
/*      */ 
/*      */     
/*      */     label34: while (true) {
/* 1047 */       for (; this.pos + i < this.limit; i++)
/* 1048 */       { switch (this.buffer[this.pos + i])
/*      */         { case '#':
/*      */           case '/':
/*      */           case ';':
/*      */           case '=':
/*      */           case '\\':
/* 1054 */             checkLenient(); break label34;
/*      */           case '\t': break label34;
/*      */           case '\n': break label34;
/*      */           case '\f': break label34;
/*      */           case '\r': break label34;
/*      */           case ' ': break label34;
/*      */           case ',':
/*      */             break label34;
/*      */           case ':':
/*      */             break label34;
/*      */           case '[':
/*      */             break label34;
/*      */           case ']':
/*      */             break label34;
/*      */           case '{':
/*      */             break label34;
/*      */           case '}':
/* 1071 */             break label34; }  }  if (i < this.buffer.length) {
/* 1072 */         if (fillBuffer(i + 1)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1080 */       if (builder == null) {
/* 1081 */         builder = new StringBuilder(Math.max(i, 16));
/*      */       }
/* 1083 */       builder.append(this.buffer, this.pos, i);
/* 1084 */       this.pos += i;
/* 1085 */       i = 0;
/* 1086 */       if (!fillBuffer(1)) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 1091 */     String result = (null == builder) ? new String(this.buffer, this.pos, i) : builder.append(this.buffer, this.pos, i).toString();
/* 1092 */     this.pos += i;
/* 1093 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private void skipQuotedValue(char quote) throws IOException {
/* 1098 */     char[] buffer = this.buffer;
/*      */     while (true) {
/* 1100 */       int p = this.pos;
/* 1101 */       int l = this.limit;
/*      */       
/* 1103 */       while (p < l) {
/* 1104 */         int c = buffer[p++];
/* 1105 */         if (c == quote) {
/* 1106 */           this.pos = p; return;
/*      */         } 
/* 1108 */         if (c == 92) {
/* 1109 */           this.pos = p;
/* 1110 */           readEscapeCharacter();
/* 1111 */           p = this.pos;
/* 1112 */           l = this.limit; continue;
/* 1113 */         }  if (c == 10) {
/* 1114 */           this.lineNumber++;
/* 1115 */           this.lineStart = p;
/*      */         } 
/*      */       } 
/* 1118 */       this.pos = p;
/* 1119 */       if (!fillBuffer(1))
/* 1120 */         throw syntaxError("Unterminated string"); 
/*      */     } 
/*      */   }
/*      */   private void skipUnquotedValue() throws IOException {
/*      */     do {
/* 1125 */       int i = 0;
/* 1126 */       for (; this.pos + i < this.limit; i++) {
/* 1127 */         switch (this.buffer[this.pos + i]) {
/*      */           case '#':
/*      */           case '/':
/*      */           case ';':
/*      */           case '=':
/*      */           case '\\':
/* 1133 */             checkLenient();
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\f':
/*      */           case '\r':
/*      */           case ' ':
/*      */           case ',':
/*      */           case ':':
/*      */           case '[':
/*      */           case ']':
/*      */           case '{':
/*      */           case '}':
/* 1145 */             this.pos += i;
/*      */             return;
/*      */         } 
/*      */       } 
/* 1149 */       this.pos += i;
/* 1150 */     } while (fillBuffer(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextInt() throws IOException {
/* 1164 */     int p = this.peeked;
/* 1165 */     if (p == 0) {
/* 1166 */       p = doPeek();
/*      */     }
/*      */ 
/*      */     
/* 1170 */     if (p == 15) {
/* 1171 */       int i = (int)this.peekedLong;
/* 1172 */       if (this.peekedLong != i) {
/* 1173 */         throw new NumberFormatException("Expected an int but was " + this.peekedLong + locationString());
/*      */       }
/* 1175 */       this.peeked = 0;
/* 1176 */       this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/* 1177 */       return i;
/*      */     } 
/*      */     
/* 1180 */     if (p == 16) {
/* 1181 */       this.peekedString = new String(this.buffer, this.pos, this.peekedNumberLength);
/* 1182 */       this.pos += this.peekedNumberLength;
/* 1183 */     } else if (p == 8 || p == 9 || p == 10) {
/* 1184 */       if (p == 10) {
/* 1185 */         this.peekedString = nextUnquotedValue();
/*      */       } else {
/* 1187 */         this.peekedString = nextQuotedValue((p == 8) ? 39 : 34);
/*      */       } 
/*      */       try {
/* 1190 */         int i = Integer.parseInt(this.peekedString);
/* 1191 */         this.peeked = 0;
/* 1192 */         this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/* 1193 */         return i;
/* 1194 */       } catch (NumberFormatException numberFormatException) {}
/*      */     }
/*      */     else {
/*      */       
/* 1198 */       throw new IllegalStateException("Expected an int but was " + peek() + locationString());
/*      */     } 
/*      */     
/* 1201 */     this.peeked = 11;
/* 1202 */     double asDouble = Double.parseDouble(this.peekedString);
/* 1203 */     int result = (int)asDouble;
/* 1204 */     if (result != asDouble) {
/* 1205 */       throw new NumberFormatException("Expected an int but was " + this.peekedString + locationString());
/*      */     }
/* 1207 */     this.peekedString = null;
/* 1208 */     this.peeked = 0;
/* 1209 */     this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/* 1210 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/* 1217 */     this.peeked = 0;
/* 1218 */     this.stack[0] = 8;
/* 1219 */     this.stackSize = 1;
/* 1220 */     this.in.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void skipValue() throws IOException {
/* 1229 */     int count = 0;
/*      */     do {
/* 1231 */       int p = this.peeked;
/* 1232 */       if (p == 0) {
/* 1233 */         p = doPeek();
/*      */       }
/*      */       
/* 1236 */       if (p == 3) {
/* 1237 */         push(1);
/* 1238 */         count++;
/* 1239 */       } else if (p == 1) {
/* 1240 */         push(3);
/* 1241 */         count++;
/* 1242 */       } else if (p == 4) {
/* 1243 */         this.stackSize--;
/* 1244 */         count--;
/* 1245 */       } else if (p == 2) {
/* 1246 */         this.stackSize--;
/* 1247 */         count--;
/* 1248 */       } else if (p == 14 || p == 10) {
/* 1249 */         skipUnquotedValue();
/* 1250 */       } else if (p == 8 || p == 12) {
/* 1251 */         skipQuotedValue('\'');
/* 1252 */       } else if (p == 9 || p == 13) {
/* 1253 */         skipQuotedValue('"');
/* 1254 */       } else if (p == 16) {
/* 1255 */         this.pos += this.peekedNumberLength;
/*      */       } 
/* 1257 */       this.peeked = 0;
/* 1258 */     } while (count != 0);
/*      */     
/* 1260 */     this.pathIndices[this.stackSize - 1] = this.pathIndices[this.stackSize - 1] + 1;
/* 1261 */     this.pathNames[this.stackSize - 1] = "null";
/*      */   }
/*      */   
/*      */   private void push(int newTop) {
/* 1265 */     if (this.stackSize == this.stack.length) {
/* 1266 */       int newLength = this.stackSize * 2;
/* 1267 */       this.stack = Arrays.copyOf(this.stack, newLength);
/* 1268 */       this.pathIndices = Arrays.copyOf(this.pathIndices, newLength);
/* 1269 */       this.pathNames = Arrays.<String>copyOf(this.pathNames, newLength);
/*      */     } 
/* 1271 */     this.stack[this.stackSize++] = newTop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fillBuffer(int minimum) throws IOException {
/* 1280 */     char[] buffer = this.buffer;
/* 1281 */     this.lineStart -= this.pos;
/* 1282 */     if (this.limit != this.pos) {
/* 1283 */       this.limit -= this.pos;
/* 1284 */       System.arraycopy(buffer, this.pos, buffer, 0, this.limit);
/*      */     } else {
/* 1286 */       this.limit = 0;
/*      */     } 
/*      */     
/* 1289 */     this.pos = 0;
/*      */     int total;
/* 1291 */     while ((total = this.in.read(buffer, this.limit, buffer.length - this.limit)) != -1) {
/* 1292 */       this.limit += total;
/*      */ 
/*      */       
/* 1295 */       if (this.lineNumber == 0 && this.lineStart == 0 && this.limit > 0 && buffer[0] == '﻿') {
/* 1296 */         this.pos++;
/* 1297 */         this.lineStart++;
/* 1298 */         minimum++;
/*      */       } 
/*      */       
/* 1301 */       if (this.limit >= minimum) {
/* 1302 */         return true;
/*      */       }
/*      */     } 
/* 1305 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int nextNonWhitespace(boolean throwOnEof) throws IOException {
/* 1323 */     char[] buffer = this.buffer;
/* 1324 */     int p = this.pos;
/* 1325 */     int l = this.limit;
/*      */     while (true) {
/* 1327 */       if (p == l) {
/* 1328 */         this.pos = p;
/* 1329 */         if (!fillBuffer(1)) {
/*      */           break;
/*      */         }
/* 1332 */         p = this.pos;
/* 1333 */         l = this.limit;
/*      */       } 
/*      */       
/* 1336 */       int c = buffer[p++];
/* 1337 */       if (c == 10) {
/* 1338 */         this.lineNumber++;
/* 1339 */         this.lineStart = p; continue;
/*      */       } 
/* 1341 */       if (c == 32 || c == 13 || c == 9) {
/*      */         continue;
/*      */       }
/*      */       
/* 1345 */       if (c == 47) {
/* 1346 */         this.pos = p;
/* 1347 */         if (p == l) {
/* 1348 */           this.pos--;
/* 1349 */           boolean charsLoaded = fillBuffer(2);
/* 1350 */           this.pos++;
/* 1351 */           if (!charsLoaded) {
/* 1352 */             return c;
/*      */           }
/*      */         } 
/*      */         
/* 1356 */         checkLenient();
/* 1357 */         char peek = buffer[this.pos];
/* 1358 */         switch (peek) {
/*      */           
/*      */           case '*':
/* 1361 */             this.pos++;
/* 1362 */             if (!skipTo("*/")) {
/* 1363 */               throw syntaxError("Unterminated comment");
/*      */             }
/* 1365 */             p = this.pos + 2;
/* 1366 */             l = this.limit;
/*      */             continue;
/*      */ 
/*      */           
/*      */           case '/':
/* 1371 */             this.pos++;
/* 1372 */             skipToEndOfLine();
/* 1373 */             p = this.pos;
/* 1374 */             l = this.limit;
/*      */             continue;
/*      */         } 
/*      */         
/* 1378 */         return c;
/*      */       } 
/* 1380 */       if (c == 35) {
/* 1381 */         this.pos = p;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1387 */         checkLenient();
/* 1388 */         skipToEndOfLine();
/* 1389 */         p = this.pos;
/* 1390 */         l = this.limit; continue;
/*      */       } 
/* 1392 */       this.pos = p;
/* 1393 */       return c;
/*      */     } 
/*      */     
/* 1396 */     if (throwOnEof) {
/* 1397 */       throw new EOFException("End of input" + locationString());
/*      */     }
/* 1399 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkLenient() throws IOException {
/* 1404 */     if (!this.lenient) {
/* 1405 */       throw syntaxError("Use JsonReader.setLenient(true) to accept malformed JSON");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void skipToEndOfLine() throws IOException {
/* 1415 */     while (this.pos < this.limit || fillBuffer(1)) {
/* 1416 */       char c = this.buffer[this.pos++];
/* 1417 */       if (c == '\n') {
/* 1418 */         this.lineNumber++;
/* 1419 */         this.lineStart = this.pos; break;
/*      */       } 
/* 1421 */       if (c == '\r') {
/*      */         break;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipTo(String toFind) throws IOException {
/* 1431 */     int length = toFind.length();
/*      */     
/* 1433 */     for (; this.pos + length <= this.limit || fillBuffer(length); this.pos++) {
/* 1434 */       if (this.buffer[this.pos] == '\n') {
/* 1435 */         this.lineNumber++;
/* 1436 */         this.lineStart = this.pos + 1;
/*      */       } else {
/*      */         
/* 1439 */         int c = 0; while (true) { if (c < length) {
/* 1440 */             if (this.buffer[this.pos + c] != toFind.charAt(c))
/*      */               break;  c++;
/*      */             continue;
/*      */           } 
/* 1444 */           return true; } 
/*      */       } 
/* 1446 */     }  return false;
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1450 */     return getClass().getSimpleName() + locationString();
/*      */   }
/*      */   
/*      */   String locationString() {
/* 1454 */     int line = this.lineNumber + 1;
/* 1455 */     int column = this.pos - this.lineStart + 1;
/* 1456 */     return " at line " + line + " column " + column + " path " + getPath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPath() {
/* 1464 */     StringBuilder result = (new StringBuilder()).append('$');
/* 1465 */     for (int i = 0, size = this.stackSize; i < size; i++) {
/* 1466 */       switch (this.stack[i]) {
/*      */         case 1:
/*      */         case 2:
/* 1469 */           result.append('[').append(this.pathIndices[i]).append(']');
/*      */           break;
/*      */         
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/* 1475 */           result.append('.');
/* 1476 */           if (this.pathNames[i] != null) {
/* 1477 */             result.append(this.pathNames[i]);
/*      */           }
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1487 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char readEscapeCharacter() throws IOException {
/*      */     char result;
/*      */     int i, end;
/* 1500 */     if (this.pos == this.limit && !fillBuffer(1)) {
/* 1501 */       throw syntaxError("Unterminated escape sequence");
/*      */     }
/*      */     
/* 1504 */     char escaped = this.buffer[this.pos++];
/* 1505 */     switch (escaped) {
/*      */       case 'u':
/* 1507 */         if (this.pos + 4 > this.limit && !fillBuffer(4)) {
/* 1508 */           throw syntaxError("Unterminated escape sequence");
/*      */         }
/*      */         
/* 1511 */         result = Character.MIN_VALUE;
/* 1512 */         for (i = this.pos, end = i + 4; i < end; i++) {
/* 1513 */           char c = this.buffer[i];
/* 1514 */           result = (char)(result << 4);
/* 1515 */           if (c >= '0' && c <= '9') {
/* 1516 */             result = (char)(result + c - 48);
/* 1517 */           } else if (c >= 'a' && c <= 'f') {
/* 1518 */             result = (char)(result + c - 97 + 10);
/* 1519 */           } else if (c >= 'A' && c <= 'F') {
/* 1520 */             result = (char)(result + c - 65 + 10);
/*      */           } else {
/* 1522 */             throw new NumberFormatException("\\u" + new String(this.buffer, this.pos, 4));
/*      */           } 
/*      */         } 
/* 1525 */         this.pos += 4;
/* 1526 */         return result;
/*      */       
/*      */       case 't':
/* 1529 */         return '\t';
/*      */       
/*      */       case 'b':
/* 1532 */         return '\b';
/*      */       
/*      */       case 'n':
/* 1535 */         return '\n';
/*      */       
/*      */       case 'r':
/* 1538 */         return '\r';
/*      */       
/*      */       case 'f':
/* 1541 */         return '\f';
/*      */       
/*      */       case '\n':
/* 1544 */         this.lineNumber++;
/* 1545 */         this.lineStart = this.pos;
/*      */ 
/*      */       
/*      */       case '"':
/*      */       case '\'':
/*      */       case '/':
/*      */       case '\\':
/* 1552 */         return escaped;
/*      */     } 
/*      */     
/* 1555 */     throw syntaxError("Invalid escape sequence");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IOException syntaxError(String message) throws IOException {
/* 1564 */     throw new MalformedJsonException(message + locationString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void consumeNonExecutePrefix() throws IOException {
/* 1572 */     nextNonWhitespace(true);
/* 1573 */     this.pos--;
/*      */     
/* 1575 */     if (this.pos + NON_EXECUTE_PREFIX.length > this.limit && !fillBuffer(NON_EXECUTE_PREFIX.length)) {
/*      */       return;
/*      */     }
/*      */     
/* 1579 */     for (int i = 0; i < NON_EXECUTE_PREFIX.length; i++) {
/* 1580 */       if (this.buffer[this.pos + i] != NON_EXECUTE_PREFIX[i]) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1586 */     this.pos += NON_EXECUTE_PREFIX.length;
/*      */   }
/*      */   
/*      */   static {
/* 1590 */     JsonReaderInternalAccess.INSTANCE = new JsonReaderInternalAccess() {
/*      */         public void promoteNameToValue(JsonReader reader) throws IOException {
/* 1592 */           if (reader instanceof JsonTreeReader) {
/* 1593 */             ((JsonTreeReader)reader).promoteNameToValue();
/*      */             return;
/*      */           } 
/* 1596 */           int p = reader.peeked;
/* 1597 */           if (p == 0) {
/* 1598 */             p = reader.doPeek();
/*      */           }
/* 1600 */           if (p == 13) {
/* 1601 */             reader.peeked = 9;
/* 1602 */           } else if (p == 12) {
/* 1603 */             reader.peeked = 8;
/* 1604 */           } else if (p == 14) {
/* 1605 */             reader.peeked = 10;
/*      */           } else {
/* 1607 */             throw new IllegalStateException("Expected a name but was " + reader
/* 1608 */                 .peek() + reader.locationString());
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\google\gson\stream\JsonReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */