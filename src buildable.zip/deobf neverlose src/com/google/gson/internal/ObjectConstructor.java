package com.google.gson.internal;

public interface ObjectConstructor<T> {
  T construct();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\google\gson\internal\ObjectConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */