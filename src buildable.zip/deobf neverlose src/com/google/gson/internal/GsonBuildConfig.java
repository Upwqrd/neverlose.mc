package com.google.gson.internal;

public final class GsonBuildConfig {
  public static final String VERSION = "2.8.6";
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\com\google\gson\internal\GsonBuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */