/*    */ package cope.cosmos.connection;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Client
/*    */ {
/*    */   private Socket socket;
/*    */   
/*    */   public Client(String server, int port) {
/*    */     try {
/*    */       try {
/* 24 */         this.socket = new Socket(server, port);
/*    */ 
/*    */         
/* 27 */         System.out.println("Connected to " + server + " at port #" + port);
/*    */       }
/* 29 */       catch (UnknownHostException exception) {
/*    */ 
/*    */         
/* 32 */         if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 33 */           exception.printStackTrace();
/*    */         }
/*    */       } 
/* 36 */     } catch (IOException exception) {
/*    */ 
/*    */       
/* 39 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 40 */         exception.printStackTrace();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void connect(String server, int port) throws IOException {
/* 52 */     this.socket = new Socket(server, port);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void disconnect() {
/*    */     try {
/* 62 */       this.socket.close();
/* 63 */     } catch (IOException exception) {
/*    */ 
/*    */       
/* 66 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT))
/* 67 */         exception.printStackTrace(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\connection\Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */