/*    */ package cope.cosmos.asm;
/*    */ 
/*    */ import java.util.Map;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.MCVersion;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.Name;
/*    */ import org.spongepowered.asm.launch.MixinBootstrap;
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ 
/*    */ 
/*    */ @Name("Cosmos")
/*    */ @MCVersion("1.12.2")
/*    */ public class MixinLoader
/*    */   implements IFMLLoadingPlugin
/*    */ {
/*    */   public MixinLoader() {
/* 17 */     MixinBootstrap.init();
/* 18 */     Mixins.addConfiguration("mixins.cosmos.json");
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getASMTransformerClass() {
/* 23 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModContainerClass() {
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSetupClass() {
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void injectData(Map<String, Object> data) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAccessTransformerClass() {
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\MixinLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */