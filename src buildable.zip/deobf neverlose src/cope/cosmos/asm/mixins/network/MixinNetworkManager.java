/*    */ package cope.cosmos.asm.mixins.network;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.client.ExceptionThrownEvent;
/*    */ import cope.cosmos.client.events.network.DisconnectEvent;
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({NetworkManager.class})
/*    */ public class MixinNetworkManager {
/*    */   @Inject(method = {"checkDisconnected"}, at = {@At("HEAD")})
/*    */   public void onDisconnect(CallbackInfo info) {
/* 20 */     DisconnectEvent disconnectEvent = new DisconnectEvent();
/* 21 */     Cosmos.EVENT_BUS.post((Event)disconnectEvent);
/*    */   }
/*    */   
/*    */   @Inject(method = {"sendPacket(Lnet/minecraft/network/Packet;)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onSendPacket(Packet<?> packetIn, CallbackInfo info) {
/* 26 */     PacketEvent.PacketSendEvent packetSendEvent = new PacketEvent.PacketSendEvent(packetIn);
/* 27 */     Cosmos.EVENT_BUS.post((Event)packetSendEvent);
/*    */     
/* 29 */     if (packetSendEvent.isCanceled()) {
/* 30 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"channelRead0"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onPacketReceive(ChannelHandlerContext chc, Packet<?> packet, CallbackInfo info) {
/* 36 */     PacketEvent.PacketReceiveEvent packetReceiveEvent = new PacketEvent.PacketReceiveEvent(packet);
/* 37 */     Cosmos.EVENT_BUS.post((Event)packetReceiveEvent);
/*    */     
/* 39 */     if (packetReceiveEvent.isCanceled()) {
/* 40 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"exceptionCaught"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onExceptionCaught(ChannelHandlerContext exceptionCaught1, Throwable exceptionCaught2, CallbackInfo info) {
/* 46 */     ExceptionThrownEvent exceptionThrownEvent = new ExceptionThrownEvent(exceptionCaught2);
/* 47 */     Cosmos.EVENT_BUS.post((Event)exceptionThrownEvent);
/*    */     
/* 49 */     if (exceptionThrownEvent.isCanceled())
/* 50 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\network\MixinNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */