/*    */ package cope.cosmos.asm.mixins.entity.horse;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.entity.horse.HorseSaddledEvent;
/*    */ import cope.cosmos.client.events.entity.horse.HorseSteerEvent;
/*    */ import net.minecraft.entity.passive.AbstractHorse;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({AbstractHorse.class})
/*    */ public class MixinAbstractHorse {
/*    */   @Inject(method = {"canBeSteered"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void canBeSteered(CallbackInfoReturnable<Boolean> info) {
/* 17 */     HorseSteerEvent horseSteerEvent = new HorseSteerEvent();
/* 18 */     Cosmos.EVENT_BUS.post((Event)horseSteerEvent);
/*    */     
/* 20 */     if (horseSteerEvent.isCanceled()) {
/* 21 */       info.cancel();
/* 22 */       info.setReturnValue(Boolean.valueOf(true));
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"isHorseSaddled"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void isHorseSaddled(CallbackInfoReturnable<Boolean> info) {
/* 28 */     HorseSaddledEvent horseSaddledEvent = new HorseSaddledEvent();
/* 29 */     Cosmos.EVENT_BUS.post((Event)horseSaddledEvent);
/*    */     
/* 31 */     if (horseSaddledEvent.isCanceled()) {
/* 32 */       info.cancel();
/* 33 */       info.setReturnValue(Boolean.valueOf(true));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\horse\MixinAbstractHorse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */