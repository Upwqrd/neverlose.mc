/*    */ package cope.cosmos.asm.mixins.entity.crystal;
/*    */ 
/*    */ import cope.cosmos.client.events.render.entity.CrystalUpdateEvent;
/*    */ import net.minecraft.entity.item.EntityEnderCrystal;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({EntityEnderCrystal.class})
/*    */ public class MixinEntityEnderCrystal {
/*    */   @Inject(method = {"onUpdate"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onOnUpdate(CallbackInfo info) {
/* 16 */     CrystalUpdateEvent crystalUpdateEvent = new CrystalUpdateEvent();
/* 17 */     MinecraftForge.EVENT_BUS.post((Event)crystalUpdateEvent);
/*    */     
/* 19 */     if (crystalUpdateEvent.isCanceled())
/* 20 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\crystal\MixinEntityEnderCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */