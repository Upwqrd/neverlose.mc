//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.entity;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.entity.hitbox.EntityHitboxSizeEvent;
/*    */ import cope.cosmos.client.events.motion.movement.StepEvent;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.MoverType;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({Entity.class})
/*    */ public abstract class MixinEntity
/*    */   implements Wrapper
/*    */ {
/*    */   @Shadow
/*    */   public float stepHeight;
/*    */   
/*    */   @Shadow
/*    */   public abstract AxisAlignedBB getEntityBoundingBox();
/*    */   
/*    */   @Inject(method = {"move"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/profiler/Profiler;endSection()V", shift = At.Shift.BEFORE, ordinal = 0)})
/*    */   public void onMove(MoverType type, double x, double y, double z, CallbackInfo info) {
/* 30 */     if (((Entity)this).equals(mc.player)) {
/* 31 */       StepEvent event = new StepEvent(getEntityBoundingBox(), this.stepHeight);
/* 32 */       Cosmos.EVENT_BUS.post((Event)event);
/*    */       
/* 34 */       if (event.isCanceled()) {
/* 35 */         this.stepHeight = event.getHeight();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"getCollisionBorderSize"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onGetCollisionBorderSize(CallbackInfoReturnable<Float> info) {
/* 42 */     EntityHitboxSizeEvent entityHitboxSizeEvent = new EntityHitboxSizeEvent();
/* 43 */     Cosmos.EVENT_BUS.post((Event)entityHitboxSizeEvent);
/*    */     
/* 45 */     if (entityHitboxSizeEvent.isCanceled()) {
/* 46 */       info.cancel();
/* 47 */       info.setReturnValue(Float.valueOf(entityHitboxSizeEvent.getHitboxSize()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\MixinEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
