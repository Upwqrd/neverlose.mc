/*    */ package cope.cosmos.asm.mixins.entity.player;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.other.SkinLocationEvent;
/*    */ import cope.cosmos.client.events.render.player.ModifyFOVEvent;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({AbstractClientPlayer.class})
/*    */ public class MixinAbstractClientPlayer {
/*    */   @Inject(method = {"getLocationSkin()Lnet/minecraft/util/ResourceLocation;"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getLocationSkin(CallbackInfoReturnable<ResourceLocation> info) {
/* 18 */     SkinLocationEvent skinLocationEvent = new SkinLocationEvent();
/* 19 */     Cosmos.EVENT_BUS.post((Event)skinLocationEvent);
/*    */   }
/*    */   
/*    */   @Inject(method = {"getFovModifier"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getFOVModifier(CallbackInfoReturnable<Float> info) {
/* 24 */     ModifyFOVEvent modifyFOVEvent = new ModifyFOVEvent();
/* 25 */     Cosmos.EVENT_BUS.post((Event)modifyFOVEvent);
/*    */     
/* 27 */     if (modifyFOVEvent.isCanceled()) {
/* 28 */       info.cancel();
/* 29 */       info.setReturnValue(Float.valueOf(1.0F));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\player\MixinAbstractClientPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */