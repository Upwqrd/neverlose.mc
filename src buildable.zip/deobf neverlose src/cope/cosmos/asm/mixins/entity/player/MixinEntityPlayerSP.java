//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.asm.mixins.entity.player;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.entity.LivingUpdateEvent;
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.entity.player.UpdateWalkingPlayerEvent;
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.events.motion.movement.MotionUpdateEvent;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({EntityPlayerSP.class})
/*     */ public abstract class MixinEntityPlayerSP extends AbstractClientPlayer implements Wrapper {
/*     */   public MixinEntityPlayerSP() {
/*  26 */     super((World)(Minecraft.getMinecraft()).world, (Minecraft.getMinecraft()).player.getGameProfile());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updateLock;
/*     */   
/*     */   @Shadow
/*     */   protected Minecraft mc;
/*     */   
/*     */   @Shadow
/*     */   private boolean prevOnGround;
/*     */   
/*     */   @Shadow
/*     */   private float lastReportedYaw;
/*     */   
/*     */   @Shadow
/*     */   private float lastReportedPitch;
/*     */   
/*     */   @Shadow
/*     */   private int positionUpdateTicks;
/*     */   
/*     */   @Shadow
/*     */   private double lastReportedPosX;
/*     */   
/*     */   @Shadow
/*     */   private double lastReportedPosY;
/*     */   
/*     */   @Shadow
/*     */   private double lastReportedPosZ;
/*     */   
/*     */   @Shadow
/*     */   private boolean autoJumpEnabled;
/*     */   
/*     */   @Shadow
/*     */   private boolean serverSprintState;
/*     */   
/*     */   @Shadow
/*     */   private boolean serverSneakState;
/*     */   
/*     */   @Shadow
/*     */   protected abstract boolean isCurrentViewEntity();
/*     */   
/*     */   @Shadow
/*     */   public abstract void onUpdate();
/*     */   
/*     */   @Redirect(method = {"move"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"))
/*     */   public void move(AbstractClientPlayer player, MoverType type, double x, double y, double z) {
/*  73 */     MotionEvent motionEvent = new MotionEvent(type, x, y, z);
/*  74 */     Cosmos.EVENT_BUS.post((Event)motionEvent);
/*     */     
/*  76 */     if (motionEvent.isCanceled()) {
/*  77 */       move(motionEvent.getType(), motionEvent.getX(), motionEvent.getY(), motionEvent.getZ());
/*     */     }
/*     */     else {
/*     */       
/*  81 */       move(type, x, y, z);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Redirect(method = {"onLivingUpdate"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;setSprinting(Z)V", ordinal = 2))
/*     */   public void onLivingUpdate(EntityPlayerSP entityPlayerSP, boolean sprintUpdate) {
/*  87 */     LivingUpdateEvent livingUpdateEvent = new LivingUpdateEvent(entityPlayerSP, sprintUpdate);
/*  88 */     Cosmos.EVENT_BUS.post((Event)livingUpdateEvent);
/*     */     
/*  90 */     if (livingUpdateEvent.isCanceled()) {
/*  91 */       livingUpdateEvent.getEntityPlayerSP().setSprinting(true);
/*     */     }
/*     */     else {
/*     */       
/*  95 */       entityPlayerSP.setSprinting(sprintUpdate);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onUpdateMovingPlayer(CallbackInfo info) {
/* 103 */     RotationUpdateEvent rotationUpdateEvent = new RotationUpdateEvent();
/* 104 */     Cosmos.EVENT_BUS.post((Event)rotationUpdateEvent);
/*     */     
/* 106 */     if (rotationUpdateEvent.isCanceled()) {
/*     */ 
/*     */       
/* 109 */       MotionUpdateEvent motionUpdateEvent = new MotionUpdateEvent();
/* 110 */       Cosmos.EVENT_BUS.post((Event)motionUpdateEvent);
/*     */ 
/*     */       
/* 113 */       info.cancel();
/*     */       
/* 115 */       if (motionUpdateEvent.isCanceled()) {
/* 116 */         this.positionUpdateTicks++;
/*     */         
/* 118 */         boolean sprintUpdate = isSprinting();
/* 119 */         if (sprintUpdate != this.serverSprintState) {
/* 120 */           if (sprintUpdate) {
/* 121 */             this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SPRINTING));
/*     */           }
/*     */           else {
/*     */             
/* 125 */             this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */           } 
/*     */           
/* 128 */           this.serverSprintState = sprintUpdate;
/*     */         } 
/*     */         
/* 131 */         boolean sneakUpdate = isSneaking();
/* 132 */         if (sneakUpdate != this.serverSneakState) {
/* 133 */           if (sneakUpdate) {
/* 134 */             this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SNEAKING));
/*     */           }
/*     */           else {
/*     */             
/* 138 */             this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */           } 
/*     */           
/* 141 */           this.serverSneakState = sneakUpdate;
/*     */         } 
/*     */         
/* 144 */         if (isCurrentViewEntity()) {
/* 145 */           boolean movementUpdate = (StrictMath.pow(motionUpdateEvent.getX() - this.lastReportedPosX, 2.0D) + StrictMath.pow(motionUpdateEvent.getY() - this.lastReportedPosY, 2.0D) + StrictMath.pow(motionUpdateEvent.getZ() - this.lastReportedPosZ, 2.0D) > 9.0E-4D || this.positionUpdateTicks >= 20);
/* 146 */           boolean rotationUpdate = ((motionUpdateEvent.getYaw() - this.lastReportedYaw) != 0.0D || (motionUpdateEvent.getPitch() - this.lastReportedPitch) != 0.0D);
/*     */           
/* 148 */           if (isRiding()) {
/* 149 */             this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(this.motionX, -999.0D, this.motionZ, motionUpdateEvent.getYaw(), motionUpdateEvent.getPitch(), motionUpdateEvent.getOnGround()));
/* 150 */             movementUpdate = false;
/*     */           
/*     */           }
/* 153 */           else if (movementUpdate && rotationUpdate) {
/* 154 */             this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(motionUpdateEvent.getX(), motionUpdateEvent.getY(), motionUpdateEvent.getZ(), motionUpdateEvent.getYaw(), motionUpdateEvent.getPitch(), motionUpdateEvent.getOnGround()));
/*     */           
/*     */           }
/* 157 */           else if (movementUpdate) {
/* 158 */             this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(motionUpdateEvent.getX(), motionUpdateEvent.getY(), motionUpdateEvent.getZ(), motionUpdateEvent.getOnGround()));
/*     */           
/*     */           }
/* 161 */           else if (rotationUpdate) {
/* 162 */             this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(motionUpdateEvent.getYaw(), motionUpdateEvent.getPitch(), motionUpdateEvent.getOnGround()));
/*     */           
/*     */           }
/* 165 */           else if (this.prevOnGround != motionUpdateEvent.getOnGround()) {
/* 166 */             this.mc.player.connection.sendPacket((Packet)new CPacketPlayer(motionUpdateEvent.getOnGround()));
/*     */           } 
/*     */           
/* 169 */           if (movementUpdate) {
/* 170 */             this.lastReportedPosX = motionUpdateEvent.getX();
/* 171 */             this.lastReportedPosY = motionUpdateEvent.getY();
/* 172 */             this.lastReportedPosZ = motionUpdateEvent.getZ();
/* 173 */             this.positionUpdateTicks = 0;
/*     */           } 
/*     */           
/* 176 */           if (rotationUpdate) {
/* 177 */             this.lastReportedYaw = motionUpdateEvent.getYaw();
/* 178 */             this.lastReportedPitch = motionUpdateEvent.getPitch();
/*     */           } 
/*     */           
/* 181 */           this.prevOnGround = motionUpdateEvent.getOnGround();
/* 182 */           this.autoJumpEnabled = this.mc.gameSettings.autoJump;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"onUpdate"}, at = {@At(value = "INVOKE", target = "net/minecraft/client/entity/EntityPlayerSP.onUpdateWalkingPlayer()V", ordinal = 0, shift = At.Shift.AFTER)})
/*     */   public void onUpdateMovingPlayerPost(CallbackInfo info) {
/* 192 */     if (this.updateLock) {
/*     */       return;
/*     */     }
/*     */     
/* 196 */     UpdateWalkingPlayerEvent updateWalkingPlayerEvent = new UpdateWalkingPlayerEvent();
/* 197 */     Cosmos.EVENT_BUS.post((Event)updateWalkingPlayerEvent);
/*     */ 
/*     */     
/* 200 */     float yaw = getCosmos().getRotationManager().getRotation().isValid() ? getCosmos().getRotationManager().getRotation().getYaw() : this.mc.player.rotationYaw;
/* 201 */     float pitch = getCosmos().getRotationManager().getRotation().isValid() ? getCosmos().getRotationManager().getRotation().getPitch() : this.mc.player.rotationPitch;
/*     */     
/* 203 */     if (updateWalkingPlayerEvent.isCanceled())
/*     */     {
/*     */       
/* 206 */       if (updateWalkingPlayerEvent.getIterations() > 0)
/*     */       {
/*     */         
/* 209 */         for (int i = 0; i < updateWalkingPlayerEvent.getIterations(); i++) {
/*     */ 
/*     */           
/* 212 */           this.updateLock = true;
/*     */           
/* 214 */           onUpdate();
/*     */ 
/*     */           
/* 217 */           this.updateLock = false;
/*     */           
/* 219 */           boolean sprintUpdate = isSprinting();
/* 220 */           if (sprintUpdate != this.serverSprintState) {
/* 221 */             if (sprintUpdate) {
/* 222 */               this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SPRINTING));
/*     */             }
/*     */             else {
/*     */               
/* 226 */               this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */             } 
/*     */             
/* 229 */             this.serverSprintState = sprintUpdate;
/*     */           } 
/*     */           
/* 232 */           boolean sneakUpdate = isSneaking();
/* 233 */           if (sneakUpdate != this.serverSneakState) {
/* 234 */             if (sneakUpdate) {
/* 235 */               this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SNEAKING));
/*     */             }
/*     */             else {
/*     */               
/* 239 */               this.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */             } 
/*     */             
/* 242 */             this.serverSneakState = sneakUpdate;
/*     */           } 
/*     */           
/* 245 */           if (isCurrentViewEntity()) {
/* 246 */             boolean movementUpdate = (StrictMath.pow(this.mc.player.posX - this.lastReportedPosX, 2.0D) + StrictMath.pow(this.mc.player.posY - this.lastReportedPosY, 2.0D) + StrictMath.pow(this.mc.player.posZ - this.lastReportedPosZ, 2.0D) > 9.0E-4D || this.positionUpdateTicks >= 20);
/* 247 */             boolean rotationUpdate = ((yaw - this.lastReportedYaw) != 0.0D || (pitch - this.lastReportedPitch) != 0.0D);
/*     */             
/* 249 */             if (isRiding()) {
/* 250 */               this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(this.motionX, -999.0D, this.motionZ, yaw, pitch, this.mc.player.onGround));
/* 251 */               movementUpdate = false;
/*     */             
/*     */             }
/* 254 */             else if (movementUpdate && rotationUpdate) {
/* 255 */               this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(this.mc.player.posX, this.mc.player.posY, this.mc.player.posZ, yaw, pitch, this.mc.player.onGround));
/*     */             
/*     */             }
/* 258 */             else if (movementUpdate) {
/* 259 */               this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(this.mc.player.posX, this.mc.player.posY, this.mc.player.posZ, this.mc.player.onGround));
/*     */             
/*     */             }
/* 262 */             else if (rotationUpdate) {
/* 263 */               this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(yaw, pitch, this.mc.player.onGround));
/*     */             
/*     */             }
/* 266 */             else if (this.prevOnGround != this.mc.player.onGround) {
/* 267 */               this.mc.player.connection.sendPacket((Packet)new CPacketPlayer(this.mc.player.onGround));
/*     */             } 
/*     */             
/* 270 */             if (movementUpdate) {
/* 271 */               this.lastReportedPosX = this.mc.player.posX;
/* 272 */               this.lastReportedPosY = this.mc.player.posY;
/* 273 */               this.lastReportedPosZ = this.mc.player.posZ;
/* 274 */               this.positionUpdateTicks = 0;
/*     */             } 
/*     */             
/* 277 */             if (rotationUpdate) {
/* 278 */               this.lastReportedYaw = yaw;
/* 279 */               this.lastReportedPitch = pitch;
/*     */             } 
/*     */             
/* 282 */             this.prevOnGround = this.mc.player.onGround;
/* 283 */             this.autoJumpEnabled = this.mc.gameSettings.autoJump;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\player\MixinEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
