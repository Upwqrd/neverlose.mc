//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.entity.player;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.block.WaterCollisionEvent;
/*    */ import cope.cosmos.client.events.motion.collision.EntityCollisionEvent;
/*    */ import cope.cosmos.client.events.motion.movement.TravelEvent;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.MoverType;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({EntityPlayer.class})
/*    */ public abstract class MixinEntityPlayer extends EntityLivingBase {
/*    */   public MixinEntityPlayer(World worldIn) {
/* 21 */     super(worldIn);
/*    */   }
/*    */   
/*    */   @Inject(method = {"travel"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void travel(float strafe, float vertical, float forward, CallbackInfo info) {
/* 26 */     TravelEvent travelEvent = new TravelEvent(strafe, vertical, forward);
/* 27 */     Cosmos.EVENT_BUS.post((Event)travelEvent);
/*    */     
/* 29 */     if (travelEvent.isCanceled()) {
/* 30 */       move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
/* 31 */       info.cancel();
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"applyEntityCollision"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void applyEntityCollision(Entity entity, CallbackInfo info) {
/* 37 */     EntityCollisionEvent entityCollisionEvent = new EntityCollisionEvent();
/* 38 */     Cosmos.EVENT_BUS.post((Event)entityCollisionEvent);
/*    */     
/* 40 */     if (entityCollisionEvent.isCanceled()) {
/* 41 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"isPushedByWater()Z"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void isPushedByWater(CallbackInfoReturnable<Boolean> info) {
/* 47 */     WaterCollisionEvent waterCollisionEvent = new WaterCollisionEvent();
/* 48 */     Cosmos.EVENT_BUS.post((Event)waterCollisionEvent);
/*    */     
/* 50 */     if (waterCollisionEvent.isCanceled()) {
/* 51 */       info.cancel();
/* 52 */       info.setReturnValue(Boolean.valueOf(false));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\entity\player\MixinEntityPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
