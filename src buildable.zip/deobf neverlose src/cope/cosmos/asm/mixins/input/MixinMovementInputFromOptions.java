/*    */ package cope.cosmos.asm.mixins.input;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.input.UpdateMoveStateEvent;
/*    */ import net.minecraft.util.MovementInputFromOptions;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({MovementInputFromOptions.class})
/*    */ public class MixinMovementInputFromOptions {
/*    */   @Inject(method = {"updatePlayerMoveState"}, at = {@At("RETURN")})
/*    */   public void onUpdatePlayerMoveState(CallbackInfo info) {
/* 16 */     UpdateMoveStateEvent updateMoveStateEvent = new UpdateMoveStateEvent();
/* 17 */     Cosmos.EVENT_BUS.post((Event)updateMoveStateEvent);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\input\MixinMovementInputFromOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */