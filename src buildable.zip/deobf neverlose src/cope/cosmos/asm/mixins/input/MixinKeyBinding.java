//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.input;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.input.KeyDownEvent;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({KeyBinding.class})
/*    */ public class MixinKeyBinding
/*    */ {
/*    */   @Shadow
/*    */   private boolean pressed;
/*    */   @Shadow
/*    */   private int keyCode;
/*    */   
/*    */   @Inject(method = {"isKeyDown"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onIsKeyDown(CallbackInfoReturnable<Boolean> info) {
/* 23 */     KeyDownEvent keyDownEvent = new KeyDownEvent(this.keyCode, this.pressed);
/* 24 */     Cosmos.EVENT_BUS.post((Event)keyDownEvent);
/*    */     
/* 26 */     if (keyDownEvent.isCanceled())
/* 27 */       info.setReturnValue(Boolean.valueOf(keyDownEvent.isPressed())); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\input\MixinKeyBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
