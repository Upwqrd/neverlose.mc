//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.input.MiddleClickEvent;
/*    */ import cope.cosmos.client.events.render.gui.GuiScreenClosedEvent;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({Minecraft.class})
/*    */ public class MixinMinecraft
/*    */ {
/*    */   @Shadow
/*    */   @Nullable
/*    */   public GuiScreen currentScreen;
/*    */   
/*    */   @Inject(method = {"displayGuiScreen"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void displayGuiScreen(GuiScreen scr, CallbackInfo info) {
/* 25 */     if (scr == null) {
/* 26 */       Cosmos.EVENT_BUS.post((Event)new GuiScreenClosedEvent(this.currentScreen));
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"middleClickMouse"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void middleClickMouse(CallbackInfo info) {
/* 32 */     MiddleClickEvent middleClickEvent = new MiddleClickEvent();
/* 33 */     Cosmos.EVENT_BUS.post((Event)middleClickEvent);
/*    */     
/* 35 */     if (middleClickEvent.isCanceled())
/* 36 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\MixinMinecraft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
