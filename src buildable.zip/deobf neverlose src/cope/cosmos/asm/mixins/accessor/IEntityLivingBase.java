package cope.cosmos.asm.mixins.accessor;

import java.util.Map;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({EntityLivingBase.class})
public interface IEntityLivingBase {
  @Accessor("activePotionsMap")
  Map<Potion, PotionEffect> getActivePotionMap();
  
  @Invoker("onNewPotionEffect")
  void hookOnNewPotionEffect(PotionEffect paramPotionEffect);
  
  @Invoker("onChangedPotionEffect")
  void hookOnChangedPotionEffect(PotionEffect paramPotionEffect, boolean paramBoolean);
  
  @Invoker("getArmSwingAnimationEnd")
  int hookGetArmSwingAnimationEnd();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\IEntityLivingBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */