package cope.cosmos.asm.mixins.accessor;

import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({EntityPlayerSP.class})
public interface IEntityPlayerSP {
  @Accessor("serverSprintState")
  boolean getServerSprintState();
  
  @Accessor("serverSneakState")
  boolean getServerSneakState();
  
  @Accessor("positionUpdateTicks")
  int getPositionUpdateTicks();
  
  @Accessor("lastReportedPosX")
  double getLastReportedPosX();
  
  @Accessor("lastReportedPosY")
  double getLastReportedPosY();
  
  @Accessor("lastReportedPosZ")
  double getLastReportedPosZ();
  
  @Accessor("lastReportedYaw")
  float getLastReportedYaw();
  
  @Accessor("lastReportedPitch")
  float getLastReportedPitch();
  
  @Accessor("prevOnGround")
  boolean getPreviousOnGround();
  
  @Accessor("serverSprintState")
  void setServerSprintState(boolean paramBoolean);
  
  @Accessor("serverSneakState")
  void setServerSneakState(boolean paramBoolean);
  
  @Accessor("positionUpdateTicks")
  void setPositionUpdateTicks(int paramInt);
  
  @Accessor("lastReportedPosX")
  void setLastReportedPosX(double paramDouble);
  
  @Accessor("lastReportedPosY")
  void setLastReportedPosY(double paramDouble);
  
  @Accessor("lastReportedPosZ")
  void setLastReportedPosZ(double paramDouble);
  
  @Accessor("lastReportedYaw")
  void setLastReportedYaw(float paramFloat);
  
  @Accessor("lastReportedPitch")
  void setLastReportedPitch(float paramFloat);
  
  @Accessor("prevOnGround")
  void setPreviousOnGround(boolean paramBoolean);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\IEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */