package cope.cosmos.asm.mixins.accessor;

import net.minecraft.util.text.TextComponentString;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({TextComponentString.class})
public interface ITextComponentString {
  @Accessor("text")
  void setText(String paramString);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\ITextComponentString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */