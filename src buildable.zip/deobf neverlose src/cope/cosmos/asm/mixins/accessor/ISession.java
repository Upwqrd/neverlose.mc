package cope.cosmos.asm.mixins.accessor;

import net.minecraft.util.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Session.class})
public interface ISession {
  @Accessor("username")
  void setUsername(String paramString);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\ISession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */