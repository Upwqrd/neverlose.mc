package cope.cosmos.asm.mixins.accessor;

import net.minecraft.network.play.server.SPacketPlayerPosLook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({SPacketPlayerPosLook.class})
public interface ISPacketPlayerPosLook {
  @Accessor("yaw")
  void setYaw(float paramFloat);
  
  @Accessor("yaw")
  float getYaw();
  
  @Accessor("pitch")
  void setPitch(float paramFloat);
  
  @Accessor("pitch")
  float getPitch();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\ISPacketPlayerPosLook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */