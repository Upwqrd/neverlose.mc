package cope.cosmos.asm.mixins.accessor;

import net.minecraft.util.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Timer.class})
public interface ITimer {
  @Accessor("tickLength")
  float getTickLength();
  
  @Accessor("tickLength")
  void setTickLength(float paramFloat);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\ITimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */