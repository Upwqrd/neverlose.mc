package cope.cosmos.asm.mixins.accessor;

import net.minecraft.network.play.server.SPacketEntityVelocity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({SPacketEntityVelocity.class})
public interface ISPacketEntityVelocity {
  @Accessor("motionX")
  int getMotionX();
  
  @Accessor("motionY")
  int getMotionY();
  
  @Accessor("motionZ")
  int getMotionZ();
  
  @Accessor("motionX")
  void setMotionX(int paramInt);
  
  @Accessor("motionY")
  void setMotionY(int paramInt);
  
  @Accessor("motionZ")
  void setMotionZ(int paramInt);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\ISPacketEntityVelocity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */