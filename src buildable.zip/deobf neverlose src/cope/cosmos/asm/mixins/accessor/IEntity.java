package cope.cosmos.asm.mixins.accessor;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({Entity.class})
public interface IEntity {
  @Accessor("inPortal")
  boolean getInPortal();
  
  @Accessor("isInWeb")
  boolean getInWeb();
  
  @Accessor("isInWeb")
  void setInWeb(boolean paramBoolean);
  
  @Accessor("inPortal")
  void setInPortal(boolean paramBoolean);
  
  @Invoker("setSize")
  void setEntitySize(float paramFloat1, float paramFloat2);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\IEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */