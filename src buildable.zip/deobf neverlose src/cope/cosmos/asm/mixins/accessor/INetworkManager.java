package cope.cosmos.asm.mixins.accessor;

import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({NetworkManager.class})
public interface INetworkManager {
  @Invoker("dispatchPacket")
  void hookDispatchPacket(Packet<?> paramPacket, GenericFutureListener<? extends Future<? super Void>>[] paramArrayOfGenericFutureListener);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\INetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */