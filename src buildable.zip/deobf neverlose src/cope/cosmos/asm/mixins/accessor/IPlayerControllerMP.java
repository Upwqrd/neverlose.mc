package cope.cosmos.asm.mixins.accessor;

import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({PlayerControllerMP.class})
public interface IPlayerControllerMP {
  @Accessor("curBlockDamageMP")
  void setCurrentBlockDamage(float paramFloat);
  
  @Accessor("curBlockDamageMP")
  float getCurrentBlockDamage();
  
  @Accessor("blockHitDelay")
  void setBlockHitDelay(int paramInt);
  
  @Accessor("currentPlayerItem")
  int getCurrentPlayerItem();
  
  @Accessor("currentPlayerItem")
  void setCurrentPlayerItem(int paramInt);
  
  @Invoker("syncCurrentPlayItem")
  void hookSyncCurrentPlayItem();
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\accessor\IPlayerControllerMP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */