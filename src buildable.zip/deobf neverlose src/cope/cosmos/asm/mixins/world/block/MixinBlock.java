/*    */ package cope.cosmos.asm.mixins.world.block;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.visual.WallhackModule;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({Block.class})
/*    */ public class MixinBlock
/*    */ {
/*    */   @Inject(method = {"shouldSideBeRendered"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void shouldSideBeRendered(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side, CallbackInfoReturnable<Boolean> info) {
/* 23 */     if (WallhackModule.INSTANCE.isEnabled()) {
/* 24 */       info.setReturnValue(Boolean.valueOf(WallhackModule.WHITELIST.contains(this)));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"getLightValue(Lnet/minecraft/block/state/IBlockState;)I"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getLightValue(IBlockState state, CallbackInfoReturnable<Integer> info) {
/* 37 */     if (WallhackModule.INSTANCE.isEnabled())
/* 38 */       info.setReturnValue(Integer.valueOf(100)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\world\block\MixinBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */