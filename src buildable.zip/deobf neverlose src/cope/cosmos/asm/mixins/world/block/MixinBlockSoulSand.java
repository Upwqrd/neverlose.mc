/*    */ package cope.cosmos.asm.mixins.world.block;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.block.SoulSandEvent;
/*    */ import net.minecraft.block.BlockSoulSand;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({BlockSoulSand.class})
/*    */ public class MixinBlockSoulSand
/*    */ {
/*    */   @Inject(method = {"onEntityCollidedWithBlock"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onEntityCollidedWithBlock(World world, BlockPos blockPos, IBlockState iBlockState, Entity entity, CallbackInfo info) {
/* 21 */     SoulSandEvent soulSandEvent = new SoulSandEvent();
/* 22 */     Cosmos.EVENT_BUS.post((Event)soulSandEvent);
/*    */     
/* 24 */     if (soulSandEvent.isCanceled())
/* 25 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\world\block\MixinBlockSoulSand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */