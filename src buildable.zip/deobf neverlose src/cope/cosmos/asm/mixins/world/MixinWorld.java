/*    */ package cope.cosmos.asm.mixins.world;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*    */ import cope.cosmos.client.events.render.other.RenderParticleEvent;
/*    */ import cope.cosmos.client.events.render.world.RenderSkyEvent;
/*    */ import cope.cosmos.client.events.render.world.RenderSkylightEvent;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.EnumParticleTypes;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraft.world.EnumSkyBlock;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({World.class})
/*    */ public class MixinWorld {
/*    */   @Inject(method = {"checkLightFor"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onCheckLightFor(EnumSkyBlock lightType, BlockPos pos, CallbackInfoReturnable<Boolean> info) {
/* 25 */     if (lightType.equals(EnumSkyBlock.SKY)) {
/* 26 */       RenderSkylightEvent renderSkylightEvent = new RenderSkylightEvent();
/* 27 */       Cosmos.EVENT_BUS.post((Event)renderSkylightEvent);
/*    */       
/* 29 */       if (renderSkylightEvent.isCanceled()) {
/* 30 */         info.cancel();
/* 31 */         info.setReturnValue(Boolean.valueOf(true));
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"spawnParticle(Lnet/minecraft/util/EnumParticleTypes;DDDDDD[I)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onSpawnParticle(EnumParticleTypes particleType, double xCoord, double yCoord, double zCoord, double xSpeed, double ySpeed, double zSpeed, int[] parameters, CallbackInfo info) {
/* 38 */     RenderParticleEvent renderParticleEvent = new RenderParticleEvent(particleType);
/* 39 */     Cosmos.EVENT_BUS.post((Event)renderParticleEvent);
/*    */     
/* 41 */     if (renderParticleEvent.isCanceled()) {
/* 42 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"spawnEntity"}, at = {@At("RETURN")}, cancellable = true)
/*    */   public void onSpawnEntity(Entity entity, CallbackInfoReturnable<Boolean> info) {
/* 48 */     EntityWorldEvent.EntitySpawnEvent entitySpawnEvent = new EntityWorldEvent.EntitySpawnEvent(entity);
/* 49 */     Cosmos.EVENT_BUS.post((Event)entitySpawnEvent);
/*    */     
/* 51 */     if (entitySpawnEvent.isCanceled()) {
/* 52 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"removeEntity"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onRemoveEntity(Entity entity, CallbackInfo info) {
/* 58 */     EntityWorldEvent.EntityRemoveEvent entityRemoveEvent = new EntityWorldEvent.EntityRemoveEvent(entity);
/* 59 */     Cosmos.EVENT_BUS.post((Event)entityRemoveEvent);
/*    */     
/* 61 */     if (entityRemoveEvent.isCanceled()) {
/* 62 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"removeEntityDangerously"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onRemoveEntityDangerously(Entity entity, CallbackInfo info) {
/* 68 */     EntityWorldEvent.EntityRemoveEvent entityRemoveEvent = new EntityWorldEvent.EntityRemoveEvent(entity);
/* 69 */     Cosmos.EVENT_BUS.post((Event)entityRemoveEvent);
/*    */     
/* 71 */     if (entityRemoveEvent.isCanceled()) {
/* 72 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"updateEntity"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onUpdateEntity(Entity entity, CallbackInfo info) {
/* 78 */     EntityWorldEvent.EntityUpdateEvent entityUpdateEvent = new EntityWorldEvent.EntityUpdateEvent(entity);
/* 79 */     Cosmos.EVENT_BUS.post((Event)entityUpdateEvent);
/*    */     
/* 81 */     if (entityUpdateEvent.isCanceled()) {
/* 82 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"getSkyColor"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onGetSkyColorBody(Entity entityIn, float partialTicks, CallbackInfoReturnable<Vec3d> infoReturnable) {
/* 88 */     RenderSkyEvent renderSkyEvent = new RenderSkyEvent();
/* 89 */     Cosmos.EVENT_BUS.post((Event)renderSkyEvent);
/*    */     
/* 91 */     if (renderSkyEvent.isCanceled()) {
/* 92 */       infoReturnable.cancel();
/* 93 */       infoReturnable.setReturnValue(new Vec3d(renderSkyEvent.getColor().getRed() / 255.0D, renderSkyEvent.getColor().getGreen() / 255.0D, renderSkyEvent.getColor().getBlue() / 255.0D));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\world\MixinWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */