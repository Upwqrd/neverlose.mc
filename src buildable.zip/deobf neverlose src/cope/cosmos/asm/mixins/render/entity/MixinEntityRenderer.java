//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.asm.mixins.render.entity;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.render.other.CameraClipEvent;
/*     */ import cope.cosmos.client.events.render.player.CrosshairBobEvent;
/*     */ import cope.cosmos.client.events.render.player.HurtCameraEvent;
/*     */ import cope.cosmos.client.events.render.player.RenderItemActivationEvent;
/*     */ import cope.cosmos.client.events.render.world.RenderFogEvent;
/*     */ import cope.cosmos.client.events.render.world.RenderWorldEvent;
/*     */ import net.minecraft.client.renderer.EntityRenderer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({EntityRenderer.class})
/*     */ public abstract class MixinEntityRenderer {
/*     */   @Shadow
/*     */   private ItemStack itemActivationItem;
/*     */   
/*     */   @Inject(method = {"renderWorld"}, at = {@At("RETURN")})
/*     */   private void renderWorld(CallbackInfo info) {
/*  29 */     RenderWorldEvent renderWorldEvent = new RenderWorldEvent();
/*  30 */     Cosmos.EVENT_BUS.post((Event)renderWorldEvent);
/*     */   }
/*     */   
/*     */   @Inject(method = {"setupFog"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onSetupFog(int startCoords, float partialTicks, CallbackInfo info) {
/*  35 */     RenderFogEvent renderFogEvent = new RenderFogEvent();
/*  36 */     Cosmos.EVENT_BUS.post((Event)renderFogEvent);
/*     */     
/*  38 */     if (renderFogEvent.isCanceled()) {
/*  39 */       info.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"hurtCameraEffect"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void hurtCameraEffect(float ticks, CallbackInfo info) {
/*  45 */     HurtCameraEvent hurtCameraEvent = new HurtCameraEvent();
/*  46 */     Cosmos.EVENT_BUS.post((Event)hurtCameraEvent);
/*     */     
/*  48 */     if (hurtCameraEvent.isCanceled()) {
/*  49 */       info.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @ModifyVariable(method = {"orientCamera"}, at = @At("STORE"), ordinal = 3)
/*     */   private double onOrientCameraX(double range) {
/*  71 */     CameraClipEvent cameraClipEvent = new CameraClipEvent(range);
/*  72 */     Cosmos.EVENT_BUS.post((Event)cameraClipEvent);
/*     */     
/*  74 */     return cameraClipEvent.getDistance();
/*     */   }
/*     */   
/*     */   @ModifyVariable(method = {"orientCamera"}, at = @At("STORE"), ordinal = 7)
/*     */   private double onOrientCameraZ(double range) {
/*  79 */     CameraClipEvent cameraClipEvent = new CameraClipEvent(range);
/*  80 */     Cosmos.EVENT_BUS.post((Event)cameraClipEvent);
/*     */     
/*  82 */     return cameraClipEvent.getDistance();
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderItemActivation"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onRenderItemActivation(CallbackInfo info) {
/*  87 */     RenderItemActivationEvent renderItemActivationEvent = new RenderItemActivationEvent();
/*  88 */     Cosmos.EVENT_BUS.post((Event)renderItemActivationEvent);
/*     */     
/*  90 */     if (this.itemActivationItem != null && this.itemActivationItem.getItem().equals(Items.TOTEM_OF_UNDYING) && 
/*  91 */       renderItemActivationEvent.isCanceled()) {
/*  92 */       info.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Shadow
/*     */   protected abstract void applyBobbing(float paramFloat);
/*     */   
/*     */   @Redirect(method = {"setupCameraTransform"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/EntityRenderer;applyBobbing(F)V", remap = false))
/*     */   public void onSetupCameraTransform(EntityRenderer instance, float f) {
/* 102 */     CrosshairBobEvent crosshairBobEvent = new CrosshairBobEvent();
/* 103 */     Cosmos.EVENT_BUS.post((Event)crosshairBobEvent);
/*     */ 
/*     */     
/* 106 */     if (!crosshairBobEvent.isCanceled())
/* 107 */       applyBobbing(f); 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\entity\MixinEntityRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
