//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.entity;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.RenderLivingEntityEvent;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({RenderLivingBase.class})
/*    */ public abstract class MixinRenderLivingBase {
/*    */   @Shadow
/*    */   protected ModelBase mainModel;
/*    */   
/*    */   @Redirect(method = {"renderModel"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
/*    */   private void onRenderModelPreEntityLivingBase(ModelBase modelBase, Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 24 */     RenderLivingEntityEvent.RenderLivingEntityPreEvent renderLivingEntityPreEvent = new RenderLivingEntityEvent.RenderLivingEntityPreEvent(this.mainModel, (EntityLivingBase)entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/* 25 */     Cosmos.EVENT_BUS.post((Event)renderLivingEntityPreEvent);
/*    */     
/* 27 */     if (!renderLivingEntityPreEvent.isCanceled()) {
/* 28 */       modelBase.render(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderModel"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private void onRenderModelPost(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, CallbackInfo info) {
/* 34 */     RenderLivingEntityEvent.RenderLivingEntityPostEvent renderLivingEntityPostEvent = new RenderLivingEntityEvent.RenderLivingEntityPostEvent(this.mainModel, entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor);
/* 35 */     Cosmos.EVENT_BUS.post((Event)renderLivingEntityPostEvent);
/*    */     
/* 37 */     if (renderLivingEntityPostEvent.isCanceled())
/* 38 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\entity\MixinRenderLivingBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
