//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.entity;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.RenderNametagEvent;
/*    */ import cope.cosmos.client.events.render.entity.RenderRotationsEvent;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({RenderPlayer.class})
/*    */ public class MixinRenderPlayer implements Wrapper {
/*    */   private float renderPitch;
/*    */   private float renderYaw;
/*    */   private float renderHeadYaw;
/*    */   
/*    */   @Inject(method = {"doRender"}, at = {@At("HEAD")})
/*    */   private void doRenderPre(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 22 */     if (mc.player.equals(entity)) {
/* 23 */       this.prevRenderHeadYaw = entity.prevRotationYawHead;
/* 24 */       this.prevRenderPitch = entity.prevRotationPitch;
/* 25 */       this.renderPitch = entity.rotationPitch;
/* 26 */       this.renderYaw = entity.rotationYaw;
/* 27 */       this.renderHeadYaw = entity.rotationYawHead;
/* 28 */       this.prevPrevRenderYawOffset = entity.prevRenderYawOffset;
/* 29 */       this.prevRenderYawOffset = entity.renderYawOffset;
/*    */       
/* 31 */       RenderRotationsEvent renderRotationsEvent = new RenderRotationsEvent();
/* 32 */       Cosmos.EVENT_BUS.post((Event)renderRotationsEvent);
/*    */       
/* 34 */       if (renderRotationsEvent.isCanceled()) {
/*    */         
/* 36 */         entity.rotationYaw = renderRotationsEvent.getYaw();
/* 37 */         entity.rotationYawHead = renderRotationsEvent.getYaw();
/* 38 */         entity.prevRotationYawHead = renderRotationsEvent.getYaw();
/* 39 */         entity.prevRenderYawOffset = renderRotationsEvent.getYaw();
/* 40 */         entity.renderYawOffset = renderRotationsEvent.getYaw();
/* 41 */         entity.rotationPitch = renderRotationsEvent.getPitch();
/* 42 */         entity.prevRotationPitch = renderRotationsEvent.getPitch();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   private float prevRenderHeadYaw; private float prevRenderPitch; private float prevRenderYawOffset; private float prevPrevRenderYawOffset;
/*    */   @Inject(method = {"doRender"}, at = {@At("RETURN")})
/*    */   private void doRenderPost(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 49 */     if (mc.player.equals(entity)) {
/* 50 */       entity.rotationPitch = this.renderPitch;
/* 51 */       entity.rotationYaw = this.renderYaw;
/* 52 */       entity.rotationYawHead = this.renderHeadYaw;
/* 53 */       entity.prevRotationYawHead = this.prevRenderHeadYaw;
/* 54 */       entity.prevRotationPitch = this.prevRenderPitch;
/* 55 */       entity.renderYawOffset = this.prevRenderYawOffset;
/* 56 */       entity.prevRenderYawOffset = this.prevPrevRenderYawOffset;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderEntityName"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderNametag(AbstractClientPlayer entityIn, double x, double y, double z, String name, double distanceSq, CallbackInfo info) {
/* 62 */     RenderNametagEvent renderNametagEvent = new RenderNametagEvent();
/* 63 */     Cosmos.EVENT_BUS.post((Event)renderNametagEvent);
/*    */     
/* 65 */     if (renderNametagEvent.isCanceled())
/* 66 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\entity\MixinRenderPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
