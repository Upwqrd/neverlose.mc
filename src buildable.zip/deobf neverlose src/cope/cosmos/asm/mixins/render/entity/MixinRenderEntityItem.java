//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.entity;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.RenderEntityItemEvent;
/*    */ import cope.cosmos.client.events.render.entity.RenderItemEvent;
/*    */ import net.minecraft.client.renderer.RenderItem;
/*    */ import net.minecraft.client.renderer.entity.RenderEntityItem;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({RenderEntityItem.class})
/*    */ public class MixinRenderEntityItem {
/*    */   @Shadow
/*    */   @Final
/*    */   private RenderItem itemRenderer;
/*    */   
/*    */   @Inject(method = {"doRender"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onDoRenderHead(EntityItem entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 25 */     RenderItemEvent renderItemEvent = new RenderItemEvent(entity, x, y, z, entityYaw, partialTicks);
/* 26 */     Cosmos.EVENT_BUS.post((Event)renderItemEvent);
/*    */     
/* 28 */     if (renderItemEvent.isCanceled()) {
/* 29 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"doRender"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderItem;renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V")}, cancellable = true)
/*    */   public void onDoRender(EntityItem entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 35 */     RenderEntityItemEvent renderEntityItemEvent = new RenderEntityItemEvent(this.itemRenderer, entity, x, y, z, entityYaw, partialTicks);
/* 36 */     Cosmos.EVENT_BUS.post((Event)renderEntityItemEvent);
/*    */     
/* 38 */     if (renderEntityItemEvent.isCanceled())
/* 39 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\entity\MixinRenderEntityItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
