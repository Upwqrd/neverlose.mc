//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.entity;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.CrystalTextureEvent;
/*    */ import cope.cosmos.client.events.render.entity.RenderCrystalEvent;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderEnderCrystal;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityEnderCrystal;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin(value = {RenderEnderCrystal.class}, priority = 2147483646)
/*    */ public class MixinRenderEnderCrystal
/*    */ {
/*    */   @Final
/*    */   @Shadow
/*    */   private static ResourceLocation ENDER_CRYSTAL_TEXTURES;
/*    */   @Final
/*    */   @Shadow
/*    */   private ModelBase modelEnderCrystal;
/*    */   @Final
/*    */   @Shadow
/*    */   private ModelBase modelEnderCrystalNoBase;
/*    */   
/*    */   @Redirect(method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
/*    */   private void onDoRenderPre(ModelBase modelBase, Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 36 */     RenderCrystalEvent.RenderCrystalPreEvent renderCrystalEvent = new RenderCrystalEvent.RenderCrystalPreEvent(modelBase, entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/* 37 */     Cosmos.EVENT_BUS.post((Event)renderCrystalEvent);
/*    */     
/* 39 */     if (!renderCrystalEvent.isCanceled()) {
/* 40 */       modelBase.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/*    */     }
/*    */     
/* 43 */     CrystalTextureEvent crystalTextureEvent = new CrystalTextureEvent();
/* 44 */     Cosmos.EVENT_BUS.post((Event)crystalTextureEvent);
/*    */   }
/*    */   
/*    */   @Inject(method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"}, at = {@At("RETURN")}, cancellable = true)
/*    */   public void onDoRenderPost(EntityEnderCrystal entityEnderCrystal, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo info) {
/* 49 */     RenderCrystalEvent.RenderCrystalPostEvent renderCrystalEvent = new RenderCrystalEvent.RenderCrystalPostEvent(this.modelEnderCrystal, this.modelEnderCrystalNoBase, entityEnderCrystal, x, y, z, entityYaw, partialTicks);
/* 50 */     Cosmos.EVENT_BUS.post((Event)renderCrystalEvent);
/*    */     
/* 52 */     if (renderCrystalEvent.isCanceled())
/* 53 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\entity\MixinRenderEnderCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
