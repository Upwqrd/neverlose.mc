/*    */ package cope.cosmos.asm.mixins.render.item;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.player.RenderEatingEvent;
/*    */ import cope.cosmos.client.events.render.player.RenderHeldItemEvent;
/*    */ import net.minecraft.client.renderer.ItemRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({ItemRenderer.class})
/*    */ public class MixinItemRenderer
/*    */ {
/*    */   @Inject(method = {"transformEatFirstPerson"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onTransformEat(float p_187454_1_, EnumHandSide handSide, ItemStack stack, CallbackInfo info) {
/* 20 */     RenderEatingEvent renderEatingEvent = new RenderEatingEvent();
/* 21 */     Cosmos.EVENT_BUS.post((Event)renderEatingEvent);
/*    */     
/* 23 */     if (renderEatingEvent.isCanceled()) {
/* 24 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformFirstPerson"}, at = {@At("HEAD")})
/*    */   public void onTransformFirstPersonPre(EnumHandSide handSide, float p_187459_2_, CallbackInfo info) {
/* 30 */     Cosmos.EVENT_BUS.post((Event)new RenderHeldItemEvent.Pre(handSide));
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformFirstPerson"}, at = {@At("HEAD")})
/*    */   public void onTransformFirstPersonPost(EnumHandSide handSide, float p_187459_2_, CallbackInfo info) {
/* 35 */     Cosmos.EVENT_BUS.post((Event)new RenderHeldItemEvent.Post(handSide));
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformSideFirstPerson"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onTransformSideFirstPerson(EnumHandSide handSide, float p_187459_2_, CallbackInfo info) {
/* 40 */     RenderHeldItemEvent.Pre renderHeldItemEvent = new RenderHeldItemEvent.Pre(handSide);
/* 41 */     Cosmos.EVENT_BUS.post((Event)renderHeldItemEvent);
/*    */     
/* 43 */     if (renderHeldItemEvent.isCanceled())
/* 44 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\item\MixinItemRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */