/*    */ package cope.cosmos.asm.mixins.render.item;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.LayerArmorEvent;
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
/*    */ import net.minecraft.inventory.EntityEquipmentSlot;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({LayerBipedArmor.class})
/*    */ public class MixinLayerBipedArmor
/*    */ {
/*    */   @Inject(method = {"setModelSlotVisible"}, at = {@At("HEAD")}, cancellable = true)
/*    */   protected void setModelSlotVisible(ModelBiped model, EntityEquipmentSlot slotIn, CallbackInfo info) {
/* 19 */     LayerArmorEvent layerArmorEvent = new LayerArmorEvent(model, slotIn);
/* 20 */     Cosmos.EVENT_BUS.post((Event)layerArmorEvent);
/*    */     
/* 22 */     if (layerArmorEvent.isCanceled())
/* 23 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\item\MixinLayerBipedArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */