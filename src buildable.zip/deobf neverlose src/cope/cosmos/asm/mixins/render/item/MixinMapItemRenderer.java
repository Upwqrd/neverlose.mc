/*    */ package cope.cosmos.asm.mixins.render.item;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.other.RenderMapEvent;
/*    */ import net.minecraft.client.gui.MapItemRenderer;
/*    */ import net.minecraft.world.storage.MapData;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({MapItemRenderer.class})
/*    */ public class MixinMapItemRenderer
/*    */ {
/*    */   @Inject(method = {"renderMap"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderMap(MapData mapdataIn, boolean noOverlayRendering, CallbackInfo info) {
/* 18 */     RenderMapEvent renderMapEvent = new RenderMapEvent();
/* 19 */     Cosmos.EVENT_BUS.post((Event)renderMapEvent);
/*    */     
/* 21 */     if (renderMapEvent.isCanceled())
/* 22 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\item\MixinMapItemRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */