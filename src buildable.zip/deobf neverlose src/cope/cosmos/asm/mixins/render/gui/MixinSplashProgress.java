/*    */ package cope.cosmos.asm.mixins.render.gui;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import net.minecraftforge.fml.client.SplashProgress;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({SplashProgress.class})
/*    */ public class MixinSplashProgress
/*    */ {
/*    */   @Inject(method = {"start"}, at = {@At("HEAD")}, cancellable = true, remap = false)
/*    */   private static void start(CallbackInfo ci) {
/*    */     try {
/* 18 */       Method method = SplashProgress.class.getDeclaredMethod("disableSplash", new Class[0]);
/* 19 */       method.setAccessible(true);
/* 20 */       method.invoke((Object)null, new Object[0]);
/* 21 */     } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {}
/*    */ 
/*    */ 
/*    */     
/* 25 */     ci.cancel();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\gui\MixinSplashProgress.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */