//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.gui;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.network.ConnectEvent;
/*    */ import cope.cosmos.client.ui.altgui.AltManagerGUI;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.GuiMultiplayer;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.client.multiplayer.ServerData;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({GuiMultiplayer.class})
/*    */ public class MixinGuiMultiplayer extends GuiScreen {
/*    */   @Inject(method = {"initGui"}, at = {@At("RETURN")})
/*    */   public void initGui(CallbackInfo info) {
/* 20 */     this.buttonList.add(new GuiButton(417, 7, 7, 60, 20, "Alts"));
/*    */   }
/*    */   
/*    */   @Inject(method = {"actionPerformed"}, at = {@At("RETURN")})
/*    */   public void actionPerformed(GuiButton button, CallbackInfo info) {
/* 25 */     if (button.id == 417) {
/* 26 */       this.mc.displayGuiScreen((GuiScreen)new AltManagerGUI(this));
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"connectToServer"}, at = {@At("HEAD")})
/*    */   public void onConnectToServer(ServerData server, CallbackInfo info) {
/* 32 */     ConnectEvent connectEvent = new ConnectEvent();
/* 33 */     Cosmos.EVENT_BUS.post((Event)connectEvent);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\gui\MixinGuiMultiplayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
