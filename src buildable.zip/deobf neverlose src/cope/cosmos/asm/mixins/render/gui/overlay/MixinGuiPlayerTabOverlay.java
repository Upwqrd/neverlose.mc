//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render.gui.overlay;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.gui.TabListSizeEvent;
/*    */ import cope.cosmos.client.events.render.gui.TabOverlayEvent;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.GuiPlayerTabOverlay;
/*    */ import net.minecraft.client.network.NetworkPlayerInfo;
/*    */ import net.minecraft.scoreboard.ScorePlayerTeam;
/*    */ import net.minecraft.scoreboard.Team;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({GuiPlayerTabOverlay.class})
/*    */ public class MixinGuiPlayerTabOverlay {
/*    */   @Redirect(method = {"renderPlayerlist"}, at = @At(value = "INVOKE", target = "Ljava/util/List;subList(II)Ljava/util/List;", remap = false))
/*    */   public List<NetworkPlayerInfo> renderPlayerList(List<NetworkPlayerInfo> list, int fromIndex, int toIndex) {
/* 22 */     TabListSizeEvent tabListSizeEvent = new TabListSizeEvent();
/* 23 */     Cosmos.EVENT_BUS.post((Event)tabListSizeEvent);
/*    */     
/* 25 */     if (tabListSizeEvent.isCanceled()) {
/* 26 */       return list.subList(0, list.size());
/*    */     }
/*    */ 
/*    */     
/* 30 */     return list.subList(0, Math.min(list.size(), 80));
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"getPlayerName"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getPlayerName(NetworkPlayerInfo networkPlayerInfoIn, CallbackInfoReturnable<String> info) {
/* 36 */     TabOverlayEvent tabOverlayEvent = new TabOverlayEvent((networkPlayerInfoIn.getDisplayName() != null) ? networkPlayerInfoIn.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName((Team)networkPlayerInfoIn.getPlayerTeam(), networkPlayerInfoIn.getGameProfile().getName()));
/* 37 */     Cosmos.EVENT_BUS.post((Event)tabOverlayEvent);
/*    */     
/* 39 */     if (tabOverlayEvent.isCanceled()) {
/* 40 */       info.cancel();
/* 41 */       info.setReturnValue(tabOverlayEvent.getInformation());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\gui\overlay\MixinGuiPlayerTabOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
