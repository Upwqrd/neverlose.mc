/*    */ package cope.cosmos.asm.mixins.render.gui;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.gui.RenderFontEvent;
/*    */ import cope.cosmos.util.render.FontUtil;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ @Mixin({FontRenderer.class})
/*    */ public class MixinFontRenderer
/*    */ {
/*    */   @Inject(method = {"drawString(Ljava/lang/String;FFIZ)I"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderString(String text, float x, float y, int color, boolean dropShadow, CallbackInfoReturnable<Integer> info) {
/* 19 */     RenderFontEvent renderFontEvent = new RenderFontEvent();
/* 20 */     Cosmos.EVENT_BUS.post((Event)renderFontEvent);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 43 */     if (renderFontEvent.isCanceled()) {
/* 44 */       info.setReturnValue(Integer.valueOf(FontUtil.getFontString(text, x, y, color)));
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"getStringWidth"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getWidth(String text, CallbackInfoReturnable<Integer> info) {
/* 50 */     RenderFontEvent renderFontEvent = new RenderFontEvent();
/* 51 */     Cosmos.EVENT_BUS.post((Event)renderFontEvent);
/*    */     
/* 53 */     if (renderFontEvent.isCanceled())
/* 54 */       info.setReturnValue(Integer.valueOf(FontUtil.getStringWidth(text))); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\gui\MixinFontRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */