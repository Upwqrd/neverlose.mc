/*    */ package cope.cosmos.asm.mixins.render.gui;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.gui.tooltip.RenderTooltipEvent;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({GuiScreen.class})
/*    */ public class MixinGuiScreen {
/*    */   @Inject(method = {"renderToolTip"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onRenderToolTip(ItemStack stack, int x, int y, CallbackInfo info) {
/* 17 */     RenderTooltipEvent renderTooltipEvent = new RenderTooltipEvent(stack, x, y);
/* 18 */     Cosmos.EVENT_BUS.post((Event)renderTooltipEvent);
/*    */     
/* 20 */     if (renderTooltipEvent.isCanceled())
/* 21 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\gui\MixinGuiScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */