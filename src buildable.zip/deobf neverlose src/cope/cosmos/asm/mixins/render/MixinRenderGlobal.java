/*    */ package cope.cosmos.asm.mixins.render;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.player.RenderSelectionBoxEvent;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.client.renderer.RenderGlobal;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderGlobal.class})
/*    */ public class MixinRenderGlobal
/*    */   implements Wrapper
/*    */ {
/*    */   @Inject(method = {"drawSelectionBox"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void drawSelectionBox(EntityPlayer player, RayTraceResult movingObjectPositionIn, int execute, float partialTicks, CallbackInfo info) {
/* 24 */     RenderSelectionBoxEvent renderSelectionBoxEvent = new RenderSelectionBoxEvent();
/* 25 */     Cosmos.EVENT_BUS.post((Event)renderSelectionBoxEvent);
/*    */     
/* 27 */     if (renderSelectionBoxEvent.isCanceled())
/* 28 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\MixinRenderGlobal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */