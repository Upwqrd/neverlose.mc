//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.asm.mixins.render;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.block.ColorMultiplierEvent;
/*    */ import java.nio.ByteOrder;
/*    */ import java.nio.IntBuffer;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin({BufferBuilder.class})
/*    */ public abstract class MixinBufferBuilder
/*    */ {
/*    */   @Shadow
/*    */   private boolean noColor;
/*    */   @Shadow
/*    */   private IntBuffer rawIntBuffer;
/*    */   
/*    */   @Shadow
/*    */   public abstract int getColorIndex(int paramInt);
/*    */   
/*    */   @Inject(method = {"putColorMultiplier"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void putColorMultiplier(float red, float green, float blue, int vertexIndex, CallbackInfo info) {
/* 29 */     ColorMultiplierEvent colorMultiplierEvent = new ColorMultiplierEvent(0);
/* 30 */     Cosmos.EVENT_BUS.post((Event)colorMultiplierEvent);
/*    */     
/* 32 */     if (colorMultiplierEvent.isCanceled()) {
/* 33 */       info.cancel();
/*    */       
/* 35 */       int i = getColorIndex(vertexIndex);
/* 36 */       int j = -1;
/*    */       
/* 38 */       if (!this.noColor) {
/* 39 */         j = this.rawIntBuffer.get(i);
/*    */         
/* 41 */         if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
/* 42 */           int k = (int)((j & 0xFF) * red);
/* 43 */           int l = (int)((j >> 8 & 0xFF) * green);
/* 44 */           int i1 = (int)((j >> 16 & 0xFF) * blue);
/* 45 */           j &= 0xFF000000;
/* 46 */           j = j | i1 << 16 | l << 8 | k;
/*    */         }
/*    */         else {
/*    */           
/* 50 */           int j1 = (int)((j >> 24 & 0xFF) * red);
/* 51 */           int k1 = (int)((j >> 16 & 0xFF) * green);
/* 52 */           int l1 = (int)((j >> 8 & 0xFF) * blue);
/* 53 */           j &= 0xFF;
/* 54 */           j = j | j1 << 24 | k1 << 16 | l1 << 8;
/*    */         } 
/*    */       } 
/*    */       
/* 58 */       this.rawIntBuffer.put(i, j & 0xFFFFFF | colorMultiplierEvent.getOpacity() << 24);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\MixinBufferBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
