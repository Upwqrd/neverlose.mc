/*    */ package cope.cosmos.asm.mixins.render.tile;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.render.entity.RenderBeaconBeamEvent;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityBeaconRenderer;
/*    */ import net.minecraft.tileentity.TileEntityBeacon;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({TileEntityBeaconRenderer.class})
/*    */ public class MixinTileEntityBeaconRenderer
/*    */ {
/*    */   @Inject(method = {"render"}, at = {@At("INVOKE")}, cancellable = true)
/*    */   private void renderBeaconBeam(TileEntityBeacon tileEntityBeacon, double x, double y, double z, float partialTicks, int destroyStage, float alpha, CallbackInfo info) {
/* 18 */     RenderBeaconBeamEvent renderBeaconBeamEvent = new RenderBeaconBeamEvent();
/* 19 */     Cosmos.EVENT_BUS.post((Event)renderBeaconBeamEvent);
/*    */     
/* 21 */     if (renderBeaconBeamEvent.isCanceled())
/* 22 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\asm\mixins\render\tile\MixinTileEntityBeaconRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */