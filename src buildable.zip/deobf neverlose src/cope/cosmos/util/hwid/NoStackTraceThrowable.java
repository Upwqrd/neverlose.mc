/*    */ package cope.cosmos.util.hwid;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ 
/*    */ public class NoStackTraceThrowable
/*    */   extends RuntimeException {
/*    */   public NoStackTraceThrowable(String msg) {
/*  8 */     super(msg);
/*  9 */     setStackTrace(new StackTraceElement[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 14 */     return "" + Cosmos.getVersion();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized Throwable fillInStackTrace() {
/* 19 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\hwid\NoStackTraceThrowable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */