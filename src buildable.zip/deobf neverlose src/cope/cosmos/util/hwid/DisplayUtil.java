/*    */ package cope.cosmos.util.hwid;
/*    */ 
/*    */ import cope.cosmos.client.security.login.ErrorLogin;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.datatransfer.Clipboard;
/*    */ import java.awt.datatransfer.StringSelection;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ public class DisplayUtil {
/*    */   public static void Display() {
/* 13 */     Frame frame = new Frame();
/* 14 */     frame.setVisible(false);
/* 15 */     throw new NoStackTraceThrowable("Verification was unsuccessful!");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Frame
/*    */     extends JFrame
/*    */   {
/*    */     public Frame() {
/* 24 */       setTitle("Verification failed.");
/* 25 */       setDefaultCloseOperation(2);
/* 26 */       setLocationRelativeTo(null);
/* 27 */       copyToClipboard();
/* 28 */       String message = "Sorry, you are not on the HWID list.\nHWID: " + SystemUtil.getSystemInfo() + "\n(Copied to clipboard.)";
/* 29 */       JOptionPane.showMessageDialog(this, message, "Could not verify your HWID successfully.", -1, UIManager.getIcon("OptionPane.errorIcon"));
/* 30 */       ErrorLogin.error_startup();
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static void copyToClipboard() {
/* 38 */       StringSelection selection = new StringSelection(SystemUtil.getSystemInfo());
/* 39 */       Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 40 */       clipboard.setContents(selection, selection);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\hwid\DisplayUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */