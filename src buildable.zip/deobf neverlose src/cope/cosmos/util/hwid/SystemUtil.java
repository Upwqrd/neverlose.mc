//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.hwid;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.apache.commons.codec.digest.DigestUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemUtil
/*    */ {
/*    */   public static String getSystemInfo() {
/* 21 */     return DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + 
/* 22 */           System.getProperty("os.name") + 
/* 23 */           System.getProperty("os.arch") + 
/* 24 */           System.getProperty("user.name") + 
/* 25 */           System.getenv("SystemRoot") + 
/* 26 */           System.getenv("HOMEDRIVE") + 
/* 27 */           System.getenv("PROCESSOR_LEVEL") + 
/* 28 */           System.getenv("PROCESSOR_REVISION") + 
/* 29 */           System.getenv("PROCESSOR_IDENTIFIER") + 
/* 30 */           System.getenv("PROCESSOR_ARCHITECTURE") + 
/* 31 */           System.getenv("PROCESSOR_ARCHITEW6432") + 
/* 32 */           System.getenv("NUMBER_OF_PROCESSORS"))) + 
/* 33 */       Minecraft.getMinecraft().getSession().getUsername();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\hwid\SystemUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
