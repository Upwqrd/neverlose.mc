/*    */ package cope.cosmos.util.hwid;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLReader
/*    */ {
/*    */   public static List<String> readURL() {
/* 18 */     List<String> s = new ArrayList<>();
/*    */     try {
/* 20 */       URL url = new URL("https://pastebin.com/raw/7Rn4nekT");
/* 21 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
/*    */       String hwid;
/* 23 */       while ((hwid = bufferedReader.readLine()) != null) {
/* 24 */         s.add(hwid);
/*    */       }
/* 26 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 34 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\hwid\URLReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */