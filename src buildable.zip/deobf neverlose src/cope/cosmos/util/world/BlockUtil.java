//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.world;
/*     */ 
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockUtil
/*     */   implements Wrapper
/*     */ {
/*  25 */   public static final List<Block> resistantBlocks = Arrays.asList(new Block[] { Blocks.OBSIDIAN, Blocks.ANVIL, Blocks.ENCHANTING_TABLE, Blocks.ENDER_CHEST, (Block)Blocks.BEACON });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static final List<Block> unbreakableBlocks = Arrays.asList(new Block[] { Blocks.BEDROCK, Blocks.COMMAND_BLOCK, Blocks.CHAIN_COMMAND_BLOCK, Blocks.END_PORTAL_FRAME, Blocks.BARRIER, (Block)Blocks.PORTAL });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBreakable(BlockPos position) {
/*  49 */     return !getResistance(position).equals(Resistance.UNBREAKABLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isReplaceable(BlockPos pos) {
/*  58 */     return mc.world.getBlockState(pos).getMaterial().isReplaceable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Resistance getResistance(BlockPos position) {
/*  69 */     Block block = mc.world.getBlockState(position).getBlock();
/*     */ 
/*     */     
/*  72 */     if (block != null) {
/*     */ 
/*     */       
/*  75 */       if (resistantBlocks.contains(block)) {
/*  76 */         return Resistance.RESISTANT;
/*     */       }
/*     */       
/*  79 */       if (unbreakableBlocks.contains(block)) {
/*  80 */         return Resistance.UNBREAKABLE;
/*     */       }
/*     */       
/*  83 */       if (block.getDefaultState().getMaterial().isReplaceable()) {
/*  84 */         return Resistance.REPLACEABLE;
/*     */       }
/*     */ 
/*     */       
/*  88 */       return Resistance.BREAKABLE;
/*     */     } 
/*     */ 
/*     */     
/*  92 */     return Resistance.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double getDistanceToCenter(EntityPlayer player, BlockPos in) {
/* 103 */     double dX = in.getX() + 0.5D - player.posX;
/* 104 */     double dY = in.getY() + 0.5D - player.posY;
/* 105 */     double dZ = in.getZ() + 0.5D - player.posZ;
/*     */ 
/*     */     
/* 108 */     return StrictMath.sqrt(dX * dX + dY * dY + dZ * dZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<BlockPos> getBlocksInArea(EntityPlayer player, AxisAlignedBB area) {
/* 118 */     if (player != null) {
/*     */ 
/*     */       
/* 121 */       List<BlockPos> blocks = new ArrayList<>();
/*     */ 
/*     */       
/* 124 */       for (double x = StrictMath.floor(area.minX); x <= StrictMath.ceil(area.maxX); x++) {
/* 125 */         double y; for (y = StrictMath.floor(area.minY); y <= StrictMath.ceil(area.maxY); y++) {
/* 126 */           double z; for (z = StrictMath.floor(area.minZ); z <= StrictMath.ceil(area.maxZ); z++) {
/*     */ 
/*     */             
/* 129 */             BlockPos position = player.getPosition().add(x, y, z);
/*     */ 
/*     */             
/* 132 */             if (getDistanceToCenter(player, position) < area.maxX)
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 137 */               blocks.add(position);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 142 */       return blocks;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Resistance
/*     */   {
/* 155 */     REPLACEABLE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     BREAKABLE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     RESISTANT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     UNBREAKABLE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\world\BlockUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
