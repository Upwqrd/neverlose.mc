/*    */ package cope.cosmos.util.chat;
/*    */ 
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChatUtil
/*    */ {
/*    */   public static String getPrefix() {
/* 18 */     return "[" + ChatFormatting.DARK_RED + "neverlose.mc" + ChatFormatting.WHITE + "] ";
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\chat\ChatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */