//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.combat;
/*     */ 
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.world.BlockUtil;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.CombatRules;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExplosionUtil
/*     */   implements Wrapper
/*     */ {
/*     */   public static float getDamageFromExplosion(Entity entity, Vec3d vector, boolean blockDestruction) {
/*  33 */     return calculateExplosionDamage(entity, vector, 6.0F, blockDestruction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float calculateExplosionDamage(Entity entity, Vec3d vector, float explosionSize, boolean blockDestruction) {
/*  47 */     double doubledExplosionSize = explosionSize * 2.0D;
/*     */ 
/*     */     
/*  50 */     double dist = entity.getDistance(vector.x, vector.y, vector.z) / doubledExplosionSize;
/*  51 */     if (dist > 1.0D) {
/*  52 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/*  56 */     double v = (1.0D - dist) * getBlockDensity(blockDestruction, vector, entity.getEntityBoundingBox());
/*     */ 
/*     */     
/*  59 */     float damage = CombatRules.getDamageAfterAbsorb(DamageUtil.getScaledDamage((float)((v * v + v) / 2.0D * 7.0D * doubledExplosionSize + 1.0D)), ((EntityLivingBase)entity).getTotalArmorValue(), (float)((EntityLivingBase)entity).getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
/*     */ 
/*     */     
/*  62 */     DamageSource damageSource = DamageSource.causeExplosionDamage(new Explosion(entity.world, entity, vector.x, vector.y, vector.z, (float)doubledExplosionSize, false, true));
/*     */ 
/*     */     
/*  65 */     int n = EnchantmentHelper.getEnchantmentModifierDamage(entity.getArmorInventoryList(), damageSource);
/*  66 */     if (n > 0) {
/*  67 */       damage = CombatRules.getDamageAfterMagicAbsorb(damage, n);
/*     */     }
/*     */ 
/*     */     
/*  71 */     if (((EntityLivingBase)entity).isPotionActive(MobEffects.RESISTANCE)) {
/*  72 */       PotionEffect potionEffect = ((EntityLivingBase)entity).getActivePotionEffect(MobEffects.RESISTANCE);
/*  73 */       if (potionEffect != null) {
/*  74 */         damage = damage * (25.0F - ((potionEffect.getAmplifier() + 1) * 5)) / 25.0F;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  79 */     return Math.max(damage, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double getBlockDensity(boolean blockDestruction, Vec3d vector, AxisAlignedBB bb) {
/*  92 */     double diffX = 1.0D / ((bb.maxX - bb.minX) * 2.0D + 1.0D);
/*  93 */     double diffY = 1.0D / ((bb.maxY - bb.minY) * 2.0D + 1.0D);
/*  94 */     double diffZ = 1.0D / ((bb.maxZ - bb.minZ) * 2.0D + 1.0D);
/*  95 */     double diffHorizontal = (1.0D - Math.floor(1.0D / diffX) * diffX) / 2.0D;
/*  96 */     double diffTranslational = (1.0D - Math.floor(1.0D / diffZ) * diffZ) / 2.0D;
/*     */ 
/*     */     
/*  99 */     if (diffX >= 0.0D && diffY >= 0.0D && diffZ >= 0.0D) {
/*     */ 
/*     */       
/* 102 */       float solid = 0.0F;
/* 103 */       float nonSolid = 0.0F;
/*     */       double x;
/* 105 */       for (x = 0.0D; x <= 1.0D; x += diffX) {
/* 106 */         double y; for (y = 0.0D; y <= 1.0D; y += diffY) {
/* 107 */           double z; for (z = 0.0D; z <= 1.0D; z += diffZ) {
/*     */ 
/*     */             
/* 110 */             double scaledDiffX = bb.minX + (bb.maxX - bb.minX) * x;
/* 111 */             double scaledDiffY = bb.minY + (bb.maxY - bb.minY) * y;
/* 112 */             double scaledDiffZ = bb.minZ + (bb.maxZ - bb.minZ) * z;
/*     */ 
/*     */             
/* 115 */             if (!isSolid(new Vec3d(scaledDiffX + diffHorizontal, scaledDiffY, scaledDiffZ + diffTranslational), vector, blockDestruction)) {
/* 116 */               solid++;
/*     */             }
/*     */ 
/*     */             
/* 120 */             nonSolid++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 125 */       return (solid / nonSolid);
/*     */     } 
/*     */ 
/*     */     
/* 129 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSolid(Vec3d start, Vec3d end, boolean blockDestruction) {
/* 146 */     if (!Double.isNaN(start.x) && !Double.isNaN(start.y) && !Double.isNaN(start.z) && 
/* 147 */       !Double.isNaN(end.x) && !Double.isNaN(end.y) && !Double.isNaN(end.z)) {
/*     */ 
/*     */       
/* 150 */       int currX = MathHelper.floor(start.x);
/* 151 */       int currY = MathHelper.floor(start.y);
/* 152 */       int currZ = MathHelper.floor(start.z);
/*     */ 
/*     */       
/* 155 */       int endX = MathHelper.floor(end.x);
/* 156 */       int endY = MathHelper.floor(end.y);
/* 157 */       int endZ = MathHelper.floor(end.z);
/*     */ 
/*     */       
/* 160 */       BlockPos blockPos = new BlockPos(currX, currY, currZ);
/* 161 */       IBlockState blockState = mc.world.getBlockState(blockPos);
/* 162 */       Block block = blockState.getBlock();
/*     */       
/* 164 */       if (blockState.getCollisionBoundingBox((IBlockAccess)mc.world, blockPos) != Block.NULL_AABB && block.canCollideCheck(blockState, false) && (BlockUtil.resistantBlocks.contains(block) || BlockUtil.unbreakableBlocks.contains(block) || !blockDestruction)) {
/* 165 */         RayTraceResult collisionInterCheck = blockState.collisionRayTrace((World)mc.world, blockPos, start, end);
/*     */ 
/*     */         
/* 168 */         if (collisionInterCheck != null) {
/* 169 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 174 */       double seDeltaX = end.x - start.x;
/* 175 */       double seDeltaY = end.y - start.y;
/* 176 */       double seDeltaZ = end.z - start.z;
/*     */ 
/*     */       
/* 179 */       int steps = 200;
/*     */ 
/*     */       
/* 182 */       while (steps-- >= 0) {
/*     */         EnumFacing facing;
/*     */         
/* 185 */         if (Double.isNaN(start.x) || Double.isNaN(start.y) || Double.isNaN(start.z)) {
/* 186 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 190 */         if (currX == endX && currY == endY && currZ == endZ) {
/* 191 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 195 */         boolean unboundedX = true;
/* 196 */         boolean unboundedY = true;
/* 197 */         boolean unboundedZ = true;
/*     */ 
/*     */         
/* 200 */         double stepX = 999.0D;
/* 201 */         double stepY = 999.0D;
/* 202 */         double stepZ = 999.0D;
/* 203 */         double deltaX = 999.0D;
/* 204 */         double deltaY = 999.0D;
/* 205 */         double deltaZ = 999.0D;
/*     */ 
/*     */         
/* 208 */         if (endX > currX) {
/* 209 */           stepX = (currX + 1);
/*     */ 
/*     */         
/*     */         }
/* 213 */         else if (endX < currX) {
/* 214 */           stepX = currX;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 219 */           unboundedX = false;
/*     */         } 
/*     */         
/* 222 */         if (endY > currY) {
/* 223 */           stepY = currY + 1.0D;
/*     */         
/*     */         }
/* 226 */         else if (endY < currY) {
/* 227 */           stepY = currY;
/*     */         }
/*     */         else {
/*     */           
/* 231 */           unboundedY = false;
/*     */         } 
/*     */         
/* 234 */         if (endZ > currZ) {
/* 235 */           stepZ = currZ + 1.0D;
/*     */         
/*     */         }
/* 238 */         else if (endZ < currZ) {
/* 239 */           stepZ = currZ;
/*     */         }
/*     */         else {
/*     */           
/* 243 */           unboundedZ = false;
/*     */         } 
/*     */ 
/*     */         
/* 247 */         if (unboundedX) {
/* 248 */           deltaX = (stepX - start.x) / seDeltaX;
/*     */         }
/*     */         
/* 251 */         if (unboundedY) {
/* 252 */           deltaY = (stepY - start.y) / seDeltaY;
/*     */         }
/*     */         
/* 255 */         if (unboundedZ) {
/* 256 */           deltaZ = (stepZ - start.z) / seDeltaZ;
/*     */         }
/*     */ 
/*     */         
/* 260 */         if (deltaX == 0.0D) {
/* 261 */           deltaX = -1.0E-4D;
/*     */         }
/*     */         
/* 264 */         if (deltaY == 0.0D) {
/* 265 */           deltaY = -1.0E-4D;
/*     */         }
/*     */         
/* 268 */         if (deltaZ == 0.0D) {
/* 269 */           deltaZ = -1.0E-4D;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 275 */         if (deltaX < deltaY && deltaX < deltaZ) {
/* 276 */           facing = (endX > currX) ? EnumFacing.WEST : EnumFacing.EAST;
/* 277 */           start = new Vec3d(stepX, start.y + seDeltaY * deltaX, start.z + seDeltaZ * deltaX);
/*     */         
/*     */         }
/* 280 */         else if (deltaY < deltaZ) {
/* 281 */           facing = (endY > currY) ? EnumFacing.DOWN : EnumFacing.UP;
/* 282 */           start = new Vec3d(start.x + seDeltaX * deltaY, stepY, start.z + seDeltaZ * deltaY);
/*     */         }
/*     */         else {
/*     */           
/* 286 */           facing = (endZ > currZ) ? EnumFacing.NORTH : EnumFacing.SOUTH;
/* 287 */           start = new Vec3d(start.x + seDeltaX * deltaZ, start.y + seDeltaY * deltaZ, stepZ);
/*     */         } 
/*     */ 
/*     */         
/* 291 */         currX = MathHelper.floor(start.x) - ((facing == EnumFacing.EAST) ? 1 : 0);
/* 292 */         currY = MathHelper.floor(start.y) - ((facing == EnumFacing.UP) ? 1 : 0);
/* 293 */         currZ = MathHelper.floor(start.z) - ((facing == EnumFacing.SOUTH) ? 1 : 0);
/*     */ 
/*     */         
/* 296 */         blockPos = new BlockPos(currX, currY, currZ);
/* 297 */         blockState = mc.world.getBlockState(blockPos);
/* 298 */         block = blockState.getBlock();
/*     */ 
/*     */         
/* 301 */         if (block.canCollideCheck(blockState, false) && (BlockUtil.resistantBlocks.contains(block) || BlockUtil.unbreakableBlocks.contains(block) || !blockDestruction)) {
/* 302 */           RayTraceResult collisionInterCheck = blockState.collisionRayTrace((World)mc.world, blockPos, start, end);
/*     */ 
/*     */           
/* 305 */           if (collisionInterCheck != null) {
/* 306 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\combat\ExplosionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
