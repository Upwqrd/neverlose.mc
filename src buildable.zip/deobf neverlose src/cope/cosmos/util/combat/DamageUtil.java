//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.combat;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.world.EnumDifficulty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DamageUtil
/*    */   implements Wrapper
/*    */ {
/*    */   public static float getScaledDamage(float damage) {
/* 19 */     WorldClient worldClient = mc.world;
/* 20 */     if (worldClient == null) {
/* 21 */       return damage;
/*    */     }
/*    */ 
/*    */     
/* 25 */     switch (mc.world.getDifficulty())
/*    */     { case PEACEFUL:
/* 27 */         return 0.0F;
/*    */       case EASY:
/* 29 */         return Math.min(damage / 2.0F + 1.0F, damage);
/*    */       
/*    */       default:
/* 32 */         return damage;
/*    */       case HARD:
/* 34 */         break; }  return damage * 3.0F / 2.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean canTakeDamage() {
/* 43 */     return !mc.player.capabilities.isCreativeMode;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\combat\DamageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
