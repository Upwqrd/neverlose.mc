//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.combat;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnemyUtil
/*    */   implements Wrapper
/*    */ {
/*    */   public static float getHealth(Entity entity) {
/* 23 */     if (entity instanceof EntityPlayer) {
/* 24 */       return ((EntityPlayer)entity).getHealth() + ((EntityPlayer)entity).getAbsorptionAmount();
/*    */     }
/*    */ 
/*    */     
/* 28 */     if (entity instanceof EntityLivingBase) {
/* 29 */       return ((EntityLivingBase)entity).getHealth() + ((EntityLivingBase)entity).getAbsorptionAmount();
/*    */     }
/*    */     
/* 32 */     return 0.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static float getArmor(Entity target) {
/* 41 */     if (target instanceof EntityPlayer) {
/*    */       
/* 43 */       float armorDurability = 0.0F;
/*    */ 
/*    */       
/* 46 */       for (ItemStack armor : target.getArmorInventoryList()) {
/* 47 */         if (armor != null && !armor.getItem().equals(Items.AIR)) {
/* 48 */           armorDurability += (armor.getMaxDamage() - armor.getItemDamage() / armor.getMaxDamage()) * 100.0F;
/*    */         }
/*    */       } 
/*    */       
/* 52 */       return armorDurability;
/*    */     } 
/*    */     
/* 55 */     return 0.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isDead(Entity entity) {
/* 64 */     return (getHealth(entity) <= 0.0F || entity.isDead);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\combat\EnemyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
