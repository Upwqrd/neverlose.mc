//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.render;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.client.FontModule;
/*     */ import cope.cosmos.font.FontRenderer;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.awt.Font;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FontUtil
/*     */   implements Wrapper
/*     */ {
/*     */   private static FontRenderer globalFont;
/*     */   
/*     */   public static void load() {
/*  17 */     globalFont = new FontRenderer(getFont("hindmadurai", 40.0F));
/*     */   }
/*     */   
/*     */   public static void drawStringWithShadow(String text, float x, float y, int color) {
/*  21 */     if (FontModule.INSTANCE.isEnabled()) {
/*  22 */       globalFont.drawStringWithShadow(text, x, y, color);
/*     */     }
/*     */     else {
/*     */       
/*  26 */       mc.fontRenderer.drawStringWithShadow(text, x, y, color);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void drawCenteredStringWithShadow(String text, float x, float y, int color) {
/*  31 */     if (FontModule.INSTANCE.isEnabled()) {
/*  32 */       globalFont.drawStringWithShadow(text, x - globalFont.getStringWidth(text) / 2.0F + 0.75F, y - globalFont.getHeight() / 2.0F + 2.0F, color);
/*     */     }
/*     */     else {
/*     */       
/*  36 */       mc.fontRenderer.drawStringWithShadow(text, x - mc.fontRenderer.getStringWidth(text) / 2.0F, y - mc.fontRenderer.FONT_HEIGHT / 2.0F, color);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getStringWidth(String text) {
/*  41 */     if (FontModule.INSTANCE.isEnabled()) {
/*  42 */       return globalFont.getStringWidth(text);
/*     */     }
/*     */     
/*  45 */     return mc.fontRenderer.getStringWidth(text);
/*     */   }
/*     */   
/*     */   public static float getFontHeight() {
/*  49 */     return mc.fontRenderer.FONT_HEIGHT;
/*     */   }
/*     */   
/*     */   public static List<String> wrapWords(String text, double width) {
/*  53 */     ArrayList<String> finalWords = new ArrayList<>();
/*     */     
/*  55 */     if (getStringWidth(text) > width) {
/*  56 */       String[] words = text.split(" ");
/*  57 */       StringBuilder currentWord = new StringBuilder();
/*  58 */       char lastColorCode = Character.MAX_VALUE;
/*     */       
/*  60 */       for (String word : words) {
/*  61 */         for (int innerIndex = 0; innerIndex < (word.toCharArray()).length; innerIndex++) {
/*  62 */           char c = word.toCharArray()[innerIndex];
/*     */           
/*  64 */           if (c == '§' && innerIndex < (word.toCharArray()).length - 1) {
/*  65 */             lastColorCode = word.toCharArray()[innerIndex + 1];
/*     */           }
/*     */         } 
/*     */         
/*  69 */         if (getStringWidth(currentWord + word + " ") < width) {
/*  70 */           currentWord.append(word).append(" ");
/*     */         } else {
/*  72 */           finalWords.add(currentWord.toString());
/*  73 */           currentWord = new StringBuilder("§" + lastColorCode + word + " ");
/*     */         } 
/*     */       } 
/*     */       
/*  77 */       if (currentWord.length() > 0) {
/*  78 */         if (getStringWidth(currentWord.toString()) < width) {
/*  79 */           finalWords.add("§" + lastColorCode + currentWord + " ");
/*  80 */           currentWord = new StringBuilder();
/*     */         } else {
/*  82 */           finalWords.addAll(formatString(currentWord.toString(), width));
/*     */         } 
/*     */       }
/*     */     } else {
/*  86 */       finalWords.add(text);
/*     */     } 
/*     */     
/*  89 */     return finalWords;
/*     */   }
/*     */   
/*     */   public static List<String> formatString(String string, double width) {
/*  93 */     ArrayList<String> finalWords = new ArrayList<>();
/*  94 */     StringBuilder currentWord = new StringBuilder();
/*  95 */     char lastColorCode = Character.MAX_VALUE;
/*  96 */     char[] chars = string.toCharArray();
/*     */     
/*  98 */     for (int index = 0; index < chars.length; index++) {
/*  99 */       char c = chars[index];
/*     */       
/* 101 */       if (c == '§' && index < chars.length - 1) {
/* 102 */         lastColorCode = chars[index + 1];
/*     */       }
/*     */       
/* 105 */       if (getStringWidth(currentWord.toString() + c) < width) {
/* 106 */         currentWord.append(c);
/*     */       } else {
/* 108 */         finalWords.add(currentWord.toString());
/* 109 */         currentWord = new StringBuilder("§" + lastColorCode + c);
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     if (currentWord.length() > 0) {
/* 114 */       finalWords.add(currentWord.toString());
/*     */     }
/*     */     
/* 117 */     return finalWords;
/*     */   }
/*     */   
/*     */   public static int getFontString(String text, float x, float y, int color) {
/* 121 */     if (FontModule.INSTANCE.isEnabled()) {
/* 122 */       return globalFont.drawStringWithShadow(text, x, y, color);
/*     */     }
/*     */     
/* 125 */     return mc.fontRenderer.drawStringWithShadow(text, x, y, color);
/*     */   }
/*     */   
/*     */   private static Font getFont(String fontName, float size) {
/*     */     try {
/* 130 */       InputStream inputStream = FontUtil.class.getResourceAsStream("/assets/cosmos/fonts/" + fontName + ".ttf");
/*     */       
/* 132 */       if (inputStream != null) {
/* 133 */         Font awtClientFont = Font.createFont(0, inputStream);
/* 134 */         awtClientFont = awtClientFont.deriveFont(0, size);
/* 135 */         inputStream.close();
/* 136 */         return awtClientFont;
/*     */       } 
/*     */ 
/*     */       
/* 140 */       return new Font("default", 0, (int)size);
/*     */     }
/* 142 */     catch (Exception exception) {
/* 143 */       exception.printStackTrace();
/* 144 */       return new Font("default", 0, (int)size);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\render\FontUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
