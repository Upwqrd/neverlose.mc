//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.render;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderUtil
/*     */   implements Wrapper
/*     */ {
/*  28 */   public static Tessellator tessellator = Tessellator.getInstance();
/*  29 */   public static BufferBuilder bufferBuilder = tessellator.getBuffer();
/*     */ 
/*     */   
/*  32 */   private static ScaledResolution resolution = new ScaledResolution(mc);
/*     */   
/*     */   static {
/*  35 */     Cosmos.EVENT_BUS.register(new Object()
/*     */         {
/*     */           
/*     */           @SubscribeEvent
/*     */           public void onRenderGameOverlay(RenderGameOverlayEvent.Post event)
/*     */           {
/*  41 */             RenderUtil.resolution = event.getResolution();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawBox(RenderBuilder renderBuilder) {
/*  55 */     if (mc.getRenderViewEntity() != null) {
/*     */ 
/*     */ 
/*     */       
/*  59 */       AxisAlignedBB axisAlignedBB = renderBuilder.getAxisAlignedBB().offset(-(mc.getRenderManager()).viewerPosX, -(mc.getRenderManager()).viewerPosY, -(mc.getRenderManager()).viewerPosZ);
/*     */ 
/*     */       
/*  62 */       switch (renderBuilder.getBox()) {
/*     */         case FILL:
/*  64 */           drawSelectionBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor());
/*     */           break;
/*     */         case OUTLINE:
/*  67 */           drawSelectionBoundingBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 144));
/*     */           break;
/*     */         case BOTH:
/*  70 */           drawSelectionBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor());
/*  71 */           drawSelectionBoundingBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 144));
/*     */           break;
/*     */         case GLOW:
/*  74 */           drawSelectionGlowFilledBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 0));
/*     */           break;
/*     */         case REVERSE:
/*  77 */           drawSelectionGlowFilledBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 0), renderBuilder.getColor());
/*     */           break;
/*     */         case CLAW:
/*  80 */           drawClawBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 255));
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/*  85 */       renderBuilder.build();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawSelectionBox(AxisAlignedBB axisAlignedBB, double height, double length, double width, Color color) {
/* 100 */     bufferBuilder.begin(5, DefaultVertexFormats.POSITION_COLOR);
/*     */ 
/*     */     
/* 103 */     addChainedFilledBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + length, axisAlignedBB.maxY + height, axisAlignedBB.maxZ + width, color);
/*     */ 
/*     */     
/* 106 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addChainedFilledBoxVertices(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color color) {
/* 122 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 123 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 124 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 125 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 126 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 127 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 128 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 129 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 130 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 131 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 132 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 133 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 134 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 135 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 136 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 137 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 138 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 139 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 140 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 141 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 142 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 143 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 144 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 145 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 146 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 147 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 148 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 149 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 150 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 151 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawSelectionBoundingBox(AxisAlignedBB axisAlignedBB, double height, double length, double width, Color color) {
/* 165 */     bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*     */ 
/*     */     
/* 168 */     addChainedBoundingBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + length, axisAlignedBB.maxY + height, axisAlignedBB.maxZ + width, color);
/*     */ 
/*     */     
/* 171 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addChainedBoundingBoxVertices(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color color) {
/* 187 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 188 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 189 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 190 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 191 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 192 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 193 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 194 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 195 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 196 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 197 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 198 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 199 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 200 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 201 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 202 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 203 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 204 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawSelectionGlowFilledBox(AxisAlignedBB axisAlignedBB, double height, double length, double width, Color startColor, Color endColor) {
/* 219 */     bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*     */ 
/*     */     
/* 222 */     addChainedGlowBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + length, axisAlignedBB.maxY + height, axisAlignedBB.maxZ + width, startColor, endColor);
/*     */ 
/*     */     
/* 225 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addChainedGlowBoxVertices(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color startColor, Color endColor) {
/* 242 */     bufferBuilder.pos(minX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 243 */     bufferBuilder.pos(maxX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 244 */     bufferBuilder.pos(maxX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 245 */     bufferBuilder.pos(minX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 246 */     bufferBuilder.pos(minX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 247 */     bufferBuilder.pos(minX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 248 */     bufferBuilder.pos(maxX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 249 */     bufferBuilder.pos(maxX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 250 */     bufferBuilder.pos(minX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 251 */     bufferBuilder.pos(minX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 252 */     bufferBuilder.pos(maxX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 253 */     bufferBuilder.pos(maxX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 254 */     bufferBuilder.pos(maxX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 255 */     bufferBuilder.pos(maxX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 256 */     bufferBuilder.pos(maxX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 257 */     bufferBuilder.pos(maxX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 258 */     bufferBuilder.pos(minX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 259 */     bufferBuilder.pos(maxX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 260 */     bufferBuilder.pos(maxX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 261 */     bufferBuilder.pos(minX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 262 */     bufferBuilder.pos(minX, minY, minZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 263 */     bufferBuilder.pos(minX, minY, maxZ).color(startColor.getRed() / 255.0F, startColor.getGreen() / 255.0F, startColor.getBlue() / 255.0F, startColor.getAlpha() / 255.0F).endVertex();
/* 264 */     bufferBuilder.pos(minX, maxY, maxZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/* 265 */     bufferBuilder.pos(minX, maxY, minZ).color(endColor.getRed() / 255.0F, endColor.getGreen() / 255.0F, endColor.getBlue() / 255.0F, endColor.getAlpha() / 255.0F).endVertex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawClawBox(AxisAlignedBB axisAlignedBB, double height, double length, double width, Color color) {
/* 279 */     bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*     */ 
/*     */     
/* 282 */     addChainedClawBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + length, axisAlignedBB.maxY + height, axisAlignedBB.maxZ + width, color);
/*     */ 
/*     */     
/* 285 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addChainedClawBoxVertices(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color color) {
/* 301 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 302 */     bufferBuilder.pos(minX, minY, maxZ - 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 303 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 304 */     bufferBuilder.pos(minX, minY, minZ + 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 305 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 306 */     bufferBuilder.pos(maxX, minY, maxZ - 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 307 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 308 */     bufferBuilder.pos(maxX, minY, minZ + 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 309 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 310 */     bufferBuilder.pos(maxX - 0.8D, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 311 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 312 */     bufferBuilder.pos(maxX - 0.8D, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 313 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 314 */     bufferBuilder.pos(minX + 0.8D, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 315 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 316 */     bufferBuilder.pos(minX + 0.8D, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 317 */     bufferBuilder.pos(minX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 318 */     bufferBuilder.pos(minX, minY + 0.2D, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 319 */     bufferBuilder.pos(minX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 320 */     bufferBuilder.pos(minX, minY + 0.2D, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 321 */     bufferBuilder.pos(maxX, minY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 322 */     bufferBuilder.pos(maxX, minY + 0.2D, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 323 */     bufferBuilder.pos(maxX, minY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 324 */     bufferBuilder.pos(maxX, minY + 0.2D, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 325 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 326 */     bufferBuilder.pos(minX, maxY, maxZ - 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 327 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 328 */     bufferBuilder.pos(minX, maxY, minZ + 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 329 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 330 */     bufferBuilder.pos(maxX, maxY, maxZ - 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 331 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 332 */     bufferBuilder.pos(maxX, maxY, minZ + 0.8D).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 333 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 334 */     bufferBuilder.pos(maxX - 0.8D, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 335 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 336 */     bufferBuilder.pos(maxX - 0.8D, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 337 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 338 */     bufferBuilder.pos(minX + 0.8D, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 339 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 340 */     bufferBuilder.pos(minX + 0.8D, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 341 */     bufferBuilder.pos(minX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 342 */     bufferBuilder.pos(minX, maxY - 0.2D, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 343 */     bufferBuilder.pos(minX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 344 */     bufferBuilder.pos(minX, maxY - 0.2D, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 345 */     bufferBuilder.pos(maxX, maxY, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 346 */     bufferBuilder.pos(maxX, maxY - 0.2D, minZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/* 347 */     bufferBuilder.pos(maxX, maxY, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
/* 348 */     bufferBuilder.pos(maxX, maxY - 0.2D, maxZ).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
/*     */   }
/*     */   
/*     */   public static void drawCircle(RenderBuilder renderBuilder, Vec3d vec3d, double radius, double height, Color color) {
/* 352 */     renderCircle(bufferBuilder, vec3d, radius, height, color);
/* 353 */     renderBuilder.build();
/*     */   }
/*     */   
/*     */   public static void renderCircle(BufferBuilder bufferBuilder, Vec3d vec3d, double radius, double height, Color color) {
/* 357 */     GlStateManager.disableCull();
/* 358 */     GlStateManager.disableAlpha();
/* 359 */     GlStateManager.shadeModel(7425);
/* 360 */     bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*     */     
/* 362 */     for (int i = 0; i < 361; i++) {
/* 363 */       bufferBuilder.pos(vec3d.x + Math.sin(Math.toRadians(i)) * radius - (mc.getRenderManager()).viewerPosX, vec3d.y + height - (mc.getRenderManager()).viewerPosY, vec3d.z + Math.cos(Math.toRadians(i)) * radius - (mc.getRenderManager()).viewerPosZ).color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 1.0F).endVertex();
/*     */     }
/*     */     
/* 366 */     tessellator.draw();
/*     */     
/* 368 */     GlStateManager.enableCull();
/* 369 */     GlStateManager.enableAlpha();
/* 370 */     GlStateManager.shadeModel(7424);
/*     */   }
/*     */   
/*     */   public static void drawNametag(BlockPos blockPos, float height, String text) {
/* 374 */     GlStateManager.pushMatrix();
/* 375 */     glBillboardDistanceScaled(blockPos.getX() + 0.5F, blockPos.getY() + height, blockPos.getZ() + 0.5F, (EntityPlayer)mc.player, 1.0F);
/* 376 */     GlStateManager.disableDepth();
/* 377 */     GlStateManager.translate(-(mc.fontRenderer.getStringWidth(text) / 2.0D), 0.0D, 0.0D);
/* 378 */     FontUtil.drawStringWithShadow(text, 0.0F, 0.0F, -1);
/* 379 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
/* 383 */     glBillboard(x, y, z);
/* 384 */     int distance = (int)player.getDistance(x, y, z);
/* 385 */     float scaleDistance = distance / 2.0F / (2.0F + 2.0F - scale);
/*     */     
/* 387 */     if (scaleDistance < 1.0F) {
/* 388 */       scaleDistance = 1.0F;
/*     */     }
/* 390 */     GlStateManager.scale(scaleDistance, scaleDistance, scaleDistance);
/*     */   }
/*     */   
/*     */   public static void glBillboard(float x, float y, float z) {
/* 394 */     float scale = 0.02666667F;
/*     */     
/* 396 */     GlStateManager.translate(x - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z - (mc.getRenderManager()).viewerPosZ);
/* 397 */     GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
/* 398 */     GlStateManager.rotate(-mc.player.rotationYaw, 0.0F, 1.0F, 0.0F);
/* 399 */     GlStateManager.rotate(mc.player.rotationPitch, (mc.gameSettings.thirdPersonView == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/* 400 */     GlStateManager.scale(-scale, -scale, scale);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawLine3D(Vec3d from, Vec3d to, Color color, double lineWidth) {
/* 406 */     GL11.glDepthMask(false);
/* 407 */     GL11.glDisable(2929);
/*     */     
/* 409 */     GL11.glDisable(3008);
/* 410 */     GL11.glEnable(3042);
/* 411 */     GL11.glDisable(3553);
/* 412 */     GL11.glBlendFunc(770, 771);
/* 413 */     GL11.glEnable(2848);
/* 414 */     GL11.glHint(3154, 4354);
/* 415 */     GL11.glLineWidth(0.1F);
/*     */ 
/*     */     
/* 418 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*     */ 
/*     */     
/* 421 */     GL11.glLineWidth((float)lineWidth);
/* 422 */     GL11.glBegin(1);
/*     */ 
/*     */     
/* 425 */     GL11.glVertex3d(from.x, from.y, from.z);
/* 426 */     GL11.glVertex3d(to.x, to.y, to.z);
/*     */     
/* 428 */     GL11.glEnd();
/*     */ 
/*     */     
/* 431 */     GL11.glDepthMask(true);
/* 432 */     GL11.glEnable(2929);
/*     */     
/* 434 */     GL11.glEnable(3553);
/* 435 */     GL11.glDisable(3042);
/* 436 */     GL11.glEnable(3008);
/* 437 */     GL11.glDisable(2848);
/*     */ 
/*     */     
/* 440 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawRect(float x, float y, float width, float height, int color) {
/* 446 */     Color c = new Color(color, true);
/* 447 */     GL11.glPushMatrix();
/* 448 */     GL11.glDisable(3553);
/* 449 */     GL11.glEnable(3042);
/* 450 */     GL11.glBlendFunc(770, 771);
/* 451 */     GL11.glShadeModel(7425);
/* 452 */     GL11.glBegin(7);
/* 453 */     GL11.glColor4f(c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F, c.getAlpha() / 255.0F);
/* 454 */     GL11.glVertex2f(x, y);
/* 455 */     GL11.glVertex2f(x, y + height);
/* 456 */     GL11.glVertex2f(x + width, y + height);
/* 457 */     GL11.glVertex2f(x + width, y);
/* 458 */     GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/* 459 */     GL11.glEnd();
/* 460 */     GL11.glEnable(3553);
/* 461 */     GL11.glDisable(3042);
/* 462 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public static void drawRect(float x, float y, float width, float height, Color color) {
/* 466 */     GL11.glPushMatrix();
/* 467 */     GL11.glDisable(3553);
/* 468 */     GL11.glEnable(3042);
/* 469 */     GL11.glBlendFunc(770, 771);
/* 470 */     GL11.glShadeModel(7425);
/* 471 */     GL11.glBegin(7);
/* 472 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 473 */     GL11.glVertex2f(x, y);
/* 474 */     GL11.glVertex2f(x, y + height);
/* 475 */     GL11.glVertex2f(x + width, y + height);
/* 476 */     GL11.glVertex2f(x + width, y);
/* 477 */     GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/* 478 */     GL11.glEnd();
/* 479 */     GL11.glEnable(3553);
/* 480 */     GL11.glDisable(3042);
/* 481 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public static void drawBorder(float x, float y, float width, float height, Color color) {
/* 485 */     drawRect(x - 0.5F, y - 0.5F, 0.5F, height + 1.0F, color);
/* 486 */     drawRect(x + width, y - 0.5F, 0.5F, height + 1.0F, color);
/* 487 */     drawRect(x, y - 0.5F, width, 0.5F, color);
/* 488 */     drawRect(x, y + height, width, 0.5F, color);
/*     */   }
/*     */   
/*     */   public static void drawRoundedRect(double x, double y, double width, double height, double radius, Color color) {
/* 492 */     GL11.glPushAttrib(0);
/*     */     
/* 494 */     GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 495 */     x *= 2.0D;
/* 496 */     y *= 2.0D;
/* 497 */     width *= 2.0D;
/* 498 */     height *= 2.0D;
/*     */     
/* 500 */     width += x;
/* 501 */     height += y;
/*     */     
/* 503 */     GL11.glEnable(3042);
/* 504 */     GL11.glDisable(3553);
/* 505 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 506 */     GL11.glEnable(2848);
/* 507 */     GL11.glBegin(9);
/*     */     
/*     */     int i;
/* 510 */     for (i = 0; i <= 90; i++) {
/* 511 */       GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, y + radius + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
/*     */     }
/*     */     
/* 514 */     for (i = 90; i <= 180; i++) {
/* 515 */       GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, height - radius + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
/*     */     }
/*     */     
/* 518 */     for (i = 0; i <= 90; i++) {
/* 519 */       GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180.0D) * radius, height - radius + Math.cos(i * Math.PI / 180.0D) * radius);
/*     */     }
/*     */     
/* 522 */     for (i = 90; i <= 180; i++) {
/* 523 */       GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180.0D) * radius, y + radius + Math.cos(i * Math.PI / 180.0D) * radius);
/*     */     }
/*     */     
/* 526 */     GL11.glEnd();
/* 527 */     GL11.glEnable(3553);
/* 528 */     GL11.glDisable(3042);
/* 529 */     GL11.glDisable(2848);
/* 530 */     GL11.glDisable(3042);
/* 531 */     GL11.glEnable(3553);
/*     */ 
/*     */     
/* 534 */     GL11.glScaled(2.0D, 2.0D, 2.0D);
/* 535 */     GL11.glPopAttrib();
/*     */   }
/*     */   
/*     */   public static void drawPolygon(double x, double y, float radius, int sides, Color color) {
/* 539 */     GL11.glEnable(3042);
/* 540 */     GL11.glDisable(3553);
/* 541 */     GL11.glBlendFunc(770, 771);
/* 542 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 543 */     bufferBuilder.begin(6, DefaultVertexFormats.POSITION);
/* 544 */     bufferBuilder.pos(x, y, 0.0D).endVertex();
/* 545 */     double TWICE_PI = 6.283185307179586D;
/*     */     
/* 547 */     for (int i = 0; i <= sides; i++) {
/* 548 */       double angle = TWICE_PI * i / sides + Math.toRadians(180.0D);
/* 549 */       bufferBuilder.pos(x + Math.sin(angle) * radius, y + Math.cos(angle) * radius, 0.0D).endVertex();
/*     */     } 
/*     */     
/* 552 */     tessellator.draw();
/* 553 */     GL11.glEnable(3553);
/* 554 */     GL11.glDisable(3042);
/*     */   }
/*     */   
/*     */   public static double getDisplayWidth() {
/* 558 */     return resolution.getScaledWidth_double();
/*     */   }
/*     */   
/*     */   public static double getDisplayHeight() {
/* 562 */     return resolution.getScaledHeight_double();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\render\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
