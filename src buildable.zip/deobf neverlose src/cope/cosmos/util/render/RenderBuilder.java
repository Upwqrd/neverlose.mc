//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.render;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderBuilder
/*     */ {
/*     */   private boolean setup;
/*     */   private boolean depth;
/*     */   private boolean blend;
/*     */   private boolean texture;
/*     */   private boolean cull;
/*     */   private boolean alpha;
/*     */   private boolean shade;
/*  22 */   private AxisAlignedBB axisAlignedBB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
/*  23 */   private Box box = Box.FILL;
/*     */   
/*     */   private double height;
/*     */   
/*     */   private double length;
/*     */   private double width;
/*  29 */   private Color color = Color.WHITE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder setup() {
/*  36 */     GlStateManager.pushMatrix();
/*  37 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/*  38 */     GL11.glEnable(2848);
/*  39 */     GL11.glHint(3154, 4354);
/*  40 */     this.setup = true;
/*  41 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder depth(boolean in) {
/*  50 */     if (in) {
/*  51 */       GlStateManager.disableDepth();
/*  52 */       GlStateManager.depthMask(false);
/*     */     } 
/*     */     
/*  55 */     this.depth = in;
/*  56 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder blend() {
/*  64 */     GlStateManager.enableBlend();
/*  65 */     this.blend = true;
/*  66 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder texture() {
/*  74 */     GlStateManager.disableTexture2D();
/*  75 */     this.texture = true;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder line(float width) {
/*  85 */     GlStateManager.glLineWidth(width);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder cull(boolean in) {
/*  95 */     if (this.cull) {
/*  96 */       GlStateManager.disableCull();
/*     */     }
/*     */     
/*  99 */     this.cull = in;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder alpha(boolean in) {
/* 109 */     if (this.alpha) {
/* 110 */       GlStateManager.disableAlpha();
/*     */     }
/*     */     
/* 113 */     this.alpha = in;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder shade(boolean in) {
/* 123 */     if (in) {
/* 124 */       GlStateManager.shadeModel(7425);
/*     */     }
/*     */     
/* 127 */     this.shade = in;
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder build() {
/* 136 */     if (this.depth) {
/* 137 */       GlStateManager.depthMask(true);
/* 138 */       GlStateManager.enableDepth();
/*     */     } 
/*     */     
/* 141 */     if (this.texture) {
/* 142 */       GlStateManager.enableTexture2D();
/*     */     }
/*     */     
/* 145 */     if (this.blend) {
/* 146 */       GlStateManager.disableBlend();
/*     */     }
/*     */     
/* 149 */     if (this.cull) {
/* 150 */       GlStateManager.enableCull();
/*     */     }
/*     */     
/* 153 */     if (this.alpha) {
/* 154 */       GlStateManager.enableAlpha();
/*     */     }
/*     */     
/* 157 */     if (this.shade) {
/* 158 */       GlStateManager.shadeModel(7424);
/*     */     }
/*     */     
/* 161 */     if (this.setup) {
/* 162 */       GL11.glDisable(2848);
/* 163 */       GlStateManager.popMatrix();
/*     */     } 
/*     */     
/* 166 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder position(BlockPos in) {
/* 175 */     position(new AxisAlignedBB(in.getX(), in.getY(), in.getZ(), (in.getX() + 1), (in.getY() + 1), (in.getZ() + 1)));
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder position(Vec3d in) {
/* 185 */     position(new AxisAlignedBB(in.x, in.y, in.z, in.x + 1.0D, in.y + 1.0D, in.z + 1.0D));
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder position(AxisAlignedBB in) {
/* 195 */     this.axisAlignedBB = in;
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder height(double in) {
/* 205 */     this.height = in;
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder width(double in) {
/* 215 */     this.width = in;
/* 216 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder length(double in) {
/* 225 */     this.length = in;
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder color(Color in) {
/* 235 */     this.color = in;
/* 236 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderBuilder box(Box in) {
/* 245 */     this.box = in;
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB getAxisAlignedBB() {
/* 254 */     return this.axisAlignedBB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/* 262 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/* 270 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLength() {
/* 278 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 286 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box getBox() {
/* 294 */     return this.box;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Box
/*     */   {
/* 302 */     FILL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     OUTLINE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     BOTH,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     GLOW,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 322 */     REVERSE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     CLAW,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\render\RenderBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
