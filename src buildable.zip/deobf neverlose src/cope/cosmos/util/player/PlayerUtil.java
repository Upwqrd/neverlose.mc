//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.player;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.movement.FlightModule;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import cope.cosmos.util.world.BlockUtil;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.EnumAction;
/*    */ import net.minecraft.item.ItemTool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerUtil
/*    */   implements Wrapper
/*    */ {
/*    */   public static double getHealth() {
/* 21 */     return (mc.player.getHealth() + mc.player.getAbsorptionAmount());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isEating() {
/* 29 */     if (mc.player.isHandActive()) {
/* 30 */       return (mc.player.getActiveItemStack().getItemUseAction().equals(EnumAction.EAT) || mc.player.getActiveItemStack().getItemUseAction().equals(EnumAction.DRINK));
/*    */     }
/*    */     
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isMending() {
/* 41 */     return (InventoryUtil.isHolding(Items.EXPERIENCE_BOTTLE) && mc.gameSettings.keyBindUseItem.isKeyDown());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isMining() {
/* 49 */     return (InventoryUtil.isHolding((Class)ItemTool.class) && mc.playerController.getIsHittingBlock() && BlockUtil.isBreakable(mc.objectMouseOver.getBlockPos()) && !mc.world.isAirBlock(mc.objectMouseOver.getBlockPos()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isInLiquid() {
/* 57 */     return (mc.player.isInLava() || mc.player.isInWater());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isCollided() {
/* 65 */     return (mc.player.collidedHorizontally || mc.player.collidedVertically);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isFlying() {
/* 73 */     return (FlightModule.INSTANCE.isActive() || mc.player.isElytraFlying() || mc.player.capabilities.isFlying);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\player\PlayerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
