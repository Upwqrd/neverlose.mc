//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.player;
/*     */ 
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ public class MotionUtil
/*     */   implements Wrapper
/*     */ {
/*     */   public static void setMoveSpeed(double speed, float stepHeight) {
/*  10 */     Entity currentMover = mc.player.isRiding() ? mc.player.getRidingEntity() : (Entity)mc.player;
/*     */     
/*  12 */     if (currentMover != null) {
/*  13 */       float forward = mc.player.movementInput.moveForward;
/*  14 */       float strafe = mc.player.movementInput.moveStrafe;
/*  15 */       float yaw = mc.player.rotationYaw;
/*     */       
/*  17 */       if (!isMoving()) {
/*  18 */         currentMover.motionX = 0.0D;
/*  19 */         currentMover.motionZ = 0.0D;
/*     */       
/*     */       }
/*  22 */       else if (forward != 0.0F) {
/*  23 */         if (strafe >= 1.0F) {
/*  24 */           yaw += ((forward > 0.0F) ? -45 : 45);
/*  25 */           strafe = 0.0F;
/*     */         
/*     */         }
/*  28 */         else if (strafe <= -1.0F) {
/*  29 */           yaw += ((forward > 0.0F) ? 45 : -45);
/*  30 */           strafe = 0.0F;
/*     */         } 
/*     */         
/*  33 */         if (forward > 0.0F) {
/*  34 */           forward = 1.0F;
/*     */         }
/*  36 */         else if (forward < 0.0F) {
/*  37 */           forward = -1.0F;
/*     */         } 
/*     */       } 
/*  40 */       double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  41 */       double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/*     */       
/*  43 */       currentMover.motionX = forward * speed * cos + strafe * speed * sin;
/*  44 */       currentMover.motionZ = forward * speed * sin - strafe * speed * cos;
/*  45 */       currentMover.stepHeight = stepHeight;
/*     */       
/*  47 */       if (!isMoving()) {
/*  48 */         currentMover.motionX = 0.0D;
/*  49 */         currentMover.motionZ = 0.0D;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static double[] getMoveSpeed(double speed) {
/*  55 */     float forward = mc.player.movementInput.moveForward;
/*  56 */     float strafe = mc.player.movementInput.moveStrafe;
/*  57 */     float yaw = mc.player.rotationYaw;
/*     */     
/*  59 */     if (!isMoving()) {
/*  60 */       return new double[] { 0.0D, 0.0D };
/*     */     }
/*     */     
/*  63 */     if (forward != 0.0F) {
/*  64 */       if (strafe >= 1.0F) {
/*  65 */         yaw += ((forward > 0.0F) ? -45 : 45);
/*  66 */         strafe = 0.0F;
/*     */       
/*     */       }
/*  69 */       else if (strafe <= -1.0F) {
/*  70 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*  71 */         strafe = 0.0F;
/*     */       } 
/*     */       
/*  74 */       if (forward > 0.0F) {
/*  75 */         forward = 1.0F;
/*     */       }
/*  77 */       else if (forward < 0.0F) {
/*  78 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/*  81 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  82 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/*     */     
/*  84 */     double motionX = forward * speed * cos + strafe * speed * sin;
/*  85 */     double motionZ = forward * speed * sin - strafe * speed * cos;
/*     */     
/*  87 */     return new double[] { motionX, motionZ };
/*     */   }
/*     */   
/*     */   public static void stopMotion(double fall) {
/*  91 */     Entity currentMover = mc.player.isRiding() ? mc.player.getRidingEntity() : (Entity)mc.player;
/*     */     
/*  93 */     if (currentMover != null) {
/*  94 */       currentMover.setVelocity(0.0D, fall, 0.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isMoving() {
/*  99 */     return (mc.player.moveForward != 0.0F || mc.player.moveStrafing != 0.0F);
/*     */   }
/*     */   
/*     */   public static boolean hasMoved() {
/* 103 */     return (StrictMath.pow(mc.player.motionX, 2.0D) + StrictMath.pow(mc.player.motionY, 2.0D) + StrictMath.pow(mc.player.motionZ, 2.0D) >= 9.0E-4D);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\player\MotionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
