//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.util.player;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryUtil
/*     */   implements Wrapper
/*     */ {
/*     */   public static boolean isHolding(Item item) {
/*  26 */     return (mc.player.getHeldItemMainhand().getItem().equals(item) || mc.player.getHeldItemOffhand().getItem().equals(item));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHolding(Block block) {
/*  35 */     return (mc.player.getHeldItemMainhand().getItem().equals(Item.getItemFromBlock(block)) || mc.player.getHeldItemOffhand().getItem().equals(Item.getItemFromBlock(block)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHolding(Item[] items) {
/*  44 */     return (Arrays.<Item>stream(items).anyMatch(inventoryItem -> inventoryItem.equals(mc.player.getHeldItemMainhand().getItem())) || Arrays.<Item>stream(items).anyMatch(inventoryItem -> inventoryItem.equals(mc.player.getHeldItemOffhand().getItem())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHolding(Block[] blocks) {
/*  53 */     return (Arrays.<Block>stream(blocks).anyMatch(inventoryItem -> Item.getItemFromBlock(inventoryItem).equals(mc.player.getHeldItemMainhand().getItem())) || Arrays.<Block>stream(blocks).anyMatch(inventoryItem -> Item.getItemFromBlock(inventoryItem).equals(mc.player.getHeldItemOffhand().getItem())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHolding(Class<? extends Item> clazz) {
/*  62 */     return (clazz.isInstance(mc.player.getHeldItemMainhand().getItem()) || clazz.isInstance(mc.player.getHeldItemOffhand().getItem()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInHotbar(Item in) {
/*  71 */     return (Cosmos.INSTANCE.getInventoryManager().searchSlot(in, InventoryManager.InventoryRegion.HOTBAR) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getHighestEnchantLevel() {
/*  80 */     int highestLvl = 0;
/*     */ 
/*     */     
/*  83 */     for (int i = 0; i < mc.player.getHeldItemMainhand().getEnchantmentTagList().tagCount(); i++) {
/*     */       
/*  85 */       NBTTagCompound enchantment = mc.player.getHeldItemMainhand().getEnchantmentTagList().getCompoundTagAt(i);
/*     */       
/*  87 */       if (enchantment.getShort("lvl") > highestLvl) {
/*  88 */         highestLvl = enchantment.getShort("lvl");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return highestLvl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getItemCount(Item item) {
/* 103 */     if (item instanceof net.minecraft.item.ItemArmor) {
/* 104 */       return mc.player.inventory.armorInventory.stream()
/* 105 */         .filter(itemStack -> itemStack.getItem().equals(item))
/* 106 */         .mapToInt(ItemStack::getCount)
/* 107 */         .sum();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     return mc.player.inventory.mainInventory.stream()
/* 113 */       .filter(itemStack -> itemStack.getItem().equals(item))
/* 114 */       .mapToInt(ItemStack::getCount)
/* 115 */       .sum() + mc.player.inventory.offHandInventory
/*     */       
/* 117 */       .stream()
/* 118 */       .filter(itemStack -> itemStack.getItem().equals(item))
/* 119 */       .mapToInt(ItemStack::getCount)
/* 120 */       .sum();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\player\InventoryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
