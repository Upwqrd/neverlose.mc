//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.player;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import cope.cosmos.util.holder.Rotation;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AngleUtil
/*    */   implements Wrapper
/*    */ {
/*    */   public static Rotation calculateAngles(Vec3d to) {
/* 22 */     float yaw = (float)(Math.toDegrees(Math.atan2((to.subtract(mc.player.getPositionEyes(1.0F))).z, (to.subtract(mc.player.getPositionEyes(1.0F))).x)) - 90.0D);
/* 23 */     float pitch = (float)Math.toDegrees(-Math.atan2((to.subtract(mc.player.getPositionEyes(1.0F))).y, Math.hypot((to.subtract(mc.player.getPositionEyes(1.0F))).x, (to.subtract(mc.player.getPositionEyes(1.0F))).z)));
/*    */ 
/*    */     
/* 26 */     return new Rotation(MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Vec3d getVectorForRotation(Rotation rotation) {
/* 35 */     float yawCos = MathHelper.cos(-rotation.getYaw() * 0.017453292F - 3.1415927F);
/* 36 */     float yawSin = MathHelper.sin(-rotation.getYaw() * 0.017453292F - 3.1415927F);
/* 37 */     float pitchCos = -MathHelper.cos(-rotation.getPitch() * 0.017453292F);
/* 38 */     float pitchSin = MathHelper.sin(-rotation.getPitch() * 0.017453292F);
/* 39 */     return new Vec3d((yawSin * pitchCos), pitchSin, (yawCos * pitchCos));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\player\AngleUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
