/*     */ package cope.cosmos.util.math;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timer
/*     */   implements Wrapper
/*     */ {
/*     */   private long milliseconds;
/*     */   private long ticks;
/*     */   
/*     */   public Timer() {
/*  20 */     this.milliseconds = -1L;
/*  21 */     this.ticks = -1L;
/*     */ 
/*     */     
/*  24 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdate(LivingEvent.LivingUpdateEvent event) {
/*  30 */     if (nullCheck()) {
/*  31 */       this.ticks++;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  36 */       this.milliseconds = -1L;
/*  37 */       this.ticks = -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean passedTime(long time, Format format) {
/*  48 */     switch (format)
/*     */     
/*     */     { default:
/*  51 */         return (System.currentTimeMillis() - this.milliseconds >= time);
/*     */       case SECONDS:
/*  53 */         return (System.currentTimeMillis() - this.milliseconds >= time * 1000L);
/*     */       case TICKS:
/*  55 */         break; }  return (this.ticks >= time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMilliseconds() {
/*  64 */     if (this.milliseconds <= 0L) {
/*  65 */       return 0L;
/*     */     }
/*     */     
/*  68 */     return System.currentTimeMillis() - this.milliseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTime(long in, Format format) {
/*  77 */     switch (format) {
/*     */       
/*     */       default:
/*  80 */         this.milliseconds = System.currentTimeMillis() - in;
/*     */         return;
/*     */       case SECONDS:
/*  83 */         this.milliseconds = System.currentTimeMillis() - in * 1000L; return;
/*     */       case TICKS:
/*     */         break;
/*  86 */     }  this.ticks = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetTime() {
/*  96 */     this.milliseconds = System.currentTimeMillis();
/*  97 */     this.ticks = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Format
/*     */   {
/* 105 */     MILLISECONDS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     SECONDS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     TICKS;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\math\Timer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */