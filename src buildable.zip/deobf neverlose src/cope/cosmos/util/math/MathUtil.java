/*    */ package cope.cosmos.util.math;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.RoundingMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MathUtil
/*    */ {
/*    */   public static double roundDouble(double number, int scale) {
/* 19 */     BigDecimal bigDecimal = new BigDecimal(number);
/*    */ 
/*    */     
/* 22 */     bigDecimal = bigDecimal.setScale(scale, RoundingMode.HALF_UP);
/* 23 */     return bigDecimal.doubleValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static float roundFloat(double number, int scale) {
/* 33 */     BigDecimal bigDecimal = BigDecimal.valueOf(number);
/*    */ 
/*    */     
/* 36 */     bigDecimal = bigDecimal.setScale(scale, RoundingMode.FLOOR);
/* 37 */     return bigDecimal.floatValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static double toExponent(double num, int exponent) {
/* 47 */     double result = 1.0D;
/*    */ 
/*    */     
/* 50 */     if (exponent < 0) {
/* 51 */       int exponentAbs = Math.abs(exponent);
/*    */       
/* 53 */       while (exponentAbs > 0) {
/* 54 */         if ((exponentAbs & 0x1) != 0) {
/* 55 */           result *= num;
/*    */         }
/*    */         
/* 58 */         exponentAbs >>= 1;
/* 59 */         num *= num;
/*    */       } 
/*    */       
/* 62 */       return 1.0D / result;
/*    */     } 
/*    */ 
/*    */     
/* 66 */     while (exponent > 0) {
/* 67 */       if ((exponent & 0x1) != 0) {
/* 68 */         result *= num;
/*    */       }
/*    */       
/* 71 */       exponent >>= 1;
/* 72 */       num *= num;
/*    */     } 
/*    */     
/* 75 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\math\MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */