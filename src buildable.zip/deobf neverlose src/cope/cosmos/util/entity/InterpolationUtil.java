//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.entity;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpolationUtil
/*    */   implements Wrapper
/*    */ {
/*    */   public static Vec3d getInterpolatedPosition(Entity entity, float ticks) {
/* 20 */     return (new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ))
/* 21 */       .add((new Vec3d(entity.posX - entity.lastTickPosX, entity.posY - entity.lastTickPosY, entity.posZ - entity.lastTickPosZ))
/* 22 */         .scale(ticks));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\entity\InterpolationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
