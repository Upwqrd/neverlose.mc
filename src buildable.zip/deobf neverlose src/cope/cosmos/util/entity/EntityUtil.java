//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util.entity;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EnumCreatureType;
/*    */ import net.minecraft.entity.monster.EntityEnderman;
/*    */ import net.minecraft.entity.monster.EntityIronGolem;
/*    */ import net.minecraft.entity.monster.EntityPigZombie;
/*    */ import net.minecraft.entity.passive.EntityWolf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityUtil
/*    */ {
/*    */   public static boolean isPassiveMob(Entity entity) {
/* 30 */     if (entity instanceof EntityWolf) {
/* 31 */       return !((EntityWolf)entity).isAngry();
/*    */     }
/*    */ 
/*    */     
/* 35 */     if (entity instanceof EntityIronGolem) {
/* 36 */       return (((EntityIronGolem)entity).getRevengeTarget() == null);
/*    */     }
/*    */ 
/*    */     
/* 40 */     return (entity instanceof net.minecraft.entity.EntityAgeable || entity instanceof net.minecraft.entity.passive.EntityAmbientCreature || entity instanceof net.minecraft.entity.passive.EntitySquid);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isVehicleMob(Entity entity) {
/* 49 */     return (entity instanceof net.minecraft.entity.item.EntityBoat || entity instanceof net.minecraft.entity.item.EntityMinecart);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isHostileMob(Entity entity) {
/* 58 */     return ((entity.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(entity)) || entity instanceof net.minecraft.entity.monster.EntitySpider);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isNeutralMob(Entity entity) {
/* 67 */     return ((entity instanceof EntityPigZombie && !((EntityPigZombie)entity).isAngry()) || (entity instanceof EntityWolf && !((EntityWolf)entity).isAngry()) || (entity instanceof EntityEnderman && ((EntityEnderman)entity).isScreaming()));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\entity\EntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
