/*    */ package cope.cosmos.util.holder;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Rotation
/*    */   implements Wrapper
/*    */ {
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   private final Rotate rotate;
/*    */   
/*    */   public Rotation(float yaw, float pitch, Rotate rotate) {
/* 18 */     this.yaw = yaw;
/* 19 */     this.pitch = pitch;
/* 20 */     this.rotate = rotate;
/*    */   }
/*    */   
/*    */   public Rotation(float yaw, float pitch) {
/* 24 */     this(yaw, pitch, Rotate.NONE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getYaw() {
/* 32 */     return this.yaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setYaw(float in) {
/* 40 */     this.yaw = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getPitch() {
/* 48 */     return this.pitch;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPitch(float in) {
/* 56 */     this.pitch = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rotate getRotation() {
/* 64 */     return this.rotate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 72 */     return (!Float.isNaN(getYaw()) && !Float.isNaN(getPitch()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Rotate
/*    */   {
/* 80 */     PACKET,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 85 */     CLIENT,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 90 */     NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\holder\Rotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */