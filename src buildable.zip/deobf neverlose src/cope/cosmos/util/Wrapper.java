//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.util;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Wrapper
/*    */ {
/* 15 */   public static final Minecraft mc = Minecraft.getMinecraft();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean nullCheck() {
/* 22 */     return (mc.player != null && mc.world != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Cosmos getCosmos() {
/* 30 */     return Cosmos.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Logger getLogger() {
/* 38 */     return LogManager.getLogger("neverlose.mc | 1.0b");
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\Wrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
