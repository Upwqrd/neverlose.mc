/*    */ package cope.cosmos.util.string;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringFormatter
/*    */ {
/*    */   public static String capitalise(String in) {
/* 15 */     if (in.length() != 0) {
/* 16 */       return Character.toTitleCase(in.charAt(0)) + in.substring(1);
/*    */     }
/*    */     
/* 19 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String formatEnum(Enum<?> in) {
/* 29 */     String enumName = in.name();
/*    */ 
/*    */     
/* 32 */     if (!enumName.contains("_")) {
/* 33 */       char firstChar = enumName.charAt(0);
/* 34 */       String suffixChars = enumName.split(String.valueOf(firstChar), 2)[1];
/* 35 */       return String.valueOf(firstChar).toUpperCase() + suffixChars.toLowerCase();
/*    */     } 
/*    */ 
/*    */     
/* 39 */     String[] names = enumName.split("_");
/* 40 */     StringBuilder nameToReturn = new StringBuilder();
/*    */ 
/*    */     
/* 43 */     for (String name : names) {
/* 44 */       char firstChar = name.charAt(0);
/* 45 */       String suffixChars = name.split(String.valueOf(firstChar), 2)[1];
/* 46 */       nameToReturn.append(String.valueOf(firstChar).toUpperCase()).append(suffixChars.toLowerCase());
/*    */     } 
/*    */     
/* 49 */     return nameToReturn.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\string\StringFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */