/*    */ package cope.cosmos.util.string;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.client.ColorsModule;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ public class ColorUtil
/*    */ {
/*    */   public static Color getPrimaryColor(int offset) {
/* 10 */     switch ((ColorsModule.Rainbow)ColorsModule.rainbow.getValue()) {
/*    */       case GRADIENT:
/* 12 */         return rainbow(offset, ((Color)ColorsModule.clientColor.getValue()).getAlpha());
/*    */       case STATIC:
/* 14 */         return rainbow(1L, ((Color)ColorsModule.clientColor.getValue()).getAlpha());
/*    */       case ALPHA:
/* 16 */         return alphaCycle((Color)ColorsModule.clientColor.getValue(), offset * 2 + 10);
/*    */     } 
/*    */     
/* 19 */     return (Color)ColorsModule.clientColor.getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color getPrimaryColor() {
/* 24 */     switch ((ColorsModule.Rainbow)ColorsModule.rainbow.getValue()) {
/*    */       case GRADIENT:
/*    */       case STATIC:
/* 27 */         return rainbow(1L, ((Color)ColorsModule.clientColor.getValue()).getAlpha());
/*    */       case ALPHA:
/* 29 */         return alphaCycle((Color)ColorsModule.clientColor.getValue(), 10);
/*    */     } 
/*    */     
/* 32 */     return (Color)ColorsModule.clientColor.getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color getPrimaryAlphaColor(int alpha) {
/* 37 */     return new Color(getPrimaryColor().getRed(), getPrimaryColor().getGreen(), getPrimaryColor().getBlue(), alpha);
/*    */   }
/*    */   
/*    */   public static Color alphaCycle(Color clientColor, int count) {
/* 41 */     float[] hsb = new float[3];
/* 42 */     Color.RGBtoHSB(clientColor.getRed(), clientColor.getGreen(), clientColor.getBlue(), hsb);
/* 43 */     float brightness = Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0F + 50.0F / count * 2.0F) % 2.0F - 1.0F);
/* 44 */     brightness = 0.5F + 0.5F * brightness;
/* 45 */     hsb[2] = brightness % 2.0F;
/* 46 */     return new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
/*    */   }
/*    */   
/*    */   public static Color rainbow(long offset, int alpha) {
/* 50 */     float hue = (float)((System.currentTimeMillis() * ((Double)ColorsModule.speed.getValue()).doubleValue() / 10.0D + (offset * 500L)) % 30000.0D / ((Double)ColorsModule.difference.getValue()).doubleValue() / 100.0D / 30000.0D / ((Double)ColorsModule.difference.getValue()).doubleValue() / 20.0D);
/* 51 */     int rgb = Color.HSBtoRGB(hue, ((Double)ColorsModule.saturation.getValue()).floatValue(), ((Double)ColorsModule.brightness.getValue()).floatValue());
/* 52 */     int red = rgb >> 16 & 0xFF;
/* 53 */     int green = rgb >> 8 & 0xFF;
/* 54 */     int blue = rgb & 0xFF;
/* 55 */     return new Color(red, green, blue, alpha);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\string\ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */