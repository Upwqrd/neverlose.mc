/*     */ package cope.cosmos.util.file;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileSystemUtil
/*     */ {
/*  23 */   private static final List<Path> WRITING_PATHS = new CopyOnWriteArrayList<>();
/*     */ 
/*     */   
/*  26 */   public static final Path RUNNING_DIRECTORY = Paths.get("", new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Path COSMOS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     Path dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String read(Path path, boolean createIfNotExist) {
/*  46 */     if (Files.isDirectory(path, new java.nio.file.LinkOption[0])) {
/*  47 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  51 */     if (createIfNotExist) {
/*  52 */       create(path);
/*     */     }
/*     */     
/*  55 */     InputStream stream = null;
/*  56 */     String content = null;
/*     */     
/*     */     try {
/*  59 */       stream = new FileInputStream(path.toFile());
/*     */       
/*  61 */       StringBuilder builder = new StringBuilder();
/*     */       
/*     */       int i;
/*     */       
/*  65 */       while ((i = stream.read()) != -1) {
/*  66 */         builder.append((char)i);
/*     */       }
/*     */ 
/*     */       
/*  70 */       content = builder.toString();
/*  71 */     } catch (IOException e) {
/*  72 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/*     */       
/*  76 */       if (stream != null) {
/*     */         try {
/*  78 */           stream.close();
/*  79 */         } catch (IOException e) {
/*  80 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  85 */     return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void write(Path path, String content) {
/*  96 */     if (WRITING_PATHS.contains(path)) {
/*     */       
/*  98 */       System.out.println("[Cosmos] Tried to write to path " + path + " while already writing to it! Aborting...");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 103 */     create(path);
/*     */ 
/*     */     
/* 106 */     OutputStream stream = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 111 */       WRITING_PATHS.add(path);
/*     */ 
/*     */       
/* 114 */       stream = new FileOutputStream(path.toFile());
/*     */ 
/*     */       
/* 117 */       stream.write(content.getBytes(StandardCharsets.UTF_8), 0, content.length());
/* 118 */     } catch (IOException e) {
/*     */ 
/*     */       
/* 121 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/*     */       
/* 125 */       if (stream != null) {
/*     */         try {
/* 127 */           stream.close();
/* 128 */         } catch (IOException e) {
/* 129 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 135 */     WRITING_PATHS.remove(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void create(Path path) {
/* 143 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       
/*     */       try {
/*     */         
/* 147 */         Files.createFile(path, (FileAttribute<?>[])new FileAttribute[0]);
/* 148 */       } catch (IOException e) {
/* 149 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWriteable(Path path) {
/* 161 */     return (Files.exists(path, new java.nio.file.LinkOption[0]) && Files.isWritable(path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void createSystemFile(Path path, boolean directory) {
/* 170 */     if (Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 174 */     if (directory) {
/*     */       try {
/* 176 */         Files.createDirectory(path, (FileAttribute<?>[])new FileAttribute[0]);
/* 177 */       } catch (IOException e) {
/* 178 */         e.printStackTrace();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 183 */       create(path);
/*     */     } 
/*     */ 
/*     */     
/* 187 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 188 */       System.out.println("[Cosmos] Created the " + (directory ? "directory" : "file") + " " + path + " successfully.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 199 */       dir = (new File(System.getProperty("user.dir"))).toPath();
/* 200 */     } catch (Exception ignored) {
/* 201 */       dir = RUNNING_DIRECTORY;
/*     */     } 
/*     */ 
/*     */     
/* 205 */     if (dir == null || !isWriteable(dir)) {
/* 206 */       dir = RUNNING_DIRECTORY;
/*     */     }
/*     */ 
/*     */     
/* 210 */     COSMOS = dir.resolve("neverlose.mc");
/*     */   }
/* 212 */   public static final Path INFO = COSMOS.resolve("info.toml");
/* 213 */   public static final Path SOCIAL = COSMOS.resolve("social.toml");
/* 214 */   public static final Path ALTS = COSMOS.resolve("alts.toml");
/* 215 */   public static final Path WALLHACK = COSMOS.resolve("wallhack_blocks.toml");
/* 216 */   public static final Path GUI = COSMOS.resolve("gui.toml");
/*     */ 
/*     */   
/* 219 */   public static final Path PRESETS = COSMOS.resolve("presets");
/*     */   
/*     */   static {
/* 222 */     createSystemFile(COSMOS, true);
/* 223 */     createSystemFile(PRESETS, true);
/*     */     
/* 225 */     createSystemFile(INFO, false);
/* 226 */     createSystemFile(SOCIAL, false);
/* 227 */     createSystemFile(ALTS, false);
/* 228 */     createSystemFile(WALLHACK, false);
/* 229 */     createSystemFile(GUI, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmo\\util\file\FileSystemUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */