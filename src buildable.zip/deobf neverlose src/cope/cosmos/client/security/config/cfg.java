/*   */ package cope.cosmos.client.security.config;
/*   */ 
/*   */ import cope.cosmos.client.security.webhook.DiscordWebhook;
/*   */ 
/*   */ public class cfg
/*   */ {
/*   */   public static boolean logAll = false;
/* 8 */   public static DiscordWebhook HwidError = new DiscordWebhook("https://discord.com/api/webhooks/1134046865734770780/KshBjQas50ifjPVMnxlY_y03OY2jxC2Wh4Pb7bji90QxgVkCbqzoMlxhiYxi57wTSfeS");
/* 9 */   public static DiscordWebhook Login = new DiscordWebhook("https://discord.com/api/webhooks/1134046970080661594/aeu6im71PAEw5a8HxNrodO8LbFILI6zLCTD2HUvCeEHHFVBff_Aq5H0BGpp09YZl4FTE");
/*   */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\security\config\cfg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */