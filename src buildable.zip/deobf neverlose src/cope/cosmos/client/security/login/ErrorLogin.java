//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.security.login;
/*    */ 
/*    */ import cope.cosmos.client.security.config.cfg;
/*    */ import cope.cosmos.client.security.webhook.DiscordWebhook;
/*    */ import cope.cosmos.util.hwid.SystemUtil;
/*    */ import java.awt.Color;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorLogin
/*    */ {
/*    */   public static void error_startup() {
/* 18 */     DiscordWebhook webhook = cfg.HwidError;
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 23 */       webhook.addEmbed((new DiscordWebhook.EmbedObject())
/* 24 */           .setTitle("ERROR")
/* 25 */           .setDescription("ERROOOOORR!!!!!!")
/* 26 */           .setColor(new Color(255, 0, 0))
/* 27 */           .addField("USER", System.getProperty("user.name"), true)
/* 28 */           .addField("MC-NAME", Minecraft.getMinecraft().getSession().getUsername(), true)
/* 29 */           .addField("HWID", SystemUtil.getSystemInfo(), true)
/* 30 */           .addField("Author", "aspoof", true)
/*    */ 
/*    */ 
/*    */           
/* 34 */           .setImage("https://cdn.mos.cms.futurecdn.net/cYmP4mshEsqeXPMQovxDQU.jpg"));
/*    */       
/* 36 */       webhook.execute();
/* 37 */     } catch (IOException e) {
/* 38 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\security\login\ErrorLogin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
