//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.security.login;
/*    */ 
/*    */ import cope.cosmos.client.security.config.cfg;
/*    */ import cope.cosmos.client.security.webhook.DiscordWebhook;
/*    */ import java.awt.Color;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuccessfulLogin
/*    */ {
/*    */   public static void startup() {
/* 18 */     DiscordWebhook webhook = cfg.Login;
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 23 */       webhook.addEmbed((new DiscordWebhook.EmbedObject())
/* 24 */           .setTitle("Login")
/* 25 */           .setDescription("Successful login to neverlose")
/* 26 */           .setColor(new Color(255, 0, 0))
/* 27 */           .addField("USER", System.getProperty("user.name"), true)
/* 28 */           .addField("MC-NAME", Minecraft.getMinecraft().getSession().getUsername(), true)
/* 29 */           .addField("Author", "aspoof", true)
/*    */ 
/*    */           
/* 32 */           .setImage("https://media.discordapp.net/attachments/1112038417413447771/1133230703937601537/Screenshot_20230724_215405.jpg"));
/*    */       
/* 34 */       webhook.execute();
/* 35 */     } catch (IOException e) {
/* 36 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\security\login\SuccessfulLogin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
