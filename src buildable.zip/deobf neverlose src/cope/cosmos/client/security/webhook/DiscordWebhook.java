/*     */ package cope.cosmos.client.security.webhook;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscordWebhook
/*     */ {
/*     */   private final String url;
/*     */   private String content;
/*     */   private String username;
/*     */   private String avatarUrl;
/*     */   private boolean tts;
/*  27 */   private List<EmbedObject> embeds = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscordWebhook(String url) {
/*  35 */     this.url = url;
/*     */   }
/*     */   
/*     */   public void setContent(String content) {
/*  39 */     this.content = content;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  43 */     this.username = username;
/*     */   }
/*     */   
/*     */   public void setAvatarUrl(String avatarUrl) {
/*  47 */     this.avatarUrl = avatarUrl;
/*     */   }
/*     */   
/*     */   public void setTts(boolean tts) {
/*  51 */     this.tts = tts;
/*     */   }
/*     */   
/*     */   public void addEmbed(EmbedObject embed) {
/*  55 */     this.embeds.add(embed);
/*     */   }
/*     */   public void clearEmbeds() {
/*  58 */     this.embeds.clear();
/*     */   }
/*     */   
/*     */   public void execute() throws IOException {
/*  62 */     if (this.content == null && this.embeds.isEmpty()) {
/*  63 */       throw new IllegalArgumentException("Set content or add at least one EmbedObject");
/*     */     }
/*     */     
/*  66 */     JSONObject json = new JSONObject();
/*     */     
/*  68 */     json.put("content", this.content);
/*  69 */     json.put("username", this.username);
/*  70 */     json.put("avatar_url", this.avatarUrl);
/*  71 */     json.put("tts", Boolean.valueOf(this.tts));
/*     */     
/*  73 */     if (!this.embeds.isEmpty()) {
/*  74 */       List<JSONObject> embedObjects = new ArrayList<>();
/*     */       
/*  76 */       for (EmbedObject embed : this.embeds) {
/*  77 */         JSONObject jsonEmbed = new JSONObject();
/*     */         
/*  79 */         jsonEmbed.put("title", embed.getTitle());
/*  80 */         jsonEmbed.put("description", embed.getDescription());
/*  81 */         jsonEmbed.put("url", embed.getUrl());
/*     */         
/*  83 */         if (embed.getColor() != null) {
/*  84 */           Color color = embed.getColor();
/*  85 */           int rgb = color.getRed();
/*  86 */           rgb = (rgb << 8) + color.getGreen();
/*  87 */           rgb = (rgb << 8) + color.getBlue();
/*     */           
/*  89 */           jsonEmbed.put("color", Integer.valueOf(rgb));
/*     */         } 
/*     */         
/*  92 */         EmbedObject.Footer footer = embed.getFooter();
/*  93 */         EmbedObject.Image image = embed.getImage();
/*  94 */         EmbedObject.Thumbnail thumbnail = embed.getThumbnail();
/*  95 */         EmbedObject.Author author = embed.getAuthor();
/*  96 */         List<EmbedObject.Field> fields = embed.getFields();
/*     */         
/*  98 */         if (footer != null) {
/*  99 */           JSONObject jsonFooter = new JSONObject();
/*     */           
/* 101 */           jsonFooter.put("text", footer.getText());
/* 102 */           jsonFooter.put("icon_url", footer.getIconUrl());
/* 103 */           jsonEmbed.put("footer", jsonFooter);
/*     */         } 
/*     */         
/* 106 */         if (image != null) {
/* 107 */           JSONObject jsonImage = new JSONObject();
/*     */           
/* 109 */           jsonImage.put("url", image.getUrl());
/* 110 */           jsonEmbed.put("image", jsonImage);
/*     */         } 
/*     */         
/* 113 */         if (thumbnail != null) {
/* 114 */           JSONObject jsonThumbnail = new JSONObject();
/*     */           
/* 116 */           jsonThumbnail.put("url", thumbnail.getUrl());
/* 117 */           jsonEmbed.put("thumbnail", jsonThumbnail);
/*     */         } 
/*     */         
/* 120 */         if (author != null) {
/* 121 */           JSONObject jsonAuthor = new JSONObject();
/*     */           
/* 123 */           jsonAuthor.put("name", author.getName());
/* 124 */           jsonAuthor.put("url", author.getUrl());
/* 125 */           jsonAuthor.put("icon_url", author.getIconUrl());
/* 126 */           jsonEmbed.put("author", jsonAuthor);
/*     */         } 
/*     */         
/* 129 */         List<JSONObject> jsonFields = new ArrayList<>();
/* 130 */         for (EmbedObject.Field field : fields) {
/* 131 */           JSONObject jsonField = new JSONObject();
/*     */           
/* 133 */           jsonField.put("name", field.getName());
/* 134 */           jsonField.put("value", field.getValue());
/* 135 */           jsonField.put("inline", Boolean.valueOf(field.isInline()));
/*     */           
/* 137 */           jsonFields.add(jsonField);
/*     */         } 
/*     */         
/* 140 */         jsonEmbed.put("fields", jsonFields.toArray());
/* 141 */         embedObjects.add(jsonEmbed);
/*     */       } 
/*     */       
/* 144 */       json.put("embeds", embedObjects.toArray());
/*     */     } 
/*     */     
/* 147 */     URL url = new URL(this.url);
/* 148 */     HttpsURLConnection connection = (HttpsURLConnection)url.openConnection();
/* 149 */     connection.addRequestProperty("Content-Type", "application/json");
/* 150 */     connection.addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
/* 151 */     connection.setDoOutput(true);
/* 152 */     connection.setRequestMethod("POST");
/*     */     
/* 154 */     OutputStream stream = connection.getOutputStream();
/* 155 */     stream.write(json.toString().getBytes());
/* 156 */     stream.flush();
/* 157 */     stream.close();
/*     */     
/* 159 */     connection.getInputStream().close();
/* 160 */     connection.disconnect();
/*     */   }
/*     */   
/*     */   public static class EmbedObject
/*     */   {
/*     */     private String title;
/*     */     private String description;
/*     */     private String url;
/*     */     private Color color;
/*     */     private Footer footer;
/*     */     private Thumbnail thumbnail;
/*     */     private Image image;
/*     */     private Author author;
/* 173 */     private List<Field> fields = new ArrayList<>();
/*     */     
/*     */     public String getTitle() {
/* 176 */       return this.title;
/*     */     }
/*     */     
/*     */     public String getDescription() {
/* 180 */       return this.description;
/*     */     }
/*     */     
/*     */     public String getUrl() {
/* 184 */       return this.url;
/*     */     }
/*     */     
/*     */     public Color getColor() {
/* 188 */       return this.color;
/*     */     }
/*     */     
/*     */     public Footer getFooter() {
/* 192 */       return this.footer;
/*     */     }
/*     */     
/*     */     public Thumbnail getThumbnail() {
/* 196 */       return this.thumbnail;
/*     */     }
/*     */     
/*     */     public Image getImage() {
/* 200 */       return this.image;
/*     */     }
/*     */     
/*     */     public Author getAuthor() {
/* 204 */       return this.author;
/*     */     }
/*     */     
/*     */     public List<Field> getFields() {
/* 208 */       return this.fields;
/*     */     }
/*     */     
/*     */     public EmbedObject setTitle(String title) {
/* 212 */       this.title = title;
/* 213 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setDescription(String description) {
/* 217 */       this.description = description;
/* 218 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setUrl(String url) {
/* 222 */       this.url = url;
/* 223 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setColor(Color color) {
/* 227 */       this.color = color;
/* 228 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setFooter(String text, String icon) {
/* 232 */       this.footer = new Footer(text, icon);
/* 233 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setThumbnail(String url) {
/* 237 */       this.thumbnail = new Thumbnail(url);
/* 238 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setImage(String url) {
/* 242 */       this.image = new Image(url);
/* 243 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setAuthor(String name, String url, String icon) {
/* 247 */       this.author = new Author(name, url, icon);
/* 248 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject addField(String name, String value, boolean inline) {
/* 252 */       this.fields.add(new Field(name, value, inline));
/* 253 */       return this;
/*     */     }
/*     */     
/*     */     private class Footer {
/*     */       private String text;
/*     */       private String iconUrl;
/*     */       
/*     */       private Footer(String text, String iconUrl) {
/* 261 */         this.text = text;
/* 262 */         this.iconUrl = iconUrl;
/*     */       }
/*     */       
/*     */       private String getText() {
/* 266 */         return this.text;
/*     */       }
/*     */       
/*     */       private String getIconUrl() {
/* 270 */         return this.iconUrl;
/*     */       }
/*     */     }
/*     */     
/*     */     private class Thumbnail {
/*     */       private String url;
/*     */       
/*     */       private Thumbnail(String url) {
/* 278 */         this.url = url;
/*     */       }
/*     */       
/*     */       private String getUrl() {
/* 282 */         return this.url;
/*     */       }
/*     */     }
/*     */     
/*     */     private class Image {
/*     */       private String url;
/*     */       
/*     */       private Image(String url) {
/* 290 */         this.url = url;
/*     */       }
/*     */       
/*     */       private String getUrl() {
/* 294 */         return this.url;
/*     */       }
/*     */     }
/*     */     
/*     */     private class Author {
/*     */       private String name;
/*     */       private String url;
/*     */       private String iconUrl;
/*     */       
/*     */       private Author(String name, String url, String iconUrl) {
/* 304 */         this.name = name;
/* 305 */         this.url = url;
/* 306 */         this.iconUrl = iconUrl;
/*     */       }
/*     */       
/*     */       private String getName() {
/* 310 */         return this.name;
/*     */       }
/*     */       
/*     */       private String getUrl() {
/* 314 */         return this.url;
/*     */       }
/*     */       
/*     */       private String getIconUrl() {
/* 318 */         return this.iconUrl;
/*     */       }
/*     */     }
/*     */     
/*     */     private class Field {
/*     */       private String name;
/*     */       private String value;
/*     */       private boolean inline;
/*     */       
/*     */       private Field(String name, String value, boolean inline) {
/* 328 */         this.name = name;
/* 329 */         this.value = value;
/* 330 */         this.inline = inline;
/*     */       }
/*     */       
/*     */       private String getName() {
/* 334 */         return this.name;
/*     */       }
/*     */       
/*     */       private String getValue() {
/* 338 */         return this.value;
/*     */       }
/*     */       
/*     */       private boolean isInline() {
/* 342 */         return this.inline; } } } private class Footer { private String text; private String iconUrl; private Footer(String text, String iconUrl) { this.text = text; this.iconUrl = iconUrl; } private String getText() { return this.text; } private String getIconUrl() { return this.iconUrl; } } private class Thumbnail { private String url; private Thumbnail(String url) { this.url = url; } private String getUrl() { return this.url; } } private class Image { private String url; private Image(String url) { this.url = url; } private String getUrl() { return this.url; } } private class Author { private String name; private String url; private String iconUrl; private Author(String name, String url, String iconUrl) { this.name = name; this.url = url; this.iconUrl = iconUrl; } private String getName() { return this.name; } private String getUrl() { return this.url; } private String getIconUrl() { return this.iconUrl; } } private class Field { private String name; private boolean isInline() { return this.inline; } private String value; private boolean inline; private Field(String name, String value, boolean inline) { this.name = name;
/*     */       this.value = value;
/*     */       this.inline = inline; } private String getName() {
/*     */       return this.name;
/*     */     } private String getValue() {
/*     */       return this.value;
/*     */     } }
/* 349 */    private class JSONObject { private final HashMap<String, Object> map = new HashMap<>();
/*     */     
/*     */     void put(String key, Object value) {
/* 352 */       if (value != null) {
/* 353 */         this.map.put(key, value);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 359 */       StringBuilder builder = new StringBuilder();
/* 360 */       Set<Map.Entry<String, Object>> entrySet = this.map.entrySet();
/* 361 */       builder.append("{");
/*     */       
/* 363 */       int i = 0;
/* 364 */       for (Map.Entry<String, Object> entry : entrySet) {
/* 365 */         Object val = entry.getValue();
/* 366 */         builder.append(quote(entry.getKey())).append(":");
/*     */         
/* 368 */         if (val instanceof String) {
/* 369 */           builder.append(quote(String.valueOf(val)));
/* 370 */         } else if (val instanceof Integer) {
/* 371 */           builder.append(Integer.valueOf(String.valueOf(val)));
/* 372 */         } else if (val instanceof Boolean) {
/* 373 */           builder.append(val);
/* 374 */         } else if (val instanceof JSONObject) {
/* 375 */           builder.append(val.toString());
/* 376 */         } else if (val.getClass().isArray()) {
/* 377 */           builder.append("[");
/* 378 */           int len = Array.getLength(val);
/* 379 */           for (int j = 0; j < len; j++) {
/* 380 */             builder.append(Array.get(val, j).toString()).append((j != len - 1) ? "," : "");
/*     */           }
/* 382 */           builder.append("]");
/*     */         } 
/*     */         
/* 385 */         builder.append((++i == entrySet.size()) ? "}" : ",");
/*     */       } 
/*     */       
/* 388 */       return builder.toString();
/*     */     }
/*     */     
/*     */     private String quote(String string) {
/* 392 */       return "\"" + string + "\"";
/*     */     }
/*     */     
/*     */     private JSONObject() {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\security\webhook\DiscordWebhook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */