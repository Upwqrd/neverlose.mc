/*    */ package cope.cosmos.client.features.modules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Category
/*    */ {
/* 12 */   CLIENT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 17 */   COMBAT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   VISUAL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   PLAYER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   MOVEMENT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   MISC,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   HIDDEN;
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */