//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Bind;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category.CategoryFrameComponent;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClickGUIModule
/*    */   extends Module
/*    */ {
/*    */   public static ClickGUIModule INSTANCE;
/*    */   
/*    */   public ClickGUIModule() {
/* 23 */     super("ClickGUI", Category.CLIENT, "This screen.");
/* 24 */     INSTANCE = this;
/* 25 */     getBind().setValue(new Bind(54, Bind.Device.KEYBOARD));
/* 26 */     setExempt(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 31 */   public static Setting<Boolean> pauseGame = (new Setting("PauseGame", Boolean.valueOf(false)))
/* 32 */     .setDescription("Pause the game when in GUI");
/*    */   
/* 34 */   public static Setting<Boolean> blur = (new Setting("Blur", Boolean.valueOf(false)))
/* 35 */     .setDescription("Blur shader for GUI background");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 41 */     if (isEnabled() && mc.currentScreen == null) {
/*    */ 
/*    */       
/* 44 */       mc.displayGuiScreen((GuiScreen)getCosmos().getClickGUI());
/* 45 */       mc.currentScreen = (GuiScreen)getCosmos().getClickGUI();
/* 46 */       Cosmos.EVENT_BUS.register(getCosmos().getClickGUI());
/*    */ 
/*    */       
/* 49 */       getCosmos().getClickGUI().getCategoryFrameComponents().forEach(categoryFrameComponent -> categoryFrameComponent.setOpen(true));
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 54 */       if (((Boolean)blur.getValue()).booleanValue()) {
/* 55 */         mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onSettingEnable(SettingUpdateEvent event) {
/* 62 */     if (event.getSetting().equals(blur))
/*    */     {
/*    */       
/* 65 */       if (((Boolean)blur.getValue()).booleanValue()) {
/* 66 */         mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
/*    */       
/*    */       }
/* 69 */       else if (mc.entityRenderer.isShaderActive()) {
/* 70 */         mc.entityRenderer.getShaderGroup().deleteShaderGroup();
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\ClickGUIModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
