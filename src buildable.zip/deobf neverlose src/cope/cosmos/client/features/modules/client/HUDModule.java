//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.client;
/*     */ 
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.render.gui.RenderAdvancementEvent;
/*     */ import cope.cosmos.client.events.render.gui.RenderPotionHUDEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.movement.SpeedModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.TickManager;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import java.util.Comparator;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HUDModule
/*     */   extends Module
/*     */ {
/*     */   public static HUDModule INSTANCE;
/*     */   
/*     */   public HUDModule() {
/*  42 */     super("HUD", Category.CLIENT, "Displays the HUD");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.bottomRight = 10.0F;
/* 102 */     this.topRight = 10.0F;
/* 103 */     this.bottomLeft = 10.0F;
/*     */     setDrawn(false);
/*     */     setExempt(true);
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Boolean> watermark = (new Setting("Watermark", Boolean.valueOf(true))).setDescription("Displays a client watermark"); public static Setting<Boolean> activeModules = (new Setting("ActiveModules", Boolean.valueOf(true))).setDescription("Displays all enabled modules"); public static Setting<Rendering> rendering = (new Setting("Rendering", Rendering.UP)).setDescription("Rendering position of the elements"); public static Setting<Boolean> coordinates = (new Setting("Coordinates", Boolean.valueOf(true))).setDescription("Displays the user's coordinates"); public static Setting<Boolean> direction = (new Setting("Direction", Boolean.valueOf(true))).setDescription("Displays the user's facing direction"); public static Setting<Boolean> speed = (new Setting("Speed", Boolean.valueOf(true))).setDescription("Displays the user's speed"); public static Setting<Boolean> ping = (new Setting("Ping", Boolean.valueOf(true))).setDescription("Displays the user's server connection speed"); public static Setting<Boolean> fps = (new Setting("FPS", Boolean.valueOf(true))).setDescription("Displays the current FPS"); public static Setting<Boolean> tps = (new Setting("TPS", Boolean.valueOf(true))).setDescription("Displays the server TPS"); public static Setting<Boolean> armor = (new Setting("Armor", Boolean.valueOf(true))).setDescription("Displays the player's armor");
/*     */   
/*     */   public void onRender2D() {
/* 111 */     int SCREEN_WIDTH = (new ScaledResolution(mc)).getScaledWidth();
/* 112 */     int SCREEN_HEIGHT = (new ScaledResolution(mc)).getScaledHeight();
/*     */ 
/*     */     
/* 115 */     this.globalOffset = 0;
/* 116 */     this.topRight = 0.0F;
/* 117 */     this.bottomLeft = 10.0F;
/*     */     
/* 119 */     if (((Rendering)rendering.getValue()).equals(Rendering.UP)) {
/* 120 */       this.bottomRight = 10.0F;
/*     */     }
/*     */     else {
/*     */       
/* 124 */       this.bottomRight = 0.0F;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     if (mc.currentScreen instanceof net.minecraft.client.gui.GuiChat) {
/* 129 */       this.bottomLeft += 14.0F;
/*     */       
/* 131 */       if (((Rendering)rendering.getValue()).equals(Rendering.UP)) {
/* 132 */         this.bottomRight += 14.0F;
/*     */       }
/*     */       else {
/*     */         
/* 136 */         this.topRight += 14.0F;
/*     */       } 
/*     */     } 
/*     */     
/* 140 */     if (((Boolean)watermark.getValue()).booleanValue()) {
/* 141 */       FontUtil.drawStringWithShadow("neverlose.mc" + TextFormatting.WHITE + " " + "1.0b", 2.0F, 2.0F, ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */     }
/*     */     
/* 144 */     if (mc.currentScreen == null || mc.currentScreen instanceof net.minecraft.client.gui.GuiChat) {
/*     */ 
/*     */       
/* 147 */       if (((Boolean)activeModules.getValue()).booleanValue()) {
/* 148 */         this.listOffset = 0.0F;
/*     */         
/* 150 */         getCosmos().getModuleManager()
/* 151 */           .getModules(module -> module.isDrawn())
/* 152 */           .stream()
/* 153 */           .filter(module -> (module.getAnimation().getAnimationFactor() > 0.05D))
/* 154 */           .sorted(Comparator.comparing(module -> Integer.valueOf(FontUtil.getStringWidth(module.getName() + (!module.getInfo().equals("") ? (" [" + module.getInfo() + "]") : "")) * -1)))
/* 155 */           .forEach(module -> {
/*     */               StringBuilder moduleString = new StringBuilder(module.getName());
/*     */ 
/*     */               
/*     */               if (!module.getInfo().equals("")) {
/*     */                 moduleString.append(TextFormatting.GRAY).append(" [").append(TextFormatting.WHITE).append(module.getInfo()).append(TextFormatting.GRAY).append("]");
/*     */               }
/*     */ 
/*     */               
/*     */               FontUtil.drawStringWithShadow(moduleString.toString(), (float)(SCREEN_WIDTH - FontUtil.getStringWidth(moduleString.toString()) * module.getAnimation().getAnimationFactor() - 1.0D), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (2.0F + this.listOffset) : ((SCREEN_HEIGHT - 10) - this.listOffset - this.topRight), ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */ 
/*     */               
/*     */               this.listOffset = (float)(this.listOffset + (mc.fontRenderer.FONT_HEIGHT + 1) * module.getAnimation().getAnimationFactor());
/*     */               
/*     */               this.globalOffset++;
/*     */             });
/*     */       } 
/*     */       
/* 173 */       if (((Boolean)potionEffects.getValue()).booleanValue())
/*     */       {
/*     */         
/* 176 */         mc.player.getActivePotionEffects().forEach(potionEffect -> {
/*     */               String potionName = I18n.format(potionEffect.getEffectName(), new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (!potionName.equals("FullBright") && !potionName.equals("SpeedMine")) {
/*     */                 StringBuilder potionFormatted = new StringBuilder(potionName);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 potionFormatted.append(" ").append(potionEffect.getAmplifier() + 1).append(ChatFormatting.WHITE).append(" ").append(Potion.getPotionDurationString(potionEffect, 1.0F));
/*     */ 
/*     */ 
/*     */                 
/*     */                 FontUtil.drawStringWithShadow(potionFormatted.toString(), (SCREEN_WIDTH - FontUtil.getStringWidth(potionFormatted.toString()) + 2), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (SCREEN_HEIGHT - this.bottomRight) : (2.0F + this.bottomRight), potionEffect.getPotion().getLiquidColor());
/*     */ 
/*     */ 
/*     */                 
/*     */                 this.bottomRight += FontUtil.getFontHeight() + 1.0F;
/*     */ 
/*     */ 
/*     */                 
/*     */                 this.globalOffset++;
/*     */               } 
/*     */             });
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 207 */       if (((Boolean)HUDModule.speed.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 210 */         double distanceX = mc.player.posX - mc.player.prevPosX;
/* 211 */         double distanceZ = mc.player.posZ - mc.player.prevPosZ;
/*     */ 
/*     */         
/* 214 */         float speed = MathUtil.roundFloat((MathHelper.sqrt(StrictMath.pow(distanceX, 2.0D) + StrictMath.pow(distanceZ, 2.0D)) / 1000.0F / 1.3888889E-5F * 50.0F / getCosmos().getTickManager().getTickLength()), 1);
/*     */ 
/*     */         
/* 217 */         if (MotionUtil.isMoving() && SpeedModule.INSTANCE.isEnabled()) {
/* 218 */           speed += 2.0F;
/*     */         }
/*     */ 
/*     */         
/* 222 */         String speedString = "Speed " + TextFormatting.WHITE + speed + " kmh";
/*     */ 
/*     */         
/* 225 */         FontUtil.drawStringWithShadow(speedString, (SCREEN_WIDTH - FontUtil.getStringWidth(speedString) - 2), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (SCREEN_HEIGHT - this.bottomRight) : (2.0F + this.bottomRight), ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */ 
/*     */         
/* 228 */         this.bottomRight += FontUtil.getFontHeight() + 1.0F;
/* 229 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 232 */       if (((Boolean)ping.getValue()).booleanValue()) {
/* 233 */         String pingDisplay = "Ping " + TextFormatting.WHITE + (!mc.isSingleplayer() ? ((NetHandlerPlayClient)Objects.<NetHandlerPlayClient>requireNonNull(mc.getConnection())).getPlayerInfo(mc.player.getUniqueID()).getResponseTime() : 0) + "ms";
/* 234 */         FontUtil.drawStringWithShadow(pingDisplay, (SCREEN_WIDTH - FontUtil.getStringWidth(pingDisplay) - 2), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (SCREEN_HEIGHT - this.bottomRight) : (2.0F + this.bottomRight), ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */ 
/*     */         
/* 237 */         this.bottomRight += FontUtil.getFontHeight() + 1.0F;
/* 238 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 241 */       if (((Boolean)tps.getValue()).booleanValue()) {
/* 242 */         String tpsDisplay = "TPS " + TextFormatting.WHITE + Cosmos.INSTANCE.getTickManager().getTPS(TickManager.TPS.AVERAGE);
/* 243 */         FontUtil.drawStringWithShadow(tpsDisplay, (SCREEN_WIDTH - FontUtil.getStringWidth(tpsDisplay) - 2), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (SCREEN_HEIGHT - this.bottomRight) : (2.0F + this.bottomRight), ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */ 
/*     */         
/* 246 */         this.bottomRight += FontUtil.getFontHeight() + 1.0F;
/* 247 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 250 */       if (((Boolean)fps.getValue()).booleanValue()) {
/* 251 */         String tpsDisplay = "FPS " + TextFormatting.WHITE + Minecraft.getDebugFPS();
/* 252 */         FontUtil.drawStringWithShadow(tpsDisplay, (SCREEN_WIDTH - FontUtil.getStringWidth(tpsDisplay) - 2), ((Rendering)rendering.getValue()).equals(Rendering.UP) ? (SCREEN_HEIGHT - this.bottomRight) : (2.0F + this.bottomRight), ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/*     */ 
/*     */         
/* 255 */         this.bottomRight += FontUtil.getFontHeight() + 1.0F;
/* 256 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 259 */       if (((Boolean)coordinates.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 262 */         StringBuilder coordinateString = new StringBuilder();
/*     */ 
/*     */         
/* 265 */         boolean inNether = mc.world.getBiome(mc.player.getPosition()).getBiomeName().equalsIgnoreCase("Hell");
/*     */ 
/*     */         
/* 268 */         coordinateString.append("XYZ (")
/* 269 */           .append(TextFormatting.WHITE)
/* 270 */           .append(MathUtil.roundFloat(mc.player.posX, 1))
/* 271 */           .append(", ")
/* 272 */           .append(MathUtil.roundFloat(mc.player.posY, 1))
/* 273 */           .append(", ")
/* 274 */           .append(MathUtil.roundFloat(mc.player.posZ, 1))
/* 275 */           .append(TextFormatting.RESET)
/* 276 */           .append(") [")
/* 277 */           .append(TextFormatting.WHITE)
/* 278 */           .append(MathUtil.roundFloat(inNether ? (mc.player.posX * 8.0D) : (mc.player.posX / 8.0D), 1))
/* 279 */           .append(", ")
/* 280 */           .append(MathUtil.roundFloat(mc.player.posY, 1))
/* 281 */           .append(", ")
/* 282 */           .append(MathUtil.roundFloat(inNether ? (mc.player.posZ * 8.0D) : (mc.player.posZ / 8.0D), 1))
/* 283 */           .append(TextFormatting.RESET)
/* 284 */           .append("]");
/*     */         
/* 286 */         FontUtil.drawStringWithShadow(coordinateString.toString(), 2.0F, SCREEN_HEIGHT - this.bottomLeft, ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/* 287 */         this.bottomLeft += FontUtil.getFontHeight() + 1.0F;
/* 288 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 291 */       if (((Boolean)HUDModule.direction.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 294 */         EnumFacing direction = mc.player.getHorizontalFacing();
/* 295 */         EnumFacing.AxisDirection axisDirection = direction.getAxisDirection();
/*     */         
/* 297 */         FontUtil.drawStringWithShadow(StringFormatter.capitalise(direction.getName()) + " (" + TextFormatting.WHITE + StringFormatter.formatEnum((Enum)direction.getAxis()) + (axisDirection.equals(EnumFacing.AxisDirection.POSITIVE) ? "+" : "-") + TextFormatting.RESET + ")", 2.0F, SCREEN_HEIGHT - this.bottomLeft, ColorUtil.getPrimaryColor(this.globalOffset).getRGB());
/* 298 */         this.bottomLeft += FontUtil.getFontHeight() + 1.0F;
/* 299 */         this.globalOffset++;
/*     */       } 
/*     */       
/* 302 */       if (((Boolean)armor.getValue()).booleanValue()) {
/* 303 */         this.armorOffset = 0;
/* 304 */         mc.player.inventory.armorInventory.forEach(itemStack -> {
/*     */               if (!itemStack.isEmpty()) {
/*     */                 int yScaled = 0;
/*     */                 
/*     */                 if (mc.player.isInWater()) {
/*     */                   yScaled = 10;
/*     */                 }
/*     */                 
/*     */                 if (mc.player.capabilities.isCreativeMode) {
/*     */                   yScaled = -15;
/*     */                 }
/*     */                 
/*     */                 GlStateManager.pushMatrix();
/*     */                 
/*     */                 RenderHelper.enableGUIStandardItemLighting();
/*     */                 
/*     */                 (mc.getRenderItem()).zLevel = 200.0F;
/*     */                 
/*     */                 mc.getRenderItem().renderItemAndEffectIntoGUI(itemStack, SCREEN_WIDTH / 2 + (9 - this.armorOffset) * 16 - 78, SCREEN_HEIGHT - yScaled - 55);
/*     */                 
/*     */                 mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, itemStack, SCREEN_WIDTH / 2 + (9 - this.armorOffset) * 16 - 78, SCREEN_HEIGHT - yScaled - 55, "");
/*     */                 
/*     */                 (mc.getRenderItem()).zLevel = 0.0F;
/*     */                 
/*     */                 RenderHelper.disableStandardItemLighting();
/*     */                 
/*     */                 GlStateManager.popMatrix();
/*     */               } 
/*     */               
/*     */               this.armorOffset++;
/*     */             });
/*     */       } 
/*     */     } 
/*     */     
/* 338 */     if (((Boolean)tabGUI.getValue()).booleanValue())
/* 339 */       getCosmos().getTabGUI().render(); 
/*     */   }
/*     */   public static Setting<Boolean> tabGUI = (new Setting("TabGUI", Boolean.valueOf(false))).setDescription("Displays the client's TabGUI"); public static Setting<Boolean> potionEffects = (new Setting("PotionEffects", Boolean.valueOf(true))).setDescription("Displays the player's active potion effects"); public static Setting<Boolean> potionHUD = (new Setting("PotionHUD", Boolean.valueOf(false))).setDescription("Displays the vanilla potion effect hud"); public static Setting<Boolean> advancements = (new Setting("Advancements", Boolean.valueOf(false))).setDescription("Displays the vanilla advancement notification"); private int globalOffset; private float listOffset; private int armorOffset; private float bottomRight; private float topRight; private float bottomLeft;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 345 */     if (mc.currentScreen == null && (
/* 346 */       (Boolean)tabGUI.getValue()).booleanValue()) {
/* 347 */       getCosmos().getTabGUI().onKeyPress(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderPotionHUD(RenderPotionHUDEvent event) {
/* 354 */     if (!((Boolean)potionHUD.getValue()).booleanValue())
/*     */     {
/*     */       
/* 357 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderAdvancement(RenderAdvancementEvent event) {
/* 363 */     if (!((Boolean)advancements.getValue()).booleanValue())
/*     */     {
/*     */       
/* 366 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Rendering
/*     */   {
/* 375 */     UP,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     DOWN;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\HUDModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
