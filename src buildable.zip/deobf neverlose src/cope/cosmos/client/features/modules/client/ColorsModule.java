/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.features.PersistentFeature;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PersistentFeature
/*    */ public class ColorsModule
/*    */   extends Module
/*    */ {
/*    */   public static ColorsModule INSTANCE;
/*    */   
/*    */   public ColorsModule() {
/* 19 */     super("Colors", Category.CLIENT, "The universal color for the client");
/* 20 */     INSTANCE = this;
/* 21 */     setDrawn(false);
/* 22 */     setExempt(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public static Setting<Color> clientColor = (new Setting("ClientColor", new Color(118, 98, 224, 255)))
/* 28 */     .setDescription("The primary color for the client");
/*    */ 
/*    */ 
/*    */   
/* 32 */   public static Setting<Rainbow> rainbow = (new Setting("Rainbow", Rainbow.NONE))
/* 33 */     .setDescription("Add a rainbow effect to the client color");
/*    */   
/* 35 */   public static Setting<Double> speed = (new Setting("RainbowSpeed", Double.valueOf(0.1D), Double.valueOf(50.0D), Double.valueOf(100.0D), 1))
/* 36 */     .setDescription("Speed of the rainbow")
/* 37 */     .setVisible(() -> Boolean.valueOf(!((Rainbow)rainbow.getValue()).equals(Rainbow.NONE)));
/*    */   
/* 39 */   public static Setting<Double> saturation = (new Setting("RainbowSaturation", Double.valueOf(0.01D), Double.valueOf(0.35D), Double.valueOf(1.0D), 2))
/* 40 */     .setDescription("Saturation of the rainbow")
/* 41 */     .setVisible(() -> Boolean.valueOf(!((Rainbow)rainbow.getValue()).equals(Rainbow.NONE)));
/*    */   
/* 43 */   public static Setting<Double> brightness = (new Setting("RainbowBrightness", Double.valueOf(0.01D), Double.valueOf(1.0D), Double.valueOf(1.0D), 2))
/* 44 */     .setDescription("Brightness of the rainbow")
/* 45 */     .setVisible(() -> Boolean.valueOf(!((Rainbow)rainbow.getValue()).equals(Rainbow.NONE)));
/*    */   
/* 47 */   public static Setting<Double> difference = (new Setting("RainbowDifference", Double.valueOf(0.1D), Double.valueOf(40.0D), Double.valueOf(100.0D), 1))
/* 48 */     .setDescription("Difference offset of the rainbow")
/* 49 */     .setVisible(() -> Boolean.valueOf(!((Rainbow)rainbow.getValue()).equals(Rainbow.NONE)));
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Rainbow
/*    */   {
/* 56 */     GRADIENT,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     STATIC,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 66 */     ALPHA,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\ColorsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */