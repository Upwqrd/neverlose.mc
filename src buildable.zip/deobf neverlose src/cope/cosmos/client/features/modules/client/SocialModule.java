/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.events.render.gui.TabOverlayEvent;
/*    */ import cope.cosmos.client.features.PersistentFeature;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.client.manager.managers.SocialManager;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ @PersistentFeature
/*    */ public class SocialModule
/*    */   extends Module
/*    */ {
/*    */   public static SocialModule INSTANCE;
/*    */   
/*    */   public SocialModule() {
/* 21 */     super("Social", Category.CLIENT, "Allows the social system to function");
/* 22 */     INSTANCE = this;
/*    */     
/* 24 */     setExempt(true);
/* 25 */     setDrawn(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static Setting<Boolean> friends = (new Setting("Friends", Boolean.valueOf(true)))
/* 31 */     .setDescription("Allow friends system to function");
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTabOverlay(TabOverlayEvent event) {
/* 35 */     if (((Boolean)friends.getValue()).booleanValue())
/*    */     {
/*    */       
/* 38 */       if (getCosmos().getSocialManager().getSocial(event.getInformation()).equals(SocialManager.Relationship.FRIEND)) {
/*    */ 
/*    */         
/* 41 */         event.setCanceled(true);
/* 42 */         event.setInformation(TextFormatting.AQUA + event.getInformation());
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\SocialModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */