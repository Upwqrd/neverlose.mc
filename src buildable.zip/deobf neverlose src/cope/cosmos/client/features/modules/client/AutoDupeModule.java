//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.client;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItemFrame;
/*     */ import net.minecraft.entity.passive.AbstractChestHorse;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumHand;
/*     */ 
/*     */ public class AutoDupeModule extends Module {
/*     */   public static AutoDupeModule INSTANCE;
/*     */   public static Setting<Boolean> shulkersonly = new Setting("ShulkersOnly", Boolean.valueOf(true));
/*     */   public static Setting<Float> range = new Setting("Range", Float.valueOf(0.0F), Float.valueOf(5.0F), Float.valueOf(6.0F), 1);
/*     */   
/*     */   public AutoDupeModule() {
/*  21 */     super("AutoDupe", Category.CLIENT, "Auto dupes");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  29 */     this.timeout_ticks = 0;
/*     */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   public static Setting<Float> turns = new Setting("Turns", Float.valueOf(0.0F), Float.valueOf(1.0F), Float.valueOf(3.0F), 1);
/*     */   
/*     */   public void onUpdate() {
/*  36 */     if (mc.player != null && mc.world != null) {
/*     */       
/*  38 */       this; if (((Boolean)shulkersonly.getValue()).booleanValue()) {
/*  39 */         int shulker_slot = getShulkerSlot();
/*  40 */         if (shulker_slot != -1) {
/*  41 */           mc.player.inventory.currentItem = shulker_slot;
/*     */         }
/*     */       } 
/*  44 */       for (Entity frame : mc.world.loadedEntityList) {
/*     */         
/*  46 */         this; if (frame instanceof EntityItemFrame && mc.player.getDistance(frame) <= ((Float)range.getValue()).floatValue()) {
/*  47 */           this; if (this.timeout_ticks >= ((Float)ticks.getValue()).floatValue()) {
/*  48 */             if (((EntityItemFrame)frame).getDisplayedItem().getItem() == Items.AIR && !mc.player.getHeldItemMainhand().isEmpty()) {
/*  49 */               mc.playerController.interactWithEntity((EntityPlayer)mc.player, frame, EnumHand.MAIN_HAND);
/*     */             }
/*  51 */             if (((EntityItemFrame)frame).getDisplayedItem().getItem() != Items.AIR) {
/*  52 */               int i = 0; this; for (; i < ((Float)turns.getValue()).floatValue(); i++) {
/*  53 */                 mc.playerController.interactWithEntity((EntityPlayer)mc.player, frame, EnumHand.MAIN_HAND);
/*     */               }
/*  55 */               mc.playerController.attackEntity((EntityPlayer)mc.player, frame);
/*  56 */               this.timeout_ticks = 0;
/*     */             } 
/*     */           } 
/*  59 */           this.timeout_ticks++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public static Setting<Float> ticks = new Setting("Ticks", Float.valueOf(1.0F), Float.valueOf(10.0F), Float.valueOf(20.0F), 1);
/*     */   Entity donkey;
/*     */   private int timeout_ticks;
/*     */   
/*     */   private int getShulkerSlot() {
/*  69 */     int shulker_slot = -1;
/*  70 */     for (int i = 0; i < 9; i++) {
/*  71 */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/*  72 */       if (item instanceof net.minecraft.item.ItemShulkerBox) shulker_slot = i; 
/*     */     } 
/*  74 */     return shulker_slot;
/*     */   }
/*     */   
/*     */   public void putChestOn() {
/*  78 */     mc.player.inventory.currentItem = findAirInHotbar();
/*  79 */     mc.player.inventory.currentItem = findChestInHotbar();
/*  80 */     mc.playerController.interactWithEntity((EntityPlayer)mc.player, this.donkey, EnumHand.MAIN_HAND);
/*     */   }
/*     */   
/*     */   private int findChestInHotbar() {
/*  84 */     int slot = -1;
/*  85 */     for (int i = 0; i < 9; ) {
/*     */       
/*  87 */       ItemStack stack = mc.player.inventory.getStackInSlot(i); Block block;
/*  88 */       if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock) || !(block = ((ItemBlock)stack.getItem()).getBlock() instanceof net.minecraft.block.BlockChest)) {
/*     */         i++; continue;
/*  90 */       }  slot = i;
/*     */     } 
/*     */     
/*  93 */     return slot;
/*     */   }
/*     */   
/*     */   private int findAirInHotbar() {
/*  97 */     int slot = -1;
/*  98 */     for (int i = 0; i < 9; i++) {
/*  99 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 100 */       if (stack.getItem() == Items.AIR)
/* 101 */         slot = i; 
/*     */     } 
/* 103 */     return slot;
/*     */   }
/*     */   
/*     */   private boolean isValidEntity(Entity entity) {
/* 107 */     if (entity instanceof AbstractChestHorse) {
/* 108 */       AbstractChestHorse donkey = (AbstractChestHorse)entity;
/* 109 */       return (!donkey.isChild() && donkey.isTame());
/*     */     } 
/* 111 */     return false;
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 115 */     Frame;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\AutoDupeModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
