/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.events.render.gui.RenderFontEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FontModule
/*    */   extends Module
/*    */ {
/*    */   public static FontModule INSTANCE;
/*    */   
/*    */   public FontModule() {
/* 17 */     super("Font", Category.CLIENT, "Allows you to customize the client font.");
/* 18 */     INSTANCE = this;
/* 19 */     setDrawn(false);
/* 20 */     setExempt(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public static Setting<Boolean> vanilla = (new Setting("Vanilla", Boolean.valueOf(false)))
/* 26 */     .setDescription("Overrides the minecraft vanilla font");
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onFontRender(RenderFontEvent event) {
/* 30 */     if (((Boolean)vanilla.getValue()).booleanValue())
/*    */     {
/*    */       
/* 33 */       event.setCanceled(true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\FontModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */