//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.client;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ 
/*     */ public class StreamerModeModule
/*     */   extends Module
/*     */ {
/*     */   public static StreamerModeModule INSTANCE;
/*     */   private JFrame frame;
/*     */   
/*     */   public StreamerModeModule() {
/*  23 */     super("StreamerMode", Category.CLIENT, "Opens a separate window that shows your coordinates");
/*  24 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   private JLabel facing;
/*     */   private JLabel coordinates;
/*     */   private JLabel netherCoordinates;
/*     */   
/*     */   public void onEnable() {
/*  33 */     super.onEnable();
/*     */ 
/*     */     
/*  36 */     this.frame = new JFrame("Cosmos Streamer Mode");
/*     */     
/*  38 */     this.frame.setSize(1000, 350);
/*     */ 
/*     */     
/*  41 */     this.frame.setLayout(new BoxLayout(this.frame.getContentPane(), 1));
/*  42 */     this.frame.getContentPane().setBackground(Color.BLACK);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.facing = new JLabel("Facing: ");
/*  48 */     this.facing.setFont(new Font("Verdana", 0, 26));
/*     */     
/*  50 */     this.coordinates = new JLabel("XYZ: ");
/*  51 */     this.coordinates.setFont(new Font("Verdana", 0, 26));
/*     */     
/*  53 */     this.netherCoordinates = new JLabel("XYZ [Nether]: ");
/*  54 */     this.netherCoordinates.setFont(new Font("Verdana", 0, 26));
/*     */ 
/*     */     
/*  57 */     this.frame.add(this.facing);
/*  58 */     this.frame.add(this.coordinates);
/*  59 */     this.frame.add(this.netherCoordinates);
/*     */ 
/*     */     
/*  62 */     this.frame.addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent event)
/*     */           {
/*  66 */             StreamerModeModule.this.disable(true);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  71 */     this.frame.pack();
/*  72 */     this.frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  77 */     super.onDisable();
/*     */ 
/*     */     
/*  80 */     if (this.frame != null) {
/*  81 */       this.frame.setVisible(false);
/*  82 */       this.frame.dispose();
/*     */       
/*  84 */       this.facing = null;
/*  85 */       this.coordinates = null;
/*  86 */       this.netherCoordinates = null;
/*  87 */       this.frame = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  95 */     EnumFacing direction = mc.player.getHorizontalFacing();
/*  96 */     EnumFacing.AxisDirection axisDirection = direction.getAxisDirection();
/*     */     
/*  98 */     this.facing.setText("Facing: " + direction + " (" + StringFormatter.formatEnum((Enum)direction.getAxis()) + (axisDirection.equals(EnumFacing.AxisDirection.POSITIVE) ? "+" : "-") + ")");
/*     */ 
/*     */     
/* 101 */     String overWorldCoordinate = (mc.player.dimension != -1) ? ("XYZ " + MathUtil.roundFloat(mc.player.posX, 1) + " " + MathUtil.roundFloat(mc.player.posY, 1) + " " + MathUtil.roundFloat(mc.player.posZ, 1)) : ("XYZ " + MathUtil.roundFloat(mc.player.posX * 8.0D, 1) + " " + MathUtil.roundFloat(mc.player.posY * 8.0D, 1) + " " + MathUtil.roundFloat(mc.player.posZ * 8.0D, 1));
/* 102 */     String netherCoordinate = (mc.player.dimension == -1) ? ("XYZ " + MathUtil.roundFloat(mc.player.posX, 1) + " " + MathUtil.roundFloat(mc.player.posY, 1) + " " + MathUtil.roundFloat(mc.player.posZ, 1)) : ("XYZ " + MathUtil.roundFloat(mc.player.posX / 8.0D, 1) + " " + MathUtil.roundFloat(mc.player.posY / 8.0D, 1) + " " + MathUtil.roundFloat(mc.player.posZ / 8.0D, 1));
/*     */     
/* 104 */     this.coordinates.setText(overWorldCoordinate);
/* 105 */     this.netherCoordinates.setText("[Nether] " + netherCoordinate);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\StreamerModeModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
