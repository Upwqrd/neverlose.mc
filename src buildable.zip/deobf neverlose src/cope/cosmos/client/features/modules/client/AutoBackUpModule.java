//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.security.webhook.DiscordWebhook;
/*    */ import java.awt.Color;
/*    */ import java.io.IOException;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.client.multiplayer.ServerData;
/*    */ 
/*    */ public class AutoBackUpModule
/*    */   extends Module {
/*    */   DiscordWebhook discordWebhook;
/*    */   
/*    */   public AutoBackUpModule() {
/* 16 */     super("AutoBackUp", Category.CLIENT, "AutoSendBackUp massage");
/*    */     
/* 18 */     this.discordWebhook = new DiscordWebhook("https://discord.com/api/webhooks/1134053170562224149/-xocs0gLVYwpDscuzjA0w2wZ70VcuvOaiTsqQM2MIxJS3gU5-30E9abAGT6xq_l1tehq");
/*    */   } public void onEnable() {
/* 20 */     super.onEnable();
/*    */     try {
/* 22 */       this.discordWebhook.setContent("@everyone");
/* 23 */       this.discordWebhook.addEmbed((new DiscordWebhook.EmbedObject())
/* 24 */           .setTitle(mc.player.getName() + " ПР�?СИТ П�?М�?Щ�? П�?М�?ГИТЕ �?�?�?�?�?�?�?�?�?")
/* 25 */           .setColor(Color.PINK)
/* 26 */           .addField("Server", serverCheck(), true)
/* 27 */           .addField("Coords", "X: " + Math.round(mc.player.posX) + " Y: " + Math.round(mc.player.posY) + " Z: " + Math.round(mc.player.posZ), true)
/* 28 */           .addField("Dimension", dimensionCheck(), true));
/* 29 */       this.discordWebhook.execute();
/*    */     }
/* 31 */     catch (IOException e) {
/* 32 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public String serverCheck() {
/*    */     String ip;
/* 38 */     if (mc.isSingleplayer()) {
/* 39 */       ip = "SinglePlayer";
/*    */     } else {
/* 41 */       ip = ((ServerData)Objects.requireNonNull((T)mc.getCurrentServerData())).serverIP;
/*    */     } 
/* 43 */     return ip;
/*    */   }
/*    */   
/*    */   public String dimensionCheck() {
/*    */     String dim;
/* 48 */     int dimension = mc.player.dimension;
/* 49 */     if (dimension == 0) {
/* 50 */       dim = "OverWorld";
/* 51 */     } else if (dimension == -1) {
/* 52 */       dim = "Nether";
/*    */     } else {
/* 54 */       dim = "End";
/*    */     } 
/* 56 */     return dim;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\AutoBackUpModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
