/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.manager.managers.PresenceManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscordPresenceModule
/*    */   extends Module
/*    */ {
/*    */   public static DiscordPresenceModule INSTANCE;
/*    */   
/*    */   public DiscordPresenceModule() {
/* 15 */     super("DiscordPresence", Category.CLIENT, "Displays a custom presence on Discord");
/* 16 */     INSTANCE = this;
/*    */     
/* 18 */     setDrawn(false);
/* 19 */     setExempt(true);
/* 20 */     enable(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 25 */     super.onEnable();
/*    */ 
/*    */     
/* 28 */     PresenceManager.startPresence();
/*    */ 
/*    */     
/* 31 */     if (nullCheck()) {
/* 32 */       getCosmos().getChatManager().sendClientMessage("Starting Discord Presence!");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 38 */     super.onDisable();
/*    */ 
/*    */     
/* 41 */     PresenceManager.interruptPresence();
/*    */ 
/*    */     
/* 44 */     if (nullCheck())
/* 45 */       getCosmos().getChatManager().sendClientMessage("Shutting down Discord Presence!"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\DiscordPresenceModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */