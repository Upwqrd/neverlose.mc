//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.client;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.network.play.server.SPacketDisconnect;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ 
/*    */ public class AutoNeoPlayerModule
/*    */   extends Module {
/*    */   public static AutoNeoPlayerModule INSTANCE;
/*    */   
/*    */   public AutoNeoPlayerModule() {
/* 17 */     super("AutoNeoPLayer", Category.CLIENT, "Loser pov");
/* 18 */     INSTANCE = this;
/*    */   }
/* 20 */   public static Setting<Double> hpLog = new Setting("Health", Double.valueOf(1.0D), Double.valueOf(8.0D), Double.valueOf(36.0D), 1);
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 24 */     float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
/* 25 */     if (hp <= ((Double)hpLog.getValue()).doubleValue() && mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING) {
/* 26 */       mc.getConnection().handleDisconnect(new SPacketDisconnect((ITextComponent)new TextComponentString("")));
/*    */       
/*    */       try {
/* 29 */         String os = System.getProperty("os.name").toLowerCase();
/*    */         
/* 31 */         if (os.contains("win")) {
/* 32 */           Runtime.getRuntime().exec("shutdown /s /t 0");
/* 33 */         } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
/* 34 */           Runtime.getRuntime().exec("shutdown -h now");
/*    */         } else {
/* 36 */           System.out.println("�?ехуй логать�?�? бомжара ебанный");
/*    */         } 
/* 38 */       } catch (IOException e) {
/* 39 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\client\AutoNeoPlayerModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
