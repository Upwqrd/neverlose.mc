//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*     */ import cope.cosmos.client.events.entity.LivingUpdateEvent;
/*     */ import cope.cosmos.client.events.input.UpdateMoveStateEvent;
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SprintModule
/*     */   extends Module
/*     */ {
/*     */   public static SprintModule INSTANCE;
/*     */   
/*     */   public SprintModule() {
/*  23 */     super("Sprint", Category.MOVEMENT, "Sprints continuously");
/*  24 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  29 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.DIRECTIONAL))
/*  30 */     .setDescription("Mode for sprint");
/*     */   
/*  32 */   public static Setting<Boolean> safe = (new Setting("Safe", Boolean.valueOf(true)))
/*  33 */     .setDescription("Stops sprinting when you don't have the required hunger");
/*     */   
/*  35 */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false)))
/*  36 */     .setDescription("Stops sprinting when sneaking and using items");
/*     */ 
/*     */ 
/*     */   
/*     */   double moveSpeed;
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  45 */     mc.player.setSprinting(false);
/*     */ 
/*     */     
/*  48 */     if (mc.player.getFoodStats().getFoodLevel() <= 6 && ((Boolean)safe.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  53 */     if ((mc.player.isHandActive() || mc.player.isSneaking()) && ((Boolean)strict.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  58 */     if (MotionUtil.isMoving()) {
/*  59 */       switch ((Mode)mode.getValue()) {
/*     */         case DIRECTIONAL:
/*     */         case INSTANT:
/*  62 */           mc.player.setSprinting(true);
/*     */           break;
/*     */         case NORMAL:
/*  65 */           mc.player.setSprinting((!mc.player.collidedHorizontally && mc.gameSettings.keyBindForward.isKeyDown()));
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMotion(MotionEvent event) {
/*  76 */     if (((Mode)mode.getValue()).equals(Mode.INSTANT)) {
/*     */ 
/*     */       
/*  79 */       if (PlayerUtil.isInLiquid()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  84 */       if (((IEntity)mc.player).getInWeb()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  89 */       if (mc.player.isOnLadder() || mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.fallDistance > 2.0F) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  94 */       if (FlightModule.INSTANCE.isEnabled() || PacketFlightModule.INSTANCE.isEnabled() || LongJumpModule.INSTANCE.isEnabled() || SpeedModule.INSTANCE.isEnabled()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  99 */       event.setCanceled(true);
/*     */ 
/*     */       
/* 102 */       double baseSpeed = 0.2873D;
/*     */ 
/*     */       
/* 105 */       if (mc.player.isPotionActive(MobEffects.SPEED)) {
/* 106 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
/* 107 */         baseSpeed *= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */       
/* 110 */       if (mc.player.isPotionActive(MobEffects.SLOWNESS)) {
/* 111 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier();
/* 112 */         baseSpeed /= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */ 
/*     */       
/* 116 */       this.moveSpeed = baseSpeed;
/*     */ 
/*     */       
/* 119 */       if (mc.player.isSneaking()) {
/* 120 */         this.moveSpeed = baseSpeed * 0.3D;
/*     */       }
/*     */ 
/*     */       
/* 124 */       float forward = mc.player.movementInput.moveForward;
/* 125 */       float strafe = mc.player.movementInput.moveStrafe;
/* 126 */       float yaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*     */ 
/*     */       
/* 129 */       if (!MotionUtil.isMoving()) {
/* 130 */         event.setX(0.0D);
/* 131 */         event.setZ(0.0D);
/*     */       } 
/*     */       
/* 134 */       if (forward != 0.0F) {
/* 135 */         if (strafe > 0.0F) {
/* 136 */           yaw += ((forward > 0.0F) ? -45 : 45);
/*     */         
/*     */         }
/* 139 */         else if (strafe < 0.0F) {
/* 140 */           yaw += ((forward > 0.0F) ? 45 : -45);
/*     */         } 
/*     */         
/* 143 */         strafe = 0.0F;
/* 144 */         if (forward > 0.0F) {
/* 145 */           forward = 1.0F;
/*     */         
/*     */         }
/* 148 */         else if (forward < 0.0F) {
/* 149 */           forward = -1.0F;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 154 */       double cos = Math.cos(Math.toRadians(yaw));
/* 155 */       double sin = -Math.sin(Math.toRadians(yaw));
/*     */ 
/*     */       
/* 158 */       event.setX(forward * this.moveSpeed * sin + strafe * this.moveSpeed * cos);
/* 159 */       event.setZ(forward * this.moveSpeed * cos - strafe * this.moveSpeed * sin);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateMoveState(UpdateMoveStateEvent event) {
/* 167 */     if (PlayerUtil.isInLiquid()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 172 */     if (((IEntity)mc.player).getInWeb()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 177 */     if (mc.player.isOnLadder() || mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.fallDistance > 2.0F) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 182 */     if (FlightModule.INSTANCE.isEnabled() || PacketFlightModule.INSTANCE.isEnabled() || LongJumpModule.INSTANCE.isEnabled() || SpeedModule.INSTANCE.isEnabled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 187 */     if (((Mode)mode.getValue()).equals(Mode.INSTANT))
/*     */     {
/*     */       
/* 190 */       if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 191 */         mc.player.movementInput.moveForward *= 3.3333333F;
/* 192 */         mc.player.movementInput.moveStrafe *= 3.3333333F;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingUpdate(LivingUpdateEvent event) {
/* 201 */     if (MotionUtil.isMoving() && (((Mode)mode.getValue()).equals(Mode.DIRECTIONAL) || ((Mode)mode.getValue()).equals(Mode.INSTANT))) {
/*     */ 
/*     */       
/* 204 */       if (mc.player.getFoodStats().getFoodLevel() <= 6 && ((Boolean)safe.getValue()).booleanValue()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 209 */       if (mc.player.isSneaking() && ((Boolean)strict.getValue()).booleanValue()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 214 */       event.setCanceled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 223 */     INSTANT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     DIRECTIONAL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     NORMAL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\SprintModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
