//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ISPacketEntityVelocity;
/*     */ import cope.cosmos.asm.mixins.accessor.ISPacketExplosion;
/*     */ import cope.cosmos.client.events.block.WaterCollisionEvent;
/*     */ import cope.cosmos.client.events.motion.collision.EntityCollisionEvent;
/*     */ import cope.cosmos.client.events.motion.movement.KnockBackEvent;
/*     */ import cope.cosmos.client.events.motion.movement.PushOutOfBlocksEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.projectile.EntityFishHook;
/*     */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*     */ import net.minecraft.network.play.server.SPacketEntityVelocity;
/*     */ import net.minecraft.network.play.server.SPacketExplosion;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class VelocityModule
/*     */   extends Module
/*     */ {
/*     */   public static VelocityModule INSTANCE;
/*     */   
/*     */   public VelocityModule() {
/*  28 */     super("Velocity", Category.MOVEMENT, "Take no knockback.", () -> "H" + horizontal.getValue() + "%, V" + vertical.getValue() + "%");
/*  29 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static Setting<Double> horizontal = (new Setting("Horizontal", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(100.0D), 2))
/*  35 */     .setDescription("Horizontal velocity modifier");
/*     */   
/*  37 */   public static Setting<Double> vertical = (new Setting("Vertical", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(100.0D), 2))
/*  38 */     .setDescription("Vertical velocity modifier");
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static Setting<Boolean> noPush = (new Setting("NoPush", Boolean.valueOf(true)))
/*  43 */     .setDescription("Prevents being pushed");
/*     */   
/*  45 */   public static Setting<Boolean> entities = (new Setting("Entities", Boolean.valueOf(true)))
/*  46 */     .setDescription("Prevents being pushed by entities")
/*  47 */     .setVisible(() -> (Boolean)noPush.getValue());
/*     */   
/*  49 */   public static Setting<Boolean> blocks = (new Setting("Blocks", Boolean.valueOf(true)))
/*  50 */     .setDescription("Prevents being pushed out of blocks")
/*  51 */     .setVisible(() -> (Boolean)noPush.getValue());
/*     */   
/*  53 */   public static Setting<Boolean> liquid = (new Setting("Liquid", Boolean.valueOf(true)))
/*  54 */     .setDescription("Prevents being pushed by liquids")
/*  55 */     .setVisible(() -> (Boolean)noPush.getValue());
/*     */   
/*  57 */   public static Setting<Boolean> fishHook = (new Setting("Fishhooks", Boolean.valueOf(true)))
/*  58 */     .setDescription("Prevents being pulled by fishhooks")
/*  59 */     .setVisible(() -> (Boolean)noPush.getValue());
/*     */ 
/*     */   
/*     */   private float collisionReduction;
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  66 */     if (((Boolean)noPush.getValue()).booleanValue() && ((Boolean)entities.getValue()).booleanValue())
/*     */     {
/*     */       
/*  69 */       mc.player.entityCollisionReduction = 1.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  75 */     super.onEnable();
/*     */ 
/*     */     
/*  78 */     this.collisionReduction = mc.player.entityCollisionReduction;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  83 */     super.onDisable();
/*     */ 
/*     */     
/*  86 */     mc.player.entityCollisionReduction = this.collisionReduction;
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/*  92 */     if (nullCheck()) {
/*     */ 
/*     */       
/*  95 */       if (event.getPacket() instanceof SPacketEntityVelocity)
/*     */       {
/*     */         
/*  98 */         if (((SPacketEntityVelocity)event.getPacket()).getEntityID() == mc.player.getEntityId())
/*     */         {
/*     */           
/* 101 */           if (((Double)horizontal.getValue()).doubleValue() == 0.0D && ((Double)vertical.getValue()).doubleValue() == 0.0D) {
/* 102 */             event.setCanceled(true);
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 108 */             SPacketEntityVelocity packet = (SPacketEntityVelocity)event.getPacket();
/* 109 */             if (packet.getEntityID() == mc.player.getEntityId()) {
/*     */ 
/*     */               
/* 112 */               int motionX = ((ISPacketEntityVelocity)packet).getMotionX() / 100;
/* 113 */               int motionY = ((ISPacketEntityVelocity)packet).getMotionY() / 100;
/* 114 */               int motionZ = ((ISPacketEntityVelocity)packet).getMotionZ() / 100;
/*     */ 
/*     */               
/* 117 */               ((ISPacketEntityVelocity)packet).setMotionX(motionX * ((Double)horizontal.getValue()).intValue());
/* 118 */               ((ISPacketEntityVelocity)packet).setMotionY(motionY * ((Double)vertical.getValue()).intValue());
/* 119 */               ((ISPacketEntityVelocity)packet).setMotionZ(motionZ * ((Double)horizontal.getValue()).intValue());
/*     */             } 
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 126 */       if (event.getPacket() instanceof SPacketExplosion)
/*     */       {
/*     */         
/* 129 */         if (((Double)horizontal.getValue()).doubleValue() == 0.0D && ((Double)vertical.getValue()).doubleValue() == 0.0D) {
/* 130 */           event.setCanceled(true);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 135 */           SPacketExplosion packet = (SPacketExplosion)event.getPacket();
/*     */ 
/*     */           
/* 138 */           float motionX = ((ISPacketExplosion)packet).getMotionX() / 100.0F;
/* 139 */           float motionY = ((ISPacketExplosion)packet).getMotionY() / 100.0F;
/* 140 */           float motionZ = ((ISPacketExplosion)packet).getMotionZ() / 100.0F;
/*     */ 
/*     */           
/* 143 */           ((ISPacketExplosion)packet).setMotionX(motionX * ((Double)horizontal.getValue()).floatValue());
/* 144 */           ((ISPacketExplosion)packet).setMotionY(motionY * ((Double)vertical.getValue()).floatValue());
/* 145 */           ((ISPacketExplosion)packet).setMotionZ(motionZ * ((Double)horizontal.getValue()).floatValue());
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 150 */       if (event.getPacket() instanceof SPacketEntityStatus && ((SPacketEntityStatus)event.getPacket()).getOpCode() == 31 && (
/* 151 */         (Boolean)fishHook.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 154 */         Entity entity = ((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world);
/*     */ 
/*     */         
/* 157 */         if (entity instanceof EntityFishHook) {
/*     */ 
/*     */           
/* 160 */           EntityFishHook entityFishHook = (EntityFishHook)entity;
/* 161 */           if (entityFishHook.caughtEntity.equals(mc.player)) {
/* 162 */             event.setCanceled(true);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPush(PushOutOfBlocksEvent event) {
/* 174 */     if (((Boolean)noPush.getValue()).booleanValue() && ((Boolean)blocks.getValue()).booleanValue()) {
/* 175 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onKnockback(KnockBackEvent event) {
/* 183 */     if (((Double)horizontal.getValue()).doubleValue() == 0.0D && ((Double)vertical.getValue()).doubleValue() == 0.0D) {
/* 184 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityCollision(EntityCollisionEvent event) {
/* 192 */     if (((Boolean)noPush.getValue()).booleanValue() && ((Boolean)entities.getValue()).booleanValue()) {
/* 193 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWaterCollision(WaterCollisionEvent event) {
/* 201 */     if (((Boolean)noPush.getValue()).booleanValue() && ((Boolean)liquid.getValue()).booleanValue())
/* 202 */       event.setCanceled(true); 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\VelocityModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
