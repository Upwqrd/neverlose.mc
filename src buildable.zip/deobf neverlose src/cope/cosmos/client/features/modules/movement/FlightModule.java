//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.asm.mixins.accessor.INetworkManager;
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class FlightModule
/*     */   extends Module
/*     */ {
/*     */   public static FlightModule INSTANCE;
/*     */   
/*     */   public FlightModule() {
/*  24 */     super("Flight", Category.MOVEMENT, "Allows player to fly", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*  25 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  30 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.CREATIVE))
/*  31 */     .setDescription("Mode for flight");
/*     */   
/*  33 */   public static Setting<Friction> friction = (new Setting("Friction", Friction.FAST))
/*  34 */     .setDescription("Mode for speed friction factor");
/*     */   
/*  36 */   public static Setting<Boolean> damage = (new Setting("Damage", Boolean.valueOf(false)))
/*  37 */     .setDescription("Attempt to damage player for smoother flight");
/*     */   
/*  39 */   public static Setting<Boolean> antiKick = (new Setting("AntiKick", Boolean.valueOf(true)))
/*  40 */     .setDescription("Prevents vanilla anticheat from kicking you");
/*     */   
/*  42 */   public static Setting<Boolean> ground = (new Setting("Ground", Boolean.valueOf(false)))
/*  43 */     .setDescription("Forces packets to be on the ground");
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static Setting<Double> speed = (new Setting("Speed", Double.valueOf(0.1D), Double.valueOf(1.0D), Double.valueOf(10.0D), 1))
/*  48 */     .setDescription("Speed for horizontal movement");
/*     */ 
/*     */   
/*     */   private boolean previousFly;
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  56 */     super.onEnable();
/*     */ 
/*     */     
/*  59 */     this.previousFly = mc.player.capabilities.isFlying;
/*     */ 
/*     */     
/*  62 */     if (((Mode)mode.getValue()).equals(Mode.VANILLA))
/*     */     {
/*     */       
/*  65 */       if (!mc.player.capabilities.isFlying || !mc.player.capabilities.allowFlying) {
/*  66 */         mc.player.capabilities.isFlying = true;
/*  67 */         mc.player.capabilities.allowFlying = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  72 */     if (((Boolean)damage.getValue()).booleanValue() && 
/*  73 */       mc.getConnection() != null) {
/*     */ 
/*     */       
/*  76 */       ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketPlayer.Position(mc.player.posX, (mc.player.getEntityBoundingBox()).minY + 3.5D, mc.player.posZ, false), null);
/*  77 */       ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketPlayer.Position(mc.player.posX, (mc.player.getEntityBoundingBox()).minY, mc.player.posZ, false), null);
/*  78 */       ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketPlayer.Position(mc.player.posX, (mc.player.getEntityBoundingBox()).minY, mc.player.posZ, true), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  85 */     super.onDisable();
/*     */ 
/*     */     
/*  88 */     mc.player.capabilities.isFlying = this.previousFly;
/*  89 */     mc.player.capabilities.allowFlying = this.previousFly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMotion(MotionEvent event) {
/*  96 */     event.setCanceled(true);
/*     */ 
/*     */     
/*  99 */     float flightSpeed = getSpeedWithFriction(((Double)speed.getValue()).floatValue());
/*     */ 
/*     */     
/* 102 */     if (((Mode)mode.getValue()).equals(Mode.CREATIVE)) {
/*     */ 
/*     */       
/* 105 */       if (mc.player.ticksExisted % 18 == 0 && ((Boolean)antiKick.getValue()).booleanValue()) {
/* 106 */         event.setY(-0.04D);
/*     */       }
/*     */       else {
/*     */         
/* 110 */         event.setY(0.0D);
/*     */       } 
/*     */ 
/*     */       
/* 114 */       if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 115 */         event.setY(flightSpeed);
/*     */       
/*     */       }
/* 118 */       else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 119 */         event.setY(-flightSpeed);
/*     */       } 
/*     */ 
/*     */       
/* 123 */       float forward = mc.player.movementInput.moveForward;
/* 124 */       float strafe = mc.player.movementInput.moveStrafe;
/* 125 */       float yaw = mc.player.rotationYaw;
/*     */ 
/*     */       
/* 128 */       if (!MotionUtil.isMoving()) {
/* 129 */         event.setX(0.0D);
/* 130 */         event.setZ(0.0D);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 136 */         double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 137 */         double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*     */ 
/*     */         
/* 140 */         event.setX((forward * flightSpeed) * cos + (strafe * flightSpeed) * sin);
/* 141 */         event.setZ((forward * flightSpeed) * sin - (strafe * flightSpeed) * cos);
/*     */ 
/*     */         
/* 144 */         if (!MotionUtil.isMoving()) {
/* 145 */           event.setX(0.0D);
/* 146 */           event.setZ(0.0D);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 152 */     else if (((Mode)mode.getValue()).equals(Mode.VANILLA)) {
/*     */ 
/*     */       
/* 155 */       if (mc.player.ticksExisted % 18 == 0 && ((Boolean)antiKick.getValue()).booleanValue()) {
/* 156 */         event.setY(-0.04D);
/*     */       }
/*     */ 
/*     */       
/* 160 */       if (!mc.player.capabilities.isFlying || !mc.player.capabilities.allowFlying) {
/* 161 */         mc.player.capabilities.isFlying = true;
/* 162 */         mc.player.capabilities.allowFlying = true;
/*     */       } 
/*     */ 
/*     */       
/* 166 */       mc.player.capabilities.setFlySpeed(flightSpeed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 174 */     if (event.getPacket() instanceof CPacketPlayer)
/*     */     {
/*     */       
/* 177 */       if (((Boolean)ground.getValue()).booleanValue()) {
/* 178 */         ((ICPacketPlayer)event.getPacket()).setOnGround(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSpeedWithFriction(float speed) {
/* 192 */     float baseSpeed = 0.2873F;
/*     */ 
/*     */     
/* 195 */     if (mc.player.isPotionActive(MobEffects.SPEED)) {
/* 196 */       double amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
/* 197 */       baseSpeed = (float)(baseSpeed * (1.0D + 0.2D * (amplifier + 1.0D)));
/*     */     } 
/*     */     
/* 200 */     if (mc.player.isPotionActive(MobEffects.SLOWNESS)) {
/* 201 */       double amplifier = mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier();
/* 202 */       baseSpeed = (float)(baseSpeed / (1.0D + 0.2D * (amplifier + 1.0D)));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     switch ((Friction)friction.getValue())
/*     */     
/*     */     { default:
/* 212 */         scaledSpeed = speed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         return Math.max(scaledSpeed, baseSpeed);case STRICT: scaledSpeed = speed - speed / 159.0F; return Math.max(scaledSpeed, baseSpeed);case FACTOR: break; }  float scaledSpeed = speed - 1.0E-9F; return Math.max(scaledSpeed, baseSpeed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 231 */     VANILLA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     CREATIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Friction
/*     */   {
/* 244 */     FACTOR,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     FAST,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     STRICT;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\FlightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
