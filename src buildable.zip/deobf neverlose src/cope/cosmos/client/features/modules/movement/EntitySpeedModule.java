//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import net.minecraft.entity.passive.EntityLlama;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntitySpeedModule
/*     */   extends Module
/*     */ {
/*     */   public static EntitySpeedModule INSTANCE;
/*     */   
/*     */   public EntitySpeedModule() {
/*  25 */     super("EntitySpeed", Category.MOVEMENT, "Allows you to move faster while riding entities");
/*  26 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  31 */   public static Setting<Double> speed = (new Setting("Speed", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(3.0D), 2))
/*  32 */     .setDescription("Speed when moving");
/*     */ 
/*     */ 
/*     */   
/*  36 */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false)))
/*  37 */     .setDescription("Remounts entities constantly");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  43 */     if (mc.player.isRiding() && mc.player.getRidingEntity() != null) {
/*     */ 
/*     */       
/*  46 */       (mc.player.getRidingEntity()).rotationYaw = mc.player.rotationYaw;
/*     */ 
/*     */       
/*  49 */       if (mc.player.getRidingEntity() instanceof EntityLlama) {
/*  50 */         ((EntityLlama)mc.player.getRidingEntity()).rotationYawHead = mc.player.rotationYawHead;
/*     */       }
/*     */ 
/*     */       
/*  54 */       if (mc.player.getRidingEntity().isInWater() || mc.player.getRidingEntity().isInLava()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  59 */       if (((IEntity)mc.player.getRidingEntity()).getInWeb()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  64 */       if ((mc.player.getRidingEntity()).fallDistance > 2.0F) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  69 */       double moveSpeed = ((Double)speed.getValue()).doubleValue();
/*     */ 
/*     */       
/*  72 */       float forward = mc.player.movementInput.moveForward;
/*  73 */       float strafe = mc.player.movementInput.moveStrafe;
/*  74 */       float yaw = mc.player.rotationYaw;
/*     */       
/*  76 */       if (((Boolean)strict.getValue()).booleanValue())
/*     */       {
/*     */         
/*  79 */         if (!mc.gameSettings.keyBindSneak.isKeyDown()) {
/*  80 */           mc.player.connection.sendPacket((Packet)new CPacketUseEntity(mc.player.getRidingEntity(), EnumHand.MAIN_HAND));
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*  85 */       if (!MotionUtil.isMoving()) {
/*  86 */         (mc.player.getRidingEntity()).motionX = 0.0D;
/*  87 */         (mc.player.getRidingEntity()).motionZ = 0.0D;
/*     */ 
/*     */       
/*     */       }
/*  91 */       else if (mc.world.getChunk((int)((mc.player.getRidingEntity()).posX + (mc.player.getRidingEntity()).motionX) >> 4, (int)((mc.player.getRidingEntity()).posZ + (mc.player.getRidingEntity()).motionX) >> 4) instanceof net.minecraft.world.chunk.EmptyChunk) {
/*  92 */         (mc.player.getRidingEntity()).motionX = 0.0D;
/*  93 */         (mc.player.getRidingEntity()).motionZ = 0.0D;
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/*  99 */         if (strafe > 0.0F) {
/* 100 */           yaw += (forward > 0.0F) ? -45.0F : 45.0F;
/*     */         
/*     */         }
/* 103 */         else if (strafe < 0.0F) {
/* 104 */           yaw += (forward > 0.0F) ? 45.0F : -45.0F;
/*     */         } 
/*     */         
/* 107 */         strafe = 0.0F;
/*     */         
/* 109 */         if (forward > 0.0F) {
/* 110 */           forward = 1.0F;
/*     */         
/*     */         }
/* 113 */         else if (forward < 0.0F) {
/* 114 */           forward = -1.0F;
/*     */         } 
/*     */ 
/*     */         
/* 118 */         double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 119 */         double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*     */ 
/*     */         
/* 122 */         (mc.player.getRidingEntity()).motionX = forward * moveSpeed * cos + strafe * moveSpeed * sin;
/* 123 */         (mc.player.getRidingEntity()).motionZ = forward * moveSpeed * sin - strafe * moveSpeed * cos;
/*     */ 
/*     */         
/* 126 */         if (!MotionUtil.isMoving()) {
/* 127 */           (mc.player.getRidingEntity()).motionX = 0.0D;
/* 128 */           (mc.player.getRidingEntity()).motionZ = 0.0D;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 138 */     if (mc.player.isRiding() && mc.player.getRidingEntity() != null)
/*     */     {
/*     */       
/* 141 */       if (!mc.gameSettings.keyBindSneak.isKeyDown()) {
/*     */ 
/*     */         
/* 144 */         if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketSetPassengers)
/*     */         {
/*     */           
/* 147 */           if (((Boolean)strict.getValue()).booleanValue()) {
/* 148 */             event.setCanceled(true);
/*     */           }
/*     */         }
/*     */ 
/*     */         
/* 153 */         if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook)
/*     */         {
/*     */           
/* 156 */           if (((Boolean)strict.getValue()).booleanValue())
/* 157 */             event.setCanceled(true); 
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\EntitySpeedModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
