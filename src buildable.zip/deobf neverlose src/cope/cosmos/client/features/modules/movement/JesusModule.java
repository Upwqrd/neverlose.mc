//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.client.events.motion.collision.CollisionBoundingBoxEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JesusModule
/*     */   extends Module
/*     */ {
/*     */   public static JesusModule INSTANCE;
/*     */   
/*     */   public JesusModule() {
/*  30 */     super("Jesus", Category.MOVEMENT, "Allows you to walk on water", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.floatTicks = 1000;
/*     */ 
/*     */     
/*  44 */     this.offsetTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onDisable() {
/*  48 */     super.onDisable();
/*     */ 
/*     */     
/*  51 */     this.floatOffset = 0.0D;
/*     */ 
/*     */     
/*  54 */     this.floatTicks = 1000;
/*  55 */     this.offsetTimer.resetTime();
/*  56 */     KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
/*     */   }
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.SOLID)).setDescription("Mode to use when walking on water");
/*     */   private double floatOffset;
/*     */   private int floatTicks;
/*     */   private final Timer offsetTimer;
/*     */   
/*     */   public void onUpdate() {
/*  64 */     if (((Mode)mode.getValue()).equals(Mode.SOLID) || ((Mode)mode.getValue()).equals(Mode.SOLID_STRICT)) {
/*  65 */       if (PlayerUtil.isInLiquid() || isStandingOnLiquid());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       if (PlayerUtil.isInLiquid() || mc.player.fallDistance > 3.0F || mc.player.isSneaking()) {
/*  74 */         this.floatOffset = 0.0D;
/*     */       }
/*     */ 
/*     */       
/*  78 */       if (!mc.player.isSneaking()) {
/*  79 */         if (PlayerUtil.isInLiquid()) {
/*  80 */           mc.player.motionY = 0.1D;
/*     */ 
/*     */           
/*  83 */           this.floatTicks = 0;
/*     */         
/*     */         }
/*  86 */         else if (this.floatTicks > 0 && this.floatTicks < 4) {
/*  87 */           mc.player.motionY = 0.1D;
/*     */         } 
/*     */         
/*  90 */         this.floatTicks++;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  95 */     else if (((Mode)mode.getValue()).equals(Mode.DOLPHIN) && 
/*  96 */       PlayerUtil.isInLiquid()) {
/*  97 */       KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBoundingBoxCollision(CollisionBoundingBoxEvent event) {
/* 105 */     if (nullCheck())
/*     */     {
/*     */       
/* 108 */       if (event.getEntity() != null && event.getEntity().equals(mc.player))
/*     */       {
/*     */         
/* 111 */         if (event.getBlock() instanceof net.minecraft.block.BlockLiquid)
/*     */         {
/*     */           
/* 114 */           if (!event.getBlock().equals(Blocks.FLOWING_LAVA) && !event.getBlock().equals(Blocks.FLOWING_WATER))
/*     */           {
/* 116 */             if (((Mode)mode.getValue()).equals(Mode.SOLID) || ((Mode)mode.getValue()).equals(Mode.SOLID_STRICT)) {
/*     */ 
/*     */               
/* 119 */               if (PlayerUtil.isInLiquid() || !isStandingOnLiquid()) {
/*     */                 return;
/*     */               }
/*     */ 
/*     */               
/* 124 */               if (mc.player.isBurning()) {
/*     */                 return;
/*     */               }
/*     */ 
/*     */               
/* 129 */               if (mc.player.fallDistance > 3.0F || mc.player.isSneaking() || mc.player.isRowingBoat()) {
/*     */                 return;
/*     */               }
/*     */ 
/*     */               
/* 134 */               AxisAlignedBB fullCollisionBox = (new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.921D, 1.0D)).offset(event.getPosition());
/*     */ 
/*     */               
/* 137 */               if (event.getCollisionBox().intersects(fullCollisionBox)) {
/* 138 */                 event.getCollisionList().add(fullCollisionBox);
/* 139 */                 event.setCanceled(true);
/*     */               } 
/*     */ 
/*     */               
/* 143 */               if (((Mode)mode.getValue()).equals(Mode.SOLID_STRICT)) {
/* 144 */                 Vec3d decelerationVector = event.getBlock().modifyAcceleration((World)mc.world, event.getPosition(), (Entity)mc.player, Vec3d.ZERO);
/* 145 */                 mc.player.motionX += decelerationVector.x * 0.014D;
/* 146 */                 mc.player.motionY += decelerationVector.y * 0.014D;
/* 147 */                 mc.player.motionZ += decelerationVector.z * 0.014D;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 160 */     if (event.getPacket() instanceof CPacketPlayer)
/*     */     {
/*     */       
/* 163 */       if (((ICPacketPlayer)event.getPacket()).isMoving())
/*     */       {
/*     */         
/* 166 */         if (!PlayerUtil.isInLiquid() && isStandingOnLiquid()) {
/*     */ 
/*     */           
/* 169 */           ((ICPacketPlayer)event.getPacket()).setOnGround(false);
/*     */ 
/*     */           
/* 172 */           if (((Mode)mode.getValue()).equals(Mode.SOLID)) {
/* 173 */             if (this.offsetTimer.passedTime(1L, Timer.Format.TICKS)) {
/* 174 */               this.floatOffset = 0.0D;
/* 175 */               this.offsetTimer.resetTime();
/*     */             }
/*     */             else {
/*     */               
/* 179 */               this.floatOffset = 0.2D;
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 184 */           else if (((Mode)mode.getValue()).equals(Mode.SOLID_STRICT)) {
/*     */ 
/*     */             
/* 187 */             ((ICPacketPlayer)event.getPacket()).setY(((CPacketPlayer)event.getPacket()).getY(mc.player.posY) - this.floatOffset);
/*     */ 
/*     */             
/* 190 */             this.floatOffset += 0.12D;
/*     */ 
/*     */             
/* 193 */             if (this.floatOffset > 0.4D) {
/* 194 */               this.floatOffset = 0.2D;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStandingOnLiquid() {
/* 207 */     return (mc.world.handleMaterialAcceleration(mc.player.getEntityBoundingBox().grow(0.0D, -3.0D, 0.0D).shrink(0.001D), Material.WATER, (Entity)mc.player) || mc.world.handleMaterialAcceleration(mc.player.getEntityBoundingBox().grow(0.0D, -3.0D, 0.0D).shrink(0.001D), Material.LAVA, (Entity)mc.player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 215 */     SOLID,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     SOLID_STRICT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     DOLPHIN;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\JesusModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
