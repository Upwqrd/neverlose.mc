//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.motion.movement.TravelEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElytraFlightModule
/*     */   extends Module
/*     */ {
/*     */   public static ElytraFlightModule INSTANCE;
/*     */   
/*     */   public ElytraFlightModule() {
/*  30 */     super("ElytraFlight", Category.MOVEMENT, "Allows you to fly faster on an elytra", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*  31 */     INSTANCE = this;
/*     */   }
/*     */   
/*  34 */   public static Setting<Elytra> mode = (new Setting("Mode", Elytra.CONTROL)).setDescription("Mode for ElytraFlight");
/*  35 */   public static Setting<Double> yaw = (new Setting("Yaw", Double.valueOf(0.0D), Double.valueOf(30.0D), Double.valueOf(90.0D), 1)).setDescription("Maximum allowed yaw").setVisible(() -> Boolean.valueOf(((Elytra)mode.getValue()).equals(Elytra.CONTROL_STRICT)));
/*  36 */   public static Setting<Double> pitch = (new Setting("Pitch", Double.valueOf(0.0D), Double.valueOf(30.0D), Double.valueOf(90.0D), 1)).setDescription("Maximum allowed pitch").setVisible(() -> Boolean.valueOf(((Elytra)mode.getValue()).equals(Elytra.CONTROL_STRICT)));
/*     */   
/*  38 */   public static Setting<Double> glide = (new Setting("Glide", Double.valueOf(0.0D), Double.valueOf(2.5D), Double.valueOf(5.0D), 2)).setDescription("Speed when gliding");
/*  39 */   public static Setting<Double> ascend = (new Setting("Ascend", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(5.0D), 2)).setDescription("Speed when ascending");
/*  40 */   public static Setting<Double> descend = (new Setting("Descend", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(5.0D), 2)).setDescription("Speed when descending");
/*  41 */   public static Setting<Double> fall = (new Setting("Fall", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(0.1D), 3)).setDescription("Speed when stationary");
/*  42 */   public static Setting<InventoryManager.Switch> firework = (new Setting("Firework", InventoryManager.Switch.NONE)).setDescription("Mode to switch to fireworks if necessary");
/*  43 */   public static Setting<Boolean> lockRotation = (new Setting("LockRotation", Boolean.valueOf(false))).setDescription("Locks rotation and flies in a straight path");
/*     */   
/*  45 */   public static Setting<Boolean> takeOff = (new Setting("TakeOff", Boolean.valueOf(false))).setDescription("Easier takeoff");
/*  46 */   public static Setting<Double> takeOffTimer = (new Setting("StartTimer", Double.valueOf(0.0D), Double.valueOf(0.2D), Double.valueOf(1.0D), 2)).setDescription("Timer ticks when taking off").setParent(takeOff);
/*     */   
/*  48 */   public static Setting<Boolean> pause = (new Setting("Pause", Boolean.valueOf(true))).setDescription("Pause elytra flight when");
/*  49 */   public static Setting<Boolean> pauseLiquid = (new Setting("PauseLiquid", Boolean.valueOf(true))).setDescription("When in liquid").setParent(pause);
/*  50 */   public static Setting<Boolean> pauseCollision = (new Setting("PauseCollision", Boolean.valueOf(false))).setDescription("When colliding").setParent(pause);
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTravel(TravelEvent event) {
/*  54 */     if (nullCheck() && 
/*  55 */       mc.player.isElytraFlying()) {
/*  56 */       if (((Boolean)pause.getValue()).booleanValue()) {
/*  57 */         if (PlayerUtil.isInLiquid() && ((Boolean)pauseLiquid.getValue()).booleanValue()) {
/*     */           return;
/*     */         }
/*     */         
/*  61 */         if (PlayerUtil.isCollided() && ((Boolean)pauseCollision.getValue()).booleanValue()) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  67 */       event.setCanceled(true);
/*     */       
/*  69 */       elytraFlight();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  76 */     super.onEnable();
/*     */     
/*  78 */     if (!mc.player.isElytraFlying() && ((Boolean)takeOff.getValue()).booleanValue()) {
/*  79 */       getCosmos().getTickManager().setClientTicks(((Double)takeOffTimer.getValue()).floatValue());
/*     */       
/*  81 */       if (mc.player.onGround) {
/*  82 */         mc.player.jump();
/*     */       }
/*     */       else {
/*     */         
/*  86 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void elytraFlight() {
/*  92 */     Cosmos.INSTANCE.getTickManager().setClientTicks(1.0F);
/*     */     
/*  94 */     if (((Boolean)lockRotation.getValue()).booleanValue()) {
/*  95 */       mc.player.rotationYaw = MathHelper.clamp(mc.player.rotationYaw, -((Double)yaw.getValue()).floatValue(), ((Double)yaw.getValue()).floatValue());
/*  96 */       mc.player.rotationPitch = MathHelper.clamp(mc.player.rotationPitch, -((Double)pitch.getValue()).floatValue(), ((Double)pitch.getValue()).floatValue());
/*     */     } 
/*     */     
/*  99 */     MotionUtil.stopMotion(-((Double)fall.getValue()).doubleValue());
/* 100 */     MotionUtil.setMoveSpeed(((Double)glide.getValue()).doubleValue(), 0.6F);
/*     */     
/* 102 */     switch ((Elytra)mode.getValue()) {
/*     */       case CONTROL:
/* 104 */         handleControl();
/*     */         break;
/*     */       case CONTROL_STRICT:
/* 107 */         handleStrict();
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 113 */     mc.player.prevLimbSwingAmount = 0.0F;
/* 114 */     mc.player.limbSwingAmount = 0.0F;
/* 115 */     mc.player.limbSwing = 0.0F;
/*     */   }
/*     */   
/*     */   public void handleControl() {
/* 119 */     if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 120 */       mc.player.motionY = ((Double)ascend.getValue()).doubleValue();
/*     */     
/*     */     }
/* 123 */     else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 124 */       mc.player.motionY = -((Double)descend.getValue()).doubleValue();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleStrict() {
/* 129 */     if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 130 */       mc.player.rotationPitch = -((Double)pitch.getValue()).floatValue();
/* 131 */       mc.player.motionY = ((Double)ascend.getValue()).doubleValue();
/*     */     
/*     */     }
/* 134 */     else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 135 */       mc.player.rotationPitch = ((Double)pitch.getValue()).floatValue();
/* 136 */       mc.player.motionY = -((Double)descend.getValue()).doubleValue();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 142 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook && !((InventoryManager.Switch)firework.getValue()).equals(InventoryManager.Switch.NONE) && 
/* 143 */       mc.player.isElytraFlying()) {
/* 144 */       getCosmos().getInventoryManager().switchToItem(Items.FIREWORKS, (InventoryManager.Switch)firework.getValue());
/* 145 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 152 */     return (isEnabled() && mc.player.isElytraFlying());
/*     */   }
/*     */   
/*     */   public enum Elytra {
/* 156 */     CONTROL, CONTROL_STRICT, PACKET;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\ElytraFlightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
