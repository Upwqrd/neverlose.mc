//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.client.events.motion.movement.StepEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.passive.EntityPig;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class StepModule
/*     */   extends Module
/*     */ {
/*     */   public static StepModule INSTANCE;
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.NORMAL)).setDescription("Mode for how to step up blocks");
/*     */   public static Setting<Double> height = (new Setting("Height", Double.valueOf(1.0D), Double.valueOf(1.0D), Double.valueOf(2.5D), 1)).setDescription("The maximum height to step up blocks");
/*     */   public static Setting<Boolean> useTimer = (new Setting("Timer", Boolean.valueOf(true))).setDescription("Uses timer to slow down packets").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.NORMAL)));
/*     */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("Confirms step height").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.NORMAL)));
/*     */   
/*     */   public StepModule() {
/*  26 */     super("Step", Category.MOVEMENT, "Allows you to step up blocks", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.stepTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onDisable() {
/*  60 */     super.onDisable();
/*     */ 
/*     */     
/*  63 */     mc.player.stepHeight = 0.6F;
/*     */     
/*  65 */     if (this.entityRiding != null)
/*  66 */       if (this.entityRiding instanceof net.minecraft.entity.passive.EntityHorse || this.entityRiding instanceof net.minecraft.entity.passive.EntityLlama || this.entityRiding instanceof net.minecraft.entity.passive.EntityMule || (this.entityRiding instanceof EntityPig && this.entityRiding.isBeingRidden() && ((EntityPig)this.entityRiding).canBeSteered())) {
/*  67 */         this.entityRiding.stepHeight = 1.0F;
/*     */       }
/*     */       else {
/*     */         
/*  71 */         this.entityRiding.stepHeight = 0.5F;
/*     */       }  
/*     */   }
/*     */   public static Setting<Boolean> entityStep = (new Setting("EntityStep", Boolean.valueOf(false))).setDescription("Allows you to step up blocks while riding entities");
/*     */   private boolean timer;
/*     */   private Entity entityRiding;
/*     */   private final Timer stepTimer;
/*     */   
/*     */   public void onUpdate() {
/*  80 */     if (this.timer && mc.player.onGround) {
/*  81 */       getCosmos().getTickManager().setClientTicks(1.0F);
/*  82 */       this.timer = false;
/*     */     } 
/*     */     
/*  85 */     if (mc.player.isRiding() && mc.player.getRidingEntity() != null) {
/*  86 */       this.entityRiding = mc.player.getRidingEntity();
/*     */ 
/*     */       
/*  89 */       if (((Boolean)entityStep.getValue()).booleanValue()) {
/*  90 */         (mc.player.getRidingEntity()).stepHeight = ((Double)height.getValue()).floatValue();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  95 */     if (mc.player.onGround && this.stepTimer.passedTime(200L, Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */       
/*  98 */       mc.player.stepHeight = ((Double)height.getValue()).floatValue();
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 103 */       mc.player.stepHeight = 0.5F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onStep(StepEvent event) {
/* 111 */     if (((Mode)mode.getValue()).equals(Mode.NORMAL)) {
/*     */ 
/*     */       
/* 114 */       double stepHeight = (event.getAxisAlignedBB()).minY - mc.player.posY;
/*     */ 
/*     */       
/* 117 */       if (stepHeight <= 0.0D || stepHeight > ((Double)height.getValue()).doubleValue()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 122 */       double[] offsets = getOffset(stepHeight);
/*     */ 
/*     */       
/* 125 */       if (offsets != null && offsets.length > 1) {
/*     */ 
/*     */         
/* 128 */         if (((Boolean)useTimer.getValue()).booleanValue()) {
/*     */ 
/*     */           
/* 131 */           getCosmos().getTickManager().setClientTicks(1.0F / offsets.length);
/*     */ 
/*     */           
/* 134 */           this.timer = true;
/*     */         } 
/*     */ 
/*     */         
/* 138 */         for (double offset : offsets) {
/* 139 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + offset, mc.player.posZ, false));
/*     */         }
/*     */       } 
/*     */       
/* 143 */       this.stepTimer.resetTime();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getOffset(double height) {
/* 156 */     if (height == 0.75D) {
/*     */       
/* 158 */       if (((Boolean)strict.getValue()).booleanValue()) {
/* 159 */         return new double[] { 0.42D, 0.753D, 0.75D };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       return new double[] { 0.42D, 0.753D };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     if (height == 0.8125D) {
/*     */       
/* 177 */       if (((Boolean)strict.getValue()).booleanValue()) {
/* 178 */         return new double[] { 0.39D, 0.7D, 0.8125D };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       return new double[] { 0.39D, 0.7D };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (height == 0.875D) {
/*     */       
/* 196 */       if (((Boolean)strict.getValue()).booleanValue()) {
/* 197 */         return new double[] { 0.39D, 0.7D, 0.875D };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       return new double[] { 0.39D, 0.7D };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (height == 1.0D) {
/*     */       
/* 215 */       if (((Boolean)strict.getValue()).booleanValue()) {
/* 216 */         return new double[] { 0.42D, 0.753D, 1.0D };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       return new double[] { 0.42D, 0.753D };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (height == 1.5D) {
/* 233 */       return new double[] { 0.42D, 0.75D, 1.0D, 1.16D, 1.23D, 1.2D };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     if (height == 2.0D) {
/* 245 */       return new double[] { 0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     if (height == 2.5D) {
/* 259 */       return new double[] { 0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D, 2.019D, 1.907D };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 281 */     NORMAL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     VANILLA;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\StepModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
