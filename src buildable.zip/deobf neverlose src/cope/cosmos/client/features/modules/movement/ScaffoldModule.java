/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class ScaffoldModule
/*     */   extends Module {
/*     */   public static ScaffoldModule INSTANCE;
/*     */   
/*     */   public ScaffoldModule() {
/*  20 */     super("Scaffold", Category.MOVEMENT, "Places blocks under you");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.positions = new ConcurrentLinkedQueue<>();
/*  46 */     this.currentVector = null;
/*     */     
/*  48 */     this.timer = new Timer();
/*  49 */     this.towerTimer = new Timer();
/*     */     
/*  51 */     this.oldSlot = -1;
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Double> extend = (new Setting("Extend", Double.valueOf(1.0D), Double.valueOf(1.0D), Double.valueOf(4.0D), 1)).setDescription("How far to extend the blocks");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Boolean> tower = (new Setting("Tower", Boolean.valueOf(false))).setDescription("If to place blocks going upwards rapidly");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("If to force blocks to be placed with strict servers in mind");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Swap> swap = (new Setting("Switch", Swap.NORMAL)).setDescription("How to switch to the block");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.PACKET)).setDescription("How to rotate when placing blocks");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Boolean> safewalk = (new Setting("Safewalk", Boolean.valueOf(true))).setDescription("If to attempt to stop you from walking off blocks");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(500.0D), 1)).setDescription("How long to wait before placing another block");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Boolean> render = (new Setting("Render", Boolean.valueOf(true))).setDescription("If to render the current box");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<RenderBuilder.Box> box = (new Setting("Box", RenderBuilder.Box.BOTH)).setDescription("How to render the current block").setParent(render);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<RenderBuilder.Box> outline = (new Setting("Outline", RenderBuilder.Box.OUTLINE)).setDescription("The outline of the rendered box").setParent(render);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Setting<Float> lineWidth = (new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(1.5F), Float.valueOf(5.0F), 1)).setDescription("The width of the lines rendered").setParent(render);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Queue<BlockPos> positions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vec3d currentVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Timer timer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Timer towerTimer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int oldSlot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Swap
/*     */   {
/* 230 */     NONE((String)InventoryManager.Switch.NONE),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     PACKET((String)InventoryManager.Switch.PACKET),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     NORMAL((String)InventoryManager.Switch.NORMAL),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     KEEP((String)InventoryManager.Switch.NORMAL);
/*     */     
/*     */     private final InventoryManager.Switch swap;
/*     */     
/*     */     Swap(InventoryManager.Switch swap) {
/* 252 */       this.swap = swap;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\ScaffoldModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */