//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityPlayerSP;
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.server.SPacketEntityVelocity;
/*     */ import net.minecraft.network.play.server.SPacketExplosion;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class SpeedModule
/*     */   extends Module
/*     */ {
/*     */   public static SpeedModule INSTANCE;
/*     */   
/*     */   public SpeedModule() {
/*  31 */     super("Speed", Category.MOVEMENT, "Allows you to move faster", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.strafeStage = 4;
/*     */ 
/*     */     
/*  70 */     this.groundStage = 2;
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.STRAFE)).setDescription("Mode for Speed");
/*     */   
/*     */   public static Setting<BaseSpeed> speed = (new Setting("Speed", BaseSpeed.NORMAL)).setDescription("Base speed when moving");
/*     */   
/*     */   public static Setting<Friction> friction = (new Setting("Friction", Friction.CUTOFF)).setDescription("Friction for moving through objects");
/*     */   
/*     */   public static Setting<Boolean> potionFactor = (new Setting("PotionFactor", Boolean.valueOf(true))).setDescription("Applies potions effects to speed");
/*     */   
/*     */   public static Setting<Boolean> strictJump = (new Setting("StrictJump", Boolean.valueOf(false))).setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.STRAFE_STRICT))).setDescription("Use slightly higher and therefore slower jumps to bypass better");
/*     */   
/*     */   public static Setting<Boolean> strictSprint = (new Setting("StrictSprint", Boolean.valueOf(false))).setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.STRAFE_STRICT))).setDescription("Maintains sprint while moving");
/*     */   
/*     */   public static Setting<Boolean> timer = (new Setting("Timer", Boolean.valueOf(true))).setDescription("Uses timer to speed up strafe");
/*     */   private int strafeStage;
/*     */   private int groundStage;
/*     */   private double moveSpeed;
/*     */   private double latestMoveSpeed;
/*     */   private double boostSpeed;
/*     */   private boolean accelerate;
/*     */   private int strictTicks;
/*     */   private int boostTicks;
/*     */   private boolean offsetPackets;
/*     */   
/*     */   public void onEnable() {
/*  99 */     super.onEnable();
/*     */ 
/*     */     
/* 102 */     this.strafeStage = 4;
/* 103 */     this.groundStage = 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 108 */     super.onDisable();
/*     */ 
/*     */     
/* 111 */     resetProcess();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRotationUpdate(RotationUpdateEvent event) {
/* 118 */     this.latestMoveSpeed = Math.sqrt(StrictMath.pow(mc.player.posX - mc.player.prevPosX, 2.0D) + StrictMath.pow(mc.player.posZ - mc.player.prevPosZ, 2.0D));
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMotion(MotionEvent event) {
/*     */     float forward, strafe, yaw;
/*     */     double cos, sin;
/* 125 */     if (((Friction)friction.getValue()).equals(Friction.CUTOFF)) {
/*     */ 
/*     */       
/* 128 */       if (PlayerUtil.isInLiquid()) {
/* 129 */         resetProcess();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 134 */       if (((IEntity)mc.player).getInWeb()) {
/* 135 */         resetProcess();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 141 */     if (mc.player.isOnLadder() || mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.fallDistance > 2.0F) {
/* 142 */       resetProcess();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 147 */     if (FlightModule.INSTANCE.isEnabled() || PacketFlightModule.INSTANCE.isEnabled() || LongJumpModule.INSTANCE.isEnabled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 152 */     if (mc.player.isSneaking()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 157 */     event.setCanceled(true);
/* 158 */     getCosmos().getTickManager().setClientTicks(1.0F);
/*     */ 
/*     */     
/* 161 */     double baseSpeed = 0.2873D;
/*     */     
/* 163 */     if (((BaseSpeed)speed.getValue()).equals(BaseSpeed.OLD)) {
/* 164 */       baseSpeed = 0.272D;
/*     */     }
/*     */ 
/*     */     
/* 168 */     if (((Boolean)potionFactor.getValue()).booleanValue()) {
/* 169 */       if (mc.player.isPotionActive(MobEffects.SPEED)) {
/* 170 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
/* 171 */         baseSpeed *= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */       
/* 174 */       if (mc.player.isPotionActive(MobEffects.SLOWNESS)) {
/* 175 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier();
/* 176 */         baseSpeed /= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 181 */     if (((Boolean)strictSprint.getValue()).booleanValue() && (!mc.player.isSprinting() || !((IEntityPlayerSP)mc.player).getServerSprintState()) && 
/* 182 */       mc.getConnection() != null) {
/* 183 */       mc.getConnection().getNetworkManager().sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */     }
/*     */ 
/*     */     
/* 187 */     switch ((Mode)mode.getValue()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case ON_GROUND:
/* 197 */         if (mc.player.onGround && MotionUtil.isMoving()) {
/*     */ 
/*     */           
/* 200 */           if (this.groundStage == 2) {
/*     */ 
/*     */             
/* 203 */             this.offsetPackets = true;
/*     */ 
/*     */             
/* 206 */             double acceleration = 2.149D;
/*     */ 
/*     */             
/* 209 */             this.moveSpeed *= acceleration;
/*     */ 
/*     */             
/* 212 */             this.groundStage = 3;
/*     */           
/*     */           }
/* 215 */           else if (this.groundStage == 3) {
/*     */ 
/*     */             
/* 218 */             double scaledMoveSpeed = 0.66D * (this.latestMoveSpeed - baseSpeed);
/*     */ 
/*     */             
/* 221 */             this.moveSpeed = this.latestMoveSpeed - scaledMoveSpeed;
/*     */ 
/*     */             
/* 224 */             this.groundStage = 2;
/*     */           } 
/*     */ 
/*     */           
/* 228 */           if (mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, 0.21D, 0.0D)).size() > 0 || mc.player.collidedVertically) {
/* 229 */             this.groundStage = 1;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 234 */         this.moveSpeed = Math.max(this.moveSpeed, baseSpeed);
/*     */ 
/*     */         
/* 237 */         forward = mc.player.movementInput.moveForward;
/* 238 */         strafe = mc.player.movementInput.moveStrafe;
/* 239 */         yaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*     */ 
/*     */         
/* 242 */         if (!MotionUtil.isMoving()) {
/* 243 */           event.setX(0.0D);
/* 244 */           event.setZ(0.0D);
/*     */         
/*     */         }
/* 247 */         else if (forward != 0.0F) {
/* 248 */           if (strafe > 0.0F) {
/* 249 */             yaw += (forward > 0.0F) ? -45.0F : 45.0F;
/*     */           
/*     */           }
/* 252 */           else if (strafe < 0.0F) {
/* 253 */             yaw += (forward > 0.0F) ? 45.0F : -45.0F;
/*     */           } 
/*     */           
/* 256 */           strafe = 0.0F;
/*     */           
/* 258 */           if (forward > 0.0F) {
/* 259 */             forward = 1.0F;
/*     */           
/*     */           }
/* 262 */           else if (forward < 0.0F) {
/* 263 */             forward = -1.0F;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 268 */         cos = Math.cos(Math.toRadians(yaw));
/* 269 */         sin = -Math.sin(Math.toRadians(yaw));
/*     */ 
/*     */         
/* 272 */         event.setX(forward * this.moveSpeed * sin + strafe * this.moveSpeed * cos);
/* 273 */         event.setZ(forward * this.moveSpeed * cos - strafe * this.moveSpeed * sin);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case STRAFE:
/* 284 */         if (MotionUtil.isMoving()) {
/*     */ 
/*     */           
/* 287 */           if (((Boolean)timer.getValue()).booleanValue()) {
/* 288 */             getCosmos().getTickManager().setClientTicks(1.088F);
/*     */           }
/*     */ 
/*     */           
/* 292 */           if (this.strafeStage == 1) {
/*     */ 
/*     */             
/* 295 */             this.moveSpeed = 1.35D * baseSpeed - 0.01D;
/*     */ 
/*     */           
/*     */           }
/* 299 */           else if (this.strafeStage == 2) {
/*     */ 
/*     */             
/* 302 */             double jumpSpeed = 0.3999999463558197D;
/*     */ 
/*     */             
/* 305 */             if (((Boolean)potionFactor.getValue()).booleanValue())
/*     */             {
/*     */               
/* 308 */               if (mc.player.isPotionActive(MobEffects.JUMP_BOOST)) {
/* 309 */                 double amplifier = mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier();
/* 310 */                 jumpSpeed += (amplifier + 1.0D) * 0.1D;
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/* 315 */             mc.player.motionY = jumpSpeed;
/* 316 */             event.setY(jumpSpeed);
/*     */ 
/*     */             
/* 319 */             double acceleration = 1.395D;
/*     */ 
/*     */             
/* 322 */             if (this.accelerate) {
/* 323 */               acceleration = 1.6835D;
/*     */             }
/*     */ 
/*     */             
/* 327 */             this.moveSpeed *= acceleration;
/*     */ 
/*     */           
/*     */           }
/* 331 */           else if (this.strafeStage == 3) {
/*     */ 
/*     */             
/* 334 */             double scaledMoveSpeed = 0.66D * (this.latestMoveSpeed - baseSpeed);
/*     */ 
/*     */             
/* 337 */             this.moveSpeed = this.latestMoveSpeed - scaledMoveSpeed;
/*     */ 
/*     */             
/* 340 */             this.accelerate = !this.accelerate;
/*     */           }
/*     */           else {
/*     */             
/* 344 */             if ((mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, mc.player.motionY, 0.0D)).size() > 0 || mc.player.collidedVertically) && this.strafeStage > 0)
/*     */             {
/*     */               
/* 347 */               this.strafeStage = MotionUtil.isMoving() ? 1 : 0;
/*     */             }
/*     */ 
/*     */             
/* 351 */             this.moveSpeed = this.latestMoveSpeed - this.latestMoveSpeed / 159.0D;
/*     */           } 
/*     */ 
/*     */           
/* 355 */           this.moveSpeed = Math.max(this.moveSpeed, baseSpeed);
/*     */ 
/*     */           
/* 358 */           forward = mc.player.movementInput.moveForward;
/* 359 */           strafe = mc.player.movementInput.moveStrafe;
/* 360 */           yaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*     */ 
/*     */           
/* 363 */           if (!MotionUtil.isMoving()) {
/* 364 */             event.setX(0.0D);
/* 365 */             event.setZ(0.0D);
/*     */           
/*     */           }
/* 368 */           else if (forward != 0.0F) {
/* 369 */             if (strafe > 0.0F) {
/* 370 */               yaw += (forward > 0.0F) ? -45.0F : 45.0F;
/*     */             
/*     */             }
/* 373 */             else if (strafe < 0.0F) {
/* 374 */               yaw += (forward > 0.0F) ? 45.0F : -45.0F;
/*     */             } 
/*     */             
/* 377 */             strafe = 0.0F;
/*     */             
/* 379 */             if (forward > 0.0F) {
/* 380 */               forward = 1.0F;
/*     */             
/*     */             }
/* 383 */             else if (forward < 0.0F) {
/* 384 */               forward = -1.0F;
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 389 */           cos = Math.cos(Math.toRadians(yaw));
/* 390 */           sin = -Math.sin(Math.toRadians(yaw));
/*     */ 
/*     */           
/* 393 */           event.setX(forward * this.moveSpeed * sin + strafe * this.moveSpeed * cos);
/* 394 */           event.setZ(forward * this.moveSpeed * cos - strafe * this.moveSpeed * sin);
/*     */ 
/*     */           
/* 397 */           this.strafeStage++;
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case STRAFE_STRICT:
/* 410 */         if (MotionUtil.isMoving()) {
/*     */ 
/*     */           
/* 413 */           if (((Boolean)timer.getValue()).booleanValue()) {
/* 414 */             getCosmos().getTickManager().setClientTicks(1.088F);
/*     */           }
/*     */ 
/*     */           
/* 418 */           if (this.strafeStage == 1) {
/*     */ 
/*     */             
/* 421 */             this.moveSpeed = 1.35D * baseSpeed - 0.01D;
/*     */ 
/*     */           
/*     */           }
/* 425 */           else if (this.strafeStage == 2) {
/*     */ 
/*     */             
/* 428 */             double jumpSpeed = 0.3999999463558197D;
/*     */ 
/*     */             
/* 431 */             if (((Boolean)strictJump.getValue()).booleanValue()) {
/* 432 */               jumpSpeed = 0.41999998688697815D;
/*     */             }
/*     */ 
/*     */             
/* 436 */             if (((Boolean)potionFactor.getValue()).booleanValue())
/*     */             {
/*     */               
/* 439 */               if (mc.player.isPotionActive(MobEffects.JUMP_BOOST)) {
/* 440 */                 double amplifier = mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier();
/* 441 */                 jumpSpeed += (amplifier + 1.0D) * 0.1D;
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/* 446 */             mc.player.motionY = jumpSpeed;
/* 447 */             event.setY(jumpSpeed);
/*     */ 
/*     */             
/* 450 */             double acceleration = 2.149D;
/*     */ 
/*     */             
/* 453 */             this.moveSpeed *= acceleration;
/*     */ 
/*     */           
/*     */           }
/* 457 */           else if (this.strafeStage == 3) {
/*     */ 
/*     */             
/* 460 */             double scaledMoveSpeed = 0.66D * (this.latestMoveSpeed - baseSpeed);
/*     */ 
/*     */             
/* 463 */             this.moveSpeed = this.latestMoveSpeed - scaledMoveSpeed;
/*     */           }
/*     */           else {
/*     */             
/* 467 */             if ((mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, mc.player.motionY, 0.0D)).size() > 0 || mc.player.collidedVertically) && this.strafeStage > 0)
/*     */             {
/*     */               
/* 470 */               this.strafeStage = MotionUtil.isMoving() ? 1 : 0;
/*     */             }
/*     */ 
/*     */             
/* 474 */             this.moveSpeed = this.latestMoveSpeed - this.latestMoveSpeed / 159.0D;
/*     */           } 
/*     */ 
/*     */           
/* 478 */           this.moveSpeed = Math.max(this.moveSpeed, baseSpeed);
/*     */ 
/*     */           
/* 481 */           double baseStrictSpeed = 0.465D;
/* 482 */           double baseRestrictedSpeed = 0.44D;
/*     */ 
/*     */           
/* 485 */           if (((Boolean)potionFactor.getValue()).booleanValue()) {
/* 486 */             if (mc.player.isPotionActive(MobEffects.SPEED)) {
/* 487 */               double amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
/* 488 */               baseStrictSpeed *= 1.0D + 0.2D * (amplifier + 1.0D);
/* 489 */               baseRestrictedSpeed *= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */             } 
/*     */             
/* 492 */             if (mc.player.isPotionActive(MobEffects.SLOWNESS)) {
/* 493 */               double amplifier = mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier();
/* 494 */               baseStrictSpeed /= 1.0D + 0.2D * (amplifier + 1.0D);
/* 495 */               baseRestrictedSpeed /= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 500 */           this.moveSpeed = Math.min(this.moveSpeed, (this.strictTicks > 25) ? baseStrictSpeed : baseRestrictedSpeed);
/*     */ 
/*     */           
/* 503 */           this.strictTicks++;
/*     */ 
/*     */           
/* 506 */           if (this.strictTicks > 50) {
/* 507 */             this.strictTicks = 0;
/*     */           }
/*     */ 
/*     */           
/* 511 */           float f1 = mc.player.movementInput.moveForward;
/* 512 */           float f2 = mc.player.movementInput.moveStrafe;
/* 513 */           float f3 = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*     */ 
/*     */           
/* 516 */           if (!MotionUtil.isMoving()) {
/* 517 */             event.setX(0.0D);
/* 518 */             event.setZ(0.0D);
/*     */           
/*     */           }
/* 521 */           else if (f1 != 0.0F) {
/* 522 */             if (f2 >= 1.0F) {
/* 523 */               f3 += ((f1 > 0.0F) ? -45 : 45);
/* 524 */               f2 = 0.0F;
/*     */             
/*     */             }
/* 527 */             else if (f2 <= -1.0F) {
/* 528 */               f3 += ((f1 > 0.0F) ? 45 : -45);
/* 529 */               f2 = 0.0F;
/*     */             } 
/*     */             
/* 532 */             if (f1 > 0.0F) {
/* 533 */               f1 = 1.0F;
/*     */             
/*     */             }
/* 536 */             else if (f1 < 0.0F) {
/* 537 */               f1 = -1.0F;
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 542 */           double d1 = Math.cos(Math.toRadians(f3));
/* 543 */           double d2 = -Math.sin(Math.toRadians(f3));
/*     */ 
/*     */           
/* 546 */           event.setX(f1 * this.moveSpeed * d2 + f2 * this.moveSpeed * d1);
/* 547 */           event.setZ(f1 * this.moveSpeed * d1 - f2 * this.moveSpeed * d2);
/*     */ 
/*     */           
/* 550 */           this.strafeStage++;
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case STRAFE_GROUND:
/* 563 */         this.moveSpeed = baseSpeed;
/*     */ 
/*     */         
/* 566 */         if (!mc.player.isSprinting()) {
/* 567 */           this.moveSpeed *= 0.7692307692D;
/*     */ 
/*     */         
/*     */         }
/* 571 */         else if (mc.player.isSneaking()) {
/* 572 */           this.moveSpeed *= 0.3D;
/*     */         } 
/*     */ 
/*     */         
/* 576 */         forward = mc.player.movementInput.moveForward;
/* 577 */         strafe = mc.player.movementInput.moveStrafe;
/* 578 */         yaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*     */ 
/*     */         
/* 581 */         if (!MotionUtil.isMoving()) {
/* 582 */           event.setX(0.0D);
/* 583 */           event.setZ(0.0D);
/*     */         } 
/*     */         
/* 586 */         if (forward != 0.0F) {
/* 587 */           if (strafe > 0.0F) {
/* 588 */             yaw += ((forward > 0.0F) ? -45 : 45);
/*     */           
/*     */           }
/* 591 */           else if (strafe < 0.0F) {
/* 592 */             yaw += ((forward > 0.0F) ? 45 : -45);
/*     */           } 
/*     */           
/* 595 */           strafe = 0.0F;
/* 596 */           if (forward > 0.0F) {
/* 597 */             forward = 1.0F;
/*     */           
/*     */           }
/* 600 */           else if (forward < 0.0F) {
/* 601 */             forward = -1.0F;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 606 */         cos = Math.cos(Math.toRadians(yaw));
/* 607 */         sin = -Math.sin(Math.toRadians(yaw));
/*     */ 
/*     */         
/* 610 */         event.setX(forward * this.moveSpeed * sin + strafe * this.moveSpeed * cos);
/* 611 */         event.setZ(forward * this.moveSpeed * cos - strafe * this.moveSpeed * sin);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 626 */     if (event.getPacket() instanceof CPacketEntityAction)
/*     */     {
/*     */       
/* 629 */       if (((CPacketEntityAction)event.getPacket()).getAction().equals(CPacketEntityAction.Action.STOP_SPRINTING) || ((CPacketEntityAction)event.getPacket()).getAction().equals(CPacketEntityAction.Action.START_SNEAKING))
/*     */       {
/*     */         
/* 632 */         if (((Boolean)strictSprint.getValue()).booleanValue()) {
/* 633 */           event.setCanceled(true);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 638 */     if (event.getPacket() instanceof CPacketPlayer && (
/* 639 */       (ICPacketPlayer)event.getPacket()).isMoving() && this.offsetPackets) {
/*     */ 
/*     */       
/* 642 */       ((ICPacketPlayer)event.getPacket()).setY(((CPacketPlayer)event.getPacket()).getY(0.0D) + ((mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, 0.21D, 0.0D)).size() > 0) ? 2 : 4));
/* 643 */       this.offsetPackets = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 652 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) {
/* 653 */       resetProcess();
/*     */     }
/*     */ 
/*     */     
/* 657 */     if (event.getPacket() instanceof SPacketExplosion) {
/*     */ 
/*     */       
/* 660 */       double boostMotionX = StrictMath.pow((((SPacketExplosion)event.getPacket()).getMotionX() / 8000.0F), 2.0D);
/* 661 */       double boostMotionZ = StrictMath.pow((((SPacketExplosion)event.getPacket()).getMotionX() / 8000.0F), 2.0D);
/*     */ 
/*     */       
/* 664 */       this.boostSpeed = Math.sqrt(boostMotionX + boostMotionZ);
/*     */ 
/*     */       
/* 667 */       this.boostTicks = 0;
/*     */     } 
/*     */ 
/*     */     
/* 671 */     if (event.getPacket() instanceof SPacketEntityVelocity)
/*     */     {
/*     */       
/* 674 */       if (((SPacketEntityVelocity)event.getPacket()).getEntityID() == mc.player.getEntityId()) {
/*     */ 
/*     */         
/* 677 */         double boostMotionX = StrictMath.pow((((SPacketEntityVelocity)event.getPacket()).getMotionX() / 8000.0F), 2.0D);
/* 678 */         double boostMotionZ = StrictMath.pow((((SPacketEntityVelocity)event.getPacket()).getMotionX() / 8000.0F), 2.0D);
/*     */ 
/*     */         
/* 681 */         this.boostSpeed = Math.sqrt(boostMotionX + boostMotionZ);
/*     */ 
/*     */         
/* 684 */         this.boostTicks = 0;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetProcess() {
/* 693 */     this.strafeStage = 4;
/* 694 */     this.groundStage = 2;
/* 695 */     this.moveSpeed = 0.0D;
/* 696 */     this.latestMoveSpeed = 0.0D;
/* 697 */     this.boostSpeed = 0.0D;
/* 698 */     this.strictTicks = 0;
/* 699 */     this.boostTicks = 0;
/* 700 */     this.accelerate = false;
/* 701 */     this.offsetPackets = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 709 */     STRAFE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 714 */     STRAFE_STRICT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 719 */     STRAFE_LOW,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 724 */     STRAFE_GROUND,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 729 */     ON_GROUND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum BaseSpeed
/*     */   {
/* 737 */     NORMAL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 742 */     OLD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Friction
/*     */   {
/* 750 */     FACTOR,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 755 */     FAST,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 760 */     CUTOFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\SpeedModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
