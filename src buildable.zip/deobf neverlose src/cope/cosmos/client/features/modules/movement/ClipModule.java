//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.movement;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ public class ClipModule extends Module {
/*    */   public static ClipModule INSTANCE;
/*    */   
/*    */   public static boolean isMoving() {
/* 15 */     return (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack
/* 16 */       .isKeyDown() || mc.gameSettings.keyBindLeft
/* 17 */       .isKeyDown() || mc.gameSettings.keyBindRight
/* 18 */       .isKeyDown());
/*    */   }
/*    */   
/* 21 */   public final Setting<Integer> timeout = new Setting("Timeout", Integer.valueOf(1), Integer.valueOf(5), Integer.valueOf(10), 0);
/*    */   
/*    */   private int packets;
/*    */   
/*    */   public ClipModule() {
/* 26 */     super("Clip", Category.MOVEMENT, "Clips into blocks nearby to prevent crystal damage.");
/* 27 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 32 */     super.onDisable();
/* 33 */     this.packets = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getInfo() {
/* 38 */     return String.valueOf(this.packets);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 45 */     if (isMoving()) {
/* 46 */       onDisable();
/*    */       
/*    */       return;
/*    */     } 
/* 50 */     if (mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().grow(0.01D, 0.0D, 0.01D)).size() < 2) {
/* 51 */       mc.player.setPosition(roundToClosest(mc.player.posX, Math.floor(mc.player.posX) + 0.301D, Math.floor(mc.player.posX) + 0.699D), mc.player.posY, roundToClosest(mc.player.posZ, Math.floor(mc.player.posZ) + 0.301D, Math.floor(mc.player.posZ) + 0.699D));
/* 52 */       this.packets = 0;
/*    */     }
/* 54 */     else if (mc.player.ticksExisted % ((Integer)this.timeout.getValue()).intValue() == 0) {
/* 55 */       mc.player.setPosition(mc.player.posX + MathHelper.clamp(roundToClosest(mc.player.posX, Math.floor(mc.player.posX) + 0.241D, Math.floor(mc.player.posX) + 0.759D) - mc.player.posX, -0.03D, 0.03D), mc.player.posY, mc.player.posZ + MathHelper.clamp(roundToClosest(mc.player.posZ, Math.floor(mc.player.posZ) + 0.241D, Math.floor(mc.player.posZ) + 0.759D) - mc.player.posZ, -0.03D, 0.03D));
/* 56 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, true));
/* 57 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(roundToClosest(mc.player.posX, Math.floor(mc.player.posX) + 0.23D, Math.floor(mc.player.posX) + 0.77D), mc.player.posY, roundToClosest(mc.player.posZ, Math.floor(mc.player.posZ) + 0.23D, Math.floor(mc.player.posZ) + 0.77D), true));
/* 58 */       this.packets++;
/*    */     } 
/*    */   }
/*    */   
/*    */   private double roundToClosest(double num, double low, double high) {
/* 63 */     double d1 = num - low;
/* 64 */     double d2 = high - num;
/*    */     
/* 66 */     if (d2 > d1) {
/* 67 */       return low;
/*    */     }
/*    */     
/* 70 */     return high;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\ClipModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
