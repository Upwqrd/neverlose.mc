//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityPlayerSP;
/*     */ import cope.cosmos.client.events.block.SlimeEvent;
/*     */ import cope.cosmos.client.events.block.SoulSandEvent;
/*     */ import cope.cosmos.client.events.entity.player.interact.EntityUseItemEvent;
/*     */ import cope.cosmos.client.events.entity.player.interact.ItemInputUpdateEvent;
/*     */ import cope.cosmos.client.events.input.KeyDownEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.client.settings.IKeyConflictContext;
/*     */ import net.minecraftforge.client.settings.KeyConflictContext;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoSlowModule
/*     */   extends Module
/*     */ {
/*     */   public static NoSlowModule INSTANCE;
/*     */   
/*     */   public NoSlowModule() {
/*  40 */     super("NoSlow", Category.MOVEMENT, "Removes various slowdown effects");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.isSneaking = false;
/*     */ 
/*     */     
/*  82 */     this.groundTimer = new Timer();
/*     */ 
/*     */     
/*  85 */     this.KEYS = new KeyBinding[] { mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindSprint, mc.gameSettings.keyBindSneak, mc.gameSettings.keyBindJump };
/*     */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("Allows you to bypass strict NCP server");
/*     */   public static Setting<Boolean> airStrict = (new Setting("AirStrict", Boolean.valueOf(false))).setDescription("Allows you to bypass strict NCP servers while in the air");
/*     */   public static Setting<Boolean> groundStrict = (new Setting("GroundStrict", Boolean.valueOf(false))).setDescription("Allows you to bypass strict NCP servers while on the ground");
/*     */   public static Setting<Boolean> inventoryMove = (new Setting("InventoryMove", Boolean.valueOf(true))).setDescription("Allows you to move around while in GUIs");
/*     */   public static Setting<Float> arrowLook = (new Setting("Arrow", Float.valueOf(0.0F), Float.valueOf(5.0F), Float.valueOf(10.0F), 1)).setDescription("The speed that the arrow keys should rotate you with").setVisible(() -> (Boolean)inventoryMove.getValue());
/*     */   public static Setting<Boolean> items = (new Setting("Items", Boolean.valueOf(true))).setDescription("Removes the slowdown effect while using items");
/*     */   
/*     */   public void onEnable() {
/*  97 */     super.onEnable();
/*     */ 
/*     */     
/* 100 */     if (((Boolean)ice.getValue()).booleanValue()) {
/* 101 */       Blocks.ICE.setDefaultSlipperiness(0.6F);
/* 102 */       Blocks.PACKED_ICE.setDefaultSlipperiness(0.6F);
/* 103 */       Blocks.FROSTED_ICE.setDefaultSlipperiness(0.6F);
/*     */     } 
/*     */   }
/*     */   public static Setting<Boolean> soulsand = (new Setting("SoulSand", Boolean.valueOf(false))).setDescription("Removes the slowdown effect when walking on soulsand"); public static Setting<Boolean> slime = (new Setting("Slime", Boolean.valueOf(false))).setDescription("Removes the slowdown effect when walking on slime"); public static Setting<Boolean> ice = (new Setting("Ice", Boolean.valueOf(true))).setDescription("Removes the slipperiness effect when walking on ice"); private boolean isSneaking; private final Timer groundTimer; private final KeyBinding[] KEYS;
/*     */   
/*     */   public void onDisable() {
/* 109 */     super.onDisable();
/*     */ 
/*     */     
/* 112 */     if (this.isSneaking && ((Boolean)airStrict.getValue()).booleanValue()) {
/* 113 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     }
/*     */     
/* 116 */     this.isSneaking = false;
/*     */ 
/*     */     
/* 119 */     for (KeyBinding binding : this.KEYS) {
/* 120 */       binding.setKeyConflictContext((IKeyConflictContext)KeyConflictContext.IN_GAME);
/*     */     }
/*     */ 
/*     */     
/* 124 */     if (((Boolean)ice.getValue()).booleanValue()) {
/* 125 */       Blocks.ICE.setDefaultSlipperiness(0.98F);
/* 126 */       Blocks.FROSTED_ICE.setDefaultSlipperiness(0.98F);
/* 127 */       Blocks.PACKED_ICE.setDefaultSlipperiness(0.98F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 135 */     if (this.isSneaking && ((Boolean)airStrict.getValue()).booleanValue() && !mc.player.isHandActive()) {
/* 136 */       this.isSneaking = false;
/*     */       
/* 138 */       if (mc.getConnection() != null) {
/* 139 */         mc.getConnection().getNetworkManager().sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 144 */     if (isSlowed());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (((Boolean)inventoryMove.getValue()).booleanValue() && isInScreen()) {
/*     */ 
/*     */       
/* 156 */       for (KeyBinding binding : this.KEYS) {
/* 157 */         KeyBinding.setKeyBindState(binding.getKeyCode(), Keyboard.isKeyDown(binding.getKeyCode()));
/* 158 */         binding.setKeyConflictContext(ConflictContext.FAKE_CONTEXT);
/*     */       } 
/*     */ 
/*     */       
/* 162 */       if (((Float)arrowLook.getValue()).floatValue() != 0.0F) {
/* 163 */         if (Keyboard.isKeyDown(200)) {
/* 164 */           mc.player.rotationPitch -= ((Float)arrowLook.getValue()).floatValue();
/*     */         
/*     */         }
/* 167 */         else if (Keyboard.isKeyDown(208)) {
/* 168 */           mc.player.rotationPitch += ((Float)arrowLook.getValue()).floatValue();
/*     */         
/*     */         }
/* 171 */         else if (Keyboard.isKeyDown(205)) {
/* 172 */           mc.player.rotationYaw += ((Float)arrowLook.getValue()).floatValue();
/*     */         
/*     */         }
/* 175 */         else if (Keyboard.isKeyDown(203)) {
/* 176 */           mc.player.rotationYaw -= ((Float)arrowLook.getValue()).floatValue();
/*     */         } 
/*     */ 
/*     */         
/* 180 */         mc.player.rotationPitch = MathHelper.clamp(mc.player.rotationPitch, -90.0F, 90.0F);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 186 */       for (KeyBinding binding : this.KEYS) {
/* 187 */         binding.setKeyConflictContext((IKeyConflictContext)KeyConflictContext.IN_GAME);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 196 */     if (event.getPacket() instanceof CPacketPlayer)
/*     */     {
/*     */       
/* 199 */       if (((ICPacketPlayer)event.getPacket()).isMoving())
/*     */       {
/*     */         
/* 202 */         if (isSlowed()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 210 */           if (((Boolean)strict.getValue()).booleanValue()) {
/* 211 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(mc.player.inventory.currentItem));
/*     */           }
/*     */ 
/*     */           
/* 215 */           if (((Boolean)groundStrict.getValue()).booleanValue() && ((CPacketPlayer)event.getPacket()).isOnGround()) {
/* 216 */             if (this.groundTimer.passedTime(2L, Timer.Format.TICKS)) {
/* 217 */               ((ICPacketPlayer)event.getPacket()).setY(((CPacketPlayer)event.getPacket()).getY(mc.player.posY) + 0.05D);
/* 218 */               this.groundTimer.resetTime();
/*     */             } 
/*     */ 
/*     */             
/* 222 */             ((ICPacketPlayer)event.getPacket()).setOnGround(false);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 229 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketClickWindow)
/*     */     {
/*     */       
/* 232 */       if (((Boolean)strict.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 235 */         if (mc.player.isSneaking() || ((IEntityPlayerSP)mc.player).getServerSneakState()) {
/* 236 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */         }
/*     */ 
/*     */         
/* 240 */         if (mc.player.isSprinting() || ((IEntityPlayerSP)mc.player).getServerSprintState()) {
/* 241 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onItemInputUpdate(ItemInputUpdateEvent event) {
/* 251 */     if (isSlowed()) {
/* 252 */       (event.getMovementInput()).moveForward *= 5.0F;
/* 253 */       (event.getMovementInput()).moveStrafe *= 5.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUseItem(EntityUseItemEvent event) {
/* 261 */     if (isSlowed() && ((Boolean)airStrict.getValue()).booleanValue() && !this.isSneaking) {
/* 262 */       this.isSneaking = true;
/*     */       
/* 264 */       if (mc.getConnection() != null) {
/* 265 */         mc.getConnection().getNetworkManager().sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSoulSand(SoulSandEvent event) {
/* 274 */     if (((Boolean)soulsand.getValue()).booleanValue()) {
/* 275 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSlime(SlimeEvent event) {
/* 283 */     if (((Boolean)slime.getValue()).booleanValue()) {
/* 284 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onKeyDown(KeyDownEvent event) {
/* 292 */     if (isInScreen())
/*     */     {
/*     */       
/* 295 */       if (((Boolean)inventoryMove.getValue()).booleanValue()) {
/* 296 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSlowed() {
/* 306 */     return (mc.player.isHandActive() && ((Boolean)items.getValue()).booleanValue() && !mc.player.isRiding() && !mc.player.isElytraFlying());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInScreen() {
/* 314 */     return (mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.GuiChat) && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiEditSign) && !(mc.currentScreen instanceof net.minecraft.client.gui.GuiRepair));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ConflictContext
/*     */     implements IKeyConflictContext
/*     */   {
/* 322 */     FAKE_CONTEXT
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isActive()
/*     */       {
/* 330 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean conflicts(IKeyConflictContext other) {
/* 340 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\NoSlowModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
