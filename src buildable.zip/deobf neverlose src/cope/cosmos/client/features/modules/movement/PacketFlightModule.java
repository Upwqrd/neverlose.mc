//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.INetworkManager;
/*     */ import cope.cosmos.asm.mixins.accessor.ISPacketPlayerPosLook;
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.events.network.DisconnectEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketConfirmTeleport;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.server.SPacketPlayerPosLook;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketFlightModule
/*     */   extends Module
/*     */ {
/*     */   public static PacketFlightModule INSTANCE;
/*     */   private static final double CONCEAL = 0.0624D;
/*  34 */   private static final double MOVE_FACTOR = 1.0D / StrictMath.sqrt(2.0D); public static Setting<Mode> mode = (new Setting("Mode", Mode.FACTOR)).setDescription("How to handle flying"); public static Setting<Double> factor = (new Setting("Factor", Double.valueOf(0.1D), Double.valueOf(1.5D), Double.valueOf(5.0D), 1)).setDescription("How many packets to send per movement").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.FACTOR)));
/*     */   
/*     */   public PacketFlightModule() {
/*  37 */     super("PacketFlight", Category.MOVEMENT, "Funny 1.9+ exploit", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.predictions = new HashMap<>();
/*     */ 
/*     */     
/*  64 */     this.tpId = 0;
/*     */ 
/*     */     
/*  67 */     this.lagTime = 0;
/*     */     INSTANCE = this;
/*     */   } public static Setting<Bounds> bounds = (new Setting("Bounds", Bounds.DOWN)).setDescription("The bounds offset"); public static Setting<Phase> phase = (new Setting("Phase", Phase.NCP)).setDescription("How to phase");
/*     */   public void onDisable() {
/*  71 */     super.onDisable();
/*     */     
/*  73 */     this.predictions.clear();
/*  74 */     this.tpId = 0;
/*  75 */     this.lagTime = 0;
/*     */ 
/*     */     
/*  78 */     mc.player.noClip = false;
/*     */   }
/*     */   public static Setting<Boolean> conceal = (new Setting("Conceal", Boolean.valueOf(false))).setDescription("If to force our move speed to the 0.0625"); public static Setting<Boolean> antiKick = (new Setting("AntiKick", Boolean.valueOf(true))).setDescription("If to prevent vanilla fly kicks"); private final Map<Integer, Vec3d> predictions; private int tpId;
/*     */   private int lagTime;
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onMove(MotionEvent event) {
/*  85 */     int loops = (int)Math.floor(((Double)factor.getValue()).doubleValue());
/*     */ 
/*     */     
/*  88 */     if (((Mode)mode.getValue()).equals(Mode.FACTOR)) {
/*     */ 
/*     */       
/*  91 */       if (mc.player.ticksExisted % 10.0D < 10.0D * (((Double)factor.getValue()).doubleValue() - Math.floor(((Double)factor.getValue()).doubleValue()))) {
/*  92 */         loops++;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  99 */       loops = 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 104 */     double moveSpeed = (((Boolean)conceal.getValue()).booleanValue() || --this.lagTime > 0 || isPhased()) ? 0.0624D : 0.2873D;
/*     */ 
/*     */     
/* 107 */     double motionY = 0.0D;
/*     */ 
/*     */     
/* 110 */     boolean doAntiKick = false;
/*     */     
/* 112 */     if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 113 */       motionY = 0.0624D;
/*     */       
/* 115 */       if (MotionUtil.isMoving())
/*     */       {
/*     */         
/* 118 */         moveSpeed *= MOVE_FACTOR;
/* 119 */         motionY *= MOVE_FACTOR;
/*     */       }
/*     */     
/*     */     }
/* 123 */     else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 124 */       motionY = -0.0624D;
/*     */       
/* 126 */       if (MotionUtil.isMoving())
/*     */       {
/*     */         
/* 129 */         moveSpeed *= MOVE_FACTOR;
/* 130 */         motionY *= MOVE_FACTOR;
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 139 */       doAntiKick = (((Boolean)antiKick.getValue()).booleanValue() && mc.player.ticksExisted % 40 == 0 && !isPhased() && !mc.world.collidesWithAnyBlock(mc.player.getEntityBoundingBox()) && !MotionUtil.isMoving());
/*     */       
/* 141 */       if (doAntiKick) {
/*     */         
/* 143 */         loops = 1;
/*     */ 
/*     */ 
/*     */         
/* 147 */         motionY = -0.04D;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 152 */     send(loops, moveSpeed, motionY, doAntiKick);
/*     */ 
/*     */     
/* 155 */     event.setX(mc.player.motionX);
/* 156 */     event.setY(mc.player.motionY);
/* 157 */     event.setZ(mc.player.motionZ);
/*     */ 
/*     */     
/* 160 */     if (!((Phase)phase.getValue()).equals(Phase.NONE)) {
/* 161 */       mc.player.noClip = true;
/*     */     }
/*     */ 
/*     */     
/* 165 */     event.setCanceled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 172 */     if (event.getPacket() instanceof CPacketPlayer) {
/* 173 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 181 */     if (event.getPacket() instanceof SPacketPlayerPosLook) {
/* 182 */       SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
/*     */ 
/*     */       
/* 185 */       Vec3d prediction = this.predictions.get(Integer.valueOf(packet.getTeleportId()));
/* 186 */       if (prediction != null)
/*     */       {
/*     */         
/* 189 */         if (prediction.x == packet.getX() && prediction.y == packet.getY() && prediction.z == packet.getZ()) {
/*     */ 
/*     */           
/* 192 */           if (!((Mode)mode.getValue()).equals(Mode.SETBACK)) {
/* 193 */             event.setCanceled(true);
/*     */           }
/*     */ 
/*     */           
/* 197 */           mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(packet.getTeleportId()));
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 203 */       ((ISPacketPlayerPosLook)packet).setYaw(mc.player.rotationYaw);
/* 204 */       ((ISPacketPlayerPosLook)packet).setPitch(mc.player.rotationPitch);
/*     */ 
/*     */       
/* 207 */       mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(packet.getTeleportId()));
/*     */ 
/*     */       
/* 210 */       this.lagTime = 10;
/* 211 */       this.tpId = packet.getTeleportId();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onDisconnect(DisconnectEvent event) {
/* 219 */     disable(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void send(int factor, double moveSpeed, double motionY, boolean antiKick) {
/* 225 */     if (factor == 0) {
/* 226 */       mc.player.setVelocity(0.0D, 0.0D, 0.0D);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 231 */     double[] strafe = MotionUtil.getMoveSpeed(moveSpeed);
/*     */     
/* 233 */     for (int i = 1; i < factor + 1; i++) {
/*     */ 
/*     */       
/* 236 */       double motionX = strafe[0] * i;
/* 237 */       double motionZ = strafe[1] * i;
/*     */ 
/*     */       
/* 240 */       double velY = motionY;
/*     */       
/* 242 */       if (!antiKick)
/*     */       {
/*     */         
/* 245 */         velY *= i;
/*     */       }
/*     */ 
/*     */       
/* 249 */       mc.player.motionX = motionX;
/* 250 */       mc.player.motionY = velY;
/* 251 */       mc.player.motionZ = motionZ;
/*     */ 
/*     */       
/* 254 */       Vec3d posVec = mc.player.getPositionVector();
/*     */ 
/*     */       
/* 257 */       Vec3d moveVec = posVec.add(motionX, velY, motionZ);
/*     */ 
/*     */       
/* 260 */       send(moveVec);
/*     */ 
/*     */       
/* 263 */       send(((Bounds)bounds.getValue()).modify(posVec));
/*     */ 
/*     */       
/* 266 */       if (!((Mode)mode.getValue()).equals(Mode.SETBACK)) {
/*     */ 
/*     */         
/* 269 */         this.predictions.put(Integer.valueOf(++this.tpId), moveVec);
/*     */ 
/*     */         
/* 272 */         mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(this.tpId));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void send(Vec3d vec) {
/* 284 */     ((INetworkManager)mc.player.connection.getNetworkManager()).hookDispatchPacket((Packet)new CPacketPlayer.Position(vec.x, vec.y, vec.z, true), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPhased() {
/* 294 */     return !mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().expand(-0.0625D, -0.0625D, -0.0625D)).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 301 */     FACTOR,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     FAST,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     SETBACK;
/*     */   }
/*     */   
/*     */   public enum Bounds {
/* 315 */     UP(1337.0D),
/* 316 */     DOWN(-1337.0D),
/* 317 */     MIN(512.0D);
/*     */     
/*     */     private final double yOffset;
/*     */     
/*     */     Bounds(double yOffset) {
/* 322 */       this.yOffset = yOffset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Vec3d modify(Vec3d in) {
/* 331 */       return in.add(0.0D, this.yOffset, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Phase
/*     */   {
/* 339 */     NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     VANILLA,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     NCP;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\PacketFlightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
