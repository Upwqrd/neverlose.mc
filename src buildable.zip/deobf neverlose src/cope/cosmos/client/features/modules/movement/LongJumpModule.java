//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.client.events.motion.movement.MotionEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class LongJumpModule
/*     */   extends Module
/*     */ {
/*     */   public static LongJumpModule INSTANCE;
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.NORMAL)).setDescription("Mode of jump");
/*     */   public static Setting<Double> boost = (new Setting("Boost", Double.valueOf(0.1D), Double.valueOf(4.5D), Double.valueOf(10.0D), 1)).setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.NORMAL))).setDescription("The boost speed");
/*     */   public static Setting<Boolean> potionFactor = (new Setting("PotionFactor", Boolean.valueOf(true))).setDescription("If to factor in potion effects for move speed");
/*     */   
/*     */   public LongJumpModule() {
/*  24 */     super("LongJump", Category.MOVEMENT, "Allows you to jump farther", () -> StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.stage = LongJumpStage.START;
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onDisable() {
/*  49 */     super.onDisable();
/*     */     
/*  51 */     this.moveSpeed = 0.0D;
/*  52 */     this.distance = 0.0D;
/*  53 */     this.stage = LongJumpStage.START;
/*     */   }
/*     */   
/*     */   private double moveSpeed;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMotion(MotionEvent event) {
/*  60 */     double baseSpeed = 0.2873D;
/*     */ 
/*     */     
/*  63 */     if (((Boolean)potionFactor.getValue()).booleanValue()) {
/*  64 */       if (mc.player.isPotionActive(MobEffects.SPEED)) {
/*  65 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier();
/*  66 */         baseSpeed *= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */       
/*  69 */       if (mc.player.isPotionActive(MobEffects.SLOWNESS)) {
/*  70 */         double amplifier = mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier();
/*  71 */         baseSpeed /= 1.0D + 0.2D * (amplifier + 1.0D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  76 */     if (this.stage.equals(LongJumpStage.START) && MotionUtil.isMoving()) {
/*  77 */       this.stage = LongJumpStage.JUMP;
/*     */ 
/*     */       
/*  80 */       this.moveSpeed = ((Double)boost.getValue()).doubleValue() * baseSpeed - 0.01D;
/*     */     
/*     */     }
/*  83 */     else if (this.stage.equals(LongJumpStage.JUMP)) {
/*  84 */       this.stage = LongJumpStage.SPEED;
/*     */ 
/*     */       
/*  87 */       mc.player.motionY = 0.42D;
/*  88 */       event.setY(0.42D);
/*     */ 
/*     */       
/*  91 */       this.moveSpeed *= 2.149D;
/*     */     
/*     */     }
/*  94 */     else if (this.stage.equals(LongJumpStage.SPEED)) {
/*  95 */       this.stage = LongJumpStage.COLLISION;
/*     */ 
/*     */       
/*  98 */       double adjusted = 0.66D * (this.distance - baseSpeed);
/*  99 */       this.moveSpeed = this.distance - adjusted;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 104 */       if (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, mc.player.motionY, 0.0D)).isEmpty() && mc.player.collidedVertically) {
/* 105 */         this.stage = LongJumpStage.START;
/*     */       }
/*     */       
/* 108 */       this.moveSpeed = this.distance - this.distance / 159.0D;
/*     */     } 
/*     */ 
/*     */     
/* 112 */     this.moveSpeed = Math.max(this.moveSpeed, baseSpeed);
/*     */     
/* 114 */     event.setCanceled(true);
/*     */ 
/*     */     
/* 117 */     float forward = mc.player.movementInput.moveForward;
/* 118 */     float strafe = mc.player.movementInput.moveStrafe;
/* 119 */     float yaw = mc.player.rotationYaw;
/*     */     
/* 121 */     if (!MotionUtil.isMoving()) {
/* 122 */       event.setX(0.0D);
/* 123 */       event.setZ(0.0D);
/*     */     
/*     */     }
/* 126 */     else if (forward != 0.0F) {
/* 127 */       if (strafe >= 1.0F) {
/* 128 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 129 */         strafe = 0.0F;
/*     */       
/*     */       }
/* 132 */       else if (strafe <= -1.0F) {
/* 133 */         yaw += ((forward > 0.0F) ? 45 : -45);
/* 134 */         strafe = 0.0F;
/*     */       } 
/*     */       
/* 137 */       if (forward > 0.0F) {
/* 138 */         forward = 1.0F;
/*     */       
/*     */       }
/* 141 */       else if (forward < 0.0F) {
/* 142 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 147 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 148 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*     */ 
/*     */     
/* 151 */     event.setX(forward * this.moveSpeed * cos + strafe * this.moveSpeed * sin);
/* 152 */     event.setZ(forward * this.moveSpeed * sin - strafe * this.moveSpeed * cos);
/*     */ 
/*     */     
/* 155 */     if (!MotionUtil.isMoving()) {
/* 156 */       event.setX(0.0D);
/* 157 */       event.setZ(0.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   private double distance;
/*     */   private LongJumpStage stage;
/*     */   
/*     */   public void onUpdate() {
/* 165 */     this.distance = Math.sqrt(StrictMath.pow(mc.player.posX - mc.player.prevPosX, 2.0D) + StrictMath.pow(mc.player.posZ - mc.player.prevPosZ, 2.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 172 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) {
/* 173 */       disable(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum LongJumpStage
/*     */   {
/* 182 */     START,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     JUMP,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     SPEED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     COLLISION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 206 */     COWABUNGA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     NORMAL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\LongJumpModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
