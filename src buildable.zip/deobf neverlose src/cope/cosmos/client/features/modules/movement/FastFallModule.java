//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.movement;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*     */ import cope.cosmos.client.events.entity.player.UpdateWalkingPlayerEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.combat.BurrowModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class FastFallModule
/*     */   extends Module
/*     */ {
/*     */   public static FastFallModule INSTANCE;
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.MOTION)).setDescription("Mode for falling");
/*     */   public static Setting<Double> speed = (new Setting("Speed", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(10.0D), 2)).setDescription("Fall speed").setVisible(() -> Boolean.valueOf(!((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */   public static Setting<Double> shiftTicks = (new Setting("ShiftTicks", Double.valueOf(1.0D), Double.valueOf(3.0D), Double.valueOf(5.0D), 0)).setDescription("Ticks to shift forward when falling").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */   
/*     */   public FastFallModule() {
/*  24 */     super("FastFall", Category.MOVEMENT, "Falls faster");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.rubberbandTimer = new Timer();
/*  52 */     this.strictTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  58 */     this.previousOnGround = mc.player.onGround;
/*     */   }
/*     */   public static Setting<Double> height = (new Setting("Height", Double.valueOf(0.0D), Double.valueOf(2.0D), Double.valueOf(10.0D), 1)).setDescription("Maximum height to be pulled down");
/*     */   public static Setting<Boolean> webs = (new Setting("Webs", Boolean.valueOf(false))).setDescription("Falls in webs");
/*     */   private boolean previousOnGround;
/*     */   
/*     */   public void onUpdate() {
/*  65 */     if (PlayerUtil.isInLiquid() || mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.isOnLadder()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  70 */     if (((IEntity)mc.player).getInWeb() && !((Boolean)webs.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  75 */     if (mc.gameSettings.keyBindJump.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown() || SpeedModule.INSTANCE.isEnabled() || BurrowModule.INSTANCE.isActive() || PacketFlightModule.INSTANCE.isActive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  80 */     if (!this.rubberbandTimer.passedTime(1L, Timer.Format.SECONDS)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  85 */     if (mc.player.onGround)
/*     */     {
/*     */       
/*  88 */       if (((Mode)mode.getValue()).equals(Mode.MOTION))
/*     */       {
/*     */         
/*  91 */         for (double fallHeight = 0.0D; fallHeight < ((Double)height.getValue()).doubleValue() + 0.5D; fallHeight += 0.01D) {
/*     */ 
/*     */           
/*  94 */           if (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, -fallHeight, 0.0D)).isEmpty()) {
/*     */ 
/*     */ 
/*     */             
/*  98 */             mc.player.motionY = -((Double)speed.getValue()).doubleValue();
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } } 
/*     */   }
/*     */   
/*     */   private final Timer rubberbandTimer;
/*     */   private final Timer strictTimer;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 110 */     if (PlayerUtil.isInLiquid() || mc.player.capabilities.isFlying || mc.player.isElytraFlying() || mc.player.isOnLadder()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 115 */     if (((IEntity)mc.player).getInWeb() && !((Boolean)webs.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 120 */     if (mc.gameSettings.keyBindJump.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown() || SpeedModule.INSTANCE.isEnabled() || BurrowModule.INSTANCE.isActive() || PacketFlightModule.INSTANCE.isActive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 125 */     if (!this.rubberbandTimer.passedTime(1L, Timer.Format.SECONDS)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 130 */     if (((Mode)mode.getValue()).equals(Mode.PACKET)) {
/*     */ 
/*     */       
/* 133 */       event.setCanceled(true);
/*     */ 
/*     */       
/* 136 */       if (mc.player.motionY <= 0.0D && this.previousOnGround && !mc.player.onGround)
/*     */       {
/*     */         
/* 139 */         for (double fallHeight = 0.0D; fallHeight < ((Double)height.getValue()).doubleValue() + 0.5D; fallHeight += 0.01D) {
/*     */ 
/*     */           
/* 142 */           if (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, -fallHeight, 0.0D)).isEmpty())
/*     */           {
/*     */             
/* 145 */             if (this.strictTimer.passedTime(1L, Timer.Format.SECONDS)) {
/*     */ 
/*     */               
/* 148 */               mc.player.motionX = 0.0D;
/* 149 */               mc.player.motionZ = 0.0D;
/* 150 */               event.setIterations(((Double)shiftTicks.getValue()).intValue());
/* 151 */               this.strictTimer.resetTime();
/*     */               break;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 164 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) {
/* 165 */       this.rubberbandTimer.resetTime();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 174 */     MOTION,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     PACKET;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\movement\FastFallModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
