/*     */ package cope.cosmos.client.features.modules;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.client.ModuleToggleEvent;
/*     */ import cope.cosmos.client.features.Feature;
/*     */ import cope.cosmos.client.features.PersistentFeature;
/*     */ import cope.cosmos.client.features.setting.Bind;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Module
/*     */   extends Feature
/*     */   implements Wrapper
/*     */ {
/*     */   private boolean enabled;
/*  31 */   private final boolean persistent = getClass().isAnnotationPresent((Class)PersistentFeature.class);
/*     */ 
/*     */   
/*     */   private boolean drawn;
/*     */ 
/*     */   
/*     */   private boolean exempt;
/*     */ 
/*     */   
/*  40 */   private final Setting<Bind> bind = (new Setting("Bind", new Bind(0, Bind.Device.KEYBOARD)))
/*  41 */     .setDescription("The bind of the module");
/*     */ 
/*     */   
/*     */   private final Category category;
/*     */ 
/*     */   
/*     */   private Supplier<String> info;
/*     */ 
/*     */   
/*     */   private final Animation animation;
/*     */ 
/*     */   
/*  53 */   private final List<Setting<?>> settings = new ArrayList<>();
/*     */   
/*     */   public Module(String name, Category category, String description) {
/*  56 */     super(name, description);
/*     */ 
/*     */     
/*  59 */     if (this.persistent) {
/*  60 */       this.enabled = true;
/*     */     }
/*     */     
/*  63 */     this.category = category;
/*     */ 
/*     */     
/*  66 */     Arrays.<Field>stream(getClass().getDeclaredFields())
/*  67 */       .filter(field -> Setting.class.isAssignableFrom(field.getType()))
/*  68 */       .forEach(field -> {
/*     */           field.setAccessible(true);
/*     */ 
/*     */           
/*     */           try {
/*     */             Setting<?> setting = (Setting)field.get(this);
/*     */             
/*     */             setting.setModule(this);
/*     */             
/*     */             this.settings.add(setting);
/*  78 */           } catch (IllegalArgumentException|IllegalAccessException exception) {
/*     */             exception.printStackTrace();
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  84 */     this.settings.add(this.bind);
/*     */ 
/*     */     
/*  87 */     this.drawn = true;
/*     */ 
/*     */     
/*  90 */     this.animation = new Animation(300, this.enabled);
/*     */   }
/*     */   
/*     */   public Module(String name, Category category, String description, Supplier<String> info) {
/*  94 */     this(name, category, description);
/*     */ 
/*     */     
/*  97 */     this.info = info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggle() {
/* 104 */     if (this.enabled) {
/* 105 */       disable(true);
/*     */     }
/*     */     else {
/*     */       
/* 109 */       enable(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enable(boolean in) {
/* 118 */     if (!this.persistent && !this.enabled) {
/*     */ 
/*     */       
/* 121 */       this.enabled = true;
/*     */       
/* 123 */       Cosmos.EVENT_BUS.register(this);
/*     */       
/* 125 */       if (nullCheck() || getCosmos().getNullSafeFeatures().contains(this)) {
/*     */ 
/*     */         
/* 128 */         if (in) {
/* 129 */           ModuleToggleEvent.ModuleEnableEvent event = new ModuleToggleEvent.ModuleEnableEvent(this);
/* 130 */           Cosmos.EVENT_BUS.post((Event)event);
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 135 */           onEnable();
/* 136 */         } catch (Exception exception) {
/* 137 */           exception.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disable(boolean in) {
/* 148 */     if (!this.persistent && this.enabled) {
/*     */       
/* 150 */       this.enabled = false;
/*     */       
/* 152 */       if (nullCheck() || getCosmos().getNullSafeFeatures().contains(this)) {
/*     */ 
/*     */         
/* 155 */         if (in) {
/* 156 */           ModuleToggleEvent.ModuleDisableEvent event = new ModuleToggleEvent.ModuleDisableEvent(this);
/* 157 */           Cosmos.EVENT_BUS.post((Event)event);
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 162 */           onDisable();
/* 163 */         } catch (Exception exception) {
/* 164 */           exception.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/* 168 */       Cosmos.EVENT_BUS.unregister(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/* 178 */     getAnimation().setState(true);
/*     */ 
/*     */     
/* 181 */     if (nullCheck()) {
/* 182 */       getCosmos().getTickManager().setClientTicks(1.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 192 */     getAnimation().setState(false);
/*     */ 
/*     */     
/* 195 */     if (nullCheck()) {
/* 196 */       getCosmos().getTickManager().setClientTicks(1.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onTick() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onThread() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender2D() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 240 */     return this.enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawn(boolean in) {
/* 248 */     this.drawn = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDrawn() {
/* 256 */     return this.drawn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExempt(boolean in) {
/* 264 */     this.exempt = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExempt() {
/* 272 */     return this.exempt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Setting<Bind> getBind() {
/* 281 */     return this.bind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Category getCategory() {
/* 289 */     return this.category;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfo() {
/* 297 */     return (this.info != null) ? this.info.get() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Animation getAnimation() {
/* 305 */     return this.animation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Setting<?>> getSettings() {
/* 313 */     return this.settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 321 */     return isEnabled();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */