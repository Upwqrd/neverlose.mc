/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.client.events.entity.player.interact.DualInteractEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiTaskModule
/*    */   extends Module
/*    */ {
/*    */   public static MultiTaskModule INSTANCE;
/*    */   
/*    */   public MultiTaskModule() {
/* 16 */     super("MultiTask", Category.MISC, "Allows you to use your offhand and mine at the same time");
/* 17 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onDualInteract(DualInteractEvent event) {
/* 24 */     event.setCanceled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\MultiTaskModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */