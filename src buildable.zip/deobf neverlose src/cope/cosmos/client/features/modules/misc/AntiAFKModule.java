//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.misc;
/*     */ 
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.PresenceManager;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.MotionUtil;
/*     */ import java.util.Random;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ import net.minecraft.util.text.ChatType;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class AntiAFKModule
/*     */   extends Module
/*     */ {
/*     */   public static AntiAFKModule INSTANCE;
/*     */   public static Setting<Boolean> chat = (new Setting("Chat", Boolean.valueOf(true))).setDescription("Send messages in the chat to avoid AFK detection");
/*     */   public static Setting<Boolean> jump = (new Setting("Jump", Boolean.valueOf(true))).setDescription("Jumps to avoid AFK detection");
/*     */   public static Setting<Boolean> rotate = (new Setting("Rotate", Boolean.valueOf(false))).setDescription("Rotates to avoid AFK detection");
/*     */   
/*     */   public AntiAFKModule() {
/*  27 */     super("AntiAFK", Category.MISC, "Prevents servers for kicking you for being AFK");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     this.awayTimer = new Timer();
/*     */ 
/*     */     
/*  46 */     this.chatTimer = new Timer();
/*  47 */     this.jumpTimer = new Timer();
/*  48 */     this.rotateTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onEnable() {
/*  52 */     super.onEnable();
/*     */ 
/*     */     
/*  55 */     this.awayTimer.resetTime();
/*  56 */     this.chatTimer.resetTime();
/*  57 */     this.jumpTimer.resetTime();
/*  58 */     this.rotateTimer.resetTime();
/*     */   }
/*     */   
/*     */   private final Timer awayTimer;
/*     */   private final Timer chatTimer;
/*     */   
/*     */   public void onUpdate() {
/*  65 */     if (MotionUtil.isMoving() || mc.player.movementInput.jump || mc.player.movementInput.sneak) {
/*  66 */       this.awayTimer.resetTime();
/*     */ 
/*     */     
/*     */     }
/*  70 */     else if (this.awayTimer.passedTime(20L, Timer.Format.SECONDS)) {
/*     */ 
/*     */       
/*  73 */       if (((Boolean)jump.getValue()).booleanValue())
/*     */       {
/*     */         
/*  76 */         if (this.jumpTimer.passedTime(5L, Timer.Format.SECONDS) && mc.player.onGround) {
/*  77 */           mc.player.jump();
/*     */ 
/*     */           
/*  80 */           this.jumpTimer.resetTime();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*  85 */       if (((Boolean)chat.getValue()).booleanValue()) {
/*     */ 
/*     */         
/*  88 */         Random chatRandom = new Random();
/*     */ 
/*     */         
/*  91 */         if (this.chatTimer.passedTime((10 + chatRandom.nextInt(5)), Timer.Format.SECONDS)) {
/*     */ 
/*     */           
/*  94 */           String message = PresenceManager.getPresenceDetails()[chatRandom.nextInt((PresenceManager.getPresenceDetails()).length - 1)];
/*     */ 
/*     */           
/*  97 */           getCosmos().getChatManager().sendChatMessage(message);
/*     */ 
/*     */           
/* 100 */           this.chatTimer.resetTime();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 105 */       if (((Boolean)rotate.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 108 */         Random rotateRandom = new Random();
/*     */ 
/*     */         
/* 111 */         if (this.rotateTimer.passedTime(5L, Timer.Format.SECONDS)) {
/*     */ 
/*     */           
/* 114 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(mc.player.rotationYaw + rotateRandom.nextInt(5), mc.player.rotationPitch, mc.player.onGround));
/*     */ 
/*     */           
/* 117 */           this.rotateTimer.resetTime();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private final Timer jumpTimer;
/*     */   private final Timer rotateTimer;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 127 */     if (event.getPacket() instanceof SPacketChat) {
/*     */ 
/*     */       
/* 130 */       String[] chatMessage = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText().split(" ");
/*     */ 
/*     */       
/* 133 */       if (((Boolean)chat.getValue()).booleanValue() && ((SPacketChat)event.getPacket()).getType().equals(ChatType.SYSTEM))
/*     */       {
/*     */         
/* 136 */         if (chatMessage[1].equals("whispers:"))
/*     */         {
/*     */           
/* 139 */           getCosmos().getChatManager().sendChatMessage("/r [Cosmos] I am currently AFK. Please try messaging me later.");
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\AntiAFKModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
