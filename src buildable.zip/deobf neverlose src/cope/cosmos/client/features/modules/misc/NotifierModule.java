//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.client.events.client.ModuleToggleEvent;
/*    */ import cope.cosmos.client.events.combat.TotemPopEvent;
/*    */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotifierModule
/*    */   extends Module
/*    */ {
/*    */   public static NotifierModule INSTANCE;
/*    */   
/*    */   public NotifierModule() {
/* 21 */     super("Notifier", Category.MISC, "Sends notifications in chat");
/* 22 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public static Setting<Boolean> enableNotify = (new Setting("EnableNotify", Boolean.valueOf(false)))
/* 28 */     .setDescription("Send a chat message when a modules is toggled");
/*    */   
/* 30 */   public static Setting<Boolean> popNotify = (new Setting("PopNotify", Boolean.valueOf(false)))
/* 31 */     .setDescription("Send a chat message when a nearby player is popped");
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTotemPop(TotemPopEvent event) {
/* 35 */     if (((Boolean)popNotify.getValue()).booleanValue())
/*    */     {
/*    */       
/* 38 */       if (mc.player.getDistance(event.getPopEntity()) < 10.0F) {
/*    */ 
/*    */         
/* 41 */         String popMessage = TextFormatting.DARK_PURPLE + event.getPopEntity().getName() + TextFormatting.RESET + " has popped " + getCosmos().getPopManager().getTotemPops(event.getPopEntity()) + " totems!";
/*    */ 
/*    */         
/* 44 */         getCosmos().getChatManager().sendClientMessage(popMessage);
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onEntityRemove(EntityWorldEvent.EntityRemoveEvent event) {
/* 51 */     if (getCosmos().getPopManager().getTotemPops(event.getEntity()) > 0) {
/*    */ 
/*    */       
/* 54 */       if (((Boolean)popNotify.getValue()).booleanValue()) {
/* 55 */         getCosmos().getChatManager().sendClientMessage(TextFormatting.DARK_PURPLE + event.getEntity().getName() + TextFormatting.RESET + " died after popping " + getCosmos().getPopManager().getTotemPops(event.getEntity()) + " totems!");
/*    */       }
/*    */ 
/*    */       
/* 59 */       getCosmos().getPopManager().removePops(event.getEntity());
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onModuleEnable(ModuleToggleEvent.ModuleEnableEvent event) {
/* 65 */     if (((Boolean)enableNotify.getValue()).booleanValue())
/*    */     {
/*    */       
/* 68 */       if (!event.getModule().getCategory().equals(Category.HIDDEN))
/*    */       {
/*    */         
/* 71 */         getCosmos().getChatManager().sendClientMessage(event.getModule());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onModuleDisable(ModuleToggleEvent.ModuleDisableEvent event) {
/* 78 */     if (((Boolean)enableNotify.getValue()).booleanValue())
/*    */     {
/*    */       
/* 81 */       if (!event.getModule().getCategory().equals(Category.HIDDEN))
/*    */       {
/*    */         
/* 84 */         getCosmos().getChatManager().sendClientMessage(event.getModule());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\NotifierModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
