//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.misc;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketChatMessage;
/*     */ import cope.cosmos.asm.mixins.accessor.ITextComponentString;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.chat.ChatUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ import net.minecraft.util.text.ChatType;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChatModificationsModule
/*     */   extends Module
/*     */ {
/*     */   public static ChatModificationsModule INSTANCE;
/*     */   
/*     */   public ChatModificationsModule() {
/*  29 */     super("ChatModifications", Category.MISC, "Allows you to modify the in-game chat window");
/*  30 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static Setting<Time> time = (new Setting("Time", Time.NA))
/*  36 */     .setDescription("Time format");
/*     */   
/*  38 */   public static Setting<Boolean> prefix = (new Setting("Prefix", Boolean.valueOf(false)))
/*  39 */     .setDescription("Add a cosmos prefix before chat messages");
/*     */   
/*  41 */   public static Setting<Boolean> suffix = (new Setting("Suffix", Boolean.valueOf(true)))
/*  42 */     .setDescription("Add a cosmos suffix after chat messages");
/*     */   
/*  44 */   public static Setting<Boolean> colored = (new Setting("Colored", Boolean.valueOf(true)))
/*  45 */     .setDescription("Add a > before public messages");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  56 */     if (event.getPacket() instanceof CPacketChatMessage)
/*     */     {
/*  58 */       if (!((CPacketChatMessage)event.getPacket()).getMessage().startsWith("/") && !((CPacketChatMessage)event.getPacket()).getMessage().startsWith("!") && !((CPacketChatMessage)event.getPacket()).getMessage().startsWith("$") && !((CPacketChatMessage)event.getPacket()).getMessage().startsWith("?") && !((CPacketChatMessage)event.getPacket()).getMessage().startsWith(".") && !((CPacketChatMessage)event.getPacket()).getMessage().startsWith(",")) {
/*     */         
/*  60 */         StringBuilder formattedMessage = new StringBuilder();
/*     */ 
/*     */         
/*  63 */         if (((Boolean)colored.getValue()).booleanValue()) {
/*  64 */           formattedMessage.append("> ");
/*     */         }
/*     */         
/*  67 */         formattedMessage.append(((CPacketChatMessage)event.getPacket()).getMessage());
/*     */ 
/*     */         
/*  70 */         if (((Boolean)suffix.getValue()).booleanValue()) {
/*  71 */           formattedMessage.append(" �?? ").append(toUnicode("neverlose.mc"));
/*     */         }
/*     */ 
/*     */         
/*  75 */         ((ICPacketChatMessage)event.getPacket()).setMessage(formattedMessage.toString());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/*  83 */     if (event.getPacket() instanceof SPacketChat)
/*     */     {
/*     */       
/*  86 */       if (((SPacketChat)event.getPacket()).getChatComponent() instanceof TextComponentString && !((SPacketChat)event.getPacket()).getType().equals(ChatType.GAME_INFO)) {
/*     */ 
/*     */         
/*  89 */         TextComponentString component = (TextComponentString)((SPacketChat)event.getPacket()).getChatComponent();
/*     */ 
/*     */         
/*  92 */         String formattedTime = "";
/*  93 */         switch ((Time)time.getValue()) {
/*     */           case NA:
/*  95 */             formattedTime = (new SimpleDateFormat("h:mm a")).format(new Date());
/*     */             break;
/*     */           case EU:
/*  98 */             formattedTime = (new SimpleDateFormat("k:mm")).format(new Date());
/*     */             break;
/*     */         } 
/*     */         
/* 102 */         if (component.getText() != null) {
/*     */           
/* 104 */           StringBuilder formattedText = new StringBuilder();
/*     */ 
/*     */           
/* 107 */           if (((Boolean)prefix.getValue()).booleanValue()) {
/* 108 */             formattedText.append(ChatUtil.getPrefix());
/*     */           }
/*     */ 
/*     */           
/* 112 */           if (!((Time)time.getValue()).equals(Time.NONE)) {
/* 113 */             formattedText.append(TextFormatting.GRAY).append("[").append(formattedTime).append("] ").append(TextFormatting.RESET);
/*     */           }
/*     */           
/* 116 */           formattedText.append(component.getText());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 129 */           ((ITextComponentString)component).setText(formattedText.toString());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicode(String message) {
/* 141 */     return message.toLowerCase()
/* 142 */       .replace("a", "ᴀ")
/* 143 */       .replace("b", "ʙ")
/* 144 */       .replace("c", "ᴄ")
/* 145 */       .replace("d", "ᴅ")
/* 146 */       .replace("e", "ᴇ")
/* 147 */       .replace("f", "ꜰ")
/* 148 */       .replace("g", "ɢ")
/* 149 */       .replace("h", "ʜ")
/* 150 */       .replace("i", "ɪ")
/* 151 */       .replace("j", "ᴊ")
/* 152 */       .replace("k", "ᴋ")
/* 153 */       .replace("l", "ʟ")
/* 154 */       .replace("m", "�?")
/* 155 */       .replace("n", "ɴ")
/* 156 */       .replace("o", "�?")
/* 157 */       .replace("p", "ᴘ")
/* 158 */       .replace("q", "ǫ")
/* 159 */       .replace("r", "ʀ")
/* 160 */       .replace("s", "ꜱ")
/* 161 */       .replace("t", "ᴛ")
/* 162 */       .replace("u", "ᴜ")
/* 163 */       .replace("v", "ᴠ")
/* 164 */       .replace("w", "ᴡ")
/* 165 */       .replace("x", "ˣ")
/* 166 */       .replace("y", "�?")
/* 167 */       .replace("z", "ᴢ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Time
/*     */   {
/* 175 */     NA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     EU,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\ChatModificationsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
