//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraftforge.client.GuiIngameForge;
/*    */ import net.minecraftforge.client.event.sound.PlaySoundEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PortalModule
/*    */   extends Module
/*    */ {
/*    */   public static PortalModule INSTANCE;
/*    */   
/*    */   public PortalModule() {
/* 21 */     super("Portal", Category.MISC, "Modifies portal behavior");
/* 22 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public static Setting<Boolean> godMode = (new Setting("GodMode", Boolean.valueOf(false)))
/* 28 */     .setDescription("Cancels teleport packets");
/*    */   
/* 30 */   public static Setting<Boolean> screens = (new Setting("Screens", Boolean.valueOf(true)))
/* 31 */     .setDescription("Allow the use of screens in portals");
/*    */   
/* 33 */   public static Setting<Boolean> effect = (new Setting("Effect", Boolean.valueOf(true)))
/* 34 */     .setDescription("Cancels the portal overlay effect");
/*    */   
/* 36 */   public static Setting<Boolean> sounds = (new Setting("Sounds", Boolean.valueOf(false)))
/* 37 */     .setDescription("Cancels portal sounds");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 43 */     ((IEntity)mc.player).setInPortal((!((Boolean)screens.getValue()).booleanValue() && ((IEntity)mc.player).getInPortal()));
/*    */ 
/*    */     
/* 46 */     GuiIngameForge.renderPortal = !((Boolean)effect.getValue()).booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 51 */     super.onDisable();
/*    */ 
/*    */     
/* 54 */     GuiIngameForge.renderPortal = true;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onSound(PlaySoundEvent event) {
/* 59 */     if (((Boolean)sounds.getValue()).booleanValue())
/*    */     {
/*    */       
/* 62 */       if (event.getName().equals("block.portal.ambient") || event.getName().equals("block.portal.travel") || event.getName().equals("block.portal.trigger")) {
/* 63 */         event.setResultSound(null);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 72 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketConfirmTeleport)
/*    */     {
/*    */       
/* 75 */       if (((IEntity)mc.player).getInPortal() && ((Boolean)godMode.getValue()).booleanValue())
/* 76 */         event.setCanceled(true); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\PortalModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
