//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.misc;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IRenderGlobal;
/*     */ import cope.cosmos.client.events.client.ExceptionThrownEvent;
/*     */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*     */ import cope.cosmos.client.events.network.DecodeEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.events.render.entity.CrystalUpdateEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderCrystalEvent;
/*     */ import cope.cosmos.client.events.render.world.RenderSkylightEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.DestroyBlockProgress;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityFireworkRocket;
/*     */ import net.minecraft.entity.monster.EntitySlime;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ import net.minecraft.network.play.server.SPacketParticles;
/*     */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AntiCrashModule
/*     */   extends Module
/*     */ {
/*     */   public static AntiCrashModule INSTANCE;
/*     */   public static Setting<Boolean> packets = (new Setting("Packet", Boolean.valueOf(false))).setDescription("Prevents you from getting kicked for invalid packets");
/*     */   public static Setting<Boolean> bookBan = (new Setting("BookBan", Boolean.valueOf(false))).setDescription("Prevents you from getting kicked for packet size limit");
/*     */   public static Setting<Boolean> unicode = (new Setting("UnicodeCharacters", Boolean.valueOf(false))).setDescription("Prevents unicode characters in chat from lagging you");
/*     */   public static Setting<Boolean> offhand = (new Setting("Offhand", Boolean.valueOf(false))).setDescription("Prevents you from getting crashed from item equip sounds");
/*     */   
/*     */   public AntiCrashModule() {
/*  40 */     super("AntiCrash", Category.MISC, "Prevents you from being kicked/crashed by various exploits");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.placedSigns = new ArrayList<>();
/*     */     INSTANCE = this;
/*     */   }
/*  80 */   private static final String[] UNICODE = "�? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �? �?? �? �? �? �? �? �? �? �? �?".split(" "); public static Setting<Boolean> fireworks = (new Setting("Fireworks", Boolean.valueOf(true))).setDescription("Prevents firework spam from crashing you");
/*     */   public static Setting<Boolean> crystals = (new Setting("Crystals", Boolean.valueOf(false))).setDescription("Prevents stacked crystals spam from lagging you");
/*     */   public static Setting<Boolean> skylight = (new Setting("Skylight", Boolean.valueOf(true))).setDescription("Prevents skylight updates from crashing you");
/*     */   public static Setting<Boolean> particles = (new Setting("Particles", Boolean.valueOf(false))).setDescription("Prevents laggy particles from crashing you");
/*     */   
/*     */   public void onUpdate() {
/*  86 */     if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiEditSign && (
/*  87 */       (Boolean)signs.getValue()).booleanValue())
/*     */     {
/*     */       
/*  90 */       ((IRenderGlobal)mc.renderGlobal).getDamagedBlocks().forEach((integer, destroyBlockProgress) -> {
/*     */             if (this.placedSigns.contains(destroyBlockProgress.getPosition())) {
/*     */               mc.player.closeScreen();
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Setting<Boolean> slime = (new Setting("Slime", Boolean.valueOf(false))).setDescription("Prevents large slime entities from crashing you");
/*     */   
/*     */   public static Setting<Boolean> signs = (new Setting("Signs", Boolean.valueOf(false))).setDescription("Prevents signs from kicking you when broken");
/*     */   private final List<BlockPos> placedSigns;
/*     */   
/*     */   public void onEnable() {
/* 105 */     super.onEnable();
/*     */     
/* 107 */     if (((Boolean)slime.getValue()).booleanValue()) {
/* 108 */       mc.world.loadedEntityList.forEach(entity -> {
/*     */             if (entity instanceof EntitySlime && ((EntitySlime)entity).getSlimeSize() > 4) {
/*     */               mc.world.removeEntityDangerously(entity);
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onExceptionThrown(ExceptionThrownEvent event) {
/* 122 */     if ((event.getException() instanceof NullPointerException || event.getException() instanceof java.io.IOException || event.getException() instanceof java.util.ConcurrentModificationException) && (
/* 123 */       (Boolean)packets.getValue()).booleanValue()) {
/* 124 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onDecode(DecodeEvent event) {
/* 133 */     if (((Boolean)bookBan.getValue()).booleanValue()) {
/* 134 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 140 */     if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock)
/*     */     {
/*     */       
/* 143 */       if (InventoryUtil.isHolding(Items.SIGN)) {
/* 144 */         this.placedSigns.add(((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getPos());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 151 */     if (event.getPacket() instanceof SPacketSoundEffect && ((SPacketSoundEffect)event.getPacket()).getSound().equals(SoundEvents.ITEM_ARMOR_EQUIP_GENERIC))
/*     */     {
/*     */       
/* 154 */       if (((Boolean)offhand.getValue()).booleanValue()) {
/* 155 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 160 */     if (event.getPacket() instanceof SPacketParticles && (
/* 161 */       (Boolean)particles.getValue()).booleanValue())
/*     */     {
/*     */       
/* 164 */       if (((SPacketParticles)event.getPacket()).getParticleCount() > 200) {
/* 165 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (event.getPacket() instanceof SPacketChat) {
/*     */ 
/*     */       
/* 174 */       String chatMessage = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText();
/*     */ 
/*     */       
/* 177 */       if (((Boolean)AntiCrashModule.unicode.getValue()).booleanValue())
/*     */       {
/*     */         
/* 180 */         for (int i = 0; i < chatMessage.length(); i++) {
/*     */ 
/*     */           
/* 183 */           char character = chatMessage.charAt(i);
/*     */ 
/*     */           
/* 186 */           for (String unicode : UNICODE) {
/*     */ 
/*     */             
/* 189 */             if (unicode.equalsIgnoreCase(String.valueOf(character))) {
/* 190 */               event.setCanceled(true);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntitySpawn(EntityWorldEvent.EntitySpawnEvent event) {
/* 200 */     if (event.getEntity() instanceof EntityFireworkRocket)
/*     */     {
/*     */       
/* 203 */       if (((Boolean)fireworks.getValue()).booleanValue() && !((EntityFireworkRocket)event.getEntity()).isAttachedToEntity()) {
/* 204 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */     
/* 208 */     if (event.getEntity() instanceof EntitySlime && ((EntitySlime)event.getEntity()).getSlimeSize() > 4)
/*     */     {
/*     */       
/* 211 */       if (((Boolean)slime.getValue()).booleanValue()) {
/* 212 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityUpdate(EntityWorldEvent.EntityUpdateEvent event) {
/* 219 */     if (event.getEntity() instanceof EntityFireworkRocket)
/*     */     {
/*     */       
/* 222 */       if (((Boolean)fireworks.getValue()).booleanValue() && !((EntityFireworkRocket)event.getEntity()).isAttachedToEntity()) {
/* 223 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderSkylight(RenderSkylightEvent event) {
/* 232 */     if (((Boolean)skylight.getValue()).booleanValue()) {
/* 233 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderCrystal(RenderCrystalEvent.RenderCrystalPreEvent event) {
/* 241 */     if (((Boolean)crystals.getValue()).booleanValue()) {
/* 242 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onCrystalUpdate(CrystalUpdateEvent event) {
/* 250 */     if (((Boolean)crystals.getValue()).booleanValue())
/* 251 */       event.setCanceled(true); 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\AntiCrashModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
