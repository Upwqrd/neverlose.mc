/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.client.events.render.gui.TabListSizeEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtraTabModule
/*    */   extends Module
/*    */ {
/*    */   public static ExtraTabModule INSTANCE;
/*    */   
/*    */   public ExtraTabModule() {
/* 16 */     super("ExtraTab", Category.MISC, "Extends the tablist's maximum length");
/* 17 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTabList(TabListSizeEvent event) {
/* 24 */     event.setCanceled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\ExtraTabModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */