/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerModule
/*    */   extends Module
/*    */ {
/*    */   public static TimerModule INSTANCE;
/*    */   
/*    */   public TimerModule() {
/* 15 */     super("Timer", Category.MISC, "Allows you to change the client side tick speed");
/* 16 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 21 */   public static Setting<Double> multiplier = (new Setting("Multiplier", Double.valueOf(0.1D), Double.valueOf(4.0D), Double.valueOf(50.0D), 1))
/* 22 */     .setDescription("Multiplier for the client side tick speed");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 28 */     getCosmos().getTickManager().setClientTicks(((Double)multiplier.getValue()).floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\TimerModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */