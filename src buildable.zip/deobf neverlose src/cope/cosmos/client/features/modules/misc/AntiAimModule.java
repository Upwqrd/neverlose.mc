//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.misc;
/*     */ 
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderRotationsEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import java.util.Random;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AntiAimModule
/*     */   extends Module
/*     */ {
/*     */   public static AntiAimModule INSTANCE;
/*     */   
/*     */   public AntiAimModule() {
/*  25 */     super("AntiAim", Category.MISC, "Makes you harder to hit");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.rotationTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  51 */     Random aimRandom = new Random();
/*     */     
/*  53 */     switch ((Yaw)yaw.getValue()) {
/*     */       
/*     */       case RANDOM:
/*  56 */         this.aimYaw += 5.0F;
/*     */         break;
/*     */       
/*     */       case MIN_MAX:
/*  60 */         this.aimYaw -= 5.0F;
/*     */         break;
/*     */       
/*     */       case NONE:
/*  64 */         this.aimYaw = (aimRandom.nextInt() * 180);
/*     */ 
/*     */         
/*  67 */         if (aimRandom.nextBoolean()) {
/*  68 */           this.aimYaw *= -1.0F;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     switch ((Pitch)pitch.getValue()) {
/*     */ 
/*     */       
/*     */       case RANDOM:
/*  80 */         this.aimPitch = (aimRandom.nextInt() * 90);
/*     */ 
/*     */         
/*  83 */         if (aimRandom.nextBoolean()) {
/*  84 */           this.aimPitch *= -1.0F;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case MIN_MAX:
/*  90 */         if (this.rotationTimer.passedTime(2L, Timer.Format.TICKS)) {
/*     */           
/*  92 */           this.aimPitch = 90.0F;
/*  93 */           this.rotationTimer.resetTime();
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/*  98 */         this.aimPitch = -90.0F;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   public static Setting<Yaw> yaw = (new Setting("Yaw", Yaw.LINEAR)).setDescription("Changes how your yaw is rotated");
/*     */   public static Setting<Pitch> pitch = (new Setting("Pitch", Pitch.NONE)).setDescription("Changes how your pitch is rotated");
/*     */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.PACKET)).setDescription("How to rotate").setExclusion((Object[])new Rotation.Rotate[] { Rotation.Rotate.NONE });
/*     */   private float aimYaw;
/*     */   private float aimPitch;
/*     */   private final Timer rotationTimer;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRotationUpdate(RotationUpdateEvent event) {
/* 111 */     if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE)) {
/*     */ 
/*     */       
/* 114 */       event.setCanceled(true);
/*     */ 
/*     */       
/* 117 */       if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 118 */         mc.player.rotationYaw = this.aimYaw;
/* 119 */         mc.player.rotationYawHead = this.aimYaw;
/* 120 */         mc.player.rotationPitch = this.aimPitch;
/*     */       } 
/*     */ 
/*     */       
/* 124 */       getCosmos().getRotationManager().setRotation(new Rotation(this.aimYaw, this.aimPitch));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onRenderRotations(RenderRotationsEvent event) {
/* 132 */     if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.PACKET)) {
/*     */ 
/*     */       
/* 135 */       event.setCanceled(true);
/*     */ 
/*     */       
/* 138 */       event.setYaw(this.aimYaw);
/* 139 */       event.setPitch(this.aimPitch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Yaw
/*     */   {
/* 148 */     LINEAR,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     REVERSE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     RANDOM,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Pitch
/*     */   {
/* 171 */     RANDOM,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     MIN_MAX,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\AntiAimModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
