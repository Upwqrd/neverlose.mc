//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.misc;
/*     */ 
/*     */ import cope.cosmos.client.events.input.MiddleClickEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ public class MiddleClickModule
/*     */   extends Module
/*     */ {
/*     */   public static MiddleClickModule INSTANCE;
/*     */   
/*     */   public MiddleClickModule() {
/*  28 */     super("MiddleClick", Category.MISC, "Allows you to preform an action when middle-clicking");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     this.serverSlot = -1;
/*     */     INSTANCE = this;
/*     */   } public static Setting<EntityAction> entityAction = (new Setting("EntityAction", EntityAction.FRIEND)).setDescription("Action to perform when middle-clicking an entity");
/*     */   public void onDisable() {
/*  54 */     super.onDisable();
/*     */     
/*  56 */     resetProcess();
/*  57 */     this.serverSlot = -1;
/*     */   }
/*     */   public static Setting<Boolean> pearl = (new Setting("Pearl", Boolean.valueOf(true))).setDescription("If to pearl if raytrace type is MISS"); public static Setting<Boolean> mend = (new Setting("Mend", Boolean.valueOf(true))).setDescription("If to mend if raytrace type is BLOCK");
/*     */   public static Setting<Boolean> guis = (new Setting("Guis", Boolean.valueOf(false))).setVisible(mend::getValue).setDescription("If to mend if holding middle click in a GUI");
/*     */   public static Setting<Boolean> cancelBlock = (new Setting("CancelBlock", Boolean.valueOf(true))).setDescription("Cancels block picking if you middle click a block");
/*     */   private int serverSlot;
/*     */   
/*     */   public void onTick() {
/*  65 */     if (Mouse.isButtonDown(2)) {
/*  66 */       if (!((Boolean)guis.getValue()).booleanValue() && mc.currentScreen != null) {
/*  67 */         resetProcess();
/*     */         
/*     */         return;
/*     */       } 
/*  71 */       if (mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.BLOCK) && ((Boolean)mend.getValue()).booleanValue()) {
/*  72 */         int currentSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */         
/*  75 */         int slot = getCosmos().getInventoryManager().searchSlot(Items.EXPERIENCE_BOTTLE, InventoryManager.InventoryRegion.HOTBAR);
/*     */ 
/*     */         
/*  78 */         if (slot == -1) {
/*     */ 
/*     */           
/*  81 */           if (this.serverSlot != currentSlot) {
/*  82 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(currentSlot));
/*     */           }
/*     */ 
/*     */           
/*  86 */           this.serverSlot = -1;
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */         
/*  93 */         if (slot != this.serverSlot) {
/*  94 */           this.serverSlot = slot;
/*  95 */           mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */         } 
/*     */ 
/*     */         
/*  99 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 104 */       resetProcess();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMouseInput(MiddleClickEvent event) {
/* 112 */     if (mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.BLOCK) && ((Boolean)cancelBlock.getValue()).booleanValue()) {
/* 113 */       event.setCanceled(true);
/*     */     }
/*     */     
/* 116 */     int currentSlot = mc.player.inventory.currentItem;
/*     */     
/* 118 */     switch (mc.objectMouseOver.typeOfHit) {
/*     */       case ENTITY:
/* 120 */         if (!(mc.objectMouseOver.entityHit instanceof EntityPlayer) || !Mouse.getEventButtonState()) {
/*     */           break;
/*     */         }
/*     */         
/* 124 */         switch ((EntityAction)entityAction.getValue()) {
/*     */           
/*     */           case ENTITY:
/* 127 */             if (getCosmos().getSocialManager().getSocial(mc.objectMouseOver.entityHit.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */               
/* 129 */               getCosmos().getSocialManager().removeSocial(mc.objectMouseOver.entityHit.getName());
/*     */ 
/*     */               
/* 132 */               getCosmos().getChatManager().sendClientMessage("Removed friend with name " + mc.objectMouseOver.entityHit.getName());
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 137 */             getCosmos().getSocialManager().addSocial(mc.objectMouseOver.entityHit.getName(), SocialManager.Relationship.FRIEND);
/*     */ 
/*     */             
/* 140 */             getCosmos().getChatManager().sendClientMessage("Added friend with name " + mc.objectMouseOver.entityHit.getName());
/*     */ 
/*     */             
/* 143 */             mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/w " + mc.objectMouseOver.entityHit.getName() + " I just added you as a friend on Cosmos!"));
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case MISS:
/* 149 */             mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/duel " + mc.objectMouseOver.entityHit.getName()));
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/*     */         break;
/*     */       
/*     */       case MISS:
/* 157 */         if (((Boolean)pearl.getValue()).booleanValue()) {
/*     */ 
/*     */           
/* 160 */           getCosmos().getInventoryManager().switchToItem(Items.ENDER_PEARL, InventoryManager.Switch.NORMAL);
/*     */ 
/*     */           
/* 163 */           mc.playerController.processRightClick((EntityPlayer)mc.player, (World)mc.world, EnumHand.MAIN_HAND);
/*     */ 
/*     */           
/* 166 */           getCosmos().getInventoryManager().switchToSlot(currentSlot, InventoryManager.Switch.NORMAL);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetProcess() {
/* 176 */     if (this.serverSlot != -1 && this.serverSlot != mc.player.inventory.currentItem) {
/* 177 */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(mc.player.inventory.currentItem));
/*     */     }
/*     */     
/* 180 */     this.serverSlot = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EntityAction
/*     */   {
/* 188 */     FRIEND,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     DUEL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\MiddleClickModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
