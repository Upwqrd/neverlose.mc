//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*    */ import cope.cosmos.client.events.network.DisconnectEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import java.util.concurrent.ThreadLocalRandom;
/*    */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ public class FakePlayerModule
/*    */   extends Module
/*    */ {
/*    */   public static FakePlayerModule INSTANCE;
/*    */   
/*    */   public FakePlayerModule() {
/* 22 */     super("FakePlayer", Category.MISC, "Spawns in a indestructible client-side player");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     this.id = -1;
/*    */     INSTANCE = this;
/*    */     setExempt(true);
/*    */   } public static Setting<Boolean> inventory = (new Setting("Inventory", Boolean.valueOf(true))).setDescription("Sync the fake player inventory"); public void onEnable() {
/* 40 */     super.onEnable();
/*    */ 
/*    */     
/* 43 */     EntityOtherPlayerMP fakePlayer = new EntityOtherPlayerMP((World)mc.world, new GameProfile(mc.player.getGameProfile().getId(), "FakePlayer"));
/*    */ 
/*    */     
/* 46 */     fakePlayer.copyLocationAndAnglesFrom((Entity)mc.player);
/* 47 */     fakePlayer.rotationYawHead = mc.player.rotationYaw;
/*    */ 
/*    */     
/* 50 */     if (((Boolean)inventory.getValue()).booleanValue()) {
/* 51 */       fakePlayer.inventory.copyInventory(mc.player.inventory);
/* 52 */       fakePlayer.inventoryContainer = mc.player.inventoryContainer;
/*    */     } 
/*    */ 
/*    */     
/* 56 */     if (((Boolean)health.getValue()).booleanValue()) {
/* 57 */       fakePlayer.setHealth(mc.player.getHealth());
/* 58 */       fakePlayer.setAbsorptionAmount(mc.player.getAbsorptionAmount());
/*    */     } 
/*    */ 
/*    */     
/* 62 */     fakePlayer.setSneaking(mc.player.isSneaking());
/* 63 */     fakePlayer.setPrimaryHand(mc.player.getPrimaryHand());
/*    */ 
/*    */     
/* 66 */     this.id = ThreadLocalRandom.current().nextInt(2147483647);
/* 67 */     mc.world.addEntityToWorld(this.id, (Entity)fakePlayer);
/*    */   }
/*    */   public static Setting<Boolean> health = (new Setting("Health", Boolean.valueOf(true))).setDescription("Sync the fakeplayer health"); private int id;
/*    */   
/*    */   public void onDisable() {
/* 72 */     super.onDisable();
/*    */ 
/*    */     
/* 75 */     mc.world.removeEntityFromWorld(this.id);
/* 76 */     this.id = -1;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onEntityRemove(EntityWorldEvent.EntityRemoveEvent event) {
/* 81 */     if (event.getEntity().equals(mc.player)) {
/*    */ 
/*    */       
/* 84 */       mc.world.removeEntityFromWorld(this.id);
/* 85 */       this.id = -1;
/*    */ 
/*    */       
/* 88 */       disable(true);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onDisconnect(DisconnectEvent event) {
/* 96 */     disable(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\FakePlayerModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
