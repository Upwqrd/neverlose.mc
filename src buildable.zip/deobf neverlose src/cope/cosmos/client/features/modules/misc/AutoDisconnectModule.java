//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.client.events.network.ConnectEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.math.Timer;
/*    */ import cope.cosmos.util.player.InventoryUtil;
/*    */ import cope.cosmos.util.player.PlayerUtil;
/*    */ import net.minecraft.client.gui.GuiMainMenu;
/*    */ import net.minecraft.client.gui.GuiMultiplayer;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.client.gui.GuiWorldSelection;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoDisconnectModule
/*    */   extends Module
/*    */ {
/*    */   public static AutoDisconnectModule INSTANCE;
/*    */   
/*    */   public AutoDisconnectModule() {
/* 26 */     super("AutoDisconnect", Category.MISC, "Automatically disconnects from servers when in danger");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     this.disconnectTimer = new Timer();
/*    */     INSTANCE = this;
/*    */   }
/*    */   public void onTick() {
/* 43 */     if (this.disconnectTimer.passedTime(5L, Timer.Format.SECONDS))
/*    */     {
/*    */       
/* 46 */       if (PlayerUtil.getHealth() <= ((Double)health.getValue()).doubleValue()) {
/* 47 */         disconnectClient();
/* 48 */         this.disconnectTimer.resetTime();
/*    */ 
/*    */       
/*    */       }
/* 52 */       else if (InventoryUtil.getItemCount(Items.TOTEM_OF_UNDYING) <= ((Double)totems.getValue()).doubleValue()) {
/* 53 */         disconnectClient();
/* 54 */         this.disconnectTimer.resetTime();
/*    */       }  } 
/*    */   }
/*    */   public static Setting<Double> health = (new Setting("Health", Double.valueOf(0.0D), Double.valueOf(2.0D), Double.valueOf(36.0D), 1)).setDescription("Health considered as critical health");
/*    */   public static Setting<Double> totems = (new Setting("Totems", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(10.0D), 0)).setDescription("Totem count considered as critical count");
/*    */   private final Timer disconnectTimer;
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onConnect(ConnectEvent event) {
/* 63 */     this.disconnectTimer.resetTime();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void disconnectClient() {
/*    */     GuiMultiplayer guiMultiplayer;
/* 71 */     disable(false);
/*    */ 
/*    */ 
/*    */     
/* 75 */     if (mc.isSingleplayer()) {
/* 76 */       GuiWorldSelection guiWorldSelection = new GuiWorldSelection((GuiScreen)new GuiMainMenu());
/*    */     }
/*    */     else {
/*    */       
/* 80 */       guiMultiplayer = new GuiMultiplayer((GuiScreen)new GuiMainMenu());
/*    */     } 
/*    */ 
/*    */     
/* 84 */     mc.world.sendQuittingDisconnectingPacket();
/* 85 */     mc.loadWorld(null);
/*    */ 
/*    */     
/* 88 */     mc.displayGuiScreen((GuiScreen)guiMultiplayer);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\AutoDisconnectModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
