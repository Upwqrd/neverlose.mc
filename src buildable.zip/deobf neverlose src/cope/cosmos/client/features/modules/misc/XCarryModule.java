//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.misc;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.ICPacketCloseWindow;
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XCarryModule
/*    */   extends Module
/*    */ {
/*    */   public static XCarryModule INSTANCE;
/*    */   
/*    */   public XCarryModule() {
/* 22 */     super("XCarry", Category.MISC, "Prevents the server from knowing when you open your inventory");
/* 23 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 28 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketCloseWindow)
/*    */     {
/*    */       
/* 31 */       if (((ICPacketCloseWindow)event.getPacket()).getWindowID() == mc.player.inventoryContainer.windowId)
/* 32 */         event.setCanceled(true); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\misc\XCarryModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
