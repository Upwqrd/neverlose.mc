//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoWeatherModule
/*    */   extends Module
/*    */ {
/*    */   public static NoWeatherModule INSTANCE;
/*    */   
/*    */   public NoWeatherModule() {
/* 18 */     super("NoWeather", Category.VISUAL, "Allows you to change the weather");
/* 19 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public static Setting<Weather> weather = (new Setting("Weather", Weather.CLEAR))
/* 25 */     .setDescription("Sets the world's weather");
/*    */   
/* 27 */   public static Setting<Double> time = (new Setting("Time", Double.valueOf(0.0D), Double.valueOf(6000.0D), Double.valueOf(24000.0D), 0))
/* 28 */     .setDescription("Sets the world's time");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 34 */     mc.world.setRainStrength(((Weather)weather.getValue()).getWeatherID());
/*    */ 
/*    */     
/* 37 */     mc.world.setWorldTime(((Double)time.getValue()).longValue());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 44 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate)
/*    */     {
/*    */       
/* 47 */       event.setCanceled(true);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Weather
/*    */   {
/* 56 */     CLEAR(0),
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     RAIN(1),
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 66 */     THUNDER(2);
/*    */     
/*    */     private final int id;
/*    */ 
/*    */     
/*    */     Weather(int id) {
/* 72 */       this.id = id;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public int getWeatherID() {
/* 80 */       return this.id;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\NoWeatherModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
