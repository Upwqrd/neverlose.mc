//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.events.render.gui.tooltip.RenderTooltipEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.item.ItemMap;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.storage.MapData;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TooltipsModule
/*     */   extends Module
/*     */ {
/*     */   public static TooltipsModule INSTANCE;
/*     */   
/*     */   public TooltipsModule() {
/*  30 */     super("Tooltips", Category.VISUAL, "Displays detailed tooltips");
/*  31 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  36 */   public static Setting<Boolean> shulkers = (new Setting("Shulkers", Boolean.valueOf(true)))
/*  37 */     .setDescription("Renders detailed tooltip for shulkers");
/*     */   
/*  39 */   public static Setting<Boolean> maps = (new Setting("Maps", Boolean.valueOf(true)))
/*  40 */     .setDescription("Renders detailed tooltip for maps");
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderTooltip(RenderTooltipEvent event) {
/*  46 */     if (!event.getItemStack().isEmpty()) {
/*     */ 
/*     */       
/*  49 */       if (event.getItemStack().getTagCompound() != null && event.getItemStack().getTagCompound().hasKey("BlockEntityTag", 10) && 
/*  50 */         event.getItemStack().getTagCompound().getCompoundTag("BlockEntityTag").hasKey("Items", 9))
/*     */       {
/*     */         
/*  53 */         if (((Boolean)shulkers.getValue()).booleanValue()) {
/*     */ 
/*     */           
/*  56 */           event.setCanceled(true);
/*     */ 
/*     */           
/*  59 */           NonNullList<ItemStack> itemList = NonNullList.withSize(27, ItemStack.EMPTY);
/*  60 */           ItemStackHelper.loadAllItems(event.getItemStack().getTagCompound().getCompoundTag("BlockEntityTag"), itemList);
/*     */ 
/*     */           
/*  63 */           GlStateManager.enableBlend();
/*  64 */           GlStateManager.disableRescaleNormal();
/*  65 */           RenderHelper.disableStandardItemLighting();
/*  66 */           GlStateManager.disableLighting();
/*  67 */           GlStateManager.disableDepth();
/*     */ 
/*     */           
/*  70 */           RenderUtil.drawRect((event.getX() + 8), (event.getY() - 21), (event.getX() + 10), (event.getY() - 7), (new Color(23, 23, 29)).getRGB());
/*  71 */           RenderUtil.drawRect((event.getX() + 8), (event.getY() - 7), (event.getX() + 10), (event.getY() - 5), ColorUtil.getPrimaryColor());
/*  72 */           RenderUtil.drawRect((event.getX() + 8), (event.getY() - 5), (event.getX() + 10), (event.getY() + 5), (new Color(23, 23, 29)).getRGB());
/*     */ 
/*     */           
/*  75 */           FontUtil.drawStringWithShadow(event.getItemStack().getDisplayName(), (event.getX() + 10), (event.getY() - 18), -1);
/*     */ 
/*     */           
/*  78 */           (mc.getRenderItem()).zLevel = 300.0F;
/*  79 */           GlStateManager.enableBlend();
/*  80 */           GlStateManager.enableAlpha();
/*  81 */           GlStateManager.enableTexture2D();
/*  82 */           GlStateManager.enableLighting();
/*  83 */           GlStateManager.enableDepth();
/*  84 */           RenderHelper.enableGUIStandardItemLighting();
/*     */ 
/*     */           
/*  87 */           for (int i = 0; i < itemList.size(); i++) {
/*     */ 
/*     */             
/*  90 */             mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)itemList.get(i), event.getX() + i % 9 * 16 + 11, event.getY() + i / 9 * 16 - 11 + 8);
/*  91 */             mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, (ItemStack)itemList.get(i), event.getX() + i % 9 * 16 + 11, event.getY() + i / 9 * 16 - 11 + 8, null);
/*     */           } 
/*     */ 
/*     */           
/*  95 */           RenderHelper.disableStandardItemLighting();
/*  96 */           (mc.getRenderItem()).zLevel = 0.0F;
/*  97 */           GlStateManager.enableLighting();
/*  98 */           GlStateManager.enableDepth();
/*  99 */           RenderHelper.enableStandardItemLighting();
/* 100 */           GlStateManager.enableRescaleNormal();
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 106 */       if (event.getItemStack().getItem() instanceof ItemMap) {
/*     */ 
/*     */         
/* 109 */         MapData mapData = ((ItemMap)event.getItemStack().getItem()).getMapData(event.getItemStack(), (World)mc.world);
/*     */ 
/*     */         
/* 112 */         if (mapData != null)
/*     */         {
/*     */           
/* 115 */           if (((Boolean)maps.getValue()).booleanValue()) {
/*     */ 
/*     */             
/* 118 */             event.setCanceled(true);
/*     */ 
/*     */             
/* 121 */             RenderUtil.drawRect((event.getX() + 6), (event.getY() - 3), event.getX() + 89.6F, (event.getY() + 4), (new Color(23, 23, 29)).getRGB());
/* 122 */             RenderUtil.drawRect((event.getX() + 6), (event.getY() + 4), event.getX() + 89.6F, (event.getY() + 6), ColorUtil.getPrimaryColor());
/*     */ 
/*     */             
/* 125 */             GlStateManager.pushMatrix();
/* 126 */             GlStateManager.disableDepth();
/*     */ 
/*     */             
/* 129 */             GlStateManager.translate((event.getX() + 6), (event.getY() + 6), 0.0F);
/* 130 */             GlStateManager.scale(0.7F, 0.7F, 0.0F);
/* 131 */             GL11.glDepthRange(0.0D, 0.01D);
/* 132 */             mc.entityRenderer.getMapItemRenderer().renderMap(mapData, false);
/* 133 */             GL11.glDepthRange(0.0D, 1.0D);
/*     */ 
/*     */             
/* 136 */             GlStateManager.enableDepth();
/* 137 */             GlStateManager.popMatrix();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\TooltipsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
