//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.HoleManager;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HoleESPModule
/*     */   extends Module
/*     */ {
/*     */   public static HoleESPModule INSTANCE;
/*     */   
/*     */   public HoleESPModule() {
/*  23 */     super("HoleESP", Category.VISUAL, "Highlights nearby safe holes");
/*  24 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  29 */   public static Setting<Double> range = (new Setting("Range", Double.valueOf(0.0D), Double.valueOf(5.0D), Double.valueOf(20.0D), 0)).setDescription("Range to scan for holes");
/*     */ 
/*     */ 
/*     */   
/*  33 */   public static Setting<RenderBuilder.Box> main = (new Setting("Main", RenderBuilder.Box.FILL))
/*  34 */     .setDescription("Visual style for the main render")
/*  35 */     .setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.OUTLINE, RenderBuilder.Box.CLAW, RenderBuilder.Box.BOTH });
/*     */   
/*  37 */   public static Setting<Double> mainHeight = (new Setting("MainHeight", Double.valueOf(-1.0D), Double.valueOf(0.1D), Double.valueOf(3.0D), 1))
/*  38 */     .setDescription("Height of the main render");
/*     */   
/*  40 */   public static Setting<Double> mainWidth = (new Setting("MainWidth", Double.valueOf(0.0D), Double.valueOf(1.5D), Double.valueOf(3.0D), 1))
/*  41 */     .setDescription("Line width of the main render")
/*  42 */     .setVisible(() -> Boolean.valueOf((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.BOTH) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.CLAW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.OUTLINE))));
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static Setting<RenderBuilder.Box> outline = (new Setting("Outline", RenderBuilder.Box.OUTLINE))
/*  47 */     .setDescription("Visual style for the outline render")
/*  48 */     .setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE, RenderBuilder.Box.FILL, RenderBuilder.Box.BOTH });
/*     */   
/*  50 */   public static Setting<Double> outlineHeight = (new Setting("OutlineHeight", Double.valueOf(-1.0D), Double.valueOf(0.1D), Double.valueOf(3.0D), 1))
/*  51 */     .setDescription("Height of the outline render");
/*     */   
/*  53 */   public static Setting<Double> outlineWidth = (new Setting("OutlineWidth", Double.valueOf(0.0D), Double.valueOf(1.5D), Double.valueOf(3.0D), 1))
/*  54 */     .setDescription("Line width of the outline render")
/*  55 */     .setVisible(() -> Boolean.valueOf((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.BOTH) || ((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.CLAW) || ((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.OUTLINE))));
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static Setting<Boolean> depth = (new Setting("Depth", Boolean.valueOf(true)))
/*  60 */     .setDescription("Enables vanilla depth");
/*     */ 
/*     */   
/*  63 */   public static Setting<Boolean> doubles = (new Setting("Doubles", Boolean.valueOf(true)))
/*  64 */     .setDescription("Considers double holes as safe holes");
/*     */   
/*  66 */   public static Setting<Boolean> quads = (new Setting("Quads", Boolean.valueOf(true)))
/*  67 */     .setDescription("Considers quad holes as safe holes");
/*     */   
/*  69 */   public static Setting<Boolean> voids = (new Setting("Void", Boolean.valueOf(false)))
/*  70 */     .setDescription("Highlights void and roof holes");
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static Setting<Boolean> colorSync = (new Setting("ColorSync", Boolean.valueOf(true)))
/*  75 */     .setDescription("Syncs holes colors to client colors");
/*     */   
/*  77 */   public static Setting<Color> obsidianColor = (new Setting("ObsidianColor", new Color(184, 40, 40, 45)))
/*  78 */     .setDescription("Color of the obsidian holes");
/*     */   
/*  80 */   public static Setting<Color> mixedColor = (new Setting("MixedColor", new Color(203, 203, 42, 45)))
/*  81 */     .setDescription("Color of the mixed holes");
/*     */   
/*  83 */   public static Setting<Color> bedrockColor = (new Setting("BedrockColor", new Color(48, 179, 67, 45)))
/*  84 */     .setDescription("Color of the bedrock holes");
/*     */   
/*  86 */   public static Setting<Color> voidColor = (new Setting("VoidColor", new Color(98, 0, 255, 45)))
/*  87 */     .setDescription("Color of the void holes")
/*  88 */     .setVisible(() -> (Boolean)voids.getValue());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/*  94 */     getCosmos().getHoleManager().getHoles().forEach(hole -> {
/*     */           BlockPos holePosition = hole.getHole();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (mc.player.getDistance(holePosition.getX(), holePosition.getY(), holePosition.getZ()) < ((Double)range.getValue()).doubleValue()) {
/*     */             if (((Boolean)voids.getValue()).booleanValue() && hole.getType().equals(HoleManager.Type.VOID)) {
/*     */               RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).color((Color)voidColor.getValue()).box(RenderBuilder.Box.FILL).setup().line(1.5F).depth(true).blend().texture());
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             switch (hole.getType()) {
/*     */               case OBSIDIAN:
/* 126 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */                       
/* 129 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 130 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 142 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                       
/* 146 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 147 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case MIXED:
/* 161 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                       
/* 165 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 166 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 178 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                       
/* 182 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 183 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case BEDROCK:
/* 197 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                       
/* 201 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 202 */                       (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 214 */                 RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                       
/* 218 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 219 */                       (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (((Boolean)doubles.getValue()).booleanValue()) {
/*     */               switch (hole.getType()) {
/*     */                 case DOUBLE_OBSIDIAN_X:
/* 238 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 242 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 243 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 255 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 259 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 260 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case DOUBLE_MIXED_X:
/* 274 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 278 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 279 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 291 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 295 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 296 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case DOUBLE_BEDROCK_X:
/* 310 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 314 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 315 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 327 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(0.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 331 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 332 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case DOUBLE_OBSIDIAN_Z:
/* 346 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 350 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 351 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 363 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 367 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 368 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case DOUBLE_MIXED_Z:
/* 382 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 386 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 387 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 399 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 403 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 404 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case DOUBLE_BEDROCK_Z:
/* 418 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 422 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 423 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 435 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(0.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 439 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 440 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/*     */             if (((Boolean)quads.getValue()).booleanValue())
/*     */               switch (hole.getType()) {
/*     */                 case QUAD_OBSIDIAN:
/* 460 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 464 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 465 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 477 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)obsidianColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 481 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 482 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case QUAD_BEDROCK:
/* 496 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 500 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 501 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 513 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)bedrockColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 517 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 518 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case QUAD_MIXED:
/* 532 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)mainHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)main.getValue()).setup().line(((Double)mainWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 536 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 537 */                         (((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 549 */                   RenderUtil.drawBox((new RenderBuilder()).position(hole.getHole()).height(((Double)outlineHeight.getValue()).doubleValue() - 1.0D).length(1.0D).width(1.0D).color(((Boolean)colorSync.getValue()).booleanValue() ? ColorUtil.getPrimaryAlphaColor(45) : (Color)mixedColor.getValue()).box((RenderBuilder.Box)outline.getValue()).setup().line(((Double)outlineWidth.getValue()).floatValue()).cull((((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).shade(
/*     */ 
/*     */ 
/*     */                         
/* 553 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).alpha(
/* 554 */                         (((RenderBuilder.Box)outline.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)main.getValue()).equals(RenderBuilder.Box.REVERSE))).depth(((Boolean)depth.getValue()).booleanValue()).blend().texture());
/*     */                   break;
/*     */               }  
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\HoleESPModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
