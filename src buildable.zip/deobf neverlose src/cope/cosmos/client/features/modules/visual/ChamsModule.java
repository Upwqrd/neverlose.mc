//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.events.render.entity.RenderCrystalEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderLivingEntityEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChamsModule
/*     */   extends Module
/*     */ {
/*     */   public static ChamsModule INSTANCE;
/*     */   
/*     */   public ChamsModule() {
/*  32 */     super("Chams", Category.VISUAL, "Renders entity models through walls");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.GLINT_TEXTURE = new ResourceLocation("textures/misc/enchanted_item_glint.png");
/*     */     INSTANCE = this;
/*     */   } public static Setting<Mode> mode = (new Setting("Mode", Mode.MODEL)).setDescription("Mode for Chams"); public static Setting<Boolean> players = (new Setting("Players", Boolean.valueOf(true))).setDescription("Renders chams on players"); public static Setting<Boolean> local = (new Setting("Local", Boolean.valueOf(false))).setDescription("Renders chams on the local player").setVisible(() -> (Boolean)players.getValue()); public static Setting<Boolean> mobs = (new Setting("Mobs", Boolean.valueOf(true))).setDescription("Renders chams on mobs"); public static Setting<Boolean> monsters = (new Setting("Monsters", Boolean.valueOf(true))).setDescription("Renders chams on monsters"); public static Setting<Boolean> crystals = (new Setting("Crystals", Boolean.valueOf(true))).setDescription("Renders chams on crystals"); public static Setting<Double> scale = (new Setting("CrystalScale", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(2.0D), 2)).setDescription("Scale for crystal model").setVisible(() -> (Boolean)crystals.getValue()); @SubscribeEvent
/*     */   public void onRenderLivingEntityPre(RenderLivingEntityEvent.RenderLivingEntityPreEvent event) {
/*  91 */     if (hasChams(event.getEntityLivingBase())) {
/*     */ 
/*     */       
/*  94 */       if (((Boolean)transparent.getValue()).booleanValue()) {
/*  95 */         GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*     */       }
/*     */ 
/*     */       
/*  99 */       if (!((Boolean)texture.getValue()).booleanValue())
/* 100 */         event.setCanceled(true); 
/*     */     } 
/*     */   }
/*     */   public static Setting<Double> width = (new Setting("Width", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(5.0D), 2)).setDescription("Line width for the model").setVisible(() -> Boolean.valueOf((((Mode)mode.getValue()).equals(Mode.WIRE) || ((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)))); public static Setting<Boolean> texture = (new Setting("Texture", Boolean.valueOf(false))).setDescription("Enables entity texture"); public static Setting<Boolean> transparent = (new Setting("Transparent", Boolean.valueOf(true))).setDescription("Makes entity models transparent").setVisible(() -> (Boolean)texture.getValue()); public static Setting<Boolean> shine = (new Setting("Shine", Boolean.valueOf(false))).setDescription("Adds the enchantment glint effect to the model").setVisible(() -> Boolean.valueOf(!((Mode)mode.getValue()).equals(Mode.WIRE))); public static Setting<Boolean> lighting = (new Setting("Lighting", Boolean.valueOf(true))).setDescription("Disables vanilla lighting"); public static Setting<Boolean> walls = (new Setting("Walls", Boolean.valueOf(true))).setDescription("Renders chams models through walls"); private final ResourceLocation GLINT_TEXTURE;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderLivingEntityPost(RenderLivingEntityEvent.RenderLivingEntityPostEvent event) {
/* 107 */     if (hasChams(event.getEntityLivingBase())) {
/*     */       
/* 109 */       GL11.glPushMatrix();
/* 110 */       GL11.glPushAttrib(1048575);
/*     */ 
/*     */       
/* 113 */       GL11.glDisable(3553);
/* 114 */       GL11.glEnable(3042);
/*     */ 
/*     */       
/* 117 */       if (((Boolean)lighting.getValue()).booleanValue()) {
/* 118 */         GL11.glDisable(2896);
/*     */       }
/*     */ 
/*     */       
/* 122 */       if (((Boolean)walls.getValue()).booleanValue()) {
/* 123 */         GL11.glDisable(2929);
/*     */       }
/*     */ 
/*     */       
/* 127 */       switch ((Mode)mode.getValue()) {
/*     */         case WIRE:
/* 129 */           GL11.glPolygonMode(1032, 6913);
/*     */           break;
/*     */         case WIRE_MODEL:
/*     */         case MODEL:
/* 133 */           GL11.glPolygonMode(1032, 6914);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 138 */       GL11.glEnable(2848);
/* 139 */       GL11.glHint(3154, 4354);
/* 140 */       GL11.glLineWidth(((Double)width.getValue()).floatValue());
/*     */ 
/*     */       
/* 143 */       GL11.glColor4d((getColor((Entity)event.getEntityLivingBase()).getRed() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getGreen() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getBlue() / 255.0F), ((Mode)mode.getValue()).equals(Mode.WIRE) ? 1.0D : 0.2D);
/*     */ 
/*     */       
/* 146 */       if (((Boolean)shine.getValue()).booleanValue() && !((Mode)mode.getValue()).equals(Mode.WIRE)) {
/* 147 */         GL11.glEnable(3553);
/* 148 */         GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_COLOR, GlStateManager.DestFactor.ONE);
/*     */ 
/*     */         
/* 151 */         for (float i = 0.0F; i < 2.0F; i++) {
/*     */ 
/*     */           
/* 154 */           (mc.getRenderManager()).renderEngine.bindTexture(this.GLINT_TEXTURE);
/*     */ 
/*     */           
/* 157 */           GlStateManager.matrixMode(5890);
/* 158 */           GlStateManager.loadIdentity();
/* 159 */           float textureScale = 0.33333334F;
/*     */ 
/*     */           
/* 162 */           GlStateManager.scale(textureScale, textureScale, textureScale);
/* 163 */           GlStateManager.rotate(30.0F - i * 60.0F, 0.0F, 0.0F, 1.0F);
/* 164 */           GlStateManager.translate(0.0F, ((event.getEntityLivingBase()).ticksExisted + mc.getRenderPartialTicks()) * (0.001F + i * 0.003F) * 4.0F, 0.0F);
/* 165 */           GlStateManager.matrixMode(5888);
/* 166 */           GL11.glTranslatef(0.0F, 0.0F, 0.0F);
/*     */ 
/*     */           
/* 169 */           event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */ 
/*     */           
/* 172 */           GlStateManager.matrixMode(5890);
/* 173 */           GlStateManager.loadIdentity();
/* 174 */           GlStateManager.matrixMode(5888);
/*     */         } 
/*     */         
/* 177 */         GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 178 */         GL11.glDisable(3553);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 184 */         event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */       } 
/*     */ 
/*     */       
/* 188 */       if (((Boolean)walls.getValue()).booleanValue() && !((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) {
/* 189 */         GL11.glEnable(2929);
/*     */       }
/*     */ 
/*     */       
/* 193 */       if (((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) {
/* 194 */         GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */         
/* 197 */         GL11.glColor4d((getColor((Entity)event.getEntityLivingBase()).getRed() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getGreen() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getBlue() / 255.0F), (((Mode)mode.getValue()).equals(Mode.WIRE) || ((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) ? 1.0D : 0.2D);
/*     */ 
/*     */         
/* 200 */         event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */ 
/*     */         
/* 203 */         if (((Boolean)walls.getValue()).booleanValue()) {
/* 204 */           GL11.glEnable(2929);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 209 */       if (((Boolean)lighting.getValue()).booleanValue()) {
/* 210 */         GL11.glEnable(2896);
/*     */       }
/*     */ 
/*     */       
/* 214 */       GL11.glDisable(3042);
/* 215 */       GL11.glEnable(3553);
/*     */       
/* 217 */       GL11.glPopAttrib();
/* 218 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderCrystalPre(RenderCrystalEvent.RenderCrystalPreEvent event) {
/* 226 */     if (((Boolean)transparent.getValue()).booleanValue()) {
/* 227 */       GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*     */     }
/*     */ 
/*     */     
/* 231 */     if (!((Boolean)texture.getValue()).booleanValue()) {
/* 232 */       event.setCanceled(((Boolean)crystals.getValue()).booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderCrystalPost(RenderCrystalEvent.RenderCrystalPostEvent event) {
/* 238 */     if (((Boolean)crystals.getValue()).booleanValue()) {
/*     */       
/* 240 */       GL11.glPushMatrix();
/* 241 */       GL11.glPushAttrib(1048575);
/*     */ 
/*     */       
/* 244 */       float rotation = (event.getEntityEnderCrystal()).innerRotation + event.getPartialTicks();
/* 245 */       float rotationMoved = MathHelper.sin(rotation * 0.2F) / 2.0F + 0.5F;
/* 246 */       rotationMoved = (float)(rotationMoved + StrictMath.pow(rotationMoved, 2.0D));
/*     */ 
/*     */       
/* 249 */       GL11.glTranslated(event.getX(), event.getY(), event.getZ());
/* 250 */       GL11.glScaled(((Double)scale.getValue()).doubleValue(), ((Double)scale.getValue()).doubleValue(), ((Double)scale.getValue()).doubleValue());
/*     */ 
/*     */       
/* 253 */       GL11.glDisable(3553);
/* 254 */       GL11.glEnable(3042);
/*     */ 
/*     */       
/* 257 */       if (((Boolean)lighting.getValue()).booleanValue()) {
/* 258 */         GL11.glDisable(2896);
/*     */       }
/*     */ 
/*     */       
/* 262 */       if (((Boolean)walls.getValue()).booleanValue()) {
/* 263 */         GL11.glDisable(2929);
/*     */       }
/*     */ 
/*     */       
/* 267 */       switch ((Mode)mode.getValue()) {
/*     */         case WIRE:
/* 269 */           GL11.glPolygonMode(1032, 6913);
/*     */           break;
/*     */         case WIRE_MODEL:
/*     */         case MODEL:
/* 273 */           GL11.glPolygonMode(1032, 6914);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 278 */       GL11.glEnable(2848);
/* 279 */       GL11.glHint(3154, 4354);
/* 280 */       GL11.glLineWidth(((Double)width.getValue()).floatValue());
/*     */ 
/*     */       
/* 283 */       GL11.glColor4d((getColor((Entity)event.getEntityEnderCrystal()).getRed() / 255.0F), (getColor((Entity)event.getEntityEnderCrystal()).getGreen() / 255.0F), (getColor((Entity)event.getEntityEnderCrystal()).getBlue() / 255.0F), ((Mode)mode.getValue()).equals(Mode.WIRE) ? 1.0D : 0.2D);
/*     */ 
/*     */       
/* 286 */       if (((Boolean)shine.getValue()).booleanValue() && !((Mode)mode.getValue()).equals(Mode.WIRE)) {
/* 287 */         GL11.glEnable(3553);
/* 288 */         GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_COLOR, GlStateManager.DestFactor.ONE);
/*     */ 
/*     */         
/* 291 */         for (int i = 0; i < 2; i++) {
/*     */ 
/*     */           
/* 294 */           (mc.getRenderManager()).renderEngine.bindTexture(this.GLINT_TEXTURE);
/*     */ 
/*     */           
/* 297 */           GlStateManager.matrixMode(5890);
/* 298 */           GlStateManager.loadIdentity();
/* 299 */           float textureScale = 0.33333334F;
/* 300 */           GlStateManager.scale(textureScale, textureScale, textureScale);
/* 301 */           GlStateManager.rotate((30 - i * 60), 0.0F, 0.0F, 1.0F);
/* 302 */           GlStateManager.translate(0.0F, ((event.getEntityEnderCrystal()).ticksExisted + mc.getRenderPartialTicks()) * (0.001F + i * 0.003F) * 4.0F, 0.0F);
/* 303 */           GlStateManager.matrixMode(5888);
/* 304 */           GL11.glTranslatef(0.0F, 0.0F, 0.0F);
/*     */ 
/*     */           
/* 307 */           if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 308 */             event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */           }
/*     */           else {
/*     */             
/* 312 */             event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */           } 
/*     */ 
/*     */           
/* 316 */           GlStateManager.matrixMode(5890);
/* 317 */           GlStateManager.loadIdentity();
/* 318 */           GlStateManager.matrixMode(5888);
/*     */         } 
/*     */         
/* 321 */         GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 322 */         GL11.glDisable(3553);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 328 */       else if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 329 */         event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       }
/*     */       else {
/*     */         
/* 333 */         event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 338 */       if (((Boolean)walls.getValue()).booleanValue() && !((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) {
/* 339 */         GL11.glEnable(2929);
/*     */       }
/*     */ 
/*     */       
/* 343 */       if (((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) {
/* 344 */         GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */         
/* 347 */         GL11.glColor4d((getColor((Entity)event.getEntityEnderCrystal()).getRed() / 255.0F), (getColor((Entity)event.getEntityEnderCrystal()).getGreen() / 255.0F), (getColor((Entity)event.getEntityEnderCrystal()).getBlue() / 255.0F), (((Mode)mode.getValue()).equals(Mode.WIRE) || ((Mode)mode.getValue()).equals(Mode.WIRE_MODEL)) ? 1.0D : 0.2D);
/*     */ 
/*     */         
/* 350 */         if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 351 */           event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */         }
/*     */         else {
/*     */           
/* 355 */           event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */         } 
/*     */ 
/*     */         
/* 359 */         if (((Boolean)walls.getValue()).booleanValue()) {
/* 360 */           GL11.glEnable(2929);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 365 */       if (((Boolean)lighting.getValue()).booleanValue()) {
/* 366 */         GL11.glEnable(2896);
/*     */       }
/*     */ 
/*     */       
/* 370 */       GL11.glDisable(3042);
/* 371 */       GL11.glEnable(3553);
/*     */ 
/*     */       
/* 374 */       GL11.glScaled(1.0D / ((Double)scale.getValue()).doubleValue(), 1.0D / ((Double)scale.getValue()).doubleValue(), 1.0D / ((Double)scale.getValue()).doubleValue());
/*     */       
/* 376 */       GL11.glPopAttrib();
/* 377 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(Entity in) {
/* 387 */     return getCosmos().getSocialManager().getSocial(in.getName()).equals(SocialManager.Relationship.FRIEND) ? Color.CYAN : ColorUtil.getPrimaryColor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChams(EntityLivingBase entity) {
/* 396 */     return ((entity instanceof net.minecraft.client.entity.EntityOtherPlayerMP && ((Boolean)players.getValue()).booleanValue()) || (entity instanceof net.minecraft.client.entity.EntityPlayerSP && ((Boolean)local.getValue()).booleanValue()) || ((EntityUtil.isPassiveMob((Entity)entity) || EntityUtil.isNeutralMob((Entity)entity)) && ((Boolean)mobs.getValue()).booleanValue()) || (EntityUtil.isHostileMob((Entity)entity) && ((Boolean)monsters.getValue()).booleanValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 404 */     MODEL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 409 */     WIRE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 414 */     WIRE_MODEL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\ChamsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
