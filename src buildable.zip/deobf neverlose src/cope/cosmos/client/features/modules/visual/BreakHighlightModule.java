//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.IRenderGlobal;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.render.RenderBuilder;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import cope.cosmos.util.world.BlockUtil;
/*    */ import net.minecraft.client.renderer.DestroyBlockProgress;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class BreakHighlightModule
/*    */   extends Module
/*    */ {
/*    */   public static BreakHighlightModule INSTANCE;
/*    */   
/*    */   public BreakHighlightModule() {
/* 26 */     super("BreakHighlight", Category.VISUAL, "Highlights blocks that are being broken");
/* 27 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 32 */   public static Setting<RenderBuilder.Box> renderMode = (new Setting("RenderMode", RenderBuilder.Box.BOTH))
/* 33 */     .setDescription("How to render the highlight")
/* 34 */     .setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE, RenderBuilder.Box.NONE });
/*    */   
/* 36 */   public static Setting<Float> lineWidth = (new Setting("Width", Float.valueOf(0.1F), Float.valueOf(1.0F), Float.valueOf(3.0F), 1))
/* 37 */     .setDescription("The width of the outline")
/* 38 */     .setVisible(() -> Boolean.valueOf(!((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.FILL)));
/*    */   
/* 40 */   public static Setting<Boolean> percent = (new Setting("Percent", Boolean.valueOf(false)))
/* 41 */     .setDescription("Show the percentage the block has been broken by");
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static Setting<Float> range = (new Setting("Range", Float.valueOf(1.0F), Float.valueOf(20.0F), Float.valueOf(50.0F), 1))
/* 46 */     .setDescription("The maximum distance a highlighted block can be");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRender3D() {
/* 52 */     ((IRenderGlobal)mc.renderGlobal).getDamagedBlocks().forEach((pos, progress) -> {
/*    */           if (progress != null) {
/*    */             BlockPos position = progress.getPosition();
/*    */             if (mc.world.getBlockState(position).getBlock().equals(Blocks.AIR))
/*    */               return; 
/*    */             if (BlockUtil.getDistanceToCenter((EntityPlayer)mc.player, position) <= ((Float)range.getValue()).floatValue()) {
/*    */               int damage = MathHelper.clamp(progress.getPartialBlockDamage(), 0, 8);
/*    */               AxisAlignedBB bb = mc.world.getBlockState(position).getSelectedBoundingBox((World)mc.world, position);
/*    */               double x = bb.minX + (bb.maxX - bb.minX) / 2.0D;
/*    */               double y = bb.minY + (bb.maxY - bb.minY) / 2.0D;
/*    */               double z = bb.minZ + (bb.maxZ - bb.minZ) / 2.0D;
/*    */               double sizeX = damage * (bb.maxX - x) / 8.0D;
/*    */               double sizeY = damage * (bb.maxY - y) / 8.0D;
/*    */               double sizeZ = damage * (bb.maxZ - z) / 8.0D;
/*    */               RenderUtil.drawBox((new RenderBuilder()).position(new AxisAlignedBB(x - sizeX, y - sizeY, z - sizeZ, x + sizeX, y + sizeY, z + sizeZ)).color(ColorUtil.getPrimaryAlphaColor(120)).box((RenderBuilder.Box)renderMode.getValue()).setup().line(((Float)lineWidth.getValue()).floatValue()).depth(true).blend().texture());
/*    */               if (((Boolean)percent.getValue()).booleanValue())
/*    */                 RenderUtil.drawNametag(position, 0.5F, (damage * 100 / 8) + "%"); 
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\BreakHighlightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
