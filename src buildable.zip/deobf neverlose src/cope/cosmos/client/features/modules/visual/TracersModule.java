//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.entity.InterpolationUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TracersModule
/*     */   extends Module
/*     */ {
/*     */   public static TracersModule INSTANCE;
/*     */   
/*     */   public TracersModule() {
/*  24 */     super("Tracers", Category.VISUAL, "Draws lines to entities in the world");
/*  25 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  30 */   public static Setting<Boolean> players = (new Setting("Players", Boolean.valueOf(true)))
/*  31 */     .setDescription("Draw lines to players");
/*     */   
/*  33 */   public static Setting<Boolean> passive = (new Setting("Passive", Boolean.valueOf(false)))
/*  34 */     .setDescription("Draw lines to passive entities");
/*     */   
/*  36 */   public static Setting<Boolean> neutrals = (new Setting("Neutrals", Boolean.valueOf(false)))
/*  37 */     .setDescription("Draw lines to neutral entities");
/*     */   
/*  39 */   public static Setting<Boolean> mobs = (new Setting("Mobs", Boolean.valueOf(false)))
/*  40 */     .setDescription("Draw lines to monsters");
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static Setting<Float> width = (new Setting("Width", Float.valueOf(0.1F), Float.valueOf(1.0F), Float.valueOf(1.5F), 1))
/*  45 */     .setDescription("How thick to render the lines");
/*     */   
/*  47 */   public static Setting<To> to = (new Setting("To", To.BODY))
/*  48 */     .setDescription("Where to draw the line to");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/*  54 */     mc.world.loadedEntityList.forEach(entity -> {
/*     */           if (isEntityValid(entity)) {
/*     */             Vec3d interpolatedPosition = InterpolationUtil.getInterpolatedPosition(entity, mc.getRenderPartialTicks());
/*     */             float addedHeight = 0.0F;
/*     */             switch ((To)to.getValue()) {
/*     */               case BODY:
/*     */                 addedHeight = entity.height / 2.0F;
/*     */                 break;
/*     */               case HEAD:
/*     */                 addedHeight = entity.height;
/*     */                 break;
/*     */             } 
/*     */             Vec3d entityVector = new Vec3d(interpolatedPosition.x - (mc.getRenderManager()).viewerPosX, interpolatedPosition.y - (mc.getRenderManager()).viewerPosY + addedHeight, interpolatedPosition.z - (mc.getRenderManager()).viewerPosZ);
/*     */             drawTracer(entityVector, ((Float)width.getValue()).floatValue(), ColorUtil.getPrimaryColor());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawTracer(Vec3d vecTo, float lineWidth, Color lineColor) {
/*  94 */     Vec3d eyes = (new Vec3d(0.0D, 0.0D, 1.0D)).rotatePitch(-((float)Math.toRadians(mc.player.rotationPitch))).rotateYaw(-((float)Math.toRadians(mc.player.rotationYaw))).add(0.0D, mc.player.getEyeHeight(), 0.0D);
/*     */ 
/*     */     
/*  97 */     RenderUtil.drawLine3D(eyes, vecTo, lineColor, lineWidth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEntityValid(Entity entity) {
/* 106 */     return ((entity instanceof net.minecraft.client.entity.EntityOtherPlayerMP && ((Boolean)players.getValue()).booleanValue()) || (EntityUtil.isPassiveMob(entity) && ((Boolean)passive.getValue()).booleanValue()) || (EntityUtil.isNeutralMob(entity) && ((Boolean)neutrals.getValue()).booleanValue()) || (EntityUtil.isHostileMob(entity) && ((Boolean)mobs.getValue()).booleanValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum To
/*     */   {
/* 114 */     FEET,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     BODY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     HEAD;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\TracersModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
