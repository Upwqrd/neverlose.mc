/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.events.render.other.CameraClipEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CameraClipModule
/*    */   extends Module
/*    */ {
/*    */   public static CameraClipModule INSTANCE;
/*    */   
/*    */   public CameraClipModule() {
/* 17 */     super("CameraClip", Category.VISUAL, "Clips your third person camera through blocks");
/* 18 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 23 */   public static Setting<Double> distance = (new Setting("Distance", Double.valueOf(1.0D), Double.valueOf(5.0D), Double.valueOf(20.0D), 0))
/* 24 */     .setDescription("How many blocks the camera should clip through");
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onCameraClip(CameraClipEvent event) {
/* 30 */     event.setDistance(((Double)distance.getValue()).doubleValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\CameraClipModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */