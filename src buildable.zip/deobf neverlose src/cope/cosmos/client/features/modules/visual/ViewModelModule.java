//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.events.render.player.RenderHeldItemEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class ViewModelModule
/*     */   extends Module
/*     */ {
/*     */   public static ViewModelModule INSTANCE;
/*     */   
/*     */   public ViewModelModule() {
/*  18 */     super("ViewModel", Category.VISUAL, "Changes how items are rendered in first person");
/*  19 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  26 */   public static Setting<Double> leftX = (new Setting("LeftX", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  27 */     .setDescription("The X position of the left item");
/*     */   
/*  29 */   public static Setting<Double> leftY = (new Setting("LeftY", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  30 */     .setDescription("The Y position of the left item");
/*     */   
/*  32 */   public static Setting<Double> leftZ = (new Setting("LeftZ", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  33 */     .setDescription("The Z position of the left item");
/*     */   
/*  35 */   public static Setting<Float> leftYaw = (new Setting("LeftYaw", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  36 */     .setDescription("The yaw rotation of the left item");
/*     */   
/*  38 */   public static Setting<Float> leftPitch = (new Setting("LeftPitch", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  39 */     .setDescription("The pitch rotation of the left item");
/*     */   
/*  41 */   public static Setting<Float> leftRoll = (new Setting("LeftRoll", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  42 */     .setDescription("The roll rotation of the left item");
/*     */   
/*  44 */   public static Setting<Float> leftScale = (new Setting("LeftScale", Float.valueOf(0.0F), Float.valueOf(1.0F), Float.valueOf(2.0F), 1))
/*  45 */     .setDescription("The scale of the left item");
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static Setting<Double> rightX = (new Setting("RightX", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  50 */     .setDescription("The X position of the right item");
/*     */   
/*  52 */   public static Setting<Double> rightY = (new Setting("RightY", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  53 */     .setDescription("The Y position of the right item");
/*     */   
/*  55 */   public static Setting<Double> rightZ = (new Setting("RightZ", Double.valueOf(-2.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/*  56 */     .setDescription("The Z position of the right item");
/*     */   
/*  58 */   public static Setting<Float> rightYaw = (new Setting("RightYaw", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  59 */     .setDescription("The yaw rotation of the right item");
/*     */   
/*  61 */   public static Setting<Float> rightPitch = (new Setting("RightPitch", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  62 */     .setDescription("The pitch rotation of the right item");
/*     */   
/*  64 */   public static Setting<Float> rightRoll = (new Setting("RightRoll", Float.valueOf(-180.0F), Float.valueOf(0.0F), Float.valueOf(180.0F), 1))
/*  65 */     .setDescription("The roll rotation of the right item");
/*     */   
/*  67 */   public static Setting<Float> rightScale = (new Setting("RightScale", Float.valueOf(0.0F), Float.valueOf(1.0F), Float.valueOf(2.0F), 1))
/*  68 */     .setDescription("The scale of the right item");
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderItemPre(RenderHeldItemEvent.Pre event) {
/*  74 */     switch (event.getSide()) {
/*     */       case LEFT:
/*  76 */         GlStateManager.translate(((Double)leftX.getValue()).doubleValue(), ((Double)leftY.getValue()).doubleValue(), ((Double)leftZ.getValue()).doubleValue());
/*  77 */         GlStateManager.scale(((Float)leftScale.getValue()).floatValue(), ((Float)leftScale.getValue()).floatValue(), ((Float)leftScale.getValue()).floatValue());
/*     */         break;
/*     */       case RIGHT:
/*  80 */         GlStateManager.translate(((Double)rightX.getValue()).doubleValue(), ((Double)rightY.getValue()).doubleValue(), ((Double)rightZ.getValue()).doubleValue());
/*  81 */         GlStateManager.scale(((Float)rightScale.getValue()).floatValue(), ((Float)rightScale.getValue()).floatValue(), ((Float)rightScale.getValue()).floatValue());
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderItemPost(RenderHeldItemEvent.Post event) {
/*  90 */     switch (event.getSide()) {
/*     */       case LEFT:
/*  92 */         GlStateManager.rotate(((Float)leftYaw.getValue()).floatValue(), 0.0F, 1.0F, 0.0F);
/*  93 */         GlStateManager.rotate(((Float)leftPitch.getValue()).floatValue(), 1.0F, 0.0F, 0.0F);
/*  94 */         GlStateManager.rotate(((Float)leftRoll.getValue()).floatValue(), 0.0F, 0.0F, 1.0F);
/*     */         break;
/*     */       
/*     */       case RIGHT:
/*  98 */         GlStateManager.rotate(((Float)rightYaw.getValue()).floatValue(), 0.0F, 1.0F, 0.0F);
/*  99 */         GlStateManager.rotate(((Float)rightPitch.getValue()).floatValue(), 1.0F, 0.0F, 0.0F);
/* 100 */         GlStateManager.rotate(((Float)rightRoll.getValue()).floatValue(), 0.0F, 0.0F, 1.0F);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\ViewModelModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
