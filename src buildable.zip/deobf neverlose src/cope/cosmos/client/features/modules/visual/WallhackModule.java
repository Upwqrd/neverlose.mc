//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.common.ForgeModContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WallhackModule
/*     */   extends Module
/*     */ {
/*     */   public static WallhackModule INSTANCE;
/*     */   
/*     */   public WallhackModule() {
/*  22 */     super("Wallhack", Category.VISUAL, "Allows you to see desired blocks through walls");
/*  23 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static final List<Block> WHITELIST = new ArrayList<>();
/*  35 */   public static final List<Block> DEFAULT_BLOCKS = Lists.newArrayList((Object[])new Block[] { Blocks.OBSIDIAN, Blocks.BEDROCK, (Block)Blocks.PORTAL, Blocks.END_PORTAL, Blocks.END_PORTAL_FRAME, Blocks.COMMAND_BLOCK, Blocks.CHAIN_COMMAND_BLOCK, Blocks.REPEATING_COMMAND_BLOCK, Blocks.MOB_SPAWNER, (Block)Blocks.BEACON, Blocks.BED, Blocks.DIAMOND_ORE, Blocks.COAL_ORE, Blocks.EMERALD_ORE, Blocks.GOLD_ORE, Blocks.IRON_ORE, Blocks.LAPIS_ORE, Blocks.LIT_REDSTONE_ORE, Blocks.QUARTZ_ORE, Blocks.REDSTONE_ORE, Blocks.DIAMOND_BLOCK, Blocks.COAL_BLOCK, Blocks.EMERALD_BLOCK, Blocks.GOLD_BLOCK, Blocks.IRON_BLOCK, Blocks.LAPIS_BLOCK, Blocks.REDSTONE_BLOCK });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean forgeLightPipelineEnabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  75 */     super.onEnable();
/*     */ 
/*     */     
/*  78 */     this.forgeLightPipelineEnabled = ForgeModContainer.forgeLightPipelineEnabled;
/*  79 */     ForgeModContainer.forgeLightPipelineEnabled = false;
/*     */ 
/*     */     
/*  82 */     if (nullCheck()) {
/*  83 */       reloadRenderers();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  89 */     super.onDisable();
/*     */ 
/*     */     
/*  92 */     ForgeModContainer.forgeLightPipelineEnabled = this.forgeLightPipelineEnabled;
/*     */ 
/*     */     
/*  95 */     reloadRenderers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reloadRenderers() {
/* 119 */     mc.renderChunksMany = false;
/*     */     
/* 121 */     Vec3d pos = mc.player.getPositionVector();
/* 122 */     int dist = mc.gameSettings.renderDistanceChunks * 16;
/*     */ 
/*     */     
/* 125 */     mc.renderGlobal.markBlockRangeForRenderUpdate((int)pos.x - dist, (int)pos.y - dist, (int)pos.z - dist, (int)pos.x + dist, (int)pos.y + dist, (int)pos.z + dist);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\WallhackModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
