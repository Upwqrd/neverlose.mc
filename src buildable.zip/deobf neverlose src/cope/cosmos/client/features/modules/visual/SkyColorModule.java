/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.events.render.world.RenderFogColorEvent;
/*    */ import cope.cosmos.client.events.render.world.RenderSkyEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SkyColorModule
/*    */   extends Module
/*    */ {
/*    */   public static SkyColorModule INSTANCE;
/*    */   
/*    */   public SkyColorModule() {
/* 19 */     super("SkyColor", Category.VISUAL, "Colors the sky");
/* 20 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public static Setting<Boolean> sky = (new Setting("Sky", Boolean.valueOf(true)))
/* 26 */     .setDescription("Colors the sky");
/*    */   
/* 28 */   public static Setting<Boolean> fog = (new Setting("Fog", Boolean.valueOf(true)))
/* 29 */     .setDescription("Colors the fog");
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderSky(RenderSkyEvent event) {
/* 33 */     if (((Boolean)sky.getValue()).booleanValue()) {
/*    */ 
/*    */       
/* 36 */       event.setColor(ColorUtil.getPrimaryColor());
/* 37 */       event.setCanceled(true);
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderFogColor(RenderFogColorEvent event) {
/* 43 */     if (((Boolean)fog.getValue()).booleanValue()) {
/*    */ 
/*    */       
/* 46 */       event.setColor(ColorUtil.getPrimaryColor());
/* 47 */       event.setCanceled(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\SkyColorModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */