//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.render.RenderBuilder;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import io.netty.util.internal.ConcurrentSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.network.play.server.SPacketChunkData;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.Vec2f;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewChunksModule
/*    */   extends Module
/*    */ {
/*    */   public static NewChunksModule INSTANCE;
/*    */   
/*    */   public NewChunksModule() {
/* 27 */     super("NewChunks", Category.VISUAL, "Highlights newly generated chunks");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 47 */     this.chunks = (Set<Vec2f>)new ConcurrentSet();
/*    */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender3D() {
/* 53 */     this.chunks.forEach(chunk -> RenderUtil.drawBox((new RenderBuilder()).position(new AxisAlignedBB(chunk.x, 0.0D, chunk.y, (chunk.x + 16.0F), ((Double)height.getValue()).doubleValue(), (chunk.y + 16.0F))).color(ColorUtil.getPrimaryAlphaColor(50)).box((RenderBuilder.Box)render.getValue()).setup().line(((Double)width.getValue()).floatValue()).depth(true).blend().texture()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Setting<RenderBuilder.Box> render = (new Setting("Render", RenderBuilder.Box.OUTLINE)).setDescription("Style for the visual").setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE, RenderBuilder.Box.NONE });
/*    */ 
/*    */   
/*    */   public static Setting<Double> height = (new Setting("Height", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(3.0D), 0)).setDescription("The height to render the new chunk at");
/*    */ 
/*    */   
/*    */   public static Setting<Double> width = (new Setting("Width", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(3.0D), 1)).setDescription("Line width of the render").setVisible(() -> Boolean.valueOf((((RenderBuilder.Box)render.getValue()).equals(RenderBuilder.Box.BOTH) || ((RenderBuilder.Box)render.getValue()).equals(RenderBuilder.Box.OUTLINE) || ((RenderBuilder.Box)render.getValue()).equals(RenderBuilder.Box.CLAW))));
/*    */ 
/*    */   
/*    */   private final Set<Vec2f> chunks;
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 73 */     if (event.getPacket() instanceof SPacketChunkData)
/*    */     {
/*    */       
/* 76 */       if (!((SPacketChunkData)event.getPacket()).isFullChunk())
/*    */       {
/*    */         
/* 79 */         this.chunks.add(new Vec2f((((SPacketChunkData)event.getPacket()).getChunkX() * 16), (((SPacketChunkData)event.getPacket()).getChunkZ() * 16)));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\NewChunksModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
