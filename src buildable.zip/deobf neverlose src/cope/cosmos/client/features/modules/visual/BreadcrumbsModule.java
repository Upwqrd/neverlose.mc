//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.util.LinkedList;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BreadcrumbsModule
/*     */   extends Module
/*     */ {
/*     */   public static BreadcrumbsModule INSTANCE;
/*     */   
/*     */   public BreadcrumbsModule() {
/*  20 */     super("Breadcrumbs", Category.VISUAL, "Draws a trail behind you");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.positions = new LinkedList<>();
/*     */     INSTANCE = this;
/*     */   } public static Setting<Boolean> infinite = (new Setting("Infinite", Boolean.valueOf(false))).setDescription("Makes breadcrumbs last forever"); public static Setting<Float> lifespan = (new Setting("Lifespan", Float.valueOf(1.0F), Float.valueOf(2.0F), Float.valueOf(10.0F), 1)).setDescription("The lifespan of the positions in seconds").setVisible(() -> Boolean.valueOf(!((Boolean)infinite.getValue()).booleanValue()));
/*     */   public void onDisable() {
/*  42 */     super.onDisable();
/*     */ 
/*     */     
/*  45 */     this.positions.clear();
/*     */   }
/*     */   public static Setting<Float> width = (new Setting("Width", Float.valueOf(0.1F), Float.valueOf(2.0F), Float.valueOf(5.0F), 1)).setDescription("The width of the lines"); private final LinkedList<Position> positions;
/*     */   
/*     */   public void onTick() {
/*  50 */     if (!nullCheck() || mc.player.ticksExisted <= 20) {
/*     */ 
/*     */       
/*  53 */       this.positions.clear();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  59 */     this.positions.add(new Position(new Vec3d(mc.player.lastTickPosX, mc.player.lastTickPosY, mc.player.lastTickPosZ), System.currentTimeMillis()));
/*     */ 
/*     */     
/*  62 */     this.positions.removeIf(position -> ((float)(System.currentTimeMillis() - position.getTime()) >= ((Float)lifespan.getValue()).floatValue() * 1000.0F && !((Boolean)infinite.getValue()).booleanValue()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/*  67 */     GL11.glPushMatrix();
/*  68 */     GL11.glDisable(3553);
/*  69 */     GL11.glBlendFunc(770, 771);
/*  70 */     GL11.glEnable(2848);
/*  71 */     GL11.glEnable(3042);
/*  72 */     GL11.glDisable(2929);
/*  73 */     GL11.glLineWidth(((Float)width.getValue()).floatValue());
/*     */ 
/*     */     
/*  76 */     mc.entityRenderer.disableLightmap();
/*     */     
/*  78 */     GL11.glBegin(3);
/*     */ 
/*     */     
/*  81 */     this.positions.forEach(position -> {
/*     */           GL11.glColor4f(ColorUtil.getPrimaryColor().getRed() / 255.0F, ColorUtil.getPrimaryColor().getGreen() / 255.0F, ColorUtil.getPrimaryColor().getBlue() / 255.0F, 1.0F);
/*     */ 
/*     */ 
/*     */           
/*     */           GL11.glVertex3d((position.getVec()).x - (mc.getRenderManager()).viewerPosX, (position.getVec()).y - (mc.getRenderManager()).viewerPosY, (position.getVec()).z - (mc.getRenderManager()).viewerPosZ);
/*     */         });
/*     */ 
/*     */ 
/*     */     
/*  91 */     GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
/*     */     
/*  93 */     GL11.glEnd();
/*  94 */     GL11.glEnable(2929);
/*  95 */     GL11.glDisable(2848);
/*  96 */     GL11.glDisable(3042);
/*  97 */     GL11.glEnable(3553);
/*  98 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Position
/*     */   {
/*     */     private final Vec3d vec;
/*     */     
/*     */     private final long time;
/*     */ 
/*     */     
/*     */     public Position(Vec3d vec, long time) {
/* 110 */       this.vec = vec;
/* 111 */       this.time = time;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Vec3d getVec() {
/* 119 */       return this.vec;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long getTime() {
/* 127 */       return this.time;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\BreadcrumbsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
