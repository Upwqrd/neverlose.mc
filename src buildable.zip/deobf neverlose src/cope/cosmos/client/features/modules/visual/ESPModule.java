//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityRenderer;
/*     */ import cope.cosmos.asm.mixins.accessor.IRenderGlobal;
/*     */ import cope.cosmos.asm.mixins.accessor.IRenderManager;
/*     */ import cope.cosmos.asm.mixins.accessor.IShaderGroup;
/*     */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderCrystalEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderLivingEntityEvent;
/*     */ import cope.cosmos.client.events.render.entity.ShaderColorEvent;
/*     */ import cope.cosmos.client.events.render.entity.tile.RenderTileEntityEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.client.ColorsModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.client.shader.shaders.DotShader;
/*     */ import cope.cosmos.client.shader.shaders.FillShader;
/*     */ import cope.cosmos.client.shader.shaders.OutlineShader;
/*     */ import cope.cosmos.client.shader.shaders.RainbowOutlineShader;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import net.minecraft.client.shader.Shader;
/*     */ import net.minecraft.client.shader.ShaderGroup;
/*     */ import net.minecraft.client.shader.ShaderUniform;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.EXTFramebufferObject;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPModule
/*     */   extends Module
/*     */ {
/*     */   public static ESPModule INSTANCE;
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.SHADER)).setDescription("The mode for the render style");
/*     */   public static Setting<FragmentShader> shader = (new Setting("Shader", FragmentShader.OUTLINE)).setDescription("The shader to draw on the entity").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.SHADER)));
/*     */   public static Setting<Double> width = (new Setting("Width", Double.valueOf(0.0D), Double.valueOf(1.25D), Double.valueOf(5.0D), 1)).setDescription("Line width for the visual");
/*     */   public static Setting<Boolean> players = (new Setting("Players", Boolean.valueOf(true))).setDescription("Highlight players");
/*     */   public static Setting<Boolean> passives = (new Setting("Passives", Boolean.valueOf(true))).setDescription("Highlight passives");
/*     */   public static Setting<Boolean> neutrals = (new Setting("Neutrals", Boolean.valueOf(true))).setDescription("Highlight neutrals");
/*     */   
/*     */   public ESPModule() {
/*  70 */     super("ESP", Category.VISUAL, "Allows you to see entities through walls");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     this.outlineShader = new OutlineShader();
/* 139 */     this.rainbowOutlineShader = new RainbowOutlineShader();
/* 140 */     this.dotShader = new DotShader();
/* 141 */     this.fillShader = new FillShader();
/*     */ 
/*     */     
/* 144 */     this.chorusTeleports = new ArrayList<>();
/*     */     INSTANCE = this;
/*     */   } public static Setting<Boolean> hostiles = (new Setting("Hostiles", Boolean.valueOf(true))).setDescription("Highlight hostiles"); public static Setting<Boolean> items = (new Setting("Items", Boolean.valueOf(true))).setDescription("Highlight items"); public static Setting<Boolean> crystals = (new Setting("Crystals", Boolean.valueOf(true))).setDescription("Highlight crystals"); public static Setting<Boolean> vehicles = (new Setting("Vehicles", Boolean.valueOf(true))).setDescription("Highlight vehicles"); public static Setting<Boolean> chests = (new Setting("Chests", Boolean.valueOf(true))).setDescription("Highlight chests"); public static Setting<Boolean> enderChests = (new Setting("EnderChests", Boolean.valueOf(true))).setDescription("Highlight chests");
/*     */   public void onUpdate() {
/* 148 */     if (((Mode)mode.getValue()).equals(Mode.GLOW)) {
/*     */ 
/*     */       
/* 151 */       mc.world.loadedEntityList.forEach(entity -> {
/*     */             if (entity != null && !entity.equals(mc.player) && hasHighlight(entity)) {
/*     */               entity.setGlowing(true);
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 158 */       ShaderGroup outlineShaderGroup = ((IRenderGlobal)mc.renderGlobal).getEntityOutlineShader();
/* 159 */       List<Shader> shaders = ((IShaderGroup)outlineShaderGroup).getListShaders();
/*     */ 
/*     */       
/* 162 */       shaders.forEach(shader -> {
/*     */             ShaderUniform outlineRadius = shader.getShaderManager().getShaderUniform("Radius");
/*     */             if (outlineRadius != null)
/*     */               outlineRadius.set(((Double)width.getValue()).floatValue()); 
/*     */           });
/*     */     } 
/*     */   }
/*     */   public static Setting<Boolean> shulkers = (new Setting("Shulkers", Boolean.valueOf(true))).setDescription("Highlight shulkers"); public static Setting<Boolean> hoppers = (new Setting("Hoppers", Boolean.valueOf(true))).setDescription("Highlight hoppers"); public static Setting<Boolean> furnaces = (new Setting("Furnaces", Boolean.valueOf(true))).setDescription("Highlight furnaces"); public static Setting<Boolean> chorus = (new Setting("Chorus", Boolean.valueOf(false))).setDescription("Highlights chorus teleports");
/*     */   private Framebuffer framebuffer;
/*     */   private int lastScaleFactor;
/*     */   
/*     */   public void onDisable() {
/* 174 */     super.onDisable();
/*     */ 
/*     */     
/* 177 */     if (((Mode)mode.getValue()).equals(Mode.GLOW)) {
/* 178 */       mc.world.loadedEntityList.forEach(entity -> {
/*     */             if (entity != null && entity.isGlowing()) {
/*     */               entity.setGlowing(false);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/* 186 */     this.chorusTeleports.clear();
/*     */   }
/*     */   private int lastScaleWidth; private int lastScaleHeight; private final OutlineShader outlineShader; private final RainbowOutlineShader rainbowOutlineShader; private final DotShader dotShader; private final FillShader fillShader; private final List<Vec3d> chorusTeleports;
/*     */   @SubscribeEvent
/*     */   public void onSettingUpdate(SettingUpdateEvent event) {
/* 191 */     if (event.getSetting().equals(mode) && !event.getSetting().getValue().equals(Mode.GLOW))
/*     */     {
/*     */       
/* 194 */       mc.world.loadedEntityList.forEach(entity -> {
/*     */             if (entity != null && entity.isGlowing()) {
/*     */               entity.setGlowing(false);
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacket(PacketEvent.PacketReceiveEvent event) {
/* 206 */     if (event.getPacket() instanceof SPacketSoundEffect) {
/* 207 */       SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket();
/*     */ 
/*     */ 
/*     */       
/* 211 */       if (packet.getSound().equals(SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT) || packet.getSound().equals(SoundEvents.ENTITY_ENDERMEN_TELEPORT))
/*     */       {
/*     */         
/* 214 */         this.chorusTeleports.add(new Vec3d(packet.getX(), packet.getY(), packet.getZ()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/* 223 */     if (((Boolean)chorus.getValue()).booleanValue() && !this.chorusTeleports.isEmpty())
/*     */     {
/*     */       
/* 226 */       this.chorusTeleports.forEach(pos -> RenderUtil.drawBox((new RenderBuilder()).position(new AxisAlignedBB(pos.x, pos.y, pos.z, pos.x, pos.y + 2.0D, pos.z)).box(RenderBuilder.Box.BOTH).width(((Double)width.getValue()).doubleValue()).color(ColorUtil.getPrimaryAlphaColor(80)).blend().depth(true).texture()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderOverlay(RenderGameOverlayEvent.Pre event) {
/* 245 */     if (nullCheck())
/*     */     {
/*     */       
/* 248 */       if (event.getType().equals(RenderGameOverlayEvent.ElementType.HOTBAR) && (
/* 249 */         (Mode)mode.getValue()).equals(Mode.SHADER)) {
/* 250 */         GlStateManager.enableAlpha();
/* 251 */         GlStateManager.pushMatrix();
/* 252 */         GlStateManager.pushAttrib();
/*     */ 
/*     */         
/* 255 */         if (this.framebuffer != null) {
/* 256 */           this.framebuffer.framebufferClear();
/*     */ 
/*     */           
/* 259 */           ScaledResolution scaledResolution1 = new ScaledResolution(mc);
/*     */           
/* 261 */           if (this.lastScaleFactor != scaledResolution1.getScaleFactor() || this.lastScaleWidth != scaledResolution1.getScaledWidth() || this.lastScaleHeight != scaledResolution1.getScaledHeight()) {
/* 262 */             this.framebuffer.deleteFramebuffer();
/*     */ 
/*     */             
/* 265 */             this.framebuffer = new Framebuffer(mc.displayWidth, mc.displayHeight, true);
/* 266 */             this.framebuffer.framebufferClear();
/*     */           } 
/*     */ 
/*     */           
/* 270 */           this.lastScaleFactor = scaledResolution1.getScaleFactor();
/* 271 */           this.lastScaleWidth = scaledResolution1.getScaledWidth();
/* 272 */           this.lastScaleHeight = scaledResolution1.getScaledHeight();
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 277 */           this.framebuffer = new Framebuffer(mc.displayWidth, mc.displayHeight, true);
/*     */         } 
/*     */ 
/*     */         
/* 281 */         this.framebuffer.bindFramebuffer(false);
/*     */ 
/*     */         
/* 284 */         boolean previousShadows = mc.gameSettings.entityShadows;
/* 285 */         mc.gameSettings.entityShadows = false;
/*     */ 
/*     */         
/* 288 */         ((IEntityRenderer)mc.entityRenderer).setupCamera(event.getPartialTicks(), 0);
/*     */ 
/*     */         
/* 291 */         mc.world.loadedEntityList.forEach(entity -> {
/*     */               if (entity != null && entity != mc.player && hasHighlight(entity)) {
/*     */                 mc.getRenderManager().renderEntityStatic(entity, event.getPartialTicks(), true);
/*     */               }
/*     */             });
/*     */ 
/*     */         
/* 298 */         mc.world.loadedTileEntityList.forEach(tileEntity -> {
/*     */               if (tileEntity != null && hasStorageHighlight(tileEntity)) {
/*     */                 double renderX = ((IRenderManager)mc.getRenderManager()).getRenderX();
/*     */ 
/*     */                 
/*     */                 double renderY = ((IRenderManager)mc.getRenderManager()).getRenderY();
/*     */ 
/*     */                 
/*     */                 double renderZ = ((IRenderManager)mc.getRenderManager()).getRenderZ();
/*     */                 
/*     */                 TileEntityRendererDispatcher.instance.render(tileEntity, tileEntity.getPos().getX() - renderX, tileEntity.getPos().getY() - renderY, tileEntity.getPos().getZ() - renderZ, mc.getRenderPartialTicks());
/*     */               } 
/*     */             });
/*     */         
/* 312 */         mc.gameSettings.entityShadows = previousShadows;
/*     */         
/* 314 */         GlStateManager.enableBlend();
/* 315 */         GL11.glBlendFunc(770, 771);
/*     */ 
/*     */         
/* 318 */         this.framebuffer.unbindFramebuffer();
/* 319 */         mc.getFramebuffer().bindFramebuffer(true);
/*     */ 
/*     */         
/* 322 */         mc.entityRenderer.disableLightmap();
/* 323 */         RenderHelper.disableStandardItemLighting();
/*     */         
/* 325 */         GlStateManager.pushMatrix();
/*     */ 
/*     */         
/* 328 */         if (!((ColorsModule.Rainbow)ColorsModule.rainbow.getValue()).equals(ColorsModule.Rainbow.NONE)) {
/* 329 */           switch ((FragmentShader)shader.getValue()) {
/*     */             case DOTTED:
/* 331 */               this.dotShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */             case OUTLINE:
/* 334 */               this.rainbowOutlineShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */             case OUTLINE_FILL:
/* 337 */               this.fillShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         } else {
/* 344 */           switch ((FragmentShader)shader.getValue()) {
/*     */             case DOTTED:
/* 346 */               this.dotShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */             case OUTLINE:
/* 349 */               this.outlineShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */             case OUTLINE_FILL:
/* 352 */               this.fillShader.startShader(((Double)width.getValue()).intValue(), ColorUtil.getPrimaryColor());
/*     */               break;
/*     */           } 
/*     */ 
/*     */         
/*     */         } 
/* 358 */         mc.entityRenderer.setupOverlayRendering();
/*     */         
/* 360 */         ScaledResolution scaledResolution = new ScaledResolution(mc);
/*     */ 
/*     */         
/* 363 */         GL11.glBindTexture(3553, this.framebuffer.framebufferTexture);
/* 364 */         GL11.glBegin(7);
/* 365 */         GL11.glTexCoord2d(0.0D, 1.0D);
/* 366 */         GL11.glVertex2d(0.0D, 0.0D);
/* 367 */         GL11.glTexCoord2d(0.0D, 0.0D);
/* 368 */         GL11.glVertex2d(0.0D, scaledResolution.getScaledHeight());
/* 369 */         GL11.glTexCoord2d(1.0D, 0.0D);
/* 370 */         GL11.glVertex2d(scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
/* 371 */         GL11.glTexCoord2d(1.0D, 1.0D);
/* 372 */         GL11.glVertex2d(scaledResolution.getScaledWidth(), 0.0D);
/* 373 */         GL11.glEnd();
/*     */ 
/*     */         
/* 376 */         GL20.glUseProgram(0);
/* 377 */         GL11.glPopMatrix();
/*     */ 
/*     */         
/* 380 */         mc.entityRenderer.enableLightmap();
/*     */         
/* 382 */         GlStateManager.popMatrix();
/* 383 */         GlStateManager.popAttrib();
/*     */ 
/*     */         
/* 386 */         mc.entityRenderer.setupOverlayRendering();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderEntity(RenderLivingEntityEvent event) {
/* 394 */     if (((Mode)mode.getValue()).equals(Mode.OUTLINE) && 
/* 395 */       hasHighlight((Entity)event.getEntityLivingBase())) {
/*     */ 
/*     */       
/* 398 */       if ((mc.getFramebuffer()).depthBuffer > -1) {
/*     */ 
/*     */         
/* 401 */         EXTFramebufferObject.glDeleteRenderbuffersEXT((mc.getFramebuffer()).depthBuffer);
/*     */ 
/*     */         
/* 404 */         int stencilFrameBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/*     */ 
/*     */         
/* 407 */         EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilFrameBufferID);
/*     */ 
/*     */         
/* 410 */         EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, mc.displayWidth, mc.displayHeight);
/*     */ 
/*     */         
/* 413 */         EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilFrameBufferID);
/* 414 */         EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilFrameBufferID);
/*     */ 
/*     */         
/* 417 */         (mc.getFramebuffer()).depthBuffer = -1;
/*     */       } 
/*     */ 
/*     */       
/* 421 */       GL11.glPushAttrib(1048575);
/* 422 */       GL11.glDisable(3008);
/* 423 */       GL11.glDisable(3553);
/* 424 */       GL11.glDisable(2896);
/* 425 */       GL11.glEnable(3042);
/* 426 */       GL11.glBlendFunc(770, 771);
/* 427 */       GL11.glLineWidth(((Double)width.getValue()).floatValue());
/* 428 */       GL11.glEnable(2848);
/* 429 */       GL11.glEnable(2960);
/* 430 */       GL11.glClear(1024);
/* 431 */       GL11.glClearStencil(15);
/* 432 */       GL11.glStencilFunc(512, 1, 15);
/* 433 */       GL11.glStencilOp(7681, 7681, 7681);
/* 434 */       GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */       
/* 437 */       event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */ 
/*     */       
/* 440 */       GL11.glStencilFunc(512, 0, 15);
/* 441 */       GL11.glStencilOp(7681, 7681, 7681);
/* 442 */       GL11.glPolygonMode(1032, 6914);
/*     */ 
/*     */       
/* 445 */       event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */ 
/*     */       
/* 448 */       GL11.glStencilFunc(514, 1, 15);
/* 449 */       GL11.glStencilOp(7680, 7680, 7680);
/* 450 */       GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */       
/* 453 */       GL11.glColor4d((getColor((Entity)event.getEntityLivingBase()).getRed() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getGreen() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getBlue() / 255.0F), (getColor((Entity)event.getEntityLivingBase()).getAlpha() / 255.0F));
/* 454 */       GL11.glDepthMask(false);
/* 455 */       GL11.glDisable(2929);
/* 456 */       GL11.glEnable(10754);
/* 457 */       GL11.glPolygonOffset(3.0F, -2000000.0F);
/* 458 */       OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/*     */ 
/*     */       
/* 461 */       event.getModelBase().render((Entity)event.getEntityLivingBase(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScaleFactor());
/*     */ 
/*     */       
/* 464 */       GL11.glPolygonOffset(-3.0F, 2000000.0F);
/* 465 */       GL11.glDisable(10754);
/* 466 */       GL11.glEnable(2929);
/* 467 */       GL11.glDepthMask(true);
/* 468 */       GL11.glDisable(2960);
/* 469 */       GL11.glDisable(2848);
/* 470 */       GL11.glHint(3154, 4352);
/* 471 */       GL11.glEnable(3042);
/* 472 */       GL11.glEnable(2896);
/* 473 */       GL11.glEnable(3553);
/* 474 */       GL11.glEnable(3008);
/* 475 */       GL11.glPopAttrib();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderCrystal(RenderCrystalEvent.RenderCrystalPostEvent event) {
/* 482 */     if (((Mode)mode.getValue()).equals(Mode.OUTLINE) && (
/* 483 */       (Boolean)crystals.getValue()).booleanValue()) {
/*     */ 
/*     */       
/* 486 */       float rotation = (event.getEntityEnderCrystal()).innerRotation + event.getPartialTicks();
/* 487 */       float rotationMoved = MathHelper.sin(rotation * 0.2F) / 2.0F + 0.5F;
/* 488 */       rotationMoved = (float)(rotationMoved + StrictMath.pow(rotationMoved, 2.0D));
/*     */       
/* 490 */       GL11.glPushMatrix();
/*     */ 
/*     */       
/* 493 */       GL11.glTranslated(event.getX(), event.getY(), event.getZ());
/* 494 */       GL11.glLineWidth(1.0F + ((Double)width.getValue()).floatValue());
/*     */ 
/*     */       
/* 497 */       if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 498 */         event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       }
/*     */       else {
/*     */         
/* 502 */         event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       } 
/*     */ 
/*     */       
/* 506 */       if ((mc.getFramebuffer()).depthBuffer > -1) {
/*     */ 
/*     */         
/* 509 */         EXTFramebufferObject.glDeleteRenderbuffersEXT((mc.getFramebuffer()).depthBuffer);
/*     */ 
/*     */         
/* 512 */         int stencilFrameBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/*     */ 
/*     */         
/* 515 */         EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilFrameBufferID);
/*     */ 
/*     */         
/* 518 */         EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, mc.displayWidth, mc.displayHeight);
/*     */ 
/*     */         
/* 521 */         EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilFrameBufferID);
/* 522 */         EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilFrameBufferID);
/*     */ 
/*     */         
/* 525 */         (mc.getFramebuffer()).depthBuffer = -1;
/*     */       } 
/*     */ 
/*     */       
/* 529 */       GL11.glPushAttrib(1048575);
/* 530 */       GL11.glDisable(3008);
/* 531 */       GL11.glDisable(3553);
/* 532 */       GL11.glDisable(2896);
/* 533 */       GL11.glEnable(3042);
/* 534 */       GL11.glBlendFunc(770, 771);
/* 535 */       GL11.glLineWidth(1.0F + ((Double)width.getValue()).floatValue());
/* 536 */       GL11.glEnable(2848);
/* 537 */       GL11.glEnable(2960);
/* 538 */       GL11.glClear(1024);
/* 539 */       GL11.glClearStencil(15);
/* 540 */       GL11.glStencilFunc(512, 1, 15);
/* 541 */       GL11.glStencilOp(7681, 7681, 7681);
/* 542 */       GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */       
/* 545 */       if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 546 */         event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       }
/*     */       else {
/*     */         
/* 550 */         event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       } 
/*     */ 
/*     */       
/* 554 */       GL11.glStencilFunc(512, 0, 15);
/* 555 */       GL11.glStencilOp(7681, 7681, 7681);
/* 556 */       GL11.glPolygonMode(1032, 6914);
/*     */ 
/*     */       
/* 559 */       if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 560 */         event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       }
/*     */       else {
/*     */         
/* 564 */         event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       } 
/*     */ 
/*     */       
/* 568 */       GL11.glStencilFunc(514, 1, 15);
/* 569 */       GL11.glStencilOp(7680, 7680, 7680);
/* 570 */       GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */       
/* 573 */       GL11.glDepthMask(false);
/* 574 */       GL11.glDisable(2929);
/* 575 */       GL11.glEnable(10754);
/* 576 */       GL11.glPolygonOffset(3.0F, -2000000.0F);
/* 577 */       OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/* 578 */       GL11.glColor4d((ColorUtil.getPrimaryColor().getRed() / 255.0F), (ColorUtil.getPrimaryColor().getGreen() / 255.0F), (ColorUtil.getPrimaryColor().getBlue() / 255.0F), (ColorUtil.getPrimaryColor().getAlpha() / 255.0F));
/*     */ 
/*     */       
/* 581 */       if (event.getEntityEnderCrystal().shouldShowBottom()) {
/* 582 */         event.getModelBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       }
/*     */       else {
/*     */         
/* 586 */         event.getModelNoBase().render((Entity)event.getEntityEnderCrystal(), 0.0F, rotation * 3.0F, rotationMoved * 0.2F, 0.0F, 0.0F, 0.0625F);
/*     */       } 
/*     */ 
/*     */       
/* 590 */       GL11.glPolygonOffset(-3.0F, 2000000.0F);
/* 591 */       GL11.glDisable(10754);
/* 592 */       GL11.glEnable(2929);
/* 593 */       GL11.glDepthMask(true);
/* 594 */       GL11.glDisable(2960);
/* 595 */       GL11.glDisable(2848);
/* 596 */       GL11.glHint(3154, 4352);
/* 597 */       GL11.glEnable(3042);
/* 598 */       GL11.glEnable(2896);
/* 599 */       GL11.glEnable(3553);
/* 600 */       GL11.glEnable(3008);
/* 601 */       GL11.glPopAttrib();
/* 602 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderTileEntity(RenderTileEntityEvent event) {
/* 610 */     if (((Mode)mode.getValue()).equals(Mode.OUTLINE) && 
/* 611 */       hasStorageHighlight(event.getTileEntity())) {
/*     */ 
/*     */       
/* 614 */       boolean hotbarRender = (event.getX() == 0.0D && event.getY() == 0.0D && event.getZ() == 0.0D);
/*     */ 
/*     */       
/* 617 */       if (!hotbarRender && 
/* 618 */         TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()) != null) {
/*     */ 
/*     */         
/* 621 */         event.setCanceled(true);
/*     */         
/* 623 */         GL11.glPushMatrix();
/*     */ 
/*     */         
/* 626 */         if (event.getTileEntity().hasFastRenderer()) {
/* 627 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).renderTileEntityFast(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial(), event.getBuffer().getBuffer());
/*     */         }
/*     */         else {
/*     */           
/* 631 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).render(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial());
/*     */         } 
/*     */ 
/*     */         
/* 635 */         if ((mc.getFramebuffer()).depthBuffer > -1) {
/*     */ 
/*     */           
/* 638 */           EXTFramebufferObject.glDeleteRenderbuffersEXT((mc.getFramebuffer()).depthBuffer);
/*     */ 
/*     */           
/* 641 */           int stencilFrameBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/*     */ 
/*     */           
/* 644 */           EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilFrameBufferID);
/*     */ 
/*     */           
/* 647 */           EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, mc.displayWidth, mc.displayHeight);
/*     */ 
/*     */           
/* 650 */           EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilFrameBufferID);
/* 651 */           EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilFrameBufferID);
/*     */ 
/*     */           
/* 654 */           (mc.getFramebuffer()).depthBuffer = -1;
/*     */         } 
/*     */ 
/*     */         
/* 658 */         GL11.glPushAttrib(1048575);
/* 659 */         GL11.glDisable(3008);
/* 660 */         GL11.glDisable(3553);
/* 661 */         GL11.glDisable(2896);
/* 662 */         GL11.glEnable(3042);
/* 663 */         GL11.glBlendFunc(770, 771);
/* 664 */         GL11.glLineWidth(1.0F + ((Double)width.getValue()).floatValue());
/* 665 */         GL11.glEnable(2848);
/* 666 */         GL11.glEnable(2960);
/* 667 */         GL11.glClear(1024);
/* 668 */         GL11.glClearStencil(15);
/* 669 */         GL11.glStencilFunc(512, 1, 15);
/* 670 */         GL11.glStencilOp(7681, 7681, 7681);
/* 671 */         GL11.glPolygonMode(1032, 6913);
/*     */ 
/*     */         
/* 674 */         if (event.getTileEntity().hasFastRenderer()) {
/* 675 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).renderTileEntityFast(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial(), event.getBuffer().getBuffer());
/*     */         }
/*     */         else {
/*     */           
/* 679 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).render(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial());
/*     */         } 
/*     */ 
/*     */         
/* 683 */         GL11.glStencilFunc(512, 0, 15);
/* 684 */         GL11.glStencilOp(7681, 7681, 7681);
/* 685 */         GL11.glPolygonMode(1032, 6914);
/*     */ 
/*     */         
/* 688 */         if (event.getTileEntity().hasFastRenderer()) {
/* 689 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).renderTileEntityFast(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial(), event.getBuffer().getBuffer());
/*     */         }
/*     */         else {
/*     */           
/* 693 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).render(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial());
/*     */         } 
/*     */ 
/*     */         
/* 697 */         GL11.glStencilFunc(514, 1, 15);
/* 698 */         GL11.glStencilOp(7680, 7680, 7680);
/* 699 */         GL11.glPolygonMode(1032, 6913);
/*     */         
/* 701 */         GL11.glDepthMask(false);
/* 702 */         GL11.glDisable(2929);
/* 703 */         GL11.glEnable(10754);
/* 704 */         GL11.glPolygonOffset(3.0F, -2000000.0F);
/* 705 */         OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/*     */ 
/*     */         
/* 708 */         GL11.glColor4d((ColorUtil.getPrimaryColor().getRed() / 255.0F), (ColorUtil.getPrimaryColor().getGreen() / 255.0F), (ColorUtil.getPrimaryColor().getBlue() / 255.0F), (ColorUtil.getPrimaryColor().getAlpha() / 255.0F));
/*     */ 
/*     */         
/* 711 */         if (event.getTileEntity().hasFastRenderer()) {
/* 712 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).renderTileEntityFast(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial(), event.getBuffer().getBuffer());
/*     */         }
/*     */         else {
/*     */           
/* 716 */           TileEntityRendererDispatcher.instance.getRenderer(event.getTileEntity()).render(event.getTileEntity(), event.getX(), event.getY(), event.getZ(), event.getPartialTicks(), event.getDestroyStage(), event.getPartial());
/*     */         } 
/*     */ 
/*     */         
/* 720 */         GL11.glPolygonOffset(-3.0F, 2000000.0F);
/* 721 */         GL11.glDisable(10754);
/* 722 */         GL11.glEnable(2929);
/* 723 */         GL11.glDepthMask(true);
/* 724 */         GL11.glDisable(2960);
/* 725 */         GL11.glDisable(2848);
/* 726 */         GL11.glHint(3154, 4352);
/* 727 */         GL11.glEnable(3042);
/* 728 */         GL11.glEnable(2896);
/* 729 */         GL11.glEnable(3553);
/* 730 */         GL11.glEnable(3008);
/* 731 */         GL11.glPopAttrib();
/* 732 */         GL11.glPopMatrix();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onShaderColor(ShaderColorEvent event) {
/* 849 */     if (((Mode)mode.getValue()).equals(Mode.GLOW)) {
/*     */ 
/*     */       
/* 852 */       event.setColor(getColor(event.getEntity()));
/*     */ 
/*     */       
/* 855 */       event.setCanceled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(Entity in) {
/* 865 */     return getCosmos().getSocialManager().getSocial(in.getName()).equals(SocialManager.Relationship.FRIEND) ? Color.CYAN : ColorUtil.getPrimaryColor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasHighlight(Entity entity) {
/* 874 */     return ((((Boolean)players.getValue()).booleanValue() && entity instanceof net.minecraft.entity.player.EntityPlayer) || (((Boolean)passives.getValue()).booleanValue() && EntityUtil.isPassiveMob(entity)) || (((Boolean)neutrals.getValue()).booleanValue() && EntityUtil.isNeutralMob(entity)) || (((Boolean)hostiles.getValue()).booleanValue() && EntityUtil.isHostileMob(entity)) || (((Boolean)vehicles.getValue()).booleanValue() && EntityUtil.isVehicleMob(entity)) || (((Boolean)items.getValue()).booleanValue() && (entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityExpBottle || entity instanceof net.minecraft.entity.item.EntityXPOrb)) || (((Boolean)crystals.getValue()).booleanValue() && entity instanceof net.minecraft.entity.item.EntityEnderCrystal));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasStorageHighlight(TileEntity tileEntity) {
/* 883 */     return ((((Boolean)chests.getValue()).booleanValue() && tileEntity instanceof net.minecraft.tileentity.TileEntityChest) || (((Boolean)enderChests.getValue()).booleanValue() && tileEntity instanceof net.minecraft.tileentity.TileEntityEnderChest) || (((Boolean)shulkers.getValue()).booleanValue() && tileEntity instanceof net.minecraft.tileentity.TileEntityShulkerBox) || (((Boolean)hoppers.getValue()).booleanValue() && (tileEntity instanceof net.minecraft.tileentity.TileEntityHopper || tileEntity instanceof net.minecraft.tileentity.TileEntityDropper)) || (((Boolean)furnaces.getValue()).booleanValue() && tileEntity instanceof net.minecraft.tileentity.TileEntityFurnace));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 891 */     GLOW,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 896 */     SHADER,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 901 */     OUTLINE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum FragmentShader
/*     */   {
/* 909 */     OUTLINE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 914 */     DOTTED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 919 */     OUTLINE_FILL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\ESPModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
