//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ 
/*    */ public class FullBrightModule
/*    */   extends Module
/*    */ {
/*    */   public static FullBrightModule INSTANCE;
/*    */   private float previousBright;
/*    */   private int previousNightVision;
/*    */   
/*    */   public FullBrightModule() {
/* 16 */     super("FullBright", Category.VISUAL, "Brightens up the world");
/* 17 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 26 */     super.onEnable();
/*    */ 
/*    */     
/* 29 */     this.previousBright = mc.gameSettings.gammaSetting;
/*    */ 
/*    */     
/* 32 */     if (mc.player.isPotionActive(MobEffects.NIGHT_VISION)) {
/* 33 */       this.previousNightVision = mc.player.getActivePotionEffect(MobEffects.NIGHT_VISION).getDuration();
/*    */     }
/*    */ 
/*    */     
/* 37 */     mc.gameSettings.gammaSetting = 100.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 44 */     mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION.setPotionName("FullBright"), 80950, 1, false, false));
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 49 */     super.onDisable();
/*    */ 
/*    */     
/* 52 */     mc.player.removePotionEffect(MobEffects.NIGHT_VISION);
/*    */ 
/*    */     
/* 55 */     if (this.previousNightVision > 0) {
/* 56 */       mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, this.previousNightVision));
/*    */     }
/*    */ 
/*    */     
/* 60 */     mc.gameSettings.gammaSetting = this.previousBright;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\FullBrightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
