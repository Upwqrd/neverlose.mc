//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.client.events.render.player.RenderSelectionBoxEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.render.RenderBuilder;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockHighlightModule
/*    */   extends Module
/*    */ {
/*    */   public static BlockHighlightModule INSTANCE;
/*    */   
/*    */   public BlockHighlightModule() {
/* 24 */     super("BlockHighlight", Category.VISUAL, "Highlights the block the player is focused on");
/* 25 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static Setting<RenderBuilder.Box> renderMode = (new Setting("RenderMode", RenderBuilder.Box.OUTLINE))
/* 31 */     .setDescription("Style of the visual").setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE, RenderBuilder.Box.NONE });
/*    */   
/* 33 */   public static Setting<Float> lineWidth = (new Setting("LineWidth", Float.valueOf(0.1F), Float.valueOf(1.5F), Float.valueOf(5.0F), 1))
/* 34 */     .setDescription("Width of the visual");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRender3D() {
/* 40 */     RayTraceResult mouseOver = mc.objectMouseOver;
/*    */ 
/*    */     
/* 43 */     if (mouseOver != null && mouseOver.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/*    */ 
/*    */       
/* 46 */       AxisAlignedBB mouseOverBox = mc.world.getBlockState(mouseOver.getBlockPos()).getSelectedBoundingBox((World)mc.world, mouseOver.getBlockPos());
/*    */ 
/*    */       
/* 49 */       RenderUtil.drawBox((new RenderBuilder())
/* 50 */           .position(mouseOverBox)
/* 51 */           .color(ColorUtil.getPrimaryAlphaColor(60))
/* 52 */           .box((RenderBuilder.Box)renderMode.getValue())
/* 53 */           .setup()
/* 54 */           .line(((Float)lineWidth.getValue()).floatValue())
/* 55 */           .depth(true)
/* 56 */           .blend()
/* 57 */           .texture());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderSelectionBox(RenderSelectionBoxEvent event) {
/* 66 */     event.setCanceled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\BlockHighlightModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
