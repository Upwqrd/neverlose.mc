//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.visual;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.IRenderGlobal;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.render.RenderBuilder;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.renderer.DestroyBlockProgress;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BreakESPModule
/*    */   extends Module
/*    */ {
/*    */   public static BreakESPModule INSTANCE;
/*    */   
/*    */   public BreakESPModule() {
/* 28 */     super("BreakESP", Category.VISUAL, "Highlights blocks that are being broken");
/*    */     
/* 30 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/* 34 */   public static Setting<RenderBuilder.Box> renderMode = (new Setting("RenderMode", RenderBuilder.Box.BOTH))
/* 35 */     .setDescription("How to render the highlight");
/*    */   
/* 37 */   public static Setting<Float> lineWidth = (new Setting("LineWidth", Float.valueOf(0.1F), Float.valueOf(1.0F), Float.valueOf(3.0F), 1))
/* 38 */     .setDescription("The width of the outline")
/* 39 */     .setVisible(() -> Boolean.valueOf(!((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.FILL)));
/*    */   
/* 41 */   public static Setting<Boolean> percent = (new Setting("Percent", Boolean.valueOf(true)))
/* 42 */     .setDescription("Show the percentage the block has been broken by");
/*    */   
/* 44 */   public static Setting<Boolean> colorFade = (new Setting("ColorFade", Boolean.valueOf(true)))
/* 45 */     .setDescription("Whether the color should fade between red and green depending on the progress");
/*    */   
/* 47 */   public static Setting<Float> alpha = (new Setting("Alpha", Float.valueOf(0.0F), Float.valueOf(100.0F), Float.valueOf(255.0F), 0))
/* 48 */     .setDescription("The alpha of the color");
/*    */ 
/*    */   
/* 51 */   public static Setting<Float> range = (new Setting("Range", Float.valueOf(1.0F), Float.valueOf(20.0F), Float.valueOf(50.0F), 1))
/* 52 */     .setDescription("The maximum distance a highlighted block can be");
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRender3D() {
/* 57 */     ((IRenderGlobal)mc.renderGlobal).getDamagedBlocks().forEach((pos, progress) -> {
/*    */           if (progress != null) {
/*    */             BlockPos blockPos = progress.getPosition();
/*    */             if (mc.world.getBlockState(blockPos).getBlock().equals(Blocks.AIR))
/*    */               return; 
/*    */             if (blockPos.getDistance((int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ) <= ((Float)range.getValue()).floatValue()) {
/*    */               int damage = MathHelper.clamp(progress.getPartialBlockDamage(), 0, 8);
/*    */               AxisAlignedBB bb = mc.world.getBlockState(blockPos).getSelectedBoundingBox((World)mc.world, blockPos);
/*    */               double x = bb.minX + (bb.maxX - bb.minX) / 2.0D;
/*    */               double y = bb.minY + (bb.maxY - bb.minY) / 2.0D;
/*    */               double z = bb.minZ + (bb.maxZ - bb.minZ) / 2.0D;
/*    */               double sizeX = damage * (bb.maxX - x) / 8.0D;
/*    */               double sizeY = damage * (bb.maxY - y) / 8.0D;
/*    */               double sizeZ = damage * (bb.maxZ - z) / 8.0D;
/*    */               int colourFactor = damage * 255 / 8;
/*    */               Color colour = ((Boolean)colorFade.getValue()).booleanValue() ? new Color(255 - colourFactor, colourFactor, 0, ((Float)alpha.getValue()).intValue()) : ColorUtil.getPrimaryAlphaColor(((Float)alpha.getValue()).intValue());
/*    */               RenderUtil.drawBox((new RenderBuilder()).position(new AxisAlignedBB(x - sizeX, y - sizeY, z - sizeZ, x + sizeX, y + sizeY, z + sizeZ)).color(colour).box((RenderBuilder.Box)renderMode.getValue()).setup().line(((Float)lineWidth.getValue()).floatValue()).depth(true).blend().texture());
/*    */               if (((Boolean)percent.getValue()).booleanValue())
/*    */                 RenderUtil.drawNametag(blockPos, 0.5F, (damage * 100 / 8) + "%"); 
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\BreakESPModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
