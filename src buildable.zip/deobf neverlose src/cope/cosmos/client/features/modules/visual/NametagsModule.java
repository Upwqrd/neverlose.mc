//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.visual;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IRenderManager;
/*     */ import cope.cosmos.client.events.render.entity.RenderNametagEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.util.combat.EnemyUtil;
/*     */ import cope.cosmos.util.entity.InterpolationUtil;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class NametagsModule
/*     */   extends Module
/*     */ {
/*     */   public static NametagsModule INSTANCE;
/*     */   
/*     */   public NametagsModule() {
/*  39 */     super("Nametags", Category.VISUAL, "Renders a descriptive nametag on players");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     this.playerInfoMap = new ConcurrentHashMap<>();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Boolean> health = (new Setting("Health", Boolean.valueOf(true))).setDescription("Displays the player's health"); public static Setting<Boolean> healthBar = (new Setting("HealthBar", Boolean.valueOf(false))).setDescription("Visualizes the player's health").setVisible(() -> (Boolean)health.getValue());
/*     */   public static Setting<Boolean> ping = (new Setting("Ping", Boolean.valueOf(true))).setDescription("Displays the player's ping");
/*     */   public static Setting<Boolean> gamemode = (new Setting("Gamemode", Boolean.valueOf(false))).setDescription("Displays the player's gamemode");
/*     */   public static Setting<Boolean> totemPops = (new Setting("TotemPops", Boolean.valueOf(true))).setDescription("Displays the number of totems that the player popped");
/*     */   public static Setting<Boolean> armor = (new Setting("Armor", Boolean.valueOf(true))).setDescription("Displays the player's armor");
/*     */   public static Setting<Boolean> enchantments = (new Setting("Enchantments", Boolean.valueOf(true))).setDescription("Displays the player's item enchantments");
/*     */   public static Setting<Boolean> simpleEnchantments = (new Setting("SimpleEnchantments", Boolean.valueOf(false))).setDescription("Simplify enchantment display").setVisible(() -> (Boolean)enchantments.getValue());
/*     */   public static Setting<Boolean> durability = (new Setting("Durability", Boolean.valueOf(true))).setDescription("Displays the player's item durability");
/*     */   public static Setting<Boolean> mainhand = (new Setting("Mainhand", Boolean.valueOf(true))).setDescription("Displays the player's mainhand item");
/*     */   
/*     */   public void onUpdate() {
/* 114 */     this.playerInfoMap = searchPlayerInfo();
/*     */   }
/*     */   public static Setting<Boolean> offhand = (new Setting("Offhand", Boolean.valueOf(true))).setDescription("Displays the player's offhand item"); public static Setting<Boolean> itemName = (new Setting("ItemName", Boolean.valueOf(false))).setDescription("Displays the player's mainhand item's name"); public static Setting<Boolean> background = (new Setting("Background", Boolean.valueOf(true))).setDescription("Displays a background behind the nametags"); public static Setting<Boolean> outline = (new Setting("Outline", Boolean.valueOf(false))).setDescription("Outlines the background"); public static Setting<Double> scale = (new Setting("Scale", Double.valueOf(0.1D), Double.valueOf(0.2D), Double.valueOf(3.0D), 1)).setDescription("The scaling of the nametag"); public static Setting<Boolean> distanceScale = (new Setting("DistanceScale", Boolean.valueOf(false))).setDescription("Scales the nametags size by the distance from the entity").setParent(scale); private Map<EntityPlayer, String> playerInfoMap; private float itemOffset; private float enchantOffset; private int enchantmentSize; private int maxEnchantment;
/*     */   
/*     */   public void onRender3D() {
/* 119 */     if (mc.renderEngine != null && (mc.getRenderManager()).options != null) {
/* 120 */       this.playerInfoMap.forEach((player, info) -> {
/*     */             if (mc.getRenderViewEntity() != null) {
/*     */               double renderX = ((IRenderManager)mc.getRenderManager()).getRenderX();
/*     */               double renderY = ((IRenderManager)mc.getRenderManager()).getRenderY();
/*     */               double renderZ = ((IRenderManager)mc.getRenderManager()).getRenderZ();
/*     */               Vec3d interpolatedPosition = InterpolationUtil.getInterpolatedPosition((Entity)player, mc.getRenderPartialTicks());
/*     */               int width = FontUtil.getStringWidth(info);
/*     */               float halfWidth = width / 2.0F;
/*     */               double distance = mc.getRenderViewEntity().getDistance(interpolatedPosition.x, interpolatedPosition.y, interpolatedPosition.z);
/*     */               double scaling = ((Double)scale.getValue()).doubleValue() / 10.0D;
/*     */               if (((Boolean)distanceScale.getValue()).booleanValue()) {
/*     */                 scaling = Math.max(((Double)scale.getValue()).doubleValue() * 5.0D, ((Double)scale.getValue()).doubleValue() * distance) / 50.0D;
/*     */               }
/*     */               GlStateManager.pushMatrix();
/*     */               RenderHelper.enableStandardItemLighting();
/*     */               GlStateManager.enablePolygonOffset();
/*     */               GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
/*     */               GlStateManager.disableLighting();
/*     */               GlStateManager.translate(interpolatedPosition.x - renderX, interpolatedPosition.y + player.height + (player.isSneaking() ? 0.05D : 0.08D) - renderY, interpolatedPosition.z - renderZ);
/*     */               GlStateManager.rotate(-(mc.getRenderManager()).playerViewY, 0.0F, 1.0F, 0.0F);
/*     */               GlStateManager.rotate((mc.getRenderManager()).playerViewX, (mc.gameSettings.thirdPersonView == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/*     */               GlStateManager.scale(-scaling, -scaling, scaling);
/*     */               GlStateManager.disableDepth();
/*     */               GlStateManager.enableBlend();
/*     */               if (((Boolean)background.getValue()).booleanValue() || ((Boolean)outline.getValue()).booleanValue() || ((Boolean)healthBar.getValue()).booleanValue()) {
/*     */                 GlStateManager.enableBlend();
/*     */                 if (((Boolean)outline.getValue()).booleanValue()) {
/*     */                   RenderUtil.drawBorder(-halfWidth - 1.0F, -FontUtil.getFontHeight() - (7 + (((Boolean)healthBar.getValue()).booleanValue() ? 2 : 0)), width, FontUtil.getFontHeight() + 2.0F, ColorUtil.getPrimaryColor());
/*     */                 }
/*     */                 if (((Boolean)background.getValue()).booleanValue()) {
/*     */                   RenderUtil.drawRect(-halfWidth - 1.0F, -FontUtil.getFontHeight() - (7 + (((Boolean)healthBar.getValue()).booleanValue() ? 2 : 0)), width, FontUtil.getFontHeight() + 2.0F, new Color(0, 0, 0, 100));
/*     */                 }
/*     */                 if (((Boolean)healthBar.getValue()).booleanValue()) {
/*     */                   float health = MathUtil.roundFloat(EnemyUtil.getHealth((Entity)player), 1);
/*     */                   Color color = Color.GREEN;
/*     */                   if (getCosmos().getSocialManager().getSocial(player.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */                     color = Color.CYAN;
/*     */                   } else if (health <= 16.0F && health > 12.0F) {
/*     */                     color = Color.YELLOW;
/*     */                   } else if (health <= 12.0F && health > 8.0F) {
/*     */                     color = Color.ORANGE;
/*     */                   } else if (health <= 8.0F) {
/*     */                     color = Color.RED;
/*     */                   } 
/*     */                   if (((Boolean)outline.getValue()).booleanValue()) {
/*     */                     RenderUtil.drawRect(-halfWidth - 2.0F, -7.0F, (width + 1) * health / 36.0F, 2.0F, color);
/*     */                   } else {
/*     */                     RenderUtil.drawRect(-halfWidth - 1.0F, -7.0F, width * health / 36.0F, 2.0F, color);
/*     */                   } 
/*     */                 } 
/*     */                 GlStateManager.disableBlend();
/*     */               } 
/*     */               FontUtil.drawStringWithShadow(info, -halfWidth + 1.0F, -FontUtil.getFontHeight() - (5 + (((Boolean)healthBar.getValue()).booleanValue() ? 2 : 0)), -1);
/*     */               List<ItemStack> displayItems = new ArrayList<>();
/*     */               if (((Boolean)offhand.getValue()).booleanValue() && !player.getHeldItemOffhand().isEmpty()) {
/*     */                 displayItems.add(player.getHeldItemOffhand());
/*     */               }
/*     */               if (((Boolean)armor.getValue()).booleanValue()) {
/*     */                 player.getArmorInventoryList().forEach(());
/*     */               }
/*     */               if (((Boolean)mainhand.getValue()).booleanValue() && !player.getHeldItemMainhand().isEmpty()) {
/*     */                 displayItems.add(player.getHeldItemMainhand());
/*     */               }
/*     */               Collections.reverse(displayItems);
/*     */               if (((Boolean)enchantments.getValue()).booleanValue()) {
/*     */                 this.enchantmentSize = 0;
/*     */                 displayItems.forEach(());
/*     */               } else {
/*     */                 this.enchantmentSize = 4;
/*     */               } 
/*     */               if (((Boolean)simpleEnchantments.getValue()).booleanValue()) {
/*     */                 this.enchantmentSize = 4;
/*     */               }
/*     */               if (this.enchantmentSize < 4) {
/*     */                 this.enchantmentSize = 4;
/*     */               }
/*     */               this.itemOffset = (-8 * displayItems.size());
/*     */               displayItems.forEach(());
/*     */               if (((Boolean)NametagsModule.itemName.getValue()).booleanValue()) {
/*     */                 if (!player.getHeldItemMainhand().isEmpty()) {
/*     */                   String itemName = player.getHeldItemMainhand().getDisplayName();
/*     */                   GlStateManager.pushMatrix();
/*     */                   GlStateManager.scale(0.3D, 0.3D, 0.3D);
/*     */                   float xScaled = (-8 * displayItems.size() + 16) * 3.3333335F;
/*     */                   float yScaled = ((this.enchantmentSize * -6) - FontUtil.getFontHeight() - 12.0F - (((Boolean)healthBar.getValue()).booleanValue() ? 2 : false)) * 3.3333335F;
/*     */                   FontUtil.drawStringWithShadow(itemName, xScaled, yScaled, -1);
/*     */                   GlStateManager.scale(3.33334D, 3.33334D, 3.33334D);
/*     */                   GlStateManager.popMatrix();
/*     */                 } 
/*     */               }
/*     */             } 
/*     */             GlStateManager.enableDepth();
/*     */             GlStateManager.disableBlend();
/*     */             GlStateManager.disablePolygonOffset();
/*     */             GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
/*     */             GlStateManager.popMatrix();
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<EntityPlayer, String> searchPlayerInfo() {
/* 529 */     Map<EntityPlayer, String> searchedInfoMap = new ConcurrentHashMap<>();
/*     */     
/* 531 */     mc.world.playerEntities.forEach(player -> {
/*     */           if (!mc.player.equals(player)) {
/*     */             StringBuilder playerInfo = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (!EnemyUtil.isDead((Entity)player)) {
/*     */               if (player.isSneaking()) {
/*     */                 playerInfo.append(TextFormatting.GOLD);
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (getCosmos().getSocialManager().getSocial(player.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */                 playerInfo.append(TextFormatting.AQUA);
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               playerInfo.append(player.getName()).append(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (((Boolean)gamemode.getValue()).booleanValue()) {
/*     */                 if (player.isCreative()) {
/*     */                   playerInfo.append("[C] ");
/*     */                 } else if (player.isInvisible() || player.isSpectator()) {
/*     */                   playerInfo.append("[I] ");
/*     */                 } else {
/*     */                   playerInfo.append("[S] ");
/*     */                 } 
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (((Boolean)ping.getValue()).booleanValue() && mc.getConnection() != null) {
/*     */                 if (mc.getConnection().getPlayerInfo(player.getUniqueID()) != null) {
/*     */                   int responseTime = mc.getConnection().getPlayerInfo(player.getUniqueID()).getResponseTime();
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   TextFormatting color = TextFormatting.GREEN;
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (getCosmos().getSocialManager().getSocial(player.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */                     color = TextFormatting.AQUA;
/*     */                   } else if (responseTime >= 70 && responseTime < 120) {
/*     */                     color = TextFormatting.YELLOW;
/*     */                   } else if (responseTime >= 120 && responseTime < 150) {
/*     */                     color = TextFormatting.GOLD;
/*     */                   } else if (responseTime >= 150) {
/*     */                     color = TextFormatting.RED;
/*     */                   } 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   playerInfo.append(responseTime).append("ms ");
/*     */                 } 
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (((Boolean)NametagsModule.health.getValue()).booleanValue()) {
/*     */                 float health = MathUtil.roundFloat(EnemyUtil.getHealth((Entity)player), 1);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 TextFormatting color = TextFormatting.GREEN;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 if (health <= 16.0F && health > 12.0F) {
/*     */                   color = TextFormatting.YELLOW;
/*     */                 } else if (health <= 12.0F && health > 8.0F) {
/*     */                   color = TextFormatting.GOLD;
/*     */                 } else if (health <= 8.0F && health > 4.0F) {
/*     */                   color = TextFormatting.RED;
/*     */                 } else if (health <= 4.0F) {
/*     */                   color = TextFormatting.DARK_RED;
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 playerInfo.append(color).append(health).append(" ");
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (((Boolean)totemPops.getValue()).booleanValue()) {
/*     */                 int pops = getCosmos().getPopManager().getTotemPops((Entity)player);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 if (pops > 0) {
/*     */                   TextFormatting color = TextFormatting.GREEN;
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (pops > 2) {
/*     */                     color = TextFormatting.DARK_GREEN;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (pops > 4) {
/*     */                     color = TextFormatting.YELLOW;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (pops > 6) {
/*     */                     color = TextFormatting.GOLD;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (pops > 8) {
/*     */                     color = TextFormatting.RED;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/*     */                   playerInfo.append(color).append("-").append(pops).append(" ");
/*     */                 } 
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/*     */               searchedInfoMap.put(player, playerInfo.toString());
/*     */             } 
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 682 */     return searchedInfoMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderNametag(RenderNametagEvent event) {
/* 689 */     event.setCanceled(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\visual\NametagsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
