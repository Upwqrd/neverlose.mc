/*   */ package cope.cosmos.client.features.modules.combat;
/*   */ 
/*   */ import cope.cosmos.client.features.modules.Category;
/*   */ import cope.cosmos.client.features.modules.Module;
/*   */ 
/*   */ public class AutoTrapModule extends Module {
/*   */   public AutoTrapModule() {
/* 8 */     super("AutoTrap", Category.COMBAT, "Traps enemies in obsidian");
/*   */   }
/*   */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AutoTrapModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */