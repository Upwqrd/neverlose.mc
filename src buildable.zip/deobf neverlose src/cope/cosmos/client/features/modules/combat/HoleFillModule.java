//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.HoleManager;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.util.combat.EnemyUtil;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import io.netty.util.internal.ConcurrentSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ public class HoleFillModule
/*     */   extends Module
/*     */ {
/*     */   public static HoleFillModule INSTANCE;
/*     */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("Only places on visible sides");
/*     */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotation", Rotation.Rotate.NONE)).setDescription("Mode for placement rotations");
/*     */   public static Setting<Filler> mode = (new Setting("Mode", Filler.ALL)).setDescription("Mode for the filler");
/*     */   public static Setting<BlockMode> block = (new Setting("Block", BlockMode.OBSIDIAN)).setDescription("Block to use for filling");
/*     */   
/*     */   public HoleFillModule() {
/*  35 */     super("HoleFill", Category.COMBAT, "Fills in nearby holes");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     this.fills = (Set<HoleManager.Hole>)new ConcurrentSet();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Completion> completion = (new Setting("Completion", Completion.COMPLETION)).setDescription("When to consider the filling complete"); public static Setting<Double> range = (new Setting("Range", Double.valueOf(0.0D), Double.valueOf(5.0D), Double.valueOf(15.0D), 1)).setDescription("Range to scan for holes"); public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NORMAL)).setDescription("Mode for switching to block");
/*     */   public static Setting<Double> blocks = (new Setting("Blocks", Double.valueOf(0.0D), Double.valueOf(4.0D), Double.valueOf(10.0D), 0)).setDescription("Allowed block placements per tick");
/*     */   
/*     */   public void onThread() {
/* 107 */     this.fills = searchFills();
/*     */   }
/*     */   public static Setting<Boolean> safety = (new Setting("Safety", Boolean.valueOf(false))).setDescription("Makes sure you are not the closest player for the current hole fill").setVisible(() -> Boolean.valueOf(((Filler)mode.getValue()).equals(Filler.TARGETED))); public static Setting<Boolean> doubles = (new Setting("Doubles", Boolean.valueOf(true))).setDescription("Fills in double holes");
/*     */   public static Setting<Target> target = (new Setting("Target", Target.CLOSEST)).setDescription("Priority for searching target").setVisible(() -> Boolean.valueOf(((Filler)mode.getValue()).equals(Filler.TARGETED)));
/*     */   public static Setting<Double> targetRange = (new Setting("TargetRange", Double.valueOf(0.0D), Double.valueOf(10.0D), Double.valueOf(15.0D), 0)).setDescription("Range to consider a player a target").setVisible(() -> Boolean.valueOf(((Filler)mode.getValue()).equals(Filler.TARGETED)));
/*     */   
/*     */   public void onUpdate() {
/* 114 */     this.blocksPlaced = 0;
/*     */ 
/*     */     
/* 117 */     if (this.fills.isEmpty() && ((Completion)completion.getValue()).equals(Completion.COMPLETION)) {
/* 118 */       disable(true);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 123 */     int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */     
/* 126 */     getCosmos().getInventoryManager().switchToBlock(((BlockMode)block.getValue()).getBlock(), (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */     
/* 129 */     if (InventoryUtil.isHolding(((BlockMode)block.getValue()).getBlock())) {
/* 130 */       for (HoleManager.Hole hole : this.fills) {
/*     */ 
/*     */         
/* 133 */         if (this.blocksPlaced <= ((Double)blocks.getValue()).doubleValue()) {
/* 134 */           this.blocksPlaced++;
/*     */ 
/*     */           
/* 137 */           getCosmos().getInteractionManager().placeBlock(hole.getHole(), (Rotation.Rotate)rotate.getValue(), ((Boolean)strict.getValue()).booleanValue());
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 143 */     if (previousSlot != -1)
/* 144 */       getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue()); 
/*     */   }
/*     */   public static Setting<Double> targetThreshold = (new Setting("Threshold", Double.valueOf(0.0D), Double.valueOf(3.0D), Double.valueOf(15.0D), 1)).setDescription("Target's distance from hole for it to be considered fill-able").setVisible(() -> Boolean.valueOf(((Filler)mode.getValue()).equals(Filler.TARGETED)));
/*     */   public static Setting<Boolean> render = (new Setting("Render", Boolean.valueOf(true))).setDescription("Render a visual of the filling process");
/*     */   
/*     */   public void onDisable() {
/* 150 */     super.onDisable();
/*     */ 
/*     */     
/* 153 */     this.fills.clear();
/* 154 */     this.blocksPlaced = 0;
/*     */   }
/*     */   public static Setting<RenderBuilder.Box> renderMode = (new Setting("RenderMode", RenderBuilder.Box.FILL)).setDescription("Style of the visual").setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE }).setVisible(() -> (Boolean)render.getValue()); private Set<HoleManager.Hole> fills; private int blocksPlaced;
/*     */   
/*     */   public boolean isActive() {
/* 159 */     return (isEnabled() && !this.fills.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/* 166 */     if (((Boolean)render.getValue()).booleanValue() && 
/* 167 */       !this.fills.isEmpty()) {
/* 168 */       this.fills.forEach(fill -> {
/*     */             RenderUtil.drawBox((new RenderBuilder()).position(fill.getHole()).color(ColorUtil.getPrimaryAlphaColor(60)).box((RenderBuilder.Box)renderMode.getValue()).setup().line(1.5F).depth(true).blend().texture());
/*     */             RenderUtil.drawNametag(fill.getHole(), 0.5F, "Fill");
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<HoleManager.Hole> searchFills() {
/* 200 */     ConcurrentSet<HoleManager.Hole> concurrentSet = new ConcurrentSet();
/*     */     
/* 202 */     if (((Filler)mode.getValue()).equals(Filler.TARGETED)) {
/*     */       
/* 204 */       for (EntityPlayer player : mc.world.playerEntities) {
/*     */ 
/*     */         
/* 207 */         if (player == null || player.equals(mc.player) || player.getEntityId() < 0 || EnemyUtil.isDead((Entity)player) || getCosmos().getSocialManager().getSocial(player.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 212 */         if (getCosmos().getHoleManager().isHole(player.getPosition())) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 217 */         double targetDistance = mc.player.getDistance((Entity)player);
/* 218 */         if (targetDistance > ((Double)targetRange.getValue()).doubleValue()) {
/*     */           continue;
/*     */         }
/*     */         
/* 222 */         for (HoleManager.Hole hole : getCosmos().getHoleManager().getHoles())
/*     */         {
/*     */           
/* 225 */           BlockPos holePosition = hole.getHole();
/*     */ 
/*     */           
/* 228 */           if (mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(holePosition)).isEmpty())
/*     */           {
/*     */             
/* 231 */             double holeDistance = mc.player.getDistance(holePosition.getX(), holePosition.getY(), holePosition.getZ());
/* 232 */             if (holeDistance > ((Double)range.getValue()).doubleValue()) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 237 */             if (hole.isQuad() || hole.getType().equals(HoleManager.Type.VOID)) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 242 */             if (hole.isDouble() && !((Boolean)doubles.getValue()).booleanValue()) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 247 */             double holeTargetDistance = player.getDistance(holePosition.getX(), holePosition.getY(), holePosition.getZ());
/*     */ 
/*     */             
/* 250 */             if (holeTargetDistance > ((Double)targetThreshold.getValue()).doubleValue()) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 255 */             if (holeDistance < holeTargetDistance && ((Boolean)safety.getValue()).booleanValue()) {
/*     */               continue;
/*     */             }
/*     */             
/* 259 */             concurrentSet.add(hole);
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } 
/* 265 */     } else if (((Filler)mode.getValue()).equals(Filler.ALL)) {
/*     */       
/* 267 */       for (HoleManager.Hole hole : getCosmos().getHoleManager().getHoles()) {
/*     */ 
/*     */         
/* 270 */         BlockPos holePosition = hole.getHole();
/*     */ 
/*     */         
/* 273 */         if (mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(holePosition)).isEmpty()) {
/*     */ 
/*     */           
/* 276 */           double holeDistance = mc.player.getDistance(holePosition.getX(), holePosition.getY(), holePosition.getZ());
/* 277 */           if (holeDistance > ((Double)range.getValue()).doubleValue()) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 282 */           if (hole.isQuad() || hole.getType().equals(HoleManager.Type.VOID)) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 287 */           if (hole.isDouble() && !((Boolean)doubles.getValue()).booleanValue()) {
/*     */             continue;
/*     */           }
/*     */           
/* 291 */           concurrentSet.add(hole);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 296 */     return (Set<HoleManager.Hole>)concurrentSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Filler
/*     */   {
/* 304 */     ALL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     TARGETED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Completion
/*     */   {
/* 317 */     COMPLETION,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 322 */     TARGET,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     PERSISTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum BlockMode
/*     */   {
/* 335 */     OBSIDIAN((String)new Block[] { Blocks.OBSIDIAN
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 340 */     ENDER_CHEST((String)new Block[] { Blocks.ENDER_CHEST
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 345 */     PRESSURE_PLATE((String)new Block[] { Blocks.WOODEN_PRESSURE_PLATE, Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE, Blocks.STONE_PRESSURE_PLATE, Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 350 */     WEB((String)new Block[] { Blocks.WEB });
/*     */     
/*     */     private final Block[] block;
/*     */     
/*     */     BlockMode(Block... block) {
/* 355 */       this.block = block;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Block[] getBlock() {
/* 363 */       return this.block;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Target
/*     */   {
/* 372 */     CLOSEST,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 377 */     LOWEST_HEALTH,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 382 */     LOWEST_ARMOR;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\HoleFillModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
