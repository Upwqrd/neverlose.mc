//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityLivingBase;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityPlayerSP;
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderRotationsEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.player.SwingModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.client.manager.managers.TickManager;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.combat.EnemyUtil;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.entity.InterpolationUtil;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.AngleUtil;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import cope.cosmos.util.world.RaytraceUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.TreeMap;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.network.play.server.SPacketAnimation;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AuraModule extends Module {
/*     */   public static AuraModule INSTANCE;
/*     */   
/*     */   public AuraModule() {
/*  56 */     super("Aura", Category.COMBAT, "Attacks nearby entities", () -> StringFormatter.formatEnum((Enum)target.getValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.attackTimer = new Timer();
/*     */ 
/*     */     
/* 151 */     this.switchTimer = new Timer();
/* 152 */     this.autoSwitchTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.NONE)).setDescription("Rotate to the current attack"); public static Setting<Boolean> yawStep = (new Setting("YawStep", Boolean.valueOf(false))).setDescription("Limits yaw rotations").setVisible(() -> Boolean.valueOf(!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE))); public static Setting<Double> yawStepThreshold = (new Setting("YawStepThreshold", Double.valueOf(1.0D), Double.valueOf(180.0D), Double.valueOf(180.0D), 0)).setDescription("Max angle to rotate in one tick").setVisible(() -> Boolean.valueOf((!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE) && ((Boolean)yawStep.getValue()).booleanValue())));
/*     */   public static Setting<Boolean> stopSprint = (new Setting("StopSprint", Boolean.valueOf(false))).setDescription("Stops sprinting and sneaking before attacking");
/*     */   public static Setting<Boolean> swing = (new Setting("Swing", Boolean.valueOf(true))).setDescription("Swings the players hand when attacking");
/*     */   public static Setting<Raytrace> raytrace = (new Setting("Raytrace", Raytrace.EYES)).setDescription("Trace vector");
/*     */   public static Setting<Boolean> attackDelay = (new Setting("AttackDelay", Boolean.valueOf(true))).setDescription("Delays attacks according to minecraft hit delays for maximum damage per attack");
/*     */   public static Setting<Double> attackSpeed = (new Setting("AttackSpeed", Double.valueOf(1.0D), Double.valueOf(20.0D), Double.valueOf(20.0D), 1)).setDescription("Speed to attack").setVisible(() -> Boolean.valueOf(!((Boolean)attackDelay.getValue()).booleanValue()));
/*     */   public static Setting<Double> switchDelay = (new Setting("SwitchDelay", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(10.0D), 1)).setDescription("Delay to pause after switching items");
/*     */   public static Setting<TickManager.TPS> tps = (new Setting("TPS", TickManager.TPS.NONE)).setDescription("Server TPS factor");
/*     */   public static Setting<Double> range = (new Setting("Range", Double.valueOf(0.0D), Double.valueOf(5.0D), Double.valueOf(6.0D), 1)).setDescription("Range to attack entities");
/*     */   public static Setting<Double> wallsRange = (new Setting("WallsRange", Double.valueOf(0.0D), Double.valueOf(3.5D), Double.valueOf(6.0D), 1)).setDescription("Range to attack entities through walls").setVisible(() -> Boolean.valueOf(!((Raytrace)raytrace.getValue()).equals(Raytrace.NONE)));
/*     */   public static Setting<Weapon> weapon = (new Setting("Weapon", Weapon.SWORD)).setDescription("Weapon to use for attacking");
/*     */   public static Setting<Boolean> weaponOnly = (new Setting("OnlyWeapon", Boolean.valueOf(true))).setDescription("Only attack if holding weapon");
/*     */   
/*     */   public void onUpdate() {
/* 169 */     if (AutoCrystalModule.INSTANCE.isActive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 174 */     this.attackTarget = getTarget();
/*     */ 
/*     */     
/* 177 */     if (this.rotateTicks <= 0) {
/*     */ 
/*     */       
/* 180 */       if (this.attackTarget != null) {
/*     */         boolean delayed;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         if (((Boolean)AuraModule.attackDelay.getValue()).booleanValue()) {
/*     */ 
/*     */           
/* 189 */           float adjustTicks = 20.0F - getCosmos().getTickManager().getTPS((TickManager.TPS)tps.getValue());
/*     */ 
/*     */           
/* 192 */           float cooldown = mc.player.getCooledAttackStrength(adjustTicks);
/*     */ 
/*     */           
/* 195 */           long swapDelay = ((Double)switchDelay.getValue()).longValue() * 25L;
/*     */ 
/*     */           
/* 198 */           delayed = (cooldown >= 1.0F && this.switchTimer.passedTime(swapDelay, Timer.Format.MILLISECONDS));
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 206 */           long attackDelay = (long)((((Double)attackSpeed.getMax()).doubleValue() - ((Double)attackSpeed.getValue()).doubleValue()) * 50.0D);
/*     */ 
/*     */           
/* 209 */           long swapDelay = ((Double)switchDelay.getValue()).longValue() * 25L;
/*     */ 
/*     */           
/* 212 */           delayed = (this.attackTimer.passedTime(attackDelay, Timer.Format.MILLISECONDS) && this.switchTimer.passedTime(swapDelay, Timer.Format.MILLISECONDS));
/*     */         } 
/*     */ 
/*     */         
/* 216 */         if (delayed)
/*     */         {
/*     */           
/* 219 */           this.angleVector = this.attackTarget.getPositionVector();
/*     */ 
/*     */           
/* 222 */           if (attackTarget(this.attackTarget))
/*     */           {
/*     */             
/* 225 */             this.attackTimer.resetTime();
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 232 */       this.rotateTicks--;
/*     */     } 
/*     */   }
/*     */   public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NORMAL)).setDescription("Mode for switching to weapon"); public static Setting<Boolean> autoBlock = (new Setting("AutoBlock", Boolean.valueOf(false))).setDescription("Automatically blocks with a shield"); public static Setting<Target> target = (new Setting("Target", Target.CLOSEST)).setDescription("Priority for searching target"); public static Setting<Boolean> targetPlayers = (new Setting("TargetPlayers", Boolean.valueOf(true))).setDescription("Target players"); public static Setting<Boolean> targetPassives = (new Setting("TargetPassives", Boolean.valueOf(false))).setDescription("Target passives"); public static Setting<Boolean> targetNeutrals = (new Setting("TargetNeutrals", Boolean.valueOf(false))).setDescription("Target neutrals");
/*     */   public static Setting<Boolean> targetHostiles = (new Setting("TargetHostiles", Boolean.valueOf(false))).setDescription("Target hostiles");
/*     */   
/*     */   public void onRender3D() {
/* 239 */     if (((Boolean)render.getValue()).booleanValue())
/*     */     {
/*     */       
/* 242 */       if (isActive())
/*     */       {
/*     */         
/* 245 */         RenderUtil.drawCircle((new RenderBuilder())
/* 246 */             .setup()
/* 247 */             .line(1.5F)
/* 248 */             .depth(true)
/* 249 */             .blend()
/* 250 */             .texture(), InterpolationUtil.getInterpolatedPosition(this.attackTarget, 1.0F), this.attackTarget.width, this.attackTarget.height * 0.5D * (Math.sin(mc.player.ticksExisted * 3.5D * 0.017453292519943295D) + 1.0D), ColorUtil.getPrimaryColor()); }  } 
/*     */   }
/*     */   public static Setting<Boolean> render = (new Setting("Render", Boolean.valueOf(true))).setDescription("Render a visual over the target"); private Entity attackTarget; private final Timer attackTimer; private final Timer switchTimer; private final Timer autoSwitchTimer; private Vec3d angleVector;
/*     */   private Rotation rotateAngles;
/*     */   private int rotateTicks;
/*     */   
/*     */   public void onDisable() {
/* 257 */     super.onDisable();
/*     */ 
/*     */     
/* 260 */     this.attackTarget = null;
/* 261 */     this.angleVector = null;
/* 262 */     this.rotateAngles = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 267 */     return (isEnabled() && this.attackTarget != null && (isHoldingWeapon() || !((Boolean)weaponOnly.getValue()).booleanValue()) && !AutoCrystalModule.INSTANCE.isActive());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 274 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketHeldItemChange) {
/*     */ 
/*     */       
/* 277 */       this.switchTimer.resetTime();
/*     */ 
/*     */       
/* 280 */       this.autoSwitchTimer.resetTime();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onRotationUpdate(RotationUpdateEvent event) {
/* 288 */     if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE))
/*     */     {
/*     */       
/* 291 */       if (isActive())
/*     */       {
/*     */         
/* 294 */         if (this.angleVector != null) {
/*     */ 
/*     */           
/* 297 */           event.setCanceled(true);
/*     */ 
/*     */           
/* 300 */           this.rotateAngles = AngleUtil.calculateAngles(this.angleVector);
/*     */ 
/*     */           
/* 303 */           Rotation serverRotation = getCosmos().getRotationManager().getServerRotation();
/*     */ 
/*     */           
/* 306 */           float yaw = MathHelper.wrapDegrees(serverRotation.getYaw());
/*     */ 
/*     */           
/* 309 */           float angleDifference = this.rotateAngles.getYaw() - yaw;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 314 */           if (Math.abs(angleDifference) > 180.0F) {
/*     */ 
/*     */             
/* 317 */             float adjust = (angleDifference > 0.0F) ? -360.0F : 360.0F;
/* 318 */             angleDifference += adjust;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 323 */           if (Math.abs(angleDifference) > ((Double)yawStepThreshold.getValue()).doubleValue()) {
/*     */ 
/*     */             
/* 326 */             if (((Boolean)yawStep.getValue()).booleanValue())
/*     */             {
/*     */               
/* 329 */               int rotationDirection = (angleDifference > 0.0F) ? 1 : -1;
/*     */ 
/*     */               
/* 332 */               yaw = (float)(yaw + ((Double)yawStepThreshold.getValue()).doubleValue() * rotationDirection);
/*     */ 
/*     */               
/* 335 */               this.rotateAngles = new Rotation(yaw, this.rotateAngles.getPitch());
/*     */ 
/*     */               
/* 338 */               if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 339 */                 mc.player.rotationYaw = this.rotateAngles.getYaw();
/* 340 */                 mc.player.rotationYawHead = this.rotateAngles.getYaw();
/* 341 */                 mc.player.rotationPitch = this.rotateAngles.getPitch();
/*     */               } 
/*     */ 
/*     */               
/* 345 */               getCosmos().getRotationManager().setRotation(this.rotateAngles);
/*     */ 
/*     */               
/* 348 */               this.rotateTicks++;
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 355 */             if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 356 */               mc.player.rotationYaw = this.rotateAngles.getYaw();
/* 357 */               mc.player.rotationYawHead = this.rotateAngles.getYaw();
/* 358 */               mc.player.rotationPitch = this.rotateAngles.getPitch();
/*     */             } 
/*     */ 
/*     */             
/* 362 */             getCosmos().getRotationManager().setRotation(this.rotateAngles);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderRotations(RenderRotationsEvent event) {
/* 373 */     if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.PACKET))
/*     */     {
/*     */       
/* 376 */       if (isActive())
/*     */       {
/*     */         
/* 379 */         if (this.rotateAngles != null) {
/*     */ 
/*     */           
/* 382 */           event.setCanceled(true);
/*     */ 
/*     */           
/* 385 */           event.setYaw(this.rotateAngles.getYaw());
/* 386 */           event.setPitch(this.rotateAngles.getPitch());
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Entity getTarget() {
/* 403 */     TreeMap<Double, Entity> validTargets = new TreeMap<>();
/*     */ 
/*     */     
/* 406 */     for (Entity entity : new ArrayList(mc.world.loadedEntityList)) {
/*     */ 
/*     */       
/* 409 */       if (entity == null || entity.equals(mc.player) || entity.getEntityId() < 0 || EnemyUtil.isDead(entity) || getCosmos().getSocialManager().getSocial(entity.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 414 */       if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 419 */       if (entity.isBeingRidden() && entity.getPassengers().contains(mc.player)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 424 */       if ((entity instanceof EntityPlayer && !((Boolean)targetPlayers.getValue()).booleanValue()) || (EntityUtil.isPassiveMob(entity) && !((Boolean)targetPassives.getValue()).booleanValue()) || (EntityUtil.isNeutralMob(entity) && !((Boolean)targetNeutrals.getValue()).booleanValue()) || (EntityUtil.isHostileMob(entity) && !((Boolean)targetHostiles.getValue()).booleanValue())) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 429 */       double entityRange = mc.player.getDistance(entity);
/*     */ 
/*     */       
/* 432 */       if (entityRange > ((Double)range.getValue()).doubleValue()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 437 */       boolean isNotVisible = RaytraceUtil.isNotVisible(entity, ((Raytrace)raytrace.getValue()).getModifier(entity));
/*     */ 
/*     */       
/* 440 */       if (isNotVisible && 
/* 441 */         entityRange > ((Double)wallsRange.getValue()).doubleValue()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 447 */       validTargets.put(Double.valueOf(((Target)target.getValue()).getModifier(entity)), entity);
/*     */     } 
/*     */ 
/*     */     
/* 451 */     if (!validTargets.isEmpty()) {
/*     */ 
/*     */       
/* 454 */       Entity bestTarget = (Entity)validTargets.lastEntry().getValue();
/*     */ 
/*     */       
/* 457 */       if (!EnemyUtil.isDead(bestTarget))
/*     */       {
/*     */         
/* 460 */         return bestTarget;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 465 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean attackTarget(Entity in) {
/* 475 */     if (in == null || in.isDead) {
/* 476 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 480 */     if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE) && ((Boolean)yawStep.getValue()).booleanValue())
/*     */     {
/*     */       
/* 483 */       if (!isFacing(this.angleVector)) {
/* 484 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 489 */     if (PlayerUtil.isEating() || PlayerUtil.isMending() || PlayerUtil.isMining()) {
/* 490 */       this.autoSwitchTimer.resetTime();
/*     */     }
/*     */ 
/*     */     
/* 494 */     if (!isHoldingWeapon())
/*     */     {
/*     */       
/* 497 */       if (this.autoSwitchTimer.passedTime(500L, Timer.Format.MILLISECONDS))
/*     */       {
/*     */         
/* 500 */         getCosmos().getInventoryManager().switchToItem(((Weapon)weapon.getValue()).getItem(), (InventoryManager.Switch)autoSwitch.getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 505 */     if (((Boolean)weaponOnly.getValue()).booleanValue())
/*     */     {
/*     */       
/* 508 */       if (!isHoldingWeapon()) {
/* 509 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 514 */     boolean shieldState = false;
/*     */ 
/*     */     
/* 517 */     if (((Boolean)autoBlock.getValue()).booleanValue()) {
/*     */ 
/*     */       
/* 520 */       shieldState = (mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemShield && mc.player.isActiveItemStackBlocking());
/*     */       
/* 522 */       if (shieldState) {
/* 523 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos((Entity)mc.player), EnumFacing.getFacingFromVector((float)mc.player.posX, (float)mc.player.posY, (float)mc.player.posZ)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 528 */     boolean sprintState = false;
/*     */ 
/*     */     
/* 531 */     if (((Boolean)stopSprint.getValue()).booleanValue()) {
/*     */ 
/*     */       
/* 534 */       sprintState = (mc.player.isSprinting() || ((IEntityPlayerSP)mc.player).getServerSprintState());
/*     */ 
/*     */       
/* 537 */       if (sprintState) {
/* 538 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 543 */     mc.player.connection.sendPacket((Packet)new CPacketUseEntity(in));
/* 544 */     mc.player.resetCooldown();
/*     */ 
/*     */     
/* 547 */     if (((Boolean)swing.getValue()).booleanValue()) {
/*     */ 
/*     */       
/* 550 */       ItemStack stack = mc.player.getHeldItem(EnumHand.MAIN_HAND);
/*     */ 
/*     */       
/* 553 */       if (!stack.isEmpty() && 
/* 554 */         !stack.getItem().onEntitySwing((EntityLivingBase)mc.player, stack))
/*     */       {
/*     */         
/* 557 */         if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= ((IEntityLivingBase)mc.player).hookGetArmSwingAnimationEnd() / 2 || mc.player.swingProgressInt < 0) {
/* 558 */           mc.player.swingProgressInt = -1;
/* 559 */           mc.player.isSwingInProgress = true;
/* 560 */           mc.player.swingingHand = SwingModule.INSTANCE.isEnabled() ? SwingModule.INSTANCE.getHand() : EnumHand.MAIN_HAND;
/*     */ 
/*     */           
/* 563 */           if (mc.player.world instanceof WorldServer) {
/* 564 */             ((WorldServer)mc.player.world).getEntityTracker().sendToTracking((Entity)mc.player, (Packet)new SPacketAnimation((Entity)mc.player, 0));
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 572 */     mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */ 
/*     */     
/* 575 */     if (shieldState && isHoldingWeapon()) {
/* 576 */       mc.playerController.processRightClick((EntityPlayer)mc.player, (World)mc.world, EnumHand.OFF_HAND);
/*     */     }
/*     */ 
/*     */     
/* 580 */     if (sprintState) {
/* 581 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */     }
/*     */     
/* 584 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHoldingWeapon() {
/* 594 */     Class<? extends Item> weaponItem = ((Weapon)weapon.getValue()).getItem();
/*     */ 
/*     */     
/* 597 */     return InventoryUtil.isHolding(weaponItem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFacing(Vec3d in) {
/* 607 */     Rotation serverRotation = getCosmos().getRotationManager().getServerRotation();
/*     */ 
/*     */     
/* 610 */     Rotation facingRotation = AngleUtil.calculateAngles(in);
/*     */ 
/*     */     
/* 613 */     float yaw = Math.abs(serverRotation.getYaw() - facingRotation.getYaw());
/* 614 */     float pitch = Math.abs(serverRotation.getPitch() - facingRotation.getPitch());
/*     */ 
/*     */     
/* 617 */     return ((yaw <= 0.1D)) & ((pitch <= 0.1D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Raytrace
/*     */   {
/* 639 */     FEET((String)(in -> 0.0D)),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 646 */     NONE(null), EYES(null), TORSO(null); static {
/*     */       EYES = new Raytrace("EYES", 0, in -> in.getEyeHeight());
/*     */       TORSO = new Raytrace("TORSO", 1, in -> in.height / 2.0D);
/*     */     }
/*     */     private final AuraModule.EntityModifier modifier;
/*     */     Raytrace(AuraModule.EntityModifier modifier) {
/* 652 */       this.modifier = modifier;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getModifier(Entity in) {
/* 661 */       return (this.modifier == null) ? -1000.0D : this.modifier.modify(in);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Target
/*     */   {
/*     */     private final AuraModule.EntityModifier modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/*     */       CLOSEST = new Target("CLOSEST", 0, in -> -Wrapper.mc.player.getDistance(in));
/*     */       LOWEST_HEALTH = new Target("LOWEST_HEALTH", 1, in -> -EnemyUtil.getHealth(in));
/*     */       LOWEST_ARMOR = new Target("LOWEST_ARMOR", 2, in -> -EnemyUtil.getArmor(in));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Target(AuraModule.EntityModifier modifier) {
/*     */       this.modifier = modifier;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getModifier(Entity in) {
/*     */       return (this.modifier == null) ? -1000.0D : this.modifier.modify(in);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 731 */     CLOSEST((String)ItemPickaxe.class), LOWEST_HEALTH((String)ItemPickaxe.class), LOWEST_ARMOR((String)ItemPickaxe.class); } @FunctionalInterface public static interface EntityModifier { double modify(Entity param1Entity); } public enum Weapon { SWORD((String)ItemSword.class), AXE((String)ItemAxe.class), PICKAXE((String)ItemPickaxe.class);
/*     */     
/*     */     private final Class<? extends Item> item;
/*     */ 
/*     */     
/*     */     Weapon(Class<? extends Item> item) {
/* 737 */       this.item = item;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<? extends Item> getItem() {
/* 745 */       return this.item;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AuraModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
