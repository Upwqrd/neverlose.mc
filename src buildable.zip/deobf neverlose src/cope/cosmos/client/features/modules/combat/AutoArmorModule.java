//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemArmor;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketCloseWindow;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ 
/*     */ public class AutoArmorModule
/*     */   extends Module {
/*     */   public static AutoArmorModule INSTANCE;
/*     */   public static Setting<Boolean> fast = (new Setting("Fast", Boolean.valueOf(false))).setDescription("Uses quick switching to switch the armor pieces");
/*     */   public static Setting<Boolean> inventoryStrict = (new Setting("InventoryStrict", Boolean.valueOf(false))).setDescription("Opens inventory serverside before switching");
/*     */   
/*     */   public AutoArmorModule() {
/*  28 */     super("AutoArmor", Category.COMBAT, "Automatically equips the best piece of armor");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.bestSlots = new ArmorSlot[] { new ArmorSlot(-1, false), new ArmorSlot(-1, false), new ArmorSlot(-1, false), new ArmorSlot(-1, false) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.armorTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onDisable() {
/*  69 */     super.onDisable();
/*     */ 
/*     */     
/*  72 */     this.bestSlots = new ArmorSlot[] { new ArmorSlot(-1, false), new ArmorSlot(-1, false), new ArmorSlot(-1, false), new ArmorSlot(-1, false) };
/*     */   }
/*     */   public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.0D), Double.valueOf(200.0D), Double.valueOf(1000.0D), 1)).setDescription("The delay before equipping another piece of armor");
/*     */   public static Setting<Priority> priority = (new Setting("Priority", Priority.BLAST)).setDescription("Armor type priority");
/*     */   public static Setting<Boolean> noBinding = (new Setting("NoBinding", Boolean.valueOf(true))).setDescription("If to avoid equipping armor with the enchantment Curse of Binding");
/*     */   public static Setting<Boolean> inventory = (new Setting("Inventory", Boolean.valueOf(false))).setDescription("Allow module to equip armor if the inventory GUI is open");
/*     */   private ArmorSlot[] bestSlots;
/*     */   private final Timer armorTimer;
/*     */   
/*     */   public void onTick() {
/*  82 */     if (mc.currentScreen == null || (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory && ((Boolean)inventory.getValue()).booleanValue())) {
/*     */       int i;
/*     */       
/*  85 */       for (i = 0; i < 36; i++) {
/*     */ 
/*     */         
/*  88 */         ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */ 
/*     */         
/*  91 */         if (!stack.isEmpty() && stack.getItem() instanceof ItemArmor) {
/*     */ 
/*     */ 
/*     */           
/*  95 */           ItemArmor itemArmor = (ItemArmor)stack.getItem();
/*     */ 
/*     */           
/*  98 */           if (!((Boolean)noBinding.getValue()).booleanValue() || !EnchantmentHelper.hasBindingCurse(stack)) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 103 */             int index = itemArmor.armorType.getIndex();
/*     */ 
/*     */             
/* 106 */             Item armorSlotItem = ((ItemStack)mc.player.inventory.armorInventory.get(index)).getItem();
/*     */ 
/*     */             
/* 109 */             if (!armorSlotItem.equals(Items.ELYTRA)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 115 */               int damageReduceAmount = (armorSlotItem instanceof ItemArmor) ? ((ItemArmor)armorSlotItem).damageReduceAmount : -1;
/*     */ 
/*     */               
/* 118 */               boolean armorPriority = EnchantmentHelper.getEnchantments(stack).containsKey(((Priority)priority.getValue()).getEnchantment());
/*     */ 
/*     */               
/* 121 */               if (!this.bestSlots[index].getPriority() || armorPriority)
/*     */               {
/*     */ 
/*     */ 
/*     */                 
/* 126 */                 if (damageReduceAmount < itemArmor.damageReduceAmount)
/* 127 */                   this.bestSlots[index] = new ArmorSlot(i, armorPriority);  } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 131 */       }  for (i = 0; i < 4; i++) {
/*     */ 
/*     */         
/* 134 */         if (this.armorTimer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */           
/* 137 */           if (((Boolean)inventoryStrict.getValue()).booleanValue()) {
/* 138 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.OPEN_INVENTORY));
/*     */           }
/*     */ 
/*     */           
/* 142 */           int id = this.bestSlots[i].getSlot();
/*     */ 
/*     */           
/* 145 */           if (id != -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 150 */             boolean hadItem = !((ItemStack)mc.player.inventory.armorInventory.get(i)).isEmpty();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 155 */             int packetSlot = (id < 9) ? (id + 36) : id;
/*     */ 
/*     */             
/* 158 */             if (((Boolean)fast.getValue()).booleanValue()) {
/*     */ 
/*     */               
/* 161 */               if (hadItem) {
/* 162 */                 mc.playerController.windowClick(0, 8 - i, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 167 */               mc.playerController.windowClick(0, packetSlot, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 173 */               mc.playerController.windowClick(0, packetSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */ 
/*     */               
/* 177 */               mc.playerController.windowClick(0, 8 - i, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */ 
/*     */               
/* 181 */               if (hadItem) {
/* 182 */                 mc.playerController.windowClick(0, packetSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 187 */             this.bestSlots[i] = new ArmorSlot(-1, false);
/*     */ 
/*     */             
/* 190 */             if (((Boolean)inventoryStrict.getValue()).booleanValue() && mc.getConnection() != null) {
/* 191 */               mc.getConnection().getNetworkManager().sendPacket((Packet)new CPacketCloseWindow(mc.player.inventoryContainer.windowId));
/*     */             }
/*     */ 
/*     */             
/* 195 */             this.armorTimer.resetTime();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Priority
/*     */   {
/* 207 */     BLAST((String)Enchantments.BLAST_PROTECTION),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     PROTECTION((String)Enchantments.PROTECTION);
/*     */     
/*     */     private final Enchantment enchantment;
/*     */ 
/*     */     
/*     */     Priority(Enchantment enchantment) {
/* 218 */       this.enchantment = enchantment;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Enchantment getEnchantment() {
/* 226 */       return this.enchantment;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ArmorSlot
/*     */   {
/*     */     private final int slot;
/*     */     
/*     */     private final boolean priority;
/*     */     
/*     */     public ArmorSlot(int slot, boolean priority) {
/* 238 */       this.slot = slot;
/* 239 */       this.priority = priority;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getSlot() {
/* 247 */       return this.slot;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getPriority() {
/* 255 */       return this.priority;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AutoArmorModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
