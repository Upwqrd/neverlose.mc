//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class FastProjectileModule
/*     */   extends Module
/*     */ {
/*     */   public static FastProjectileModule INSTANCE;
/*     */   
/*     */   public FastProjectileModule() {
/*  27 */     super("FastProjectile", Category.COMBAT, "Allows your projectiles to do more damage", () -> {
/*     */           if (projectileTimer.passedTime(2L, Timer.Format.SECONDS)) {
/*     */             return "Charged";
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           long timeTillCharge = 2000L - projectileTimer.getMilliseconds();
/*     */ 
/*     */ 
/*     */           
/*     */           if (timeTillCharge < 0L) {
/*     */             timeTillCharge = 0L;
/*     */           } else if (timeTillCharge > 2000L) {
/*     */             timeTillCharge = 2000L;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           return String.valueOf(MathUtil.roundDouble(timeTillCharge / 1000.0D, 1));
/*     */         });
/*     */ 
/*     */     
/*  50 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static Setting<Double> power = (new Setting("Power", Double.valueOf(1.0D), Double.valueOf(10.0D), Double.valueOf(100.0D), 0))
/*  56 */     .setDescription("How many times to send packets");
/*     */   
/*  58 */   public static Setting<Boolean> bows = (new Setting("Bows", Boolean.valueOf(false)))
/*  59 */     .setDescription("Allow bows to do more damage");
/*     */   
/*  61 */   public static Setting<Boolean> eggs = (new Setting("Eggs", Boolean.valueOf(false)))
/*  62 */     .setDescription("Allow eggs to do more damage");
/*     */   
/*  64 */   public static Setting<Boolean> snowballs = (new Setting("Snowballs", Boolean.valueOf(false)))
/*  65 */     .setDescription("Allow snowballs to do more damage");
/*     */ 
/*     */   
/*  68 */   private static final Timer projectileTimer = new Timer();
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  74 */     if (event.getPacket() instanceof CPacketPlayerDigging && ((CPacketPlayerDigging)event.getPacket()).getAction().equals(CPacketPlayerDigging.Action.RELEASE_USE_ITEM))
/*     */     {
/*     */       
/*  77 */       if ((InventoryUtil.isHolding((Item)Items.BOW) && ((Boolean)bows.getValue()).booleanValue()) || (InventoryUtil.isHolding(Items.EGG) && ((Boolean)eggs.getValue()).booleanValue()) || (InventoryUtil.isHolding(Items.SNOWBALL) && ((Boolean)snowballs.getValue()).booleanValue()))
/*     */       {
/*     */         
/*  80 */         if (projectileTimer.passedTime(2L, Timer.Format.SECONDS)) {
/*     */ 
/*     */           
/*  83 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */ 
/*     */           
/*  86 */           Random projectileRandom = new Random();
/*     */ 
/*     */           
/*  89 */           for (int tick = 0; tick < ((Double)power.getValue()).doubleValue(); tick++) {
/*     */ 
/*     */             
/*  92 */             double sin = -Math.sin(Math.toRadians(mc.player.rotationYaw));
/*  93 */             double cos = Math.cos(Math.toRadians(mc.player.rotationYaw));
/*     */ 
/*     */             
/*  96 */             if (projectileRandom.nextBoolean()) {
/*  97 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + sin * 100.0D, mc.player.posY + 5.0D, mc.player.posZ + cos * 100.0D, false));
/*  98 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX - sin * 100.0D, mc.player.posY, mc.player.posZ - cos * 100.0D, true));
/*     */             }
/*     */             else {
/*     */               
/* 102 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX - sin * 100.0D, mc.player.posY, mc.player.posZ - cos * 100.0D, true));
/* 103 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + sin * 100.0D, mc.player.posY + 5.0D, mc.player.posZ + cos * 100.0D, false));
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 108 */           projectileTimer.resetTime();
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\FastProjectileModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
