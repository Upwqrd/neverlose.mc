//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.combat;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.player.InventoryUtil;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class AutoBowReleaseModule
/*    */   extends Module
/*    */ {
/*    */   public static AutoBowReleaseModule INSTANCE;
/*    */   
/*    */   public AutoBowReleaseModule() {
/* 20 */     super("AutoBowRelease", Category.COMBAT, "Automatically releases a drawn bow");
/* 21 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public static Setting<Double> ticks = (new Setting("Ticks", Double.valueOf(3.0D), Double.valueOf(3.0D), Double.valueOf(20.0D), 0))
/* 27 */     .setDescription("Ticks to draw the bow");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 33 */     if (InventoryUtil.isHolding((Item)Items.BOW) && mc.player.isHandActive())
/*    */     {
/*    */       
/* 36 */       if (mc.player.getItemInUseMaxCount() > ((Double)ticks.getValue()).doubleValue()) {
/*    */ 
/*    */         
/* 39 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
/*    */         
/* 41 */         mc.player.stopActiveHand();
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AutoBowReleaseModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
