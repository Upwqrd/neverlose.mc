//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*      */ package cope.cosmos.client.features.modules.combat;
/*      */ import com.mojang.realmsclient.util.Pair;
/*      */ import cope.cosmos.asm.mixins.accessor.ICPacketUseEntity;
/*      */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*      */ import cope.cosmos.client.events.network.PacketEvent;
/*      */ import cope.cosmos.client.events.render.entity.RenderRotationsEvent;
/*      */ import cope.cosmos.client.features.modules.player.SwingModule;
/*      */ import cope.cosmos.client.features.setting.Setting;
/*      */ import cope.cosmos.client.manager.managers.InventoryManager;
/*      */ import cope.cosmos.client.manager.managers.SocialManager;
/*      */ import cope.cosmos.util.combat.DamageUtil;
/*      */ import cope.cosmos.util.combat.EnemyUtil;
/*      */ import cope.cosmos.util.combat.ExplosionUtil;
/*      */ import cope.cosmos.util.entity.EntityUtil;
/*      */ import cope.cosmos.util.holder.Rotation;
/*      */ import cope.cosmos.util.math.MathUtil;
/*      */ import cope.cosmos.util.math.Timer;
/*      */ import cope.cosmos.util.player.AngleUtil;
/*      */ import cope.cosmos.util.player.InventoryUtil;
/*      */ import cope.cosmos.util.player.PlayerUtil;
/*      */ import cope.cosmos.util.render.RenderUtil;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.item.EntityEnderCrystal;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.inventory.ClickType;
/*      */ import net.minecraft.inventory.Slot;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.network.Packet;
/*      */ import net.minecraft.network.play.client.CPacketUseEntity;
/*      */ import net.minecraft.network.play.server.SPacketAnimation;
/*      */ import net.minecraft.network.play.server.SPacketExplosion;
/*      */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*      */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.EnumHand;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.RayTraceResult;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.util.math.Vec3i;
/*      */ import net.minecraft.world.WorldServer;
/*      */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*      */ 
/*      */ public class AutoCrystalModule extends Module {
/*      */   public static AutoCrystalModule INSTANCE;
/*      */   public static Setting<Boolean> multiTask = (new Setting("MultiTask", Boolean.valueOf(true))).setDescription("Explodes only if we are not preforming any actions with our hands");
/*      */   public static Setting<Boolean> whileMining = (new Setting("WhileMining", Boolean.valueOf(true))).setDescription("Explodes only if we are not mining");
/*      */   public static Setting<Boolean> swing = (new Setting("Swing", Boolean.valueOf(true))).setDescription("Swings the players hand when attacking and placing");
/*      */   public static Setting<Interact> interact = (new Setting("Interact", Interact.VANILLA)).setDescription("Interaction with blocks and crystals");
/*      */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.NONE)).setDescription("Rotate to the current process");
/*      */   public static Setting<YawStep> yawStep = (new Setting("YawStep", YawStep.NONE)).setDescription("Limits yaw rotations").setVisible(() -> Boolean.valueOf(!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE)));
/*      */   public static Setting<Double> yawStepThreshold = (new Setting("YawStepThreshold", Double.valueOf(1.0D), Double.valueOf(180.0D), Double.valueOf(180.0D), 0)).setDescription("Max angle to rotate in one tick").setVisible(() -> Boolean.valueOf((!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE) && !((YawStep)yawStep.getValue()).equals(YawStep.NONE))));
/*      */   public static Setting<Boolean> raytrace = (new Setting("Raytrace", Boolean.valueOf(false))).setDescription("Restricts placements through walls");
/*      */   public static Setting<Double> offset = (new Setting("Offset", Double.valueOf(1.0D), Double.valueOf(2.0D), Double.valueOf(2.0D), 0)).setDescription("Crystal placement offset");
/*      */   public static Setting<Boolean> explode = (new Setting("Explode", Boolean.valueOf(true))).setDescription("Explodes crystals");
/*      */   public static Setting<Double> explodeSpeed = (new Setting("ExplodeSpeed", Double.valueOf(1.0D), Double.valueOf(20.0D), Double.valueOf(20.0D), 1)).setDescription("Speed to explode crystals").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Double> attackDelay = (new Setting("AttackDelay", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(5.0D), 1)).setDescription("Speed to explode crystals using old delays").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Double> explodeRange = (new Setting("ExplodeRange", Double.valueOf(1.0D), Double.valueOf(5.0D), Double.valueOf(6.0D), 1)).setDescription("Range to explode crystals").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Double> explodeWallRange = (new Setting("ExplodeWallRange", Double.valueOf(1.0D), Double.valueOf(3.5D), Double.valueOf(6.0D), 1)).setDescription("Range to explode crystals through walls").setVisible(() -> Boolean.valueOf((((Boolean)explode.getValue()).booleanValue() && !((Boolean)raytrace.getValue()).booleanValue())));
/*      */   public static Setting<Boolean> rangeEye = (new Setting("RangeEye", Boolean.valueOf(false))).setDescription("Calculates ranges to the entity's eye").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Double> ticksExisted = (new Setting("TicksExisted", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(5.0D), 0)).setDescription("Minimum age of the crystal").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Double> explodeSwitchDelay = (new Setting("SwitchDelay", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(10.0D), 1)).setDescription("Delay to pause after switching items").setVisible(() -> (Boolean)explode.getValue());
/*      */   public static Setting<Inhibit> inhibit = (new Setting("Inhibit", Inhibit.SEMI)).setDescription("Prevents excessive attacks on crystals").setVisible(() -> (Boolean)explode.getValue());
/*      */   
/*      */   public AutoCrystalModule() {
/*   74 */     super("AutoCrystal", Category.COMBAT, "Places and explodes crystals", () -> ((Boolean)debug.getValue()).booleanValue() ? getDebug() : "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     this.explodeTimer = new Timer();
/*  272 */     this.switchTimer = new Timer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  279 */     this.attackedCrystals = new ConcurrentHashMap<>();
/*  280 */     this.spawnedCrystals = new TreeMap<>();
/*      */ 
/*      */     
/*  283 */     this.inhibitCrystals = new ArrayList<>();
/*  284 */     this.deadCrystals = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  289 */     this.placeTimer = new Timer();
/*      */ 
/*      */ 
/*      */     
/*  293 */     this.autoSwitchTimer = new Timer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     this.placedCrystals = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  304 */     this.desyncTimer = new Timer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  313 */     this.crystalTimer = new Timer();
/*      */ 
/*      */ 
/*      */     
/*  317 */     this.placementPackets = new ArrayList<>();
/*  318 */     this.explosionPackets = new ArrayList<>();
/*      */     INSTANCE = this;
/*      */   }
/*      */   public static Setting<Double> inhibitFactor = (new Setting("inhibitFactor", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(5.0D), 1)).setDescription("Time to wait after inhibiting").setVisible(() -> Boolean.valueOf((((Boolean)explode.getValue()).booleanValue() && ((Inhibit)inhibit.getValue()).equals(Inhibit.FULL)))); public static Setting<Boolean> await = (new Setting("Await", Boolean.valueOf(true))).setDescription("Runs delays on packet time").setVisible(() -> (Boolean)explode.getValue()); public static Setting<Double> yieldProtection = (new Setting("YieldProtection", Double.valueOf(0.0D), Double.valueOf(2.0D), Double.valueOf(5.0D), 1)).setDescription("Inhibit factor").setVisible(() -> Boolean.valueOf((((Boolean)explode.getValue()).booleanValue() && ((Boolean)await.getValue()).booleanValue() && !((Inhibit)inhibit.getValue()).equals(Inhibit.NONE)))); public static Setting<Boolean> place = (new Setting("Place", Boolean.valueOf(true))).setDescription("Places crystals"); public static Setting<Placements> placements = (new Setting("Placements", Placements.NATIVE)).setDescription("Placement calculations for current version").setVisible(() -> (Boolean)place.getValue()); public static Setting<Sequential> sequential = (new Setting("Sequential", Sequential.NORMAL)).setDescription("Timing for placements").setVisible(() -> (Boolean)place.getValue()); public static Setting<Double> placeSpeed = (new Setting("PlaceSpeed", Double.valueOf(1.0D), Double.valueOf(20.0D), Double.valueOf(20.0D), 1)).setDescription("Speed to place crystals").setVisible(() -> (Boolean)place.getValue()); public static Setting<Double> placeRange = (new Setting("PlaceRange", Double.valueOf(1.0D), Double.valueOf(5.0D), Double.valueOf(6.0D), 1)).setDescription("Range to place crystals").setVisible(() -> (Boolean)place.getValue()); public static Setting<Double> placeWallRange = (new Setting("PlaceWallRange", Double.valueOf(1.0D), Double.valueOf(3.5D), Double.valueOf(6.0D), 1)).setDescription("Range to place crystals through walls").setVisible(() -> Boolean.valueOf((((Boolean)place.getValue()).booleanValue() && !((Boolean)raytrace.getValue()).booleanValue()))); public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NONE)).setDescription("Switching to crystals before placement").setVisible(() -> (Boolean)place.getValue()); public static Setting<InventoryManager.Switch> antiWeakness = (new Setting("AntiWeakness", InventoryManager.Switch.NONE)).setDescription("Switches to a tool when attacking crystals to bypass the weakness effect").setVisible(() -> (Boolean)explode.getValue()); public static Setting<Boolean> alternativeSwitch = (new Setting("AlternativeSwitch", Boolean.valueOf(false))).setDescription("Alternative method for switching to crystals").setVisible(() -> Boolean.valueOf(((((Boolean)place.getValue()).booleanValue() && ((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.PACKET)) || (((Boolean)explode.getValue()).booleanValue() && ((InventoryManager.Switch)antiWeakness.getValue()).equals(InventoryManager.Switch.PACKET))))); public static Setting<Double> damage = (new Setting("Damage", Double.valueOf(2.0D), Double.valueOf(4.0D), Double.valueOf(10.0D), 1)).setDescription("Minimum damage done by an action"); public static Setting<Double> lethalMultiplier = (new Setting("LethalMultiplier", Double.valueOf(0.0D), Double.valueOf(1.0D), Double.valueOf(5.0D), 1)).setDescription("Will override damages if we can kill the target in this many crystals"); public static Setting<Boolean> armorBreaker = (new Setting("ArmorBreaker", Boolean.valueOf(true))).setDescription("Attempts to break enemy armor with crystals"); public static Setting<Double> armorScale = (new Setting("ArmorScale", Double.valueOf(0.0D), Double.valueOf(5.0D), Double.valueOf(40.0D), 0)).setDescription("Will override damages if we can break the target's armor").setVisible(() -> (Boolean)armorBreaker.getValue()); public static Setting<Safety> safety = (new Setting("Safety", Safety.NONE)).setDescription("Safety check for processes");
/*      */   
/*      */   public void onThread() {
/*  324 */     this.explosion = getCrystal();
/*  325 */     this.placement = getPlacement();
/*      */ 
/*      */     
/*  328 */     if (this.crystalTimer.passedTime(1L, Timer.Format.SECONDS)) {
/*      */ 
/*      */       
/*  331 */       if (crystalCounts.length - 1 >= 0) {
/*  332 */         System.arraycopy(crystalCounts, 1, crystalCounts, 0, crystalCounts.length - 1);
/*      */       }
/*      */ 
/*      */       
/*  336 */       crystalCounts[crystalCounts.length - 1] = this.lastCrystalCount;
/*      */ 
/*      */       
/*  339 */       this.lastCrystalCount = 0L;
/*  340 */       this.crystalTimer.resetTime();
/*      */     } 
/*      */ 
/*      */     
/*  344 */     if (this.rotateTicks <= 0)
/*      */     {
/*      */       
/*  347 */       if (((Double)inhibitFactor.getValue()).doubleValue() > ((Double)inhibitFactor.getMin()).doubleValue() && ((Inhibit)inhibit.getValue()).equals(Inhibit.FULL)) {
/*      */ 
/*      */         
/*  350 */         Map.Entry<Long, Integer> latestSpawn = this.spawnedCrystals.firstEntry();
/*      */ 
/*      */         
/*  353 */         if (latestSpawn != null)
/*      */         {
/*      */ 
/*      */           
/*  357 */           double explodeDelay = ((Double)inhibitFactor.getValue()).doubleValue() * 50.0D;
/*      */ 
/*      */           
/*  360 */           long switchDelay = ((Double)explodeSwitchDelay.getValue()).longValue() * 25L;
/*      */ 
/*      */           
/*  363 */           boolean delayed = ((System.currentTimeMillis() - ((Long)latestSpawn.getKey()).longValue()) >= explodeDelay && this.switchTimer.passedTime(switchDelay, Timer.Format.MILLISECONDS));
/*      */ 
/*      */           
/*  366 */           if (this.explodeClearance || delayed)
/*      */           {
/*      */             
/*  369 */             this.angleVector = Pair.of(mc.world.getEntityByID(((Integer)latestSpawn.getValue()).intValue()).getPositionVector(), YawStep.FULL);
/*      */ 
/*      */             
/*  372 */             if (attackCrystal(((Integer)latestSpawn.getValue()).intValue()))
/*      */             {
/*      */               
/*  375 */               this.attackedCrystals.put(latestSpawn.getValue(), Long.valueOf(System.currentTimeMillis()));
/*      */ 
/*      */               
/*  378 */               if (lastAttackTime <= 0L) {
/*  379 */                 lastAttackTime = System.currentTimeMillis();
/*      */               }
/*      */ 
/*      */               
/*  383 */               if (attackTimes.length - 1 >= 0) {
/*  384 */                 System.arraycopy(attackTimes, 1, attackTimes, 0, attackTimes.length - 1);
/*      */               }
/*      */ 
/*      */               
/*  388 */               attackTimes[attackTimes.length - 1] = System.currentTimeMillis() - lastAttackTime;
/*      */ 
/*      */               
/*  391 */               lastAttackTime = System.currentTimeMillis();
/*      */ 
/*      */               
/*  394 */               this.explodeClearance = false;
/*  395 */               this.explodeTimer.resetTime();
/*      */ 
/*      */               
/*  398 */               this.spawnedCrystals.clear();
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  405 */       } else if (((Double)attackDelay.getValue()).doubleValue() > ((Double)attackDelay.getMin()).doubleValue()) {
/*      */ 
/*      */         
/*  408 */         if (this.explosion != null) {
/*      */ 
/*      */ 
/*      */           
/*  412 */           long explodeDelay = (long)(((Double)attackDelay.getValue()).doubleValue() * 25.0D);
/*      */ 
/*      */           
/*  415 */           long switchDelay = ((Double)explodeSwitchDelay.getValue()).longValue() * 25L;
/*      */ 
/*      */           
/*  418 */           boolean delayed = (this.explodeTimer.passedTime(explodeDelay, Timer.Format.MILLISECONDS) && this.switchTimer.passedTime(switchDelay, Timer.Format.MILLISECONDS));
/*      */ 
/*      */           
/*  421 */           if (this.explodeClearance || delayed) {
/*      */ 
/*      */             
/*  424 */             this.angleVector = Pair.of(((EntityEnderCrystal)this.explosion.getDamageSource()).getPositionVector(), YawStep.FULL);
/*      */ 
/*      */             
/*  427 */             if (attackCrystal(this.explosion.getDamageSource())) {
/*      */ 
/*      */               
/*  430 */               this.attackedCrystals.put(Integer.valueOf(((EntityEnderCrystal)this.explosion.getDamageSource()).getEntityId()), Long.valueOf(System.currentTimeMillis()));
/*      */ 
/*      */               
/*  433 */               if (lastAttackTime <= 0L) {
/*  434 */                 lastAttackTime = System.currentTimeMillis();
/*      */               }
/*      */ 
/*      */               
/*  438 */               if (attackTimes.length - 1 >= 0) {
/*  439 */                 System.arraycopy(attackTimes, 1, attackTimes, 0, attackTimes.length - 1);
/*      */               }
/*      */ 
/*      */               
/*  443 */               attackTimes[attackTimes.length - 1] = System.currentTimeMillis() - lastAttackTime;
/*      */ 
/*      */               
/*  446 */               lastAttackTime = System.currentTimeMillis();
/*      */ 
/*      */               
/*  449 */               this.explodeClearance = false;
/*  450 */               this.explodeTimer.resetTime();
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }  } 
/*      */   }
/*      */   public static Setting<Double> safetyBalance = (new Setting("SafetyBalance", Double.valueOf(0.1D), Double.valueOf(1.1D), Double.valueOf(3.0D), 1)).setDescription("Multiplier for actions considered unsafe").setVisible(() -> Boolean.valueOf(((Safety)safety.getValue()).equals(Safety.BALANCE))); public static Setting<Boolean> blockDestruction = (new Setting("BlockDestruction", Boolean.valueOf(false))).setDescription("Ignores terrain that can be exploded when calculating damages"); public static Setting<Boolean> targetPlayers = (new Setting("TargetPlayers", Boolean.valueOf(true))).setDescription("Target players"); public static Setting<Boolean> targetPassives = (new Setting("TargetPassives", Boolean.valueOf(false))).setDescription("Target passives"); public static Setting<Boolean> targetNeutrals = (new Setting("TargetNeutrals", Boolean.valueOf(false))).setDescription("Target neutrals"); public static Setting<Boolean> targetHostiles = (new Setting("TargetHostiles", Boolean.valueOf(false))).setDescription("Target hostiles"); public static Setting<Double> targetRange = (new Setting("TargetRange", Double.valueOf(0.1D), Double.valueOf(10.0D), Double.valueOf(15.0D), 1)).setDescription("Range to consider an entity as a target"); public static Setting<Boolean> render = (new Setting("Render", Boolean.valueOf(true))).setDescription("Renders the current process"); public static Setting<Boolean> debug = (new Setting("Debug", Boolean.valueOf(false))).setDescription("Development info"); public static Setting<Text> renderText = (new Setting("RenderText", Text.NONE)).setDescription("Renders the damage of the current process").setVisible(() -> (Boolean)render.getValue()); private Pair<Vec3d, YawStep> angleVector; private Rotation rotateAngles; private int rotateTicks; private final Timer explodeTimer; private final Timer switchTimer; private boolean explodeClearance; private DamageHolder<EntityEnderCrystal> explosion; private final Map<Integer, Long> attackedCrystals; private final TreeMap<Long, Integer> spawnedCrystals; private final List<EntityEnderCrystal> inhibitCrystals; private final List<Integer> deadCrystals; private final Timer placeTimer; private boolean placeClearance; private final Timer autoSwitchTimer; private DamageHolder<BlockPos> placement; private final Map<BlockPos, Long> placedCrystals; private final Timer desyncTimer; private static long lastAttackTime; private static long lastConfirmTime; private static final long[] attackTimes = new long[10]; private long lastCrystalCount; private final Timer crystalTimer;
/*      */   private static final long[] crystalCounts = new long[10];
/*      */   private final List<BlockPos> placementPackets;
/*      */   private final List<Integer> explosionPackets;
/*      */   
/*      */   public void onUpdate() {
/*  462 */     if (((Interact)interact.getValue()).equals(Interact.STRICT) && ((Inhibit)inhibit.getValue()).equals(Inhibit.FULL))
/*      */     {
/*      */       
/*  465 */       if (isDesynced())
/*      */       {
/*      */         
/*  468 */         if (this.desyncTimer.passedTime(5L, Timer.Format.SECONDS)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  475 */           this.desyncTimer.resetTime();
/*      */ 
/*      */           
/*  478 */           getCosmos().getChatManager().sendClientMessage("[AutoCrystal] Re-synced!");
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  484 */     if (this.rotateTicks <= 0) {
/*      */ 
/*      */       
/*  487 */       if (((Double)attackDelay.getValue()).doubleValue() <= ((Double)attackDelay.getMin()).doubleValue() || (((Double)inhibitFactor.getValue()).doubleValue() > ((Double)inhibitFactor.getMin()).doubleValue() && ((Inhibit)inhibit.getValue()).equals(Inhibit.FULL)))
/*      */       {
/*      */         
/*  490 */         if (this.explosion != null) {
/*      */ 
/*      */ 
/*      */           
/*  494 */           long explodeDelay = (long)((((Double)explodeSpeed.getMax()).doubleValue() - ((Double)explodeSpeed.getValue()).doubleValue()) * 50.0D);
/*      */ 
/*      */           
/*  497 */           if (((Boolean)await.getValue()).booleanValue()) {
/*  498 */             explodeDelay = (long)(getAverageWaitTime() + 50.0D * ((Double)yieldProtection.getValue()).doubleValue());
/*      */           }
/*      */ 
/*      */           
/*  502 */           long switchDelay = ((Double)explodeSwitchDelay.getValue()).longValue() * 25L;
/*      */ 
/*      */           
/*  505 */           boolean delayed = (this.explodeTimer.passedTime(explodeDelay, Timer.Format.MILLISECONDS) && this.switchTimer.passedTime(switchDelay, Timer.Format.MILLISECONDS));
/*      */ 
/*      */           
/*  508 */           if (this.explodeClearance || delayed) {
/*      */ 
/*      */ 
/*      */             
/*  512 */             this.angleVector = Pair.of(((EntityEnderCrystal)this.explosion.getDamageSource()).getPositionVector(), YawStep.FULL);
/*      */ 
/*      */             
/*  515 */             if (attackCrystal(this.explosion.getDamageSource())) {
/*      */ 
/*      */               
/*  518 */               this.attackedCrystals.put(Integer.valueOf(((EntityEnderCrystal)this.explosion.getDamageSource()).getEntityId()), Long.valueOf(System.currentTimeMillis()));
/*      */ 
/*      */               
/*  521 */               if (lastAttackTime <= 0L) {
/*  522 */                 lastAttackTime = System.currentTimeMillis();
/*      */               }
/*      */ 
/*      */               
/*  526 */               if (attackTimes.length - 1 >= 0) {
/*  527 */                 System.arraycopy(attackTimes, 1, attackTimes, 0, attackTimes.length - 1);
/*      */               }
/*      */ 
/*      */               
/*  531 */               attackTimes[attackTimes.length - 1] = System.currentTimeMillis() - lastAttackTime;
/*      */ 
/*      */               
/*  534 */               lastAttackTime = System.currentTimeMillis();
/*      */ 
/*      */               
/*  537 */               this.explodeClearance = false;
/*  538 */               this.explodeTimer.resetTime();
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  545 */       if (this.placement != null) {
/*      */ 
/*      */ 
/*      */         
/*  549 */         long placeDelay = (long)((((Double)placeSpeed.getMax()).doubleValue() - ((Double)placeSpeed.getValue()).doubleValue()) * 50.0D);
/*      */ 
/*      */         
/*  552 */         boolean delayed = (((Double)placeSpeed.getValue()).doubleValue() >= ((Double)placeSpeed.getMax()).doubleValue() || this.placeTimer.passedTime(placeDelay, Timer.Format.MILLISECONDS));
/*      */ 
/*      */         
/*  555 */         if (this.placeClearance || delayed) {
/*      */ 
/*      */           
/*  558 */           this.angleVector = Pair.of((new Vec3d((Vec3i)this.placement.getDamageSource())).add(0.5D, 0.5D, 0.5D), YawStep.NONE);
/*      */ 
/*      */           
/*  561 */           if (placeCrystal(this.placement.getDamageSource()))
/*      */           {
/*      */             
/*  564 */             this.placedCrystals.put(this.placement.getDamageSource(), Long.valueOf(System.currentTimeMillis()));
/*      */ 
/*      */             
/*  567 */             this.placeClearance = false;
/*  568 */             this.placeTimer.resetTime();
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/*  575 */       this.rotateTicks--;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onRender3D() {
/*  583 */     if (((Boolean)render.getValue()).booleanValue() && this.placement != null)
/*      */     {
/*      */       
/*  586 */       if (isHoldingCrystal()) {
/*      */ 
/*      */         
/*  589 */         RenderUtil.drawBox((new RenderBuilder())
/*  590 */             .position(this.placement.getDamageSource())
/*  591 */             .color(ColorUtil.getPrimaryAlphaColor(60))
/*  592 */             .box(RenderBuilder.Box.BOTH)
/*  593 */             .setup()
/*  594 */             .line(1.5F)
/*  595 */             .depth(true)
/*  596 */             .blend()
/*  597 */             .texture());
/*      */ 
/*      */ 
/*      */         
/*  601 */         if (!((Text)renderText.getValue()).equals(Text.NONE)) {
/*      */ 
/*      */           
/*  604 */           double targetDamageRounded = MathUtil.roundDouble(this.placement.getTargetDamage(), 1);
/*  605 */           double localDamageRounded = MathUtil.roundDouble(this.placement.getLocalDamage(), 1);
/*      */           
/*  607 */           if (((Text)renderText.getValue()).equals(Text.BOTH)) {
/*      */ 
/*      */             
/*  610 */             String placementInfoLineUpper = "Target: " + targetDamageRounded;
/*  611 */             String placementInfoLineLower = "Local: " + localDamageRounded;
/*      */ 
/*      */             
/*  614 */             RenderUtil.drawNametag(this.placement
/*  615 */                 .getDamageSource(), 0.7F, placementInfoLineUpper);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  621 */             RenderUtil.drawNametag(this.placement
/*  622 */                 .getDamageSource(), 0.3F, placementInfoLineLower);
/*      */           } else {
/*      */             String placementInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  634 */             switch ((Text)renderText.getValue()) {
/*      */               
/*      */               default:
/*  637 */                 placementInfo = String.valueOf(targetDamageRounded);
/*      */                 break;
/*      */               case VANILLA:
/*  640 */                 placementInfo = String.valueOf(localDamageRounded);
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/*  645 */             RenderUtil.drawNametag(this.placement
/*  646 */                 .getDamageSource(), 0.5F, placementInfo);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onEnable() {
/*  658 */     super.onEnable();
/*      */ 
/*      */     
/*  661 */     this.explodeClearance = false;
/*  662 */     this.placeClearance = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onDisable() {
/*  667 */     super.onDisable();
/*      */ 
/*      */     
/*  670 */     this.explosion = null;
/*  671 */     this.placement = null;
/*  672 */     this.angleVector = null;
/*  673 */     this.rotateAngles = null;
/*  674 */     this.rotateTicks = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  679 */     this.inhibitCrystals.clear();
/*  680 */     this.deadCrystals.clear();
/*      */     
/*  682 */     this.spawnedCrystals.clear();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isActive() {
/*  687 */     return (isEnabled() && (this.explosion != null || this.placement != null) && isHoldingCrystal());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  694 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketHeldItemChange) {
/*      */ 
/*      */       
/*  697 */       this.switchTimer.resetTime();
/*      */ 
/*      */       
/*  700 */       this.autoSwitchTimer.resetTime();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*      */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/*  708 */     boolean externalExplosion = false;
/*      */ 
/*      */     
/*  711 */     if (event.getPacket() instanceof SPacketSoundEffect && ((SPacketSoundEffect)event.getPacket()).getSound().equals(SoundEvents.ENTITY_GENERIC_EXPLODE) && ((SPacketSoundEffect)event.getPacket()).getCategory().equals(SoundCategory.BLOCKS))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  727 */       mc.addScheduledTask(() -> {
/*      */             for (Entity crystal : new ArrayList(mc.world.loadedEntityList)) {
/*      */               if (crystal == null || crystal.isDead) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               if (!(crystal instanceof EntityEnderCrystal)) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               double soundRange = crystal.getDistance(((SPacketSoundEffect)event.getPacket()).getX() + 0.5D, ((SPacketSoundEffect)event.getPacket()).getY() + 0.5D, ((SPacketSoundEffect)event.getPacket()).getZ() + 0.5D);
/*      */ 
/*      */               
/*      */               if (soundRange > 11.0D) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */               
/*      */               this.inhibitCrystals.add((EntityEnderCrystal)crystal);
/*      */ 
/*      */               
/*      */               crystal.setDead();
/*      */ 
/*      */               
/*      */               mc.world.removeEntity(crystal);
/*      */ 
/*      */               
/*      */               if (((Sequential)sequential.getValue()).equals(Sequential.STRICT)) {
/*      */                 this.deadCrystals.add(Integer.valueOf(crystal.getEntityId()));
/*      */ 
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */ 
/*      */               
/*      */               mc.world.removeEntityDangerously(crystal);
/*      */             } 
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*  772 */     if (event.getPacket() instanceof SPacketExplosion) {
/*      */ 
/*      */       
/*  775 */       List<EntityEnderCrystal> explosionCrystals = mc.world.getEntitiesWithinAABB(EntityEnderCrystal.class, new AxisAlignedBB(new BlockPos(((SPacketExplosion)event.getPacket()).getX(), ((SPacketExplosion)event.getPacket()).getY(), ((SPacketExplosion)event.getPacket()).getZ())));
/*      */ 
/*      */       
/*  778 */       for (EntityEnderCrystal crystal : explosionCrystals) {
/*      */ 
/*      */         
/*  781 */         if (!this.inhibitCrystals.contains(crystal)) {
/*  782 */           externalExplosion = true;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  788 */       mc.addScheduledTask(() -> {
/*      */             for (Entity crystal : new ArrayList(mc.world.loadedEntityList)) {
/*      */               if (crystal == null || crystal.isDead) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               if (!(crystal instanceof EntityEnderCrystal)) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               double soundRange = crystal.getDistance(((SPacketExplosion)event.getPacket()).getX() + 0.5D, ((SPacketExplosion)event.getPacket()).getY() + 0.5D, ((SPacketExplosion)event.getPacket()).getZ() + 0.5D);
/*      */ 
/*      */               
/*      */               if (soundRange > ((SPacketExplosion)event.getPacket()).getStrength()) {
/*      */                 continue;
/*      */               }
/*      */ 
/*      */               
/*      */               this.inhibitCrystals.add((EntityEnderCrystal)crystal);
/*      */ 
/*      */               
/*      */               crystal.setDead();
/*      */ 
/*      */               
/*      */               mc.world.removeEntity(crystal);
/*      */ 
/*      */               
/*      */               if (((Sequential)sequential.getValue()).equals(Sequential.STRICT)) {
/*      */                 this.deadCrystals.add(Integer.valueOf(crystal.getEntityId()));
/*      */ 
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */ 
/*      */               
/*      */               mc.world.removeEntityDangerously(crystal);
/*      */             } 
/*      */           });
/*      */     } 
/*      */ 
/*      */     
/*  833 */     if (event.getPacket() instanceof SPacketDestroyEntities)
/*      */     {
/*      */       
/*  836 */       for (int entityId : ((SPacketDestroyEntities)event.getPacket()).getEntityIDs()) {
/*      */ 
/*      */         
/*  839 */         Entity crystal = mc.world.getEntityByID(entityId);
/*      */ 
/*      */         
/*  842 */         if (crystal instanceof EntityEnderCrystal) {
/*      */ 
/*      */           
/*  845 */           if (!this.inhibitCrystals.contains(crystal)) {
/*  846 */             externalExplosion = true;
/*      */           }
/*      */           
/*  849 */           crystal.setDead();
/*      */ 
/*      */           
/*  852 */           mc.addScheduledTask(() -> {
/*      */                 mc.world.removeEntity(crystal);
/*      */                 
/*      */                 mc.world.removeEntityDangerously(crystal);
/*      */               });
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  861 */     if (externalExplosion)
/*      */     {
/*      */       
/*  864 */       if (((Sequential)sequential.getValue()).equals(Sequential.NORMAL))
/*      */       {
/*      */         
/*  867 */         if (this.placement != null) {
/*      */ 
/*      */           
/*  870 */           this.angleVector = Pair.of((new Vec3d((Vec3i)this.placement.getDamageSource())).add(0.5D, 0.5D, 0.5D), YawStep.NONE);
/*      */ 
/*      */           
/*  873 */           if (placeCrystal(this.placement.getDamageSource()))
/*      */           {
/*      */             
/*  876 */             this.placedCrystals.put(this.placement.getDamageSource(), Long.valueOf(System.currentTimeMillis()));
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  883 */     if (event.getPacket() instanceof SPacketSpawnObject && ((SPacketSpawnObject)event.getPacket()).getType() == 51) {
/*      */ 
/*      */       
/*  886 */       BlockPos spawnPosition = new BlockPos(((SPacketSpawnObject)event.getPacket()).getX() - 0.5D, ((SPacketSpawnObject)event.getPacket()).getY(), ((SPacketSpawnObject)event.getPacket()).getZ() - 0.5D);
/*      */ 
/*      */       
/*  889 */       if (((Boolean)await.getValue()).booleanValue()) {
/*      */ 
/*      */         
/*  892 */         this.angleVector = Pair.of(new Vec3d((Vec3i)spawnPosition), YawStep.FULL);
/*      */ 
/*      */         
/*  895 */         if (this.placementPackets.contains(spawnPosition.down())) {
/*      */ 
/*      */           
/*  898 */           if (((Double)inhibitFactor.getValue()).doubleValue() > ((Double)inhibitFactor.getMin()).doubleValue() && ((Inhibit)inhibit.getValue()).equals(Inhibit.FULL)) {
/*      */ 
/*      */             
/*  901 */             this.spawnedCrystals.put(Long.valueOf(System.currentTimeMillis()), Integer.valueOf(((SPacketSpawnObject)event.getPacket()).getEntityID()));
/*      */ 
/*      */           
/*      */           }
/*  905 */           else if (((Double)attackDelay.getValue()).doubleValue() > ((Double)attackDelay.getMin()).doubleValue()) {
/*      */ 
/*      */             
/*  908 */             this.explodeClearance = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  915 */           else if (attackCrystal(((SPacketSpawnObject)event.getPacket()).getEntityID())) {
/*      */ 
/*      */             
/*  918 */             this.attackedCrystals.put(Integer.valueOf(((SPacketSpawnObject)event.getPacket()).getEntityID()), Long.valueOf(System.currentTimeMillis()));
/*      */ 
/*      */             
/*  921 */             if (lastAttackTime <= 0L) {
/*  922 */               lastAttackTime = System.currentTimeMillis();
/*      */             }
/*      */ 
/*      */             
/*  926 */             if (attackTimes.length - 1 >= 0) {
/*  927 */               System.arraycopy(attackTimes, 1, attackTimes, 0, attackTimes.length - 1);
/*      */             }
/*      */ 
/*      */             
/*  931 */             attackTimes[attackTimes.length - 1] = System.currentTimeMillis() - lastAttackTime;
/*      */ 
/*      */             
/*  934 */             lastAttackTime = System.currentTimeMillis();
/*      */             
/*  936 */             this.explodeClearance = false;
/*  937 */             this.explodeTimer.resetTime();
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  942 */           this.placementPackets.clear();
/*      */ 
/*      */           
/*  945 */           this.placedCrystals.remove(spawnPosition.down());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onRenderCrystal(RenderCrystalEvent.RenderCrystalPreEvent event) {
/*  955 */     if (this.deadCrystals.contains(Integer.valueOf(event.getEntity().getEntityId())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onEntityRemove(EntityWorldEvent.EntityRemoveEvent event) {
/*  964 */     if (event.getEntity() instanceof EntityEnderCrystal) {
/*      */ 
/*      */       
/*  967 */       if (this.attackedCrystals.containsKey(Integer.valueOf(event.getEntity().getEntityId()))) {
/*      */ 
/*      */         
/*  970 */         lastConfirmTime = System.currentTimeMillis() - ((Long)this.attackedCrystals.remove(Integer.valueOf(event.getEntity().getEntityId()))).longValue();
/*      */ 
/*      */         
/*  973 */         this.lastCrystalCount++;
/*      */       } 
/*      */ 
/*      */       
/*  977 */       if (this.explosionPackets.contains(Integer.valueOf(event.getEntity().getEntityId())))
/*      */       {
/*      */         
/*  980 */         this.explosionPackets.clear();
/*      */       }
/*      */       
/*  983 */       this.inhibitCrystals.remove(event.getEntity());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*      */   public void onRotationUpdate(RotationUpdateEvent event) {
/*  991 */     if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE))
/*      */     {
/*      */       
/*  994 */       if (isActive())
/*      */       {
/*      */         
/*  997 */         if (this.angleVector != null) {
/*      */ 
/*      */           
/* 1000 */           event.setCanceled(true);
/*      */ 
/*      */           
/* 1003 */           this.rotateAngles = AngleUtil.calculateAngles((Vec3d)this.angleVector.first());
/*      */ 
/*      */           
/* 1006 */           if (!((YawStep)yawStep.getValue()).equals(YawStep.NONE)) {
/*      */ 
/*      */             
/* 1009 */             Rotation serverRotation = getCosmos().getRotationManager().getServerRotation();
/*      */ 
/*      */             
/* 1012 */             float yaw = MathHelper.wrapDegrees(serverRotation.getYaw());
/*      */ 
/*      */             
/* 1015 */             float angleDifference = this.rotateAngles.getYaw() - yaw;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1020 */             if (Math.abs(angleDifference) > 180.0F) {
/*      */ 
/*      */               
/* 1023 */               float adjust = (angleDifference > 0.0F) ? -360.0F : 360.0F;
/* 1024 */               angleDifference += adjust;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 1029 */             if (Math.abs(angleDifference) > ((Double)yawStepThreshold.getValue()).doubleValue())
/*      */             {
/*      */               
/* 1032 */               if (((YawStep)yawStep.getValue()).equals(YawStep.FULL) || (((YawStep)yawStep.getValue()).equals(YawStep.SEMI) && ((YawStep)this.angleVector.second()).equals(YawStep.FULL)))
/*      */               {
/*      */                 
/* 1035 */                 int rotationDirection = (angleDifference > 0.0F) ? 1 : -1;
/*      */ 
/*      */                 
/* 1038 */                 yaw = (float)(yaw + ((Double)yawStepThreshold.getValue()).doubleValue() * rotationDirection);
/*      */ 
/*      */                 
/* 1041 */                 this.rotateAngles = new Rotation(yaw, this.rotateAngles.getPitch());
/*      */ 
/*      */                 
/* 1044 */                 if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 1045 */                   mc.player.rotationYaw = this.rotateAngles.getYaw();
/* 1046 */                   mc.player.rotationYawHead = this.rotateAngles.getYaw();
/* 1047 */                   mc.player.rotationPitch = this.rotateAngles.getPitch();
/*      */                 } 
/*      */ 
/*      */                 
/* 1051 */                 getCosmos().getRotationManager().setRotation(this.rotateAngles);
/*      */ 
/*      */                 
/* 1054 */                 this.rotateTicks++;
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */             else
/*      */             {
/* 1061 */               if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 1062 */                 mc.player.rotationYaw = this.rotateAngles.getYaw();
/* 1063 */                 mc.player.rotationYawHead = this.rotateAngles.getYaw();
/* 1064 */                 mc.player.rotationPitch = this.rotateAngles.getPitch();
/*      */               } 
/*      */ 
/*      */               
/* 1068 */               getCosmos().getRotationManager().setRotation(this.rotateAngles);
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1076 */             if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 1077 */               mc.player.rotationYaw = this.rotateAngles.getYaw();
/* 1078 */               mc.player.rotationYawHead = this.rotateAngles.getYaw();
/* 1079 */               mc.player.rotationPitch = this.rotateAngles.getPitch();
/*      */             } 
/*      */ 
/*      */             
/* 1083 */             getCosmos().getRotationManager().setRotation(this.rotateAngles);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @SubscribeEvent
/*      */   public void onRenderRotations(RenderRotationsEvent event) {
/* 1094 */     if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.PACKET))
/*      */     {
/*      */       
/* 1097 */       if (isActive())
/*      */       {
/*      */         
/* 1100 */         if (this.rotateAngles != null) {
/*      */ 
/*      */           
/* 1103 */           event.setCanceled(true);
/*      */ 
/*      */           
/* 1106 */           event.setYaw(this.rotateAngles.getYaw());
/* 1107 */           event.setPitch(this.rotateAngles.getPitch());
/*      */         } 
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DamageHolder<EntityEnderCrystal> getCrystal() {
/* 1124 */     TreeMap<Double, DamageHolder<EntityEnderCrystal>> validCrystals = new TreeMap<>();
/*      */ 
/*      */     
/* 1127 */     for (Entity crystal : new ArrayList(mc.world.loadedEntityList)) {
/*      */ 
/*      */       
/* 1130 */       if (crystal == null || crystal.isDead) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1135 */       if (!(crystal instanceof EntityEnderCrystal)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1140 */       long elapsedTime = System.currentTimeMillis() - ((Long)this.placedCrystals.getOrDefault((new BlockPos(crystal.getPositionVector())).down(), Long.valueOf(System.currentTimeMillis()))).longValue();
/*      */ 
/*      */       
/* 1143 */       if (crystal.ticksExisted < ((Double)ticksExisted.getValue()).doubleValue() && ((float)elapsedTime / 50.0F) < ((Double)ticksExisted.getValue()).doubleValue() && !((Inhibit)inhibit.getValue()).equals(Inhibit.NONE)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1148 */       if (this.inhibitCrystals.contains(crystal) && !((Inhibit)inhibit.getValue()).equals(Inhibit.NONE)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1153 */       double crystalRange = mc.player.getDistance(crystal.posX, ((Boolean)rangeEye.getValue()).booleanValue() ? (crystal.posY + crystal.getEyeHeight()) : crystal.posY, crystal.posZ);
/*      */ 
/*      */       
/* 1156 */       if (crystalRange > ((Double)explodeRange.getValue()).doubleValue()) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1161 */       boolean isNotVisible = RaytraceUtil.isNotVisible(crystal, crystal.getEyeHeight());
/*      */ 
/*      */       
/* 1164 */       if (isNotVisible && (
/* 1165 */         crystalRange > ((Double)explodeWallRange.getValue()).doubleValue() || ((Boolean)raytrace.getValue()).booleanValue())) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1171 */       double localDamage = ExplosionUtil.getDamageFromExplosion((Entity)mc.player, crystal.getPositionVector(), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */       
/* 1174 */       for (Entity entity : new ArrayList(mc.world.loadedEntityList)) {
/*      */ 
/*      */         
/* 1177 */         if (entity == null || entity.equals(mc.player) || entity.getEntityId() < 0 || EnemyUtil.isDead(entity) || getCosmos().getSocialManager().getSocial(entity.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1182 */         if (entity instanceof EntityEnderCrystal) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1187 */         if (entity.isBeingRidden() && entity.getPassengers().contains(mc.player)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1192 */         if ((entity instanceof EntityPlayer && !((Boolean)targetPlayers.getValue()).booleanValue()) || (EntityUtil.isPassiveMob(entity) && !((Boolean)targetPassives.getValue()).booleanValue()) || (EntityUtil.isNeutralMob(entity) && !((Boolean)targetNeutrals.getValue()).booleanValue()) || (EntityUtil.isHostileMob(entity) && !((Boolean)targetHostiles.getValue()).booleanValue())) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1197 */         double entityRange = mc.player.getDistance(entity);
/*      */ 
/*      */         
/* 1200 */         if (entityRange > ((Double)targetRange.getValue()).doubleValue()) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1205 */         double targetDamage = ExplosionUtil.getDamageFromExplosion(entity, crystal.getPositionVector(), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */         
/* 1208 */         double safetyIndex = 1.0D;
/*      */ 
/*      */         
/* 1211 */         if (DamageUtil.canTakeDamage()) {
/*      */ 
/*      */           
/* 1214 */           double health = PlayerUtil.getHealth();
/*      */ 
/*      */           
/* 1217 */           if (localDamage + 0.5D > health) {
/* 1218 */             safetyIndex = -9999.0D;
/*      */ 
/*      */           
/*      */           }
/* 1222 */           else if (((Safety)safety.getValue()).equals(Safety.STABLE)) {
/*      */ 
/*      */             
/* 1225 */             double efficiency = targetDamage - localDamage;
/*      */ 
/*      */             
/* 1228 */             if (efficiency < 0.0D && Math.abs(efficiency) < 0.25D) {
/* 1229 */               efficiency = 0.0D;
/*      */             }
/*      */             
/* 1232 */             safetyIndex = efficiency;
/*      */ 
/*      */           
/*      */           }
/* 1236 */           else if (((Safety)safety.getValue()).equals(Safety.BALANCE)) {
/*      */ 
/*      */             
/* 1239 */             double balance = targetDamage * ((Double)safetyBalance.getValue()).doubleValue();
/*      */ 
/*      */             
/* 1242 */             safetyIndex = balance - localDamage;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1247 */         if (safetyIndex < 0.0D) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1252 */         validCrystals.put(Double.valueOf(targetDamage), new DamageHolder<>((EntityEnderCrystal)crystal, entity, targetDamage, localDamage));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1257 */     if (!validCrystals.isEmpty()) {
/*      */ 
/*      */       
/* 1260 */       DamageHolder<EntityEnderCrystal> bestCrystal = (DamageHolder<EntityEnderCrystal>)validCrystals.lastEntry().getValue();
/*      */ 
/*      */       
/* 1263 */       if (bestCrystal.getTargetDamage() > 1.5D) {
/*      */ 
/*      */         
/* 1266 */         boolean lethal = false;
/*      */ 
/*      */         
/* 1269 */         double health = EnemyUtil.getHealth(bestCrystal.getTarget());
/*      */ 
/*      */         
/* 1272 */         if (health <= 2.0D) {
/* 1273 */           lethal = true;
/*      */         }
/*      */ 
/*      */         
/* 1277 */         if (((Boolean)armorBreaker.getValue()).booleanValue() && 
/* 1278 */           bestCrystal.getTarget() instanceof EntityPlayer)
/*      */         {
/*      */           
/* 1281 */           for (ItemStack armor : bestCrystal.getTarget().getArmorInventoryList()) {
/* 1282 */             if (armor != null && !armor.getItem().equals(Items.AIR)) {
/*      */ 
/*      */               
/* 1285 */               float armorDurability = (armor.getMaxDamage() - armor.getItemDamage()) / armor.getMaxDamage() * 100.0F;
/*      */ 
/*      */               
/* 1288 */               if (armorDurability < ((Double)armorScale.getValue()).doubleValue()) {
/* 1289 */                 lethal = true;
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */         
/* 1298 */         double lethality = bestCrystal.getTargetDamage() * ((Double)lethalMultiplier.getValue()).doubleValue();
/*      */ 
/*      */         
/* 1301 */         if (health - lethality < 0.5D) {
/* 1302 */           lethal = true;
/*      */         }
/*      */ 
/*      */         
/* 1306 */         if (lethal || bestCrystal.getTargetDamage() > ((Double)damage.getValue()).doubleValue())
/*      */         {
/*      */           
/* 1309 */           return bestCrystal;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1315 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DamageHolder<BlockPos> getPlacement() {
/* 1325 */     if (((Boolean)place.getValue()).booleanValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1332 */       TreeMap<Double, DamageHolder<BlockPos>> validPlacements = new TreeMap<>();
/*      */ 
/*      */       
/* 1335 */       for (BlockPos position : BlockUtil.getBlocksInArea((EntityPlayer)mc.player, new AxisAlignedBB(
/* 1336 */             -((Double)placeRange.getValue()).doubleValue(), -((Double)placeRange.getValue()).doubleValue(), -((Double)placeRange.getValue()).doubleValue(), ((Double)placeRange.getValue()).doubleValue(), ((Double)placeRange.getValue()).doubleValue(), ((Double)placeRange.getValue()).doubleValue()))) {
/*      */ 
/*      */ 
/*      */         
/* 1340 */         if (!canPlaceCrystal(position)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1345 */         double placementRange = BlockUtil.getDistanceToCenter((EntityPlayer)mc.player, position);
/*      */ 
/*      */         
/* 1348 */         if (placementRange > ((Double)placeRange.getValue()).doubleValue() || placementRange > ((Double)explodeRange.getValue()).doubleValue()) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1353 */         boolean isNotVisible = RaytraceUtil.isNotVisible(position, 2.70000004768372D);
/*      */ 
/*      */         
/* 1356 */         if (isNotVisible && (
/* 1357 */           placementRange > ((Double)placeWallRange.getValue()).doubleValue() || placementRange > ((Double)explodeWallRange.getValue()).doubleValue() || ((Boolean)raytrace.getValue()).booleanValue())) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1363 */         double localDamage = ExplosionUtil.getDamageFromExplosion((Entity)mc.player, (new Vec3d((Vec3i)position)).add(0.5D, 1.0D, 0.5D), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */         
/* 1366 */         for (Entity entity : new ArrayList(mc.world.loadedEntityList)) {
/*      */ 
/*      */           
/* 1369 */           if (entity == null || entity.equals(mc.player) || entity.getEntityId() < 0 || EnemyUtil.isDead(entity) || getCosmos().getSocialManager().getSocial(entity.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1374 */           if (entity instanceof EntityEnderCrystal) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1379 */           if (entity.isBeingRidden() && entity.getPassengers().contains(mc.player)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1384 */           if ((entity instanceof EntityPlayer && !((Boolean)targetPlayers.getValue()).booleanValue()) || (EntityUtil.isPassiveMob(entity) && !((Boolean)targetPassives.getValue()).booleanValue()) || (EntityUtil.isNeutralMob(entity) && !((Boolean)targetNeutrals.getValue()).booleanValue()) || (EntityUtil.isHostileMob(entity) && !((Boolean)targetHostiles.getValue()).booleanValue())) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1389 */           double entityRange = mc.player.getDistance(entity);
/*      */ 
/*      */           
/* 1392 */           if (entityRange > ((Double)targetRange.getValue()).doubleValue()) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1397 */           double targetDamage = ExplosionUtil.getDamageFromExplosion(entity, (new Vec3d((Vec3i)position)).add(0.5D, 1.0D, 0.5D), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */           
/* 1400 */           double safetyIndex = 1.0D;
/*      */ 
/*      */           
/* 1403 */           if (DamageUtil.canTakeDamage()) {
/*      */ 
/*      */             
/* 1406 */             double health = PlayerUtil.getHealth();
/*      */ 
/*      */             
/* 1409 */             if (localDamage + 0.5D > health) {
/* 1410 */               safetyIndex = -9999.0D;
/*      */ 
/*      */             
/*      */             }
/* 1414 */             else if (((Safety)safety.getValue()).equals(Safety.STABLE)) {
/*      */ 
/*      */               
/* 1417 */               double efficiency = targetDamage - localDamage;
/*      */ 
/*      */               
/* 1420 */               if (efficiency < 0.0D && Math.abs(efficiency) < 0.25D) {
/* 1421 */                 efficiency = 0.0D;
/*      */               }
/*      */               
/* 1424 */               safetyIndex = efficiency;
/*      */ 
/*      */             
/*      */             }
/* 1428 */             else if (((Safety)safety.getValue()).equals(Safety.BALANCE)) {
/*      */ 
/*      */               
/* 1431 */               double balance = targetDamage * ((Double)safetyBalance.getValue()).doubleValue();
/*      */ 
/*      */               
/* 1434 */               safetyIndex = balance - localDamage;
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 1439 */           if (safetyIndex < 0.0D) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1444 */           validPlacements.put(Double.valueOf(targetDamage), new DamageHolder<>(position, entity, targetDamage, localDamage));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1449 */       if (!validPlacements.isEmpty()) {
/*      */ 
/*      */         
/* 1452 */         DamageHolder<BlockPos> bestPlacement = (DamageHolder<BlockPos>)validPlacements.lastEntry().getValue();
/*      */ 
/*      */         
/* 1455 */         if (bestPlacement.getTargetDamage() > 1.5D) {
/*      */ 
/*      */           
/* 1458 */           boolean lethal = false;
/*      */ 
/*      */           
/* 1461 */           double health = EnemyUtil.getHealth(bestPlacement.getTarget());
/*      */ 
/*      */           
/* 1464 */           if (health <= 2.0D) {
/* 1465 */             lethal = true;
/*      */           }
/*      */ 
/*      */           
/* 1469 */           if (((Boolean)armorBreaker.getValue()).booleanValue() && 
/* 1470 */             bestPlacement.getTarget() instanceof EntityPlayer)
/*      */           {
/*      */             
/* 1473 */             for (ItemStack armor : bestPlacement.getTarget().getArmorInventoryList()) {
/* 1474 */               if (armor != null && !armor.getItem().equals(Items.AIR)) {
/*      */ 
/*      */                 
/* 1477 */                 float armorDurability = (armor.getMaxDamage() - armor.getItemDamage()) / armor.getMaxDamage() * 100.0F;
/*      */ 
/*      */                 
/* 1480 */                 if (armorDurability < ((Double)armorScale.getValue()).doubleValue()) {
/* 1481 */                   lethal = true;
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }
/*      */           
/* 1490 */           double lethality = bestPlacement.getTargetDamage() * ((Double)lethalMultiplier.getValue()).doubleValue();
/*      */ 
/*      */           
/* 1493 */           if (health - lethality < 0.5D) {
/* 1494 */             lethal = true;
/*      */           }
/*      */ 
/*      */           
/* 1498 */           if (lethal || bestPlacement.getTargetDamage() > ((Double)damage.getValue()).doubleValue())
/*      */           {
/*      */             
/* 1501 */             return bestPlacement;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1508 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean attackCrystal(EntityEnderCrystal in) {
/* 1517 */     return attackCrystal(in.getEntityId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean attackCrystal(int in) {
/* 1529 */     PotionEffect weaknessEffect = mc.player.getActivePotionEffect(MobEffects.WEAKNESS);
/* 1530 */     PotionEffect strengthEffect = mc.player.getActivePotionEffect(MobEffects.STRENGTH);
/*      */ 
/*      */     
/* 1533 */     boolean offhand = mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemEndCrystal;
/*      */ 
/*      */     
/* 1536 */     if (PlayerUtil.isEating() && !offhand && !((Boolean)multiTask.getValue()).booleanValue()) {
/* 1537 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1541 */     if (PlayerUtil.isMining() && !offhand && !((Boolean)whileMining.getValue()).booleanValue()) {
/* 1542 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1546 */     int previousSlot = -1;
/*      */ 
/*      */     
/* 1549 */     int swordSlot = getCosmos().getInventoryManager().searchSlot(ItemSword.class, InventoryManager.InventoryRegion.INVENTORY);
/* 1550 */     int pickSlot = getCosmos().getInventoryManager().searchSlot(ItemPickaxe.class, InventoryManager.InventoryRegion.INVENTORY);
/*      */ 
/*      */     
/* 1553 */     if (!((InventoryManager.Switch)antiWeakness.getValue()).equals(InventoryManager.Switch.NONE))
/*      */     {
/*      */       
/* 1556 */       if (weaknessEffect != null && (strengthEffect == null || strengthEffect.getAmplifier() < weaknessEffect.getAmplifier()))
/*      */       {
/*      */         
/* 1559 */         if (!InventoryUtil.isHolding(ItemSword.class) || !InventoryUtil.isHolding(ItemPickaxe.class)) {
/*      */ 
/*      */           
/* 1562 */           previousSlot = mc.player.inventory.currentItem;
/*      */ 
/*      */           
/* 1565 */           if (((InventoryManager.Switch)antiWeakness.getValue()).equals(InventoryManager.Switch.PACKET) && ((Boolean)alternativeSwitch.getValue()).booleanValue()) {
/*      */ 
/*      */             
/* 1568 */             if (swordSlot != -1)
/*      */             {
/*      */               
/* 1571 */               mc.playerController.windowClick(0, swordSlot + 36, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */             
/*      */             }
/* 1574 */             else if (pickSlot != -1)
/*      */             {
/*      */               
/* 1577 */               mc.playerController.windowClick(0, pickSlot + 36, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/* 1584 */           else if (swordSlot != -1) {
/* 1585 */             getCosmos().getInventoryManager().switchToSlot(swordSlot, (InventoryManager.Switch)antiWeakness.getValue());
/*      */           
/*      */           }
/* 1588 */           else if (pickSlot != -1) {
/* 1589 */             getCosmos().getInventoryManager().switchToSlot(pickSlot, (InventoryManager.Switch)antiWeakness.getValue());
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1597 */     boolean sprintState = false;
/*      */ 
/*      */     
/* 1600 */     if (((Interact)interact.getValue()).equals(Interact.STRICT)) {
/*      */ 
/*      */       
/* 1603 */       sprintState = (mc.player.isSprinting() || ((IEntityPlayerSP)mc.player).getServerSprintState());
/*      */ 
/*      */       
/* 1606 */       if (sprintState);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1612 */     CPacketUseEntity attackPacket = new CPacketUseEntity();
/* 1613 */     ((ICPacketUseEntity)attackPacket).setAction(CPacketUseEntity.Action.ATTACK);
/* 1614 */     ((ICPacketUseEntity)attackPacket).setID(in);
/*      */ 
/*      */     
/* 1617 */     mc.player.connection.sendPacket((Packet)attackPacket);
/*      */ 
/*      */     
/* 1620 */     this.explosionPackets.add(Integer.valueOf(in));
/*      */ 
/*      */     
/* 1623 */     if (((Boolean)swing.getValue()).booleanValue()) {
/*      */ 
/*      */       
/* 1626 */       ItemStack stack = mc.player.getHeldItem(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*      */ 
/*      */       
/* 1629 */       if (!stack.isEmpty() && 
/* 1630 */         !stack.getItem().onEntitySwing((EntityLivingBase)mc.player, stack))
/*      */       {
/*      */         
/* 1633 */         if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= ((IEntityLivingBase)mc.player).hookGetArmSwingAnimationEnd() / 2 || mc.player.swingProgressInt < 0) {
/* 1634 */           mc.player.swingProgressInt = -1;
/* 1635 */           mc.player.isSwingInProgress = true;
/* 1636 */           mc.player.swingingHand = SwingModule.INSTANCE.isEnabled() ? SwingModule.INSTANCE.getHand() : (offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*      */ 
/*      */           
/* 1639 */           if (mc.player.world instanceof WorldServer) {
/* 1640 */             ((WorldServer)mc.player.world).getEntityTracker().sendToTracking((Entity)mc.player, (Packet)new SPacketAnimation((Entity)mc.player, offhand ? 3 : 0));
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1648 */     mc.player.connection.sendPacket((Packet)new CPacketAnimation((!offhand || (weaknessEffect != null && (strengthEffect == null || strengthEffect.getAmplifier() < weaknessEffect.getAmplifier()))) ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND));
/*      */ 
/*      */     
/* 1651 */     if (sprintState);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1656 */     if (previousSlot != -1)
/*      */     {
/*      */       
/* 1659 */       if (((InventoryManager.Switch)antiWeakness.getValue()).equals(InventoryManager.Switch.PACKET))
/*      */       {
/*      */         
/* 1662 */         if (((Boolean)alternativeSwitch.getValue()).booleanValue()) {
/*      */ 
/*      */           
/* 1665 */           if (swordSlot != -1)
/*      */           {
/*      */             
/* 1668 */             mc.playerController.windowClick(0, swordSlot + 36, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */           
/*      */           }
/* 1671 */           else if (pickSlot != -1)
/*      */           {
/*      */             
/* 1674 */             mc.playerController.windowClick(0, pickSlot + 36, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1683 */           getCosmos().getInventoryManager().switchToSlot(previousSlot, InventoryManager.Switch.PACKET);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1689 */     if (((Sequential)sequential.getValue()).equals(Sequential.NORMAL)) {
/* 1690 */       this.deadCrystals.add(Integer.valueOf(in));
/*      */     }
/*      */ 
/*      */     
/* 1694 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean placeCrystal(BlockPos in) {
/*      */     RayTraceResult laxResult;
/* 1705 */     if (in == null) {
/* 1706 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1710 */     if (PlayerUtil.isEating() || PlayerUtil.isMending() || PlayerUtil.isMining()) {
/* 1711 */       this.autoSwitchTimer.resetTime();
/*      */     }
/*      */ 
/*      */     
/* 1715 */     int previousSlot = -1;
/*      */ 
/*      */     
/* 1718 */     int swapSlot = getCosmos().getInventoryManager().searchSlot(Items.END_CRYSTAL, InventoryManager.InventoryRegion.HOTBAR) + 36;
/*      */ 
/*      */     
/* 1721 */     Slot previousHeldSlot = mc.player.inventoryContainer.inventorySlots.get(mc.player.inventory.currentItem + 36);
/* 1722 */     Slot previousSwapSlot = mc.player.inventoryContainer.inventorySlots.get(swapSlot);
/*      */ 
/*      */     
/* 1725 */     ItemStack heldStack = mc.player.getHeldItemMainhand();
/* 1726 */     ItemStack swapStack = previousSwapSlot.getStack();
/*      */ 
/*      */     
/* 1729 */     if (!((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NONE))
/*      */     {
/*      */       
/* 1732 */       if (!InventoryUtil.isHolding(Items.END_CRYSTAL)) {
/*      */ 
/*      */         
/* 1735 */         previousSlot = mc.player.inventory.currentItem;
/*      */ 
/*      */         
/* 1738 */         if (((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.PACKET) && ((Boolean)alternativeSwitch.getValue()).booleanValue()) {
/*      */ 
/*      */           
/* 1741 */           if (InventoryUtil.isInHotbar(Items.END_CRYSTAL))
/*      */           {
/*      */             
/* 1744 */             mc.playerController.windowClick(0, swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */ 
/*      */             
/* 1747 */             previousHeldSlot.putStack(swapStack);
/* 1748 */             previousSwapSlot.putStack(heldStack);
/*      */ 
/*      */             
/* 1751 */             mc.player.inventory.markDirty();
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1759 */         else if (((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NORMAL)) {
/*      */ 
/*      */           
/* 1762 */           if (this.autoSwitchTimer.passedTime(500L, Timer.Format.MILLISECONDS))
/*      */           {
/*      */             
/* 1765 */             getCosmos().getInventoryManager().switchToItem(Items.END_CRYSTAL, InventoryManager.Switch.NORMAL);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1770 */           getCosmos().getInventoryManager().switchToItem(Items.END_CRYSTAL, InventoryManager.Switch.NORMAL);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1777 */     ((IPlayerControllerMP)mc.playerController).hookSyncCurrentPlayItem();
/*      */ 
/*      */     
/* 1780 */     if (!isHoldingCrystal()) {
/* 1781 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1785 */     double facingX = 0.0D;
/* 1786 */     double facingY = 0.0D;
/* 1787 */     double facingZ = 0.0D;
/*      */ 
/*      */     
/* 1790 */     EnumFacing facingDirection = EnumFacing.UP;
/*      */ 
/*      */     
/* 1793 */     Rotation vectorAngles = AngleUtil.calculateAngles((Vec3d)this.angleVector.first());
/*      */ 
/*      */     
/* 1796 */     Vec3d placeVector = AngleUtil.getVectorForRotation(new Rotation(vectorAngles.getYaw(), vectorAngles.getPitch()));
/*      */ 
/*      */     
/* 1799 */     RayTraceResult interactVector = mc.world.rayTraceBlocks(mc.player.getPositionEyes(1.0F), mc.player.getPositionEyes(1.0F).add(placeVector.x * ((Double)placeRange.getValue()).doubleValue(), placeVector.y * ((Double)placeRange.getValue()).doubleValue(), placeVector.z * ((Double)placeRange.getValue()).doubleValue()), false, false, true);
/*      */ 
/*      */     
/* 1802 */     switch ((Interact)interact.getValue()) {
/*      */       case NONE:
/* 1804 */         facingDirection = EnumFacing.DOWN;
/* 1805 */         facingX = 0.5D;
/* 1806 */         facingY = 0.5D;
/* 1807 */         facingZ = 0.5D;
/*      */         break;
/*      */ 
/*      */       
/*      */       case VANILLA:
/* 1812 */         laxResult = mc.world.rayTraceBlocks(mc.player.getPositionEyes(1.0F), (new Vec3d((Vec3i)in)).add(0.5D, 0.5D, 0.5D));
/*      */         
/* 1814 */         if (laxResult != null && laxResult.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/* 1815 */           facingDirection = laxResult.sideHit;
/*      */ 
/*      */           
/* 1818 */           if (in.getY() >= mc.world.getActualHeight() - 1) {
/* 1819 */             facingDirection = EnumFacing.DOWN;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1824 */         if (interactVector != null && interactVector.hitVec != null) {
/* 1825 */           facingX = interactVector.hitVec.x - in.getX();
/* 1826 */           facingY = interactVector.hitVec.y - in.getY();
/* 1827 */           facingZ = interactVector.hitVec.z - in.getZ();
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case STRICT:
/* 1834 */         if (in.getY() > mc.player.posY + mc.player.getEyeHeight()) {
/*      */ 
/*      */           
/* 1837 */           Pair<Double, EnumFacing> closestDirection = Pair.of(Double.valueOf(Double.MAX_VALUE), EnumFacing.UP);
/*      */           
/*      */           float x;
/* 1840 */           for (x = 0.0F; x <= 1.0F; x = (float)(x + 0.05D)) {
/* 1841 */             float y; for (y = 0.0F; y <= 1.0F; y = (float)(y + 0.05D)) {
/* 1842 */               float z; for (z = 0.0F; z <= 1.0F; z = (float)(z + 0.05D)) {
/*      */ 
/*      */                 
/* 1845 */                 Vec3d traceVector = (new Vec3d((Vec3i)in)).add(x, y, z);
/*      */ 
/*      */                 
/* 1848 */                 RayTraceResult strictResult = mc.world.rayTraceBlocks(mc.player.getPositionEyes(1.0F), traceVector, false, true, false);
/*      */ 
/*      */                 
/* 1851 */                 if (strictResult != null && strictResult.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/*      */ 
/*      */                   
/* 1854 */                   double directionDistance = mc.player.getDistance(traceVector.x, traceVector.y, traceVector.z);
/*      */ 
/*      */                   
/* 1857 */                   if (directionDistance < ((Double)closestDirection.first()).doubleValue()) {
/* 1858 */                     closestDirection = Pair.of(Double.valueOf(directionDistance), strictResult.sideHit);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/* 1865 */           facingDirection = (EnumFacing)closestDirection.second();
/*      */         } 
/*      */ 
/*      */         
/* 1869 */         if (interactVector != null && interactVector.hitVec != null) {
/* 1870 */           facingX = interactVector.hitVec.x - in.getX();
/* 1871 */           facingY = interactVector.hitVec.y - in.getY();
/* 1872 */           facingZ = interactVector.hitVec.z - in.getZ();
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1879 */     boolean offhand = mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemEndCrystal;
/*      */ 
/*      */     
/* 1882 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(in, facingDirection, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, (float)facingX, (float)facingY, (float)facingZ));
/*      */ 
/*      */     
/* 1885 */     this.placementPackets.add(in);
/*      */ 
/*      */     
/* 1888 */     if (((Boolean)swing.getValue()).booleanValue()) {
/*      */ 
/*      */       
/* 1891 */       ItemStack stack = mc.player.getHeldItem(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*      */ 
/*      */       
/* 1894 */       if (!stack.isEmpty() && 
/* 1895 */         !stack.getItem().onEntitySwing((EntityLivingBase)mc.player, stack))
/*      */       {
/*      */         
/* 1898 */         if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= ((IEntityLivingBase)mc.player).hookGetArmSwingAnimationEnd() / 2 || mc.player.swingProgressInt < 0) {
/* 1899 */           mc.player.swingProgressInt = -1;
/* 1900 */           mc.player.isSwingInProgress = true;
/* 1901 */           mc.player.swingingHand = SwingModule.INSTANCE.isEnabled() ? SwingModule.INSTANCE.getHand() : (offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*      */ 
/*      */           
/* 1904 */           if (mc.player.world instanceof WorldServer) {
/* 1905 */             ((WorldServer)mc.player.world).getEntityTracker().sendToTracking((Entity)mc.player, (Packet)new SPacketAnimation((Entity)mc.player, offhand ? 3 : 0));
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1913 */     mc.player.connection.sendPacket((Packet)new CPacketAnimation(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND));
/*      */ 
/*      */     
/* 1916 */     heldStack = previousSwapSlot.getStack();
/* 1917 */     swapStack = mc.player.getHeldItemMainhand();
/*      */ 
/*      */     
/* 1920 */     if (((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.PACKET))
/*      */     {
/*      */       
/* 1923 */       if (((Boolean)alternativeSwitch.getValue()).booleanValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1929 */         mc.playerController.windowClick(0, swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/*      */ 
/*      */         
/* 1932 */         previousHeldSlot.putStack(heldStack);
/* 1933 */         previousSwapSlot.putStack(swapStack);
/*      */ 
/*      */         
/* 1936 */         mc.player.inventory.markDirty();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1950 */       else if (previousSlot != -1) {
/* 1951 */         getCosmos().getInventoryManager().switchToSlot(previousSlot, InventoryManager.Switch.NORMAL);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1957 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFacing(Vec3d in) {
/* 1967 */     Rotation serverRotation = getCosmos().getRotationManager().getServerRotation();
/*      */ 
/*      */     
/* 1970 */     Rotation facingRotation = AngleUtil.calculateAngles(in);
/*      */ 
/*      */     
/* 1973 */     float yaw = Math.abs(serverRotation.getYaw() - facingRotation.getYaw());
/* 1974 */     float pitch = Math.abs(serverRotation.getPitch() - facingRotation.getPitch());
/*      */ 
/*      */     
/* 1977 */     return ((yaw <= 0.1D)) & ((pitch <= 0.1D));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDesynced() {
/* 1987 */     if (mc.isSingleplayer()) {
/* 1988 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1992 */     return (this.explosionPackets.size() > 40 || this.placementPackets.size() > 40);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDebug() {
/* 2007 */     String debugInfo = getAverageWaitTime() + "ms, " + getConfirmTime() + ", " + getAverageCrystalsPerSecond();
/*      */     
/* 2009 */     return ((Boolean)debug.getValue()).booleanValue() ? debugInfo : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getAverageCrystalsPerSecond() {
/* 2019 */     return (int)getAverage(crystalCounts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float getConfirmTime() {
/* 2029 */     if (lastConfirmTime > 500L) {
/* 2030 */       lastConfirmTime = 0L;
/*      */     }
/*      */ 
/*      */     
/* 2034 */     return MathUtil.roundFloat(((float)lastConfirmTime / 50.0F), 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long getAverageWaitTime() {
/* 2044 */     float average = getAverage(attackTimes);
/*      */     
/* 2046 */     if (average > 500.0F) {
/* 2047 */       average = 0.0F;
/*      */     }
/*      */ 
/*      */     
/* 2051 */     return (long)average;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float getAverage(long[] in) {
/* 2062 */     float avg = 0.0F;
/*      */     
/* 2064 */     for (long time : in) {
/* 2065 */       avg += (float)time;
/*      */     }
/*      */ 
/*      */     
/* 2069 */     return avg / 10.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHoldingCrystal() {
/* 2077 */     return (InventoryUtil.isHolding(Items.END_CRYSTAL) || (((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.PACKET) && InventoryUtil.isInHotbar(Items.END_CRYSTAL)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canPlaceCrystal(BlockPos position) {
/* 2088 */     Block placeBlock = mc.world.getBlockState(position).getBlock();
/*      */ 
/*      */     
/* 2091 */     if (!placeBlock.equals(Blocks.BEDROCK) && !placeBlock.equals(Blocks.OBSIDIAN)) {
/* 2092 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2096 */     BlockPos nativePosition = position.up();
/* 2097 */     BlockPos updatedPosition = nativePosition.up();
/*      */ 
/*      */     
/* 2100 */     Block nativeBlock = mc.world.getBlockState(nativePosition).getBlock();
/*      */ 
/*      */     
/* 2103 */     if (!nativeBlock.equals(Blocks.AIR) && !nativeBlock.equals(Blocks.FIRE)) {
/* 2104 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2108 */     if (((Placements)placements.getValue()).equals(Placements.NATIVE)) {
/*      */ 
/*      */       
/* 2111 */       Block updatedBlock = mc.world.getBlockState(updatedPosition).getBlock();
/*      */ 
/*      */       
/* 2114 */       if (!updatedBlock.equals(Blocks.AIR) && !updatedBlock.equals(Blocks.FIRE)) {
/* 2115 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2120 */     int unsafeEntities = 0;
/*      */ 
/*      */     
/* 2123 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(nativePosition
/* 2124 */           .getX(), position.getY(), nativePosition.getZ(), (nativePosition.getX() + 1), nativePosition.getY() + ((Double)offset.getValue()).doubleValue(), (nativePosition.getZ() + 1)))) {
/*      */ 
/*      */ 
/*      */       
/* 2128 */       if (entity == null || entity.isDead || this.deadCrystals.contains(Integer.valueOf(entity.getEntityId()))) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 2133 */       if (entity instanceof net.minecraft.entity.item.EntityXPOrb) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 2138 */       if (entity instanceof EntityEnderCrystal) {
/*      */ 
/*      */         
/* 2141 */         if (this.attackedCrystals.containsKey(Integer.valueOf(entity.getEntityId())) && entity.ticksExisted < 20) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 2146 */         double localDamage = ExplosionUtil.getDamageFromExplosion((Entity)mc.player, entity.getPositionVector(), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */         
/* 2149 */         double idealDamage = 0.0D;
/*      */ 
/*      */         
/* 2152 */         for (Entity target : new ArrayList(mc.world.loadedEntityList)) {
/*      */ 
/*      */           
/* 2155 */           if (target == null || target.equals(mc.player) || target.getEntityId() < 0 || EnemyUtil.isDead(target) || getCosmos().getSocialManager().getSocial(target.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2160 */           if (target instanceof EntityEnderCrystal) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2165 */           if (target.isBeingRidden() && target.getPassengers().contains(mc.player)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2170 */           if ((target instanceof EntityPlayer && !((Boolean)targetPlayers.getValue()).booleanValue()) || (EntityUtil.isPassiveMob(target) && !((Boolean)targetPassives.getValue()).booleanValue()) || (EntityUtil.isNeutralMob(target) && !((Boolean)targetNeutrals.getValue()).booleanValue()) || (EntityUtil.isHostileMob(target) && !((Boolean)targetHostiles.getValue()).booleanValue())) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2175 */           double entityRange = mc.player.getDistance(target);
/*      */ 
/*      */           
/* 2178 */           if (entityRange > ((Double)targetRange.getValue()).doubleValue()) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2183 */           double targetDamage = ExplosionUtil.getDamageFromExplosion(target, entity.getPositionVector(), ((Boolean)blockDestruction.getValue()).booleanValue());
/*      */ 
/*      */           
/* 2186 */           double safetyIndex = 1.0D;
/*      */ 
/*      */           
/* 2189 */           if (DamageUtil.canTakeDamage()) {
/*      */ 
/*      */             
/* 2192 */             double health = PlayerUtil.getHealth();
/*      */ 
/*      */             
/* 2195 */             if (localDamage + 0.5D > health) {
/* 2196 */               safetyIndex = -9999.0D;
/*      */ 
/*      */             
/*      */             }
/* 2200 */             else if (((Safety)safety.getValue()).equals(Safety.STABLE)) {
/*      */ 
/*      */               
/* 2203 */               double efficiency = targetDamage - localDamage;
/*      */ 
/*      */               
/* 2206 */               if (efficiency < 0.0D && Math.abs(efficiency) < 0.25D) {
/* 2207 */                 efficiency = 0.0D;
/*      */               }
/*      */               
/* 2210 */               safetyIndex = efficiency;
/*      */ 
/*      */             
/*      */             }
/* 2214 */             else if (((Safety)safety.getValue()).equals(Safety.BALANCE)) {
/*      */ 
/*      */               
/* 2217 */               double balance = targetDamage * ((Double)safetyBalance.getValue()).doubleValue();
/*      */ 
/*      */               
/* 2220 */               safetyIndex = balance - localDamage;
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 2225 */           if (safetyIndex < 0.0D) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 2230 */           if (targetDamage > idealDamage) {
/* 2231 */             idealDamage = targetDamage;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 2236 */         if (idealDamage > ((Double)damage.getValue()).doubleValue()) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */       
/* 2241 */       unsafeEntities++;
/*      */     } 
/*      */ 
/*      */     
/* 2245 */     return (unsafeEntities <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Placements
/*      */   {
/* 2253 */     NATIVE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2258 */     UPDATED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Interact
/*      */   {
/* 2266 */     VANILLA,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2271 */     STRICT,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2276 */     NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum YawStep
/*      */   {
/* 2284 */     FULL,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2289 */     SEMI,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2294 */     NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Inhibit
/*      */   {
/* 2302 */     FULL,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2307 */     SEMI,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2312 */     NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Safety
/*      */   {
/* 2320 */     BALANCE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2325 */     STABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2330 */     NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Sequential
/*      */   {
/* 2338 */     NORMAL(1),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2343 */     STRICT(2),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2348 */     NONE(1000);
/*      */     
/*      */     private final int ticks;
/*      */ 
/*      */     
/*      */     Sequential(int ticks) {
/* 2354 */       this.ticks = ticks;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double getTicks() {
/* 2362 */       return this.ticks;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Text
/*      */   {
/* 2371 */     TARGET,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2376 */     LOCAL,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2381 */     BOTH,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2386 */     NONE;
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DamageHolder<T>
/*      */   {
/*      */     private final T damageSource;
/*      */     
/*      */     private final Entity target;
/*      */     
/*      */     private final double targetDamage;
/*      */     private final double localDamage;
/*      */     
/*      */     public DamageHolder(T damageSource, Entity target, double targetDamage, double localDamage) {
/* 2400 */       this.damageSource = damageSource;
/*      */ 
/*      */       
/* 2403 */       this.target = target;
/*      */ 
/*      */       
/* 2406 */       this.targetDamage = targetDamage;
/* 2407 */       this.localDamage = localDamage;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public T getDamageSource() {
/* 2415 */       return this.damageSource;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Entity getTarget() {
/* 2423 */       return this.target;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double getTargetDamage() {
/* 2431 */       return this.targetDamage;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double getLocalDamage() {
/* 2439 */       return this.localDamage;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AutoCrystalModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
