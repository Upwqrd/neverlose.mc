//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.client.events.combat.TotemPopEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.combat.DamageUtil;
/*     */ import cope.cosmos.util.combat.ExplosionUtil;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import cope.cosmos.util.world.ShiftBlocks;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AutoTotemModule
/*     */   extends Module
/*     */ {
/*     */   public static AutoTotemModule INSTANCE;
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.TOTEM)).setDescription("Item to use when not at critical health");
/*     */   public static Setting<Double> health = (new Setting("Health", Double.valueOf(0.0D), Double.valueOf(16.0D), Double.valueOf(20.0D), 1)).setDescription("Critical health to switch to a totem");
/*     */   public static Setting<Double> speed = (new Setting("Speed", Double.valueOf(0.0D), Double.valueOf(20.0D), Double.valueOf(20.0D), 1)).setDescription("Speed when switching items");
/*     */   
/*     */   public AutoTotemModule() {
/*  35 */     super("AutoTotem", Category.COMBAT, "Switches items in the offhand to a totem when low on health", () -> StringFormatter.formatEnum((Enum)mode.getValue()) + ", " + InventoryUtil.getItemCount(((Mode)mode.getValue()).getItem()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.offhandTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onThread() {
/*  72 */     if (mc.currentScreen == null) {
/*     */ 
/*     */       
/*  75 */       Item item = ((Mode)mode.getValue()).getItem();
/*     */ 
/*     */       
/*  78 */       if (((Boolean)offhandOverride.getValue()).booleanValue())
/*     */       {
/*     */         
/*  81 */         if (InventoryUtil.isHolding(ItemSword.class) && mc.gameSettings.keyBindUseItem.isKeyDown()) {
/*     */ 
/*     */           
/*  84 */           Block interactBlock = mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock();
/*     */ 
/*     */           
/*  87 */           if (!ShiftBlocks.contains(interactBlock) && !interactBlock.equals(Blocks.STONE_BUTTON) && !interactBlock.equals(Blocks.WOODEN_BUTTON) && !interactBlock.equals(Blocks.LEVER)) {
/*  88 */             item = Items.GOLDEN_APPLE;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*  94 */       if (DamageUtil.canTakeDamage()) {
/*     */ 
/*     */         
/*  97 */         double playerHealth = PlayerUtil.getHealth();
/*     */ 
/*     */         
/* 100 */         if (((Boolean)lethal.getValue()).booleanValue()) {
/*     */ 
/*     */           
/* 103 */           float fallDamage = (mc.player.fallDistance - 3.0F) / 2.0F + 3.5F;
/*     */ 
/*     */           
/* 106 */           if (playerHealth - fallDamage < 0.5D && !mc.player.isOverWater()) {
/* 107 */             item = Items.TOTEM_OF_UNDYING;
/*     */           }
/*     */ 
/*     */           
/* 111 */           if (PlayerUtil.isFlying()) {
/* 112 */             item = Items.TOTEM_OF_UNDYING;
/*     */           }
/*     */ 
/*     */           
/* 116 */           for (Entity entity : mc.world.loadedEntityList) {
/*     */ 
/*     */             
/* 119 */             if (entity == null || entity.isDead) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 124 */             double crystalRange = mc.player.getDistance(entity);
/* 125 */             if (crystalRange > 6.0D) {
/*     */               continue;
/*     */             }
/*     */             
/* 129 */             if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/*     */ 
/*     */               
/* 132 */               double crystalDamage = ExplosionUtil.getDamageFromExplosion((Entity)mc.player, entity.getPositionVector(), false);
/*     */ 
/*     */               
/* 135 */               if (playerHealth - crystalDamage < 0.5D) {
/* 136 */                 item = Items.TOTEM_OF_UNDYING;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 144 */         if (playerHealth <= ((Double)health.getValue()).doubleValue()) {
/* 145 */           item = Items.TOTEM_OF_UNDYING;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 150 */         int itemSlot = -1;
/*     */ 
/*     */         
/* 153 */         int gappleSlot = -1;
/* 154 */         int crappleSlot = -1;
/*     */ 
/*     */         
/* 157 */         for (int i = 9; i < (((Boolean)hotbar.getValue()).booleanValue() ? 45 : 36); i++) {
/* 158 */           if (mc.player.inventoryContainer.getSlot(i).getStack().getItem().equals(item))
/*     */           {
/*     */             
/* 161 */             if (item.equals(Items.GOLDEN_APPLE)) {
/*     */ 
/*     */               
/* 164 */               ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
/*     */ 
/*     */               
/* 167 */               if (stack.hasEffect()) {
/* 168 */                 gappleSlot = i;
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 173 */                 crappleSlot = i;
/*     */               }
/*     */             
/*     */             } else {
/*     */               
/* 178 */               itemSlot = i;
/*     */               
/*     */               break;
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 185 */         if (item.equals(Items.GOLDEN_APPLE))
/*     */         {
/*     */           
/* 188 */           if (((Boolean)crapple.getValue()).booleanValue()) {
/*     */ 
/*     */             
/* 191 */             if (mc.player.isPotionActive(MobEffects.ABSORPTION)) {
/*     */ 
/*     */ 
/*     */               
/* 195 */               if (crappleSlot != -1) {
/* 196 */                 itemSlot = crappleSlot;
/*     */ 
/*     */               
/*     */               }
/* 200 */               else if (gappleSlot != -1) {
/* 201 */                 itemSlot = gappleSlot;
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 206 */             else if (gappleSlot != -1) {
/* 207 */               itemSlot = gappleSlot;
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 215 */           else if (gappleSlot != -1) {
/* 216 */             itemSlot = gappleSlot;
/*     */ 
/*     */           
/*     */           }
/* 220 */           else if (crappleSlot != -1) {
/* 221 */             itemSlot = crappleSlot;
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 227 */         if (!isOffhand(mc.player.inventoryContainer.getSlot(itemSlot).getStack()))
/*     */         {
/*     */           
/* 230 */           if (itemSlot != -1)
/*     */           {
/*     */             
/* 233 */             if (((Boolean)fast.getValue()).booleanValue()) {
/*     */ 
/*     */ 
/*     */               
/* 237 */               long offhandDelay = (long)((((Double)speed.getMax()).doubleValue() - ((Double)speed.getValue()).doubleValue()) * 50.0D);
/*     */ 
/*     */               
/* 240 */               boolean delayed = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay, Timer.Format.MILLISECONDS));
/*     */ 
/*     */               
/* 243 */               if (delayed)
/*     */               {
/*     */                 
/* 246 */                 mc.playerController.windowClick(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */                 
/* 249 */                 mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */                 
/* 252 */                 if (mc.player.inventory.getItemStack().isEmpty()) {
/*     */ 
/*     */                   
/* 255 */                   this.offhandTimer.resetTime();
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */                 
/* 260 */                 int returnSlot = -1;
/* 261 */                 for (int j = 0; j < 36; j++) {
/* 262 */                   if (mc.player.inventory.getStackInSlot(j).isEmpty()) {
/* 263 */                     returnSlot = j;
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */                 
/* 269 */                 if (returnSlot != -1) {
/* 270 */                   mc.playerController.windowClick(0, returnSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 271 */                   mc.playerController.updateController();
/*     */                 } 
/*     */ 
/*     */                 
/* 275 */                 this.offhandTimer.resetTime();
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 284 */               long offhandDelay = (long)((((Double)speed.getMax()).doubleValue() - ((Double)speed.getValue()).doubleValue()) * 50.0D);
/*     */ 
/*     */               
/* 287 */               boolean delayedFirst = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay, Timer.Format.MILLISECONDS));
/*     */ 
/*     */               
/* 290 */               if (delayedFirst) {
/*     */ 
/*     */                 
/* 293 */                 mc.player.stopActiveHand();
/*     */ 
/*     */                 
/* 296 */                 mc.playerController.windowClick(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */                 
/* 299 */                 boolean delayedSecond = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay * 2L, Timer.Format.MILLISECONDS));
/*     */ 
/*     */                 
/* 302 */                 if (delayedSecond) {
/*     */ 
/*     */                   
/* 305 */                   mc.player.stopActiveHand();
/*     */ 
/*     */                   
/* 308 */                   mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */                   
/* 311 */                   if (mc.player.inventory.getItemStack().isEmpty()) {
/*     */ 
/*     */                     
/* 314 */                     this.offhandTimer.resetTime();
/*     */                     
/*     */                     return;
/*     */                   } 
/*     */                   
/* 319 */                   boolean delayedThird = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay * 3L, Timer.Format.MILLISECONDS));
/*     */ 
/*     */                   
/* 322 */                   if (delayedThird) {
/*     */ 
/*     */                     
/* 325 */                     int returnSlot = -1;
/* 326 */                     for (int j = 0; j < 36; j++) {
/* 327 */                       if (mc.player.inventory.getStackInSlot(j).isEmpty()) {
/* 328 */                         returnSlot = j;
/*     */                         
/*     */                         break;
/*     */                       } 
/*     */                     } 
/*     */                     
/* 334 */                     if (returnSlot != -1) {
/*     */ 
/*     */                       
/* 337 */                       mc.player.stopActiveHand();
/*     */ 
/*     */                       
/* 340 */                       mc.playerController.windowClick(0, returnSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 341 */                       mc.playerController.updateController();
/*     */                     } 
/*     */ 
/*     */                     
/* 345 */                     this.offhandTimer.resetTime();
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             }  }  } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Setting<Boolean> fast = (new Setting("Fast", Boolean.valueOf(false))).setDescription("Performs all actions in one cycle");
/*     */   public static Setting<Boolean> lethal = (new Setting("Lethal", Boolean.valueOf(true))).setDescription("Takes damage sources into account when switching");
/*     */   public static Setting<Boolean> hotbar = (new Setting("Hotbar", Boolean.valueOf(false))).setDescription("Allow hotbar items to be moved to the offhand");
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTotemPop(TotemPopEvent event) {
/* 360 */     if (event.getPopEntity().equals(mc.player)) {
/*     */ 
/*     */       
/* 363 */       Item item = Items.TOTEM_OF_UNDYING;
/*     */ 
/*     */       
/* 366 */       if (!mc.player.getHeldItemOffhand().getItem().equals(item)) {
/*     */ 
/*     */ 
/*     */         
/* 370 */         int itemSlot = -1;
/* 371 */         for (int i = 9; i < (((Boolean)hotbar.getValue()).booleanValue() ? 45 : 36); i++) {
/* 372 */           if (mc.player.inventoryContainer.getSlot(i).getStack().getItem().equals(item)) {
/* 373 */             itemSlot = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 379 */         if (itemSlot != -1)
/*     */         {
/*     */           
/* 382 */           if (((Boolean)fast.getValue()).booleanValue()) {
/*     */ 
/*     */ 
/*     */             
/* 386 */             long offhandDelay = (long)((((Double)speed.getMax()).doubleValue() - ((Double)speed.getValue()).doubleValue()) * 50.0D);
/*     */ 
/*     */             
/* 389 */             boolean delayed = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay, Timer.Format.MILLISECONDS));
/*     */ 
/*     */             
/* 392 */             if (delayed)
/*     */             {
/*     */               
/* 395 */               mc.playerController.windowClick(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */               
/* 398 */               mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */               
/* 401 */               if (mc.player.inventory.getItemStack().isEmpty()) {
/*     */ 
/*     */                 
/* 404 */                 this.offhandTimer.resetTime();
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/* 409 */               int returnSlot = -1;
/* 410 */               for (int j = 0; j < 36; j++) {
/* 411 */                 if (mc.player.inventory.getStackInSlot(j).isEmpty()) {
/* 412 */                   returnSlot = j;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               
/* 418 */               if (returnSlot != -1) {
/* 419 */                 mc.playerController.windowClick(0, returnSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 420 */                 mc.playerController.updateController();
/*     */               } 
/*     */ 
/*     */               
/* 424 */               this.offhandTimer.resetTime();
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 433 */             long offhandDelay = (long)((((Double)speed.getMax()).doubleValue() - ((Double)speed.getValue()).doubleValue()) * 50.0D);
/*     */ 
/*     */             
/* 436 */             boolean delayedFirst = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay, Timer.Format.MILLISECONDS));
/*     */ 
/*     */             
/* 439 */             if (delayedFirst) {
/*     */ 
/*     */               
/* 442 */               mc.player.stopActiveHand();
/*     */ 
/*     */               
/* 445 */               mc.playerController.windowClick(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */               
/* 448 */               boolean delayedSecond = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay * 2L, Timer.Format.MILLISECONDS));
/*     */ 
/*     */               
/* 451 */               if (delayedSecond) {
/*     */ 
/*     */                 
/* 454 */                 mc.player.stopActiveHand();
/*     */ 
/*     */                 
/* 457 */                 mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */                 
/* 460 */                 if (mc.player.inventory.getItemStack().isEmpty()) {
/*     */ 
/*     */                   
/* 463 */                   this.offhandTimer.resetTime();
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */                 
/* 468 */                 boolean delayedThird = (((Double)speed.getValue()).doubleValue() >= ((Double)speed.getMax()).doubleValue() || this.offhandTimer.passedTime(offhandDelay * 3L, Timer.Format.MILLISECONDS));
/*     */ 
/*     */                 
/* 471 */                 if (delayedThird) {
/*     */ 
/*     */                   
/* 474 */                   int returnSlot = -1;
/* 475 */                   for (int j = 0; j < 36; j++) {
/* 476 */                     if (mc.player.inventory.getStackInSlot(j).isEmpty()) {
/* 477 */                       returnSlot = j;
/*     */                       
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*     */                   
/* 483 */                   if (returnSlot != -1) {
/*     */ 
/*     */                     
/* 486 */                     mc.player.stopActiveHand();
/*     */ 
/*     */                     
/* 489 */                     mc.playerController.windowClick(0, returnSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 490 */                     mc.playerController.updateController();
/*     */                   } 
/*     */ 
/*     */                   
/* 494 */                   this.offhandTimer.resetTime();
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Setting<Boolean> crapple = (new Setting("Crapple", Boolean.valueOf(false))).setDescription("Uses a crapple in the offhand");
/*     */   
/*     */   public static Setting<Boolean> offhandOverride = (new Setting("OffhandOverride", Boolean.valueOf(true))).setDescription("Switches offhand items in non-lethal scenarios");
/*     */   
/*     */   private final Timer offhandTimer;
/*     */   
/*     */   public boolean isOffhand(ItemStack in) {
/* 512 */     ItemStack offhandItem = mc.player.getHeldItemOffhand();
/*     */ 
/*     */     
/* 515 */     if (in.getItem().equals(Items.GOLDEN_APPLE)) {
/*     */ 
/*     */       
/* 518 */       if (offhandItem.getItem().equals(in.getItem()))
/*     */       {
/*     */         
/* 521 */         boolean gapple = in.hasEffect();
/*     */ 
/*     */         
/* 524 */         return (gapple == offhandItem.hasEffect());
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 530 */       return offhandItem.getItem().equals(in.getItem());
/*     */     } 
/*     */     
/* 533 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 541 */     CRYSTAL((String)Items.END_CRYSTAL),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 546 */     GAPPLE((String)Items.GOLDEN_APPLE),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 551 */     TOTEM((String)Items.TOTEM_OF_UNDYING);
/*     */     
/*     */     private final Item item;
/*     */     
/*     */     Mode(Item item) {
/* 556 */       this.item = item;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Item getItem() {
/* 564 */       return this.item;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\AutoTotemModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
