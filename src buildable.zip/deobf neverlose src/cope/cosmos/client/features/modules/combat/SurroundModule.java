//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.AngleUtil;
/*     */ import cope.cosmos.util.world.BlockUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityBoat;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.item.EntityMinecart;
/*     */ import net.minecraft.entity.item.EntityXPOrb;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.network.play.server.SPacketBlockChange;
/*     */ import net.minecraft.network.play.server.SPacketMultiBlockChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class SurroundModule extends Module {
/*     */   public static SurroundModule INSTANCE;
/*     */   
/*     */   public SurroundModule() {
/*  44 */     super("Surround", Category.COMBAT, "Surrounds your feet with obsidian");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.placements = new ArrayList<>();
/*  85 */     this.replacements = new ArrayList<>();
/*     */ 
/*     */     
/*  88 */     this.clearTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Timing> timing = (new Setting("Timing", Timing.SEQUENTIAL)).setDescription("When to place blocks"); public static Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.NONE)).setDescription("How to rotate when placing blocks");
/*     */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("If to use strict direction to place blocks");
/*     */   public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NORMAL)).setDescription("How to switch when placing blocks");
/*     */   public static Setting<Double> blocks = (new Setting("Blocks", Double.valueOf(1.0D), Double.valueOf(4.0D), Double.valueOf(10.0D), 0)).setDescription("Allowed block placements per tick");
/*     */   public static Setting<Boolean> extend = (new Setting("Extend", Boolean.valueOf(true))).setDescription("If not centered on a block, it'll extend to a 2x1 and etc");
/*     */   public static Setting<Boolean> floor = (new Setting("Floor", Boolean.valueOf(true))).setDescription("If to place at the floor");
/*  97 */   private static final List<Class<? extends Entity>> SAFE_ENTITIES = Arrays.asList((Class<? extends Entity>[])new Class[] { EntityEnderCrystal.class, EntityItem.class, EntityXPOrb.class, EntityBoat.class, EntityMinecart.class }); public static Setting<Boolean> support = (new Setting("Support", Boolean.valueOf(true))).setDescription("If to place supporting blocks to be able to place blocks").setVisible(() -> (Boolean)floor.getValue());
/*     */   public static Setting<Completion> completion = (new Setting("Completion", Completion.SHIFT)).setDescription("When to disable the module");
/*     */   
/*     */   public void onEnable() {
/* 101 */     super.onEnable();
/*     */ 
/*     */     
/* 104 */     this.startY = mc.player.posY;
/*     */ 
/*     */     
/* 107 */     if (!((Center)center.getValue()).equals(Center.NONE)) {
/*     */ 
/*     */       
/* 110 */       double centerX = Math.floor(mc.player.posX) + 0.5D;
/* 111 */       double centerZ = Math.floor(mc.player.posZ) + 0.5D;
/*     */ 
/*     */       
/* 114 */       switch ((Center)center.getValue()) {
/*     */         default:
/*     */           return;
/*     */ 
/*     */         
/*     */         case PACKET:
/* 120 */           mc.player.motionX = (centerX - mc.player.posX) / 2.0D;
/* 121 */           mc.player.motionZ = (centerZ - mc.player.posZ) / 2.0D;
/*     */         case null:
/*     */           break;
/*     */       } 
/* 125 */       mc.player.setPosition(centerX, mc.player.posY, centerZ);
/* 126 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(centerX, mc.player.posY, centerZ, mc.player.onGround));
/*     */     } 
/*     */   }
/*     */   public static Setting<Center> center = (new Setting("Center", Center.NONE)).setDescription("Mode to center the player position"); private List<BlockPos> placements; private List<BlockPos> replacements; private final Timer clearTimer;
/*     */   private int placed;
/*     */   private double startY;
/*     */   
/*     */   public void onDisable() {
/* 134 */     super.onDisable();
/*     */ 
/*     */     
/* 137 */     this.placements.clear();
/* 138 */     this.replacements.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onThread() {
/* 145 */     BlockPos origin = new BlockPos(mc.player.posX, Math.round(mc.player.posY), mc.player.posZ);
/*     */ 
/*     */     
/* 148 */     this.placements = getPlacements(origin);
/* 149 */     this.replacements = getReplacements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 156 */     this.placed = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (mc.player.posY > this.startY && ((Completion)completion.getValue()).equals(Completion.SHIFT)) {
/* 162 */       toggle();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 167 */     if (!this.replacements.isEmpty()) {
/*     */ 
/*     */       
/* 170 */       for (BlockPos position : this.replacements)
/*     */       {
/*     */         
/* 173 */         attackEntities(position);
/*     */       }
/*     */ 
/*     */       
/* 177 */       int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */       
/* 180 */       if (!((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NONE)) {
/*     */ 
/*     */         
/* 183 */         int obsidianSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.OBSIDIAN), InventoryManager.InventoryRegion.HOTBAR);
/* 184 */         int echestSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.ENDER_CHEST), InventoryManager.InventoryRegion.HOTBAR);
/*     */ 
/*     */         
/* 187 */         if (obsidianSlot != -1) {
/* 188 */           getCosmos().getInventoryManager().switchToSlot(obsidianSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */         
/*     */         }
/* 192 */         else if (echestSlot != -1) {
/* 193 */           getCosmos().getInventoryManager().switchToSlot(echestSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 198 */       for (BlockPos position : this.replacements) {
/*     */ 
/*     */         
/* 201 */         if (this.placed >= ((Double)blocks.getValue()).intValue()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 206 */         if (placeBlock(position))
/*     */         {
/*     */           
/* 209 */           this.placed++;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 214 */       if (previousSlot != -1) {
/* 215 */         getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 222 */     else if (((Completion)completion.getValue()).equals(Completion.SURROUNDED)) {
/* 223 */       toggle();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onRotationUpdateEvent(RotationUpdateEvent event) {
/* 232 */     if (!this.replacements.isEmpty())
/*     */     {
/*     */       
/* 235 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 241 */     return (!this.replacements.isEmpty() || getCosmos().getInteractionManager().isPlacing());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 248 */     if (((Timing)timing.getValue()).equals(Timing.SEQUENTIAL)) {
/*     */ 
/*     */       
/* 251 */       if (event.getPacket() instanceof SPacketBlockChange) {
/*     */ 
/*     */         
/* 254 */         BlockPos changePosition = ((SPacketBlockChange)event.getPacket()).getBlockPosition();
/*     */ 
/*     */         
/* 257 */         if (((SPacketBlockChange)event.getPacket()).getBlockState().getMaterial().isReplaceable())
/*     */         {
/*     */           
/* 260 */           if (this.placements.contains(changePosition)) {
/*     */ 
/*     */             
/* 263 */             int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */             
/* 266 */             if (!((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NONE)) {
/*     */ 
/*     */               
/* 269 */               int obsidianSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.OBSIDIAN), InventoryManager.InventoryRegion.HOTBAR);
/* 270 */               int echestSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.ENDER_CHEST), InventoryManager.InventoryRegion.HOTBAR);
/*     */ 
/*     */               
/* 273 */               if (obsidianSlot != -1) {
/* 274 */                 getCosmos().getInventoryManager().switchToSlot(obsidianSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */               
/*     */               }
/* 278 */               else if (echestSlot != -1) {
/* 279 */                 getCosmos().getInventoryManager().switchToSlot(echestSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 284 */             if (placeBlock(changePosition))
/*     */             {
/* 286 */               this.placed++;
/*     */             }
/*     */ 
/*     */             
/* 290 */             if (previousSlot != -1) {
/* 291 */               getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 298 */       if (event.getPacket() instanceof SPacketMultiBlockChange)
/*     */       {
/*     */         
/* 301 */         for (SPacketMultiBlockChange.BlockUpdateData blockUpdateData : ((SPacketMultiBlockChange)event.getPacket()).getChangedBlocks()) {
/*     */ 
/*     */           
/* 304 */           BlockPos changePosition = blockUpdateData.getPos();
/*     */ 
/*     */           
/* 307 */           if (blockUpdateData.getBlockState().getMaterial().isReplaceable())
/*     */           {
/*     */             
/* 310 */             if (this.placements.contains(changePosition)) {
/*     */ 
/*     */               
/* 313 */               int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */               
/* 316 */               if (!((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NONE)) {
/*     */ 
/*     */                 
/* 319 */                 int obsidianSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.OBSIDIAN), InventoryManager.InventoryRegion.HOTBAR);
/* 320 */                 int echestSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.ENDER_CHEST), InventoryManager.InventoryRegion.HOTBAR);
/*     */ 
/*     */                 
/* 323 */                 if (obsidianSlot != -1) {
/* 324 */                   getCosmos().getInventoryManager().switchToSlot(obsidianSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */                 
/*     */                 }
/* 328 */                 else if (echestSlot != -1) {
/* 329 */                   getCosmos().getInventoryManager().switchToSlot(echestSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */                 } 
/*     */               } 
/*     */ 
/*     */               
/* 334 */               if (placeBlock(changePosition))
/*     */               {
/* 336 */                 this.placed++;
/*     */               }
/*     */ 
/*     */               
/* 340 */               if (previousSlot != -1) {
/* 341 */                 getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attackEntities(BlockPos in) {
/* 357 */     int ping = mc.player.connection.getPlayerInfo(mc.player.getUniqueID()).getResponseTime();
/*     */ 
/*     */     
/* 360 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(in))) {
/*     */ 
/*     */       
/* 363 */       if (entity == null || entity instanceof EntityItem || entity instanceof EntityXPOrb) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 368 */       if (this.clearTimer.passedTime((ping <= 50) ? 75L : 100L, Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */         
/* 371 */         Rotation rotation = AngleUtil.calculateAngles(entity.getPositionVector());
/*     */ 
/*     */         
/* 374 */         if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE) && rotation.isValid())
/*     */         {
/* 376 */           switch ((Rotation.Rotate)rotate.getValue()) {
/*     */             case CLIENT:
/* 378 */               mc.player.rotationYaw = rotation.getYaw();
/* 379 */               mc.player.rotationYawHead = rotation.getYaw();
/* 380 */               mc.player.rotationPitch = rotation.getPitch();
/*     */               break;
/*     */ 
/*     */             
/*     */             case PACKET:
/* 385 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotation.getYaw(), rotation.getPitch(), mc.player.onGround));
/*     */               break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 397 */         if (entity instanceof EntityEnderCrystal) {
/*     */ 
/*     */           
/* 400 */           boolean sprintState = mc.player.isSprinting();
/*     */ 
/*     */           
/* 403 */           if (((Boolean)strict.getValue()).booleanValue())
/*     */           {
/*     */             
/* 406 */             if (sprintState) {
/* 407 */               mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */             }
/*     */           }
/*     */ 
/*     */           
/* 412 */           mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/* 413 */           mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */ 
/*     */           
/* 416 */           if (((Boolean)strict.getValue()).booleanValue())
/*     */           {
/*     */             
/* 419 */             if (sprintState) {
/* 420 */               mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */             }
/*     */           }
/*     */           
/* 424 */           this.clearTimer.resetTime();
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 429 */         if (EntityUtil.isVehicleMob(entity)) {
/*     */ 
/*     */           
/* 432 */           for (int i = 0; i < 3; i++) {
/* 433 */             mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/* 434 */             mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */           } 
/*     */           
/* 437 */           this.clearTimer.resetTime();
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean placeBlock(BlockPos in) {
/* 451 */     if (BlockUtil.isReplaceable(in)) {
/*     */ 
/*     */       
/* 454 */       getCosmos().getInteractionManager().placeBlock(in, (Rotation.Rotate)rotate.getValue(), ((Boolean)strict.getValue()).booleanValue(), SAFE_ENTITIES);
/*     */ 
/*     */       
/* 457 */       return true;
/*     */     } 
/*     */     
/* 460 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<BlockPos> getPlacements(BlockPos in) {
/* 471 */     List<BlockPos> queue = new ArrayList<>();
/*     */ 
/*     */     
/* 474 */     Set<EnumFacing> inhibitedDirections = new HashSet<>();
/*     */ 
/*     */     
/* 477 */     for (EnumFacing facing : EnumFacing.VALUES) {
/*     */ 
/*     */       
/* 480 */       if (!isInvalidDirection(facing)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 485 */         BlockPos offset = in.offset(facing);
/*     */ 
/*     */         
/* 488 */         if (isEntityIntersecting(offset)) {
/*     */ 
/*     */           
/* 491 */           if (((Boolean)extend.getValue()).booleanValue() && ((Center)center.getValue()).equals(Center.NONE)) {
/*     */ 
/*     */             
/* 494 */             for (EnumFacing direction : EnumFacing.VALUES) {
/*     */ 
/*     */               
/* 497 */               if (!isInvalidDirection(direction)) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 502 */                 BlockPos extendedOffset = offset.offset(direction);
/*     */ 
/*     */                 
/* 505 */                 if (!extendedOffset.equals(in))
/*     */                 {
/*     */ 
/*     */ 
/*     */                   
/* 510 */                   if (BlockUtil.isReplaceable(extendedOffset))
/*     */                   {
/*     */                     
/* 513 */                     if (!isEntityIntersecting(extendedOffset)) {
/* 514 */                       queue.add(extendedOffset);
/*     */                     }
/*     */                     else {
/*     */                       
/* 518 */                       inhibitedDirections.add(direction);
/*     */                     } 
/*     */                   }
/*     */                 }
/*     */               } 
/*     */             } 
/* 524 */             if (inhibitedDirections.size() > 1) {
/*     */ 
/*     */               
/* 527 */               BlockPos addPosition = in;
/*     */ 
/*     */               
/* 530 */               for (EnumFacing direction : inhibitedDirections)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 536 */                 addPosition = addPosition.offset(direction);
/*     */               }
/*     */ 
/*     */               
/* 540 */               for (EnumFacing direction : EnumFacing.VALUES) {
/*     */ 
/*     */                 
/* 543 */                 if (!isInvalidDirection(direction))
/*     */                 {
/*     */ 
/*     */ 
/*     */                   
/* 548 */                   BlockPos additionPosition = addPosition.offset(direction);
/*     */ 
/*     */                   
/* 551 */                   if (!isEntityIntersecting(additionPosition))
/*     */                   {
/*     */                     
/* 554 */                     queue.add(additionPosition);
/*     */                   }
/*     */                 }
/*     */               
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 563 */           queue.add(offset);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 568 */     if (((Boolean)SurroundModule.support.getValue()).booleanValue()) {
/*     */ 
/*     */       
/* 571 */       for (BlockPos position : new ArrayList(queue)) {
/*     */ 
/*     */         
/* 574 */         boolean support = true;
/*     */ 
/*     */         
/* 577 */         for (EnumFacing direction : EnumFacing.VALUES) {
/*     */ 
/*     */           
/* 580 */           BlockPos offsetPosition = position.offset(direction);
/*     */ 
/*     */           
/* 583 */           if (!mc.world.isAirBlock(offsetPosition)) {
/*     */ 
/*     */             
/* 586 */             support = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 592 */         if (support) {
/* 593 */           queue.add(position.down());
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 598 */       Collections.reverse(queue);
/*     */     } 
/*     */     
/* 601 */     return queue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<BlockPos> getReplacements() {
/* 611 */     List<BlockPos> replacements = new ArrayList<>();
/*     */ 
/*     */     
/* 614 */     for (BlockPos position : this.placements) {
/* 615 */       if (BlockUtil.isReplaceable(position)) {
/* 616 */         replacements.add(position);
/*     */       }
/*     */     } 
/*     */     
/* 620 */     return replacements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEntityIntersecting(BlockPos in) {
/* 631 */     for (Entity entity : new ArrayList(mc.world.loadedEntityList)) {
/*     */ 
/*     */       
/* 634 */       if (entity == null || entity instanceof EntityXPOrb || entity instanceof EntityItem || entity instanceof EntityEnderCrystal) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 639 */       if (entity.getEntityBoundingBox().intersects(new AxisAlignedBB(in))) {
/* 640 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 644 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInvalidDirection(EnumFacing in) {
/* 653 */     return (in.equals(EnumFacing.UP) || (!((Boolean)floor.getValue()).booleanValue() && in.equals(EnumFacing.DOWN)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Timing
/*     */   {
/* 661 */     VANILLA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 666 */     SEQUENTIAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Center
/*     */   {
/* 674 */     TELEPORT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 679 */     MOTION,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 684 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Completion
/*     */   {
/* 692 */     SHIFT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 697 */     SURROUNDED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 702 */     PERSISTENT;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\SurroundModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
