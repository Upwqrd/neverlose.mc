//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntity;
/*     */ import cope.cosmos.asm.mixins.accessor.INetworkManager;
/*     */ import cope.cosmos.client.events.combat.CriticalModifierEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import cope.cosmos.util.player.PlayerUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CriticalsModule
/*     */   extends Module
/*     */ {
/*     */   public static CriticalsModule INSTANCE;
/*     */   
/*     */   public CriticalsModule() {
/*  34 */     super("Criticals", Category.COMBAT, "Ensures all hits are criticals", () -> {
/*     */           StringBuilder info = new StringBuilder();
/*     */ 
/*     */           
/*     */           info.append(StringFormatter.formatEnum((Enum)mode.getValue()));
/*     */ 
/*     */           
/*     */           if (!((Mode)mode.getValue()).equals(Mode.MOTION)) {
/*     */             double timeTillCritical = (((Double)delay.getValue()).doubleValue() - criticalTimer.getMilliseconds()) / 1000.0D;
/*     */ 
/*     */             
/*     */             if (timeTillCritical < 0.0D) {
/*     */               timeTillCritical = 0.0D;
/*     */             }
/*     */ 
/*     */             
/*     */             if (timeTillCritical > ((Double)delay.getValue()).doubleValue()) {
/*     */               timeTillCritical = ((Double)delay.getValue()).doubleValue();
/*     */             }
/*     */ 
/*     */             
/*     */             info.append(", ").append(timeTillCritical);
/*     */           } 
/*     */ 
/*     */           
/*     */           return info.toString();
/*     */         });
/*     */ 
/*     */     
/*  63 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.PACKET))
/*  69 */     .setDescription("Mode for attempting criticals");
/*     */   
/*  71 */   public static Setting<Double> motion = (new Setting("Motion", Double.valueOf(0.0D), Double.valueOf(0.42D), Double.valueOf(1.0D), 2))
/*  72 */     .setDescription("Vertical motion")
/*  73 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.MOTION)));
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static Setting<Double> modifier = (new Setting("Modifier", Double.valueOf(0.0D), Double.valueOf(1.5D), Double.valueOf(10.0D), 2))
/*  78 */     .setDescription("Modifies the damage done by a critical attack");
/*     */   
/*  80 */   public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.0D), Double.valueOf(200.0D), Double.valueOf(2000.0D), 0))
/*  81 */     .setDescription("Delay between attacks to attempt criticals");
/*     */ 
/*     */   
/*  84 */   private static final Timer criticalTimer = new Timer();
/*     */ 
/*     */   
/*     */   private CPacketUseEntity resendAttackPacket;
/*     */ 
/*     */   
/*     */   private CPacketAnimation resendAnimationPacket;
/*     */ 
/*     */   
/*     */   private Entity criticalEntity;
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  97 */     if (this.resendAttackPacket != null) {
/*  98 */       mc.player.connection.sendPacket((Packet)this.resendAttackPacket);
/*  99 */       this.resendAttackPacket = null;
/*     */ 
/*     */       
/* 102 */       if (this.resendAnimationPacket != null) {
/* 103 */         mc.player.connection.sendPacket((Packet)this.resendAnimationPacket);
/* 104 */         this.resendAnimationPacket = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 113 */     if (event.getPacket() instanceof CPacketUseEntity && ((CPacketUseEntity)event.getPacket()).getAction().equals(CPacketUseEntity.Action.ATTACK)) {
/*     */ 
/*     */       
/* 116 */       Entity attackEntity = ((CPacketUseEntity)event.getPacket()).getEntityFromWorld((World)mc.world);
/*     */ 
/*     */       
/* 119 */       if (PlayerUtil.isInLiquid() || mc.player.isRiding() || mc.player.isPotionActive(MobEffects.BLINDNESS) || mc.player.isOnLadder() || !mc.player.onGround || ((IEntity)mc.player).getInWeb()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 124 */       if (attackEntity instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 129 */       if (InventoryUtil.getHighestEnchantLevel() >= 1000) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 134 */       if (attackEntity != null && attackEntity.isEntityAlive())
/*     */       {
/*     */         
/* 137 */         if (EntityUtil.isVehicleMob(attackEntity)) {
/*     */ 
/*     */           
/* 140 */           if (mc.getConnection() != null) {
/* 141 */             for (int i = 0; i < 5; i++) {
/* 142 */               ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketUseEntity(attackEntity), null);
/* 143 */               ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketAnimation(((CPacketUseEntity)event.getPacket()).getHand()), null);
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*     */         }
/* 150 */         else if (!((Mode)mode.getValue()).equals(Mode.VANILLA) && !((Mode)mode.getValue()).equals(Mode.VANILLA_STRICT)) {
/*     */ 
/*     */           
/* 153 */           if (((Mode)mode.getValue()).equals(Mode.MOTION)) {
/*     */ 
/*     */             
/* 156 */             mc.player.motionY = ((Double)motion.getValue()).doubleValue();
/*     */ 
/*     */             
/* 159 */             event.setCanceled(true);
/* 160 */             this.resendAttackPacket = (CPacketUseEntity)event.getPacket();
/*     */           } 
/*     */ 
/*     */           
/* 164 */           if (criticalTimer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.MILLISECONDS)) {
/* 165 */             if (((Mode)mode.getValue()).equals(Mode.PACKET_STRICT))
/*     */             {
/*     */               
/* 168 */               event.setCanceled(true);
/*     */             }
/*     */             
/* 171 */             if (((Mode)mode.getValue()).equals(Mode.PACKET) || ((Mode)mode.getValue()).equals(Mode.PACKET_STRICT)) {
/*     */ 
/*     */               
/* 174 */               for (float offset : ((Mode)mode.getValue()).getOffsets())
/*     */               {
/*     */                 
/* 177 */                 mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, (mc.player.getEntityBoundingBox()).minY + offset, mc.player.posZ, false));
/*     */               }
/*     */ 
/*     */               
/* 181 */               this.criticalEntity = attackEntity;
/*     */             } 
/*     */ 
/*     */             
/* 185 */             if (((Mode)mode.getValue()).equals(Mode.PACKET_STRICT) && 
/* 186 */               mc.getConnection() != null) {
/* 187 */               ((INetworkManager)mc.getConnection().getNetworkManager()).hookDispatchPacket((Packet)new CPacketUseEntity(attackEntity), null);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 192 */           criticalTimer.resetTime();
/*     */ 
/*     */           
/* 195 */           mc.player.onCriticalHit(attackEntity);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 202 */     if (event.getPacket() instanceof CPacketAnimation && (
/* 203 */       (Mode)mode.getValue()).equals(Mode.MOTION)) {
/*     */ 
/*     */       
/* 206 */       event.setCanceled(true);
/* 207 */       this.resendAnimationPacket = (CPacketAnimation)event.getPacket();
/*     */     } 
/*     */ 
/*     */     
/* 211 */     if (event.getPacket() instanceof CPacketPlayer && (
/* 212 */       (ICPacketPlayer)event.getPacket()).isMoving() && 
/* 213 */       this.criticalEntity != null) {
/*     */ 
/*     */       
/* 216 */       if (this.criticalEntity.hurtResistantTime <= 16) {
/* 217 */         this.criticalEntity = null;
/*     */         
/*     */         return;
/*     */       } 
/* 221 */       event.setCanceled(true);
/*     */ 
/*     */       
/* 224 */       if (((Mode)mode.getValue()).equals(Mode.VANILLA)) {
/*     */ 
/*     */         
/* 227 */         ((ICPacketPlayer)event.getPacket()).setOnGround(false);
/*     */ 
/*     */         
/* 230 */         switch (this.criticalEntity.hurtResistantTime) {
/*     */           case 20:
/* 232 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY + 0.5D);
/*     */             break;
/*     */           case 17:
/*     */           case 19:
/* 236 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY);
/*     */             break;
/*     */           case 18:
/* 239 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY + 0.30000001192092896D);
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/* 245 */       } else if (((Mode)mode.getValue()).equals(Mode.VANILLA_STRICT)) {
/*     */ 
/*     */         
/* 248 */         ((ICPacketPlayer)event.getPacket()).setOnGround(false);
/*     */ 
/*     */         
/* 251 */         switch (this.criticalEntity.hurtResistantTime) {
/*     */           case 19:
/* 253 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY + 0.10999999940395355D);
/*     */             break;
/*     */           case 18:
/* 256 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY + 0.11000135540962219D);
/*     */             break;
/*     */           case 17:
/* 259 */             ((ICPacketPlayer)event.getPacket()).setY((mc.player.getEntityBoundingBox()).minY + 1.357900032417092E-6D);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onCriticalHit(CriticalModifierEvent event) {
/* 272 */     event.setDamageModifier(((Double)modifier.getValue()).floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 280 */     PACKET((String)new float[] { 0.05F, 0.0F, 0.03F, 0.0F
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 285 */     PACKET_STRICT((String)new float[] { 0.11F, 0.110001355F, 1.3579E-6F
/*     */ 
/*     */ 
/*     */       
/*     */       }),
/* 290 */     VANILLA((String)new float[0]),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     VANILLA_STRICT((String)new float[0]),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     MOTION((String)new float[0]);
/*     */     
/*     */     private final float[] offsets;
/*     */ 
/*     */     
/*     */     Mode(float... offsets) {
/* 306 */       this.offsets = offsets;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float[] getOffsets() {
/* 314 */       return this.offsets;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\CriticalsModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
