//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.combat;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityPlayerSP;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.entity.EntityUtil;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.player.AngleUtil;
/*     */ import cope.cosmos.util.world.BlockUtil;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BurrowModule
/*     */   extends Module
/*     */ {
/*     */   public static BurrowModule INSTANCE;
/*     */   
/*     */   public BurrowModule() {
/*  37 */     super("Burrow", Category.COMBAT, "Glitches you into a block");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.clearTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onEnable() {
/*  65 */     super.onEnable();
/*     */ 
/*     */     
/*  68 */     BlockPos origin = new BlockPos(mc.player.posX, Math.round(mc.player.posY), mc.player.posZ);
/*     */ 
/*     */     
/*  71 */     if (mc.player.onGround)
/*     */     {
/*     */       
/*  74 */       if (!mc.world.getBlockState(origin).getMaterial().blocksMovement() && mc.player.collidedVertically) {
/*     */ 
/*     */         
/*  77 */         attackEntities(origin);
/*     */ 
/*     */         
/*  80 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.41999998688698D, mc.player.posZ, true));
/*  81 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7531999805211997D, mc.player.posZ, true));
/*  82 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.00133597911214D, mc.player.posZ, true));
/*  83 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.16610926093821D, mc.player.posZ, true));
/*     */ 
/*     */         
/*  86 */         mc.player.setPosition(mc.player.posX, mc.player.posY + 1.16610926093821D, mc.player.posZ);
/*  87 */         ((IEntityPlayerSP)mc.player).setLastReportedPosY(mc.player.posY + 1.16610926093821D);
/*     */ 
/*     */         
/*  90 */         int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */         
/*  93 */         if (!((InventoryManager.Switch)autoSwitch.getValue()).equals(InventoryManager.Switch.NONE)) {
/*     */ 
/*     */           
/*  96 */           int obsidianSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.OBSIDIAN), InventoryManager.InventoryRegion.HOTBAR);
/*  97 */           int echestSlot = getCosmos().getInventoryManager().searchSlot(Item.getItemFromBlock(Blocks.ENDER_CHEST), InventoryManager.InventoryRegion.HOTBAR);
/*     */ 
/*     */           
/* 100 */           if (obsidianSlot != -1) {
/* 101 */             getCosmos().getInventoryManager().switchToSlot(obsidianSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */           
/*     */           }
/* 105 */           else if (echestSlot != -1) {
/* 106 */             getCosmos().getInventoryManager().switchToSlot(echestSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 111 */         if (placeBlock(origin)) {
/*     */ 
/*     */           
/* 114 */           mc.player.setPosition(mc.player.posX, mc.player.posY - 1.16610926093821D, mc.player.posZ);
/*     */ 
/*     */ 
/*     */           
/* 118 */           double rubberbandOffset = getOffset();
/*     */ 
/*     */           
/* 121 */           if (!((Mode)mode.getValue()).equals(Mode.STALL))
/*     */           {
/*     */             
/* 124 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + rubberbandOffset, mc.player.posZ, false));
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 129 */         if (previousSlot != -1) {
/* 130 */           getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 136 */     disable(true);
/*     */   }
/*     */   public static Setting<Double> offset = (new Setting("Offset", Double.valueOf(-10.0D), Double.valueOf(2.2D), Double.valueOf(10.0D), 1)).setDescription("How high to rubberband");
/*     */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotation", Rotation.Rotate.NONE)).setDescription("Mode for attack rotations");
/*     */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false))).setDescription("Strict interactions");
/*     */   public static Setting<Mode> mode = (new Setting("Mode", Mode.DYNAMIC)).setDescription("Block to use when burrowing");
/*     */   public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NORMAL)).setDescription("How to switch when placing blocks");
/*     */   private final Timer clearTimer;
/*     */   
/*     */   public double getOffset() {
/* 146 */     if (((Mode)mode.getValue()).equals(Mode.DYNAMIC)) {
/*     */ 
/*     */       
/* 149 */       double rubberband = Math.abs(((Double)offset.getValue()).doubleValue());
/*     */ 
/*     */       
/* 152 */       for (double height = 0.0D; height < ((Double)offset.getValue()).doubleValue(); height += 0.01D) {
/*     */ 
/*     */         
/* 155 */         if (((Double)offset.getValue()).doubleValue() > 0.0D) {
/*     */ 
/*     */           
/* 158 */           if (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, height, 0.0D)).isEmpty())
/*     */           {
/*     */             
/* 161 */             rubberband = height;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/* 169 */         else if (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty()) {
/*     */ 
/*     */           
/* 172 */           rubberband = height;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 178 */       return (((Double)offset.getValue()).doubleValue() > 0.0D) ? Math.max(rubberband, 2.2D) : Math.max(-rubberband, -2.2D);
/*     */     } 
/*     */ 
/*     */     
/* 182 */     if (((Mode)mode.getValue()).equals(Mode.STATIC))
/*     */     {
/*     */       
/* 185 */       return ((Double)offset.getValue()).doubleValue();
/*     */     }
/*     */     
/* 188 */     return -1000.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean placeBlock(BlockPos in) {
/* 198 */     if (BlockUtil.isReplaceable(in)) {
/*     */ 
/*     */       
/* 201 */       getCosmos().getInteractionManager().placeBlock(in, (Rotation.Rotate)rotate.getValue(), ((Boolean)strict.getValue()).booleanValue());
/*     */ 
/*     */       
/* 204 */       return true;
/*     */     } 
/*     */     
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attackEntities(BlockPos in) {
/* 218 */     int ping = mc.player.connection.getPlayerInfo(mc.player.getUniqueID()).getResponseTime();
/*     */ 
/*     */     
/* 221 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(in))) {
/*     */ 
/*     */       
/* 224 */       if (entity == null || entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 229 */       if (this.clearTimer.passedTime((ping <= 50) ? 75L : 100L, Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */         
/* 232 */         Rotation rotation = AngleUtil.calculateAngles(entity.getPositionVector());
/*     */ 
/*     */         
/* 235 */         if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE) && rotation.isValid())
/*     */         {
/* 237 */           switch ((Rotation.Rotate)rotate.getValue()) {
/*     */             case CLIENT:
/* 239 */               mc.player.rotationYaw = rotation.getYaw();
/* 240 */               mc.player.rotationYawHead = rotation.getYaw();
/* 241 */               mc.player.rotationPitch = rotation.getPitch();
/*     */               break;
/*     */ 
/*     */             
/*     */             case PACKET:
/* 246 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotation.getYaw(), rotation.getPitch(), mc.player.onGround));
/*     */               break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 258 */         if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/*     */ 
/*     */           
/* 261 */           boolean sprintState = mc.player.isSprinting();
/*     */ 
/*     */           
/* 264 */           if (((Boolean)strict.getValue()).booleanValue())
/*     */           {
/*     */             
/* 267 */             if (sprintState) {
/* 268 */               mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */             }
/*     */           }
/*     */ 
/*     */           
/* 273 */           mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/* 274 */           mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */ 
/*     */           
/* 277 */           if (((Boolean)strict.getValue()).booleanValue())
/*     */           {
/*     */             
/* 280 */             if (sprintState) {
/* 281 */               mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */             }
/*     */           }
/*     */           
/* 285 */           this.clearTimer.resetTime();
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 290 */         if (EntityUtil.isVehicleMob(entity)) {
/*     */ 
/*     */           
/* 293 */           for (int i = 0; i < 3; i++) {
/* 294 */             mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/* 295 */             mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */           } 
/*     */           
/* 298 */           this.clearTimer.resetTime();
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 310 */     STATIC,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     DYNAMIC,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     STALL;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\combat\BurrowModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
