//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class NoFallModule
/*     */   extends Module {
/*     */   public static NoFallModule INSTANCE;
/*     */   
/*     */   public NoFallModule() {
/*  23 */     super("NoFall", Category.PLAYER, "Attempts to negate fall damage");
/*  24 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  29 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.PACKET))
/*  30 */     .setDescription("How to negate fall damage");
/*     */   
/*  32 */   public static Setting<Double> distance = (new Setting("Distance", Double.valueOf(1.0D), Double.valueOf(2.0D), Double.valueOf(5.0D), 1))
/*  33 */     .setDescription("The minimum fall distance before attempting to prevent fall damage");
/*     */   
/*  35 */   public static Setting<InventoryManager.Switch> autoSwitch = (new Setting("Switch", InventoryManager.Switch.NORMAL))
/*  36 */     .setDescription("Mode to use when switching to a water bucket")
/*  37 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.WATER)));
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static Setting<Double> glideSpeed = (new Setting("GlideSpeed", Double.valueOf(0.1D), Double.valueOf(1.5D), Double.valueOf(5.0D), 1))
/*  42 */     .setDescription("The factor to slow down fall speed")
/*  43 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.GLIDE)));
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static Setting<Boolean> factorize = (new Setting("Factorize", Boolean.valueOf(false)))
/*  48 */     .setDescription("Spoof fall distance")
/*  49 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.RUBBERBAND)));
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  54 */     if (shouldNegateFallDamage() && !mc.player.isOverWater()) {
/*     */       int previousSlot;
/*  56 */       switch ((Mode)mode.getValue()) {
/*     */         
/*     */         case GLIDE:
/*  59 */           mc.player.motionY /= ((Double)glideSpeed.getValue()).doubleValue();
/*     */           break;
/*     */         
/*     */         case WATER:
/*  63 */           previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */           
/*  66 */           getCosmos().getInventoryManager().switchToItem(Items.WATER_BUCKET, (InventoryManager.Switch)autoSwitch.getValue());
/*     */ 
/*     */           
/*  69 */           getCosmos().getRotationManager().setRotation(new Rotation(mc.player.rotationYaw, 90.0F));
/*  70 */           mc.playerController.processRightClick((EntityPlayer)mc.player, (World)mc.world, EnumHand.MAIN_HAND);
/*     */ 
/*     */           
/*  73 */           if (previousSlot != -1) {
/*  74 */             getCosmos().getInventoryManager().switchToSlot(previousSlot, (InventoryManager.Switch)autoSwitch.getValue());
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case RUBBERBAND:
/*  80 */           if (mc.player.dimension != 1) {
/*  81 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, true));
/*     */           }
/*     */           else {
/*     */             
/*  85 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(0.0D, 64.0D, 0.0D, true));
/*     */           } 
/*     */ 
/*     */           
/*  89 */           if (((Boolean)factorize.getValue()).booleanValue()) {
/*  90 */             mc.player.fallDistance = 0.0F;
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 102 */     if (event.getPacket() instanceof CPacketPlayer && shouldNegateFallDamage())
/*     */     {
/*     */       
/* 105 */       if (((Mode)mode.getValue()).equals(Mode.PACKET) || ((Mode)mode.getValue()).equals(Mode.GLIDE))
/*     */       {
/*     */         
/* 108 */         ((ICPacketPlayer)event.getPacket()).setOnGround(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldNegateFallDamage() {
/* 118 */     return (mc.player.fallDistance >= ((Double)distance.getValue()).doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 126 */     PACKET,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     GLIDE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     WATER,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     RUBBERBAND;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\NoFallModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
