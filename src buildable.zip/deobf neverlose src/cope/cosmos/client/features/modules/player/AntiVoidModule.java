//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.modules.movement.PacketFlightModule;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ 
/*    */ 
/*    */ public class AntiVoidModule
/*    */   extends Module
/*    */ {
/*    */   public static AntiVoidModule INSTANCE;
/*    */   
/*    */   public AntiVoidModule() {
/* 18 */     super("AntiVoid", Category.PLAYER, "Prevents you from getting stuck in the void");
/* 19 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.SOLID))
/* 25 */     .setDescription("How to stop you from falling into the void");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 31 */     if (!mc.player.isSpectator() && !PacketFlightModule.INSTANCE.isEnabled())
/*    */     {
/*    */       
/* 34 */       if (mc.player.posY < 1.0D) {
/*    */ 
/*    */         
/* 37 */         getCosmos().getChatManager().sendClientMessage("[AntiVoid] " + ChatFormatting.RED + "Attempting to get player out of void!", -6980085);
/*    */         
/* 39 */         switch ((Mode)mode.getValue()) {
/*    */ 
/*    */           
/*    */           case SOLID:
/* 43 */             mc.player.motionY = 0.0D;
/*    */             break;
/*    */ 
/*    */           
/*    */           case TRAMPOLINE:
/* 48 */             mc.player.motionY = 0.5D;
/*    */             break;
/*    */ 
/*    */           
/*    */           case GLIDE:
/* 53 */             if (mc.player.motionY < 0.0D) {
/* 54 */               mc.player.motionY /= 3.0D;
/*    */             }
/*    */             break;
/*    */ 
/*    */ 
/*    */           
/*    */           case RUBBERBAND:
/* 61 */             mc.player.setVelocity(0.0D, 0.0D, 0.0D);
/*    */ 
/*    */ 
/*    */             
/* 65 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 10.0D, mc.player.posZ, false));
/*    */             break;
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Mode
/*    */   {
/* 77 */     SOLID,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     SOLID_STRICT,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 87 */     TRAMPOLINE,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 92 */     GLIDE,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 97 */     RUBBERBAND;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\AntiVoidModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
