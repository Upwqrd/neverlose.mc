//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IMinecraft;
/*     */ import cope.cosmos.client.events.entity.player.interact.RightClickItemEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.player.InventoryUtil;
/*     */ import cope.cosmos.util.world.ShiftBlocks;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class FastUseModule
/*     */   extends Module
/*     */ {
/*     */   public static FastUseModule INSTANCE;
/*     */   
/*     */   public FastUseModule() {
/*  32 */     super("FastUse", Category.PLAYER, "Allows you to place items and blocks faster");
/*  33 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static Setting<Double> speed = (new Setting("Speed", Double.valueOf(0.0D), Double.valueOf(4.0D), Double.valueOf(4.0D), 0))
/*  39 */     .setDescription("Place speed");
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static Setting<Boolean> ghostFix = (new Setting("GhostFix", Boolean.valueOf(false)))
/*  44 */     .setDescription("Fixes the item ghost issue on some servers");
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static Setting<Boolean> fastDrop = (new Setting("FastDrop", Boolean.valueOf(false)))
/*  49 */     .setDescription("Drops items faster");
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static Setting<Boolean> packetUse = (new Setting("PacketUse", Boolean.valueOf(false)))
/*  54 */     .setDescription("Uses packets when using items");
/*     */   
/*  56 */   public static Setting<Boolean> packetFood = (new Setting("PacketFood", Boolean.valueOf(false)))
/*  57 */     .setDescription("Uses packets when eating food")
/*  58 */     .setVisible(() -> (Boolean)packetUse.getValue());
/*     */   
/*  60 */   public static Setting<Boolean> packetPotion = (new Setting("PacketPotions", Boolean.valueOf(true)))
/*  61 */     .setDescription("Uses packets when drinking potions")
/*  62 */     .setVisible(() -> (Boolean)packetUse.getValue());
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static Setting<Boolean> exp = (new Setting("EXP", Boolean.valueOf(true)))
/*  67 */     .setDescription("Applies fast placements to experience");
/*     */   
/*  69 */   public static Setting<Boolean> crystals = (new Setting("Crystals", Boolean.valueOf(false)))
/*  70 */     .setDescription("Applies fast placements to crystals");
/*     */   
/*  72 */   public static Setting<Boolean> blocks = (new Setting("Blocks", Boolean.valueOf(false)))
/*  73 */     .setDescription("Applies fast placements to blocks");
/*     */   
/*  75 */   public static Setting<Boolean> spawnEggs = (new Setting("SpawnEggs", Boolean.valueOf(false)))
/*  76 */     .setDescription("Applies fast placements to spawn eggs");
/*     */   
/*  78 */   public static Setting<Boolean> fireworks = (new Setting("Fireworks", Boolean.valueOf(false)))
/*  79 */     .setDescription("Applies fast placements to fireworks");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  85 */     if (isHoldingValidItem()) {
/*     */ 
/*     */       
/*  88 */       mc.player.xpCooldown = 0;
/*     */ 
/*     */       
/*  91 */       if (((Boolean)ghostFix.getValue()).booleanValue()) {
/*     */ 
/*     */         
/*  94 */         if (mc.gameSettings.keyBindUseItem.isKeyDown()) {
/*  95 */           mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 102 */         ((IMinecraft)mc).setRightClickDelayTimer(((Double)speed.getMax()).intValue() - ((Double)speed.getValue()).intValue());
/*     */       } 
/*     */     } 
/*     */     
/* 106 */     if (((Boolean)fastDrop.getValue()).booleanValue())
/*     */     {
/*     */       
/* 109 */       if (mc.gameSettings.keyBindDrop.isKeyDown()) {
/* 110 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.DROP_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 117 */     if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock)
/*     */     {
/*     */       
/* 120 */       if (((Boolean)ghostFix.getValue()).booleanValue() && 
/* 121 */         isHoldingValidItem()) {
/*     */ 
/*     */         
/* 124 */         Block interactBlock = mc.world.getBlockState(((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getPos()).getBlock();
/*     */ 
/*     */         
/* 127 */         if (!ShiftBlocks.contains(interactBlock)) {
/* 128 */           event.setCanceled(true);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerRightClick(RightClickItemEvent event) {
/* 137 */     if (((Boolean)packetUse.getValue()).booleanValue())
/*     */     {
/*     */       
/* 140 */       if ((((Boolean)packetFood.getValue()).booleanValue() && event.getItemStack().getItem() instanceof net.minecraft.item.ItemFood) || (((Boolean)packetPotion.getValue()).booleanValue() && event.getItemStack().getItem().equals(Items.POTIONITEM))) {
/*     */ 
/*     */         
/* 143 */         event.setCanceled(true);
/* 144 */         event.getItemStack().getItem().onItemUseFinish(event.getItemStack(), (World)mc.world, (EntityLivingBase)mc.player);
/*     */ 
/*     */         
/* 147 */         for (int i = 0; i < event.getItemStack().getMaxItemUseDuration(); i++) {
/* 148 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer());
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHoldingValidItem() {
/* 159 */     return ((InventoryUtil.isHolding(Items.EXPERIENCE_BOTTLE) && ((Boolean)exp.getValue()).booleanValue()) || (InventoryUtil.isHolding(Items.END_CRYSTAL) && ((Boolean)crystals.getValue()).booleanValue()) || (InventoryUtil.isHolding(Items.SPAWN_EGG) && ((Boolean)spawnEggs.getValue()).booleanValue()) || (InventoryUtil.isHolding(Items.FIREWORKS) && ((Boolean)fireworks.getValue()).booleanValue()) || (InventoryUtil.isHolding(ItemBlock.class) && ((Boolean)blocks.getValue()).booleanValue()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 164 */     return (isEnabled() && isHoldingValidItem() && mc.player.isHandActive());
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\FastUseModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
