//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.combat.AutoCrystalModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class ReplenishModule
/*     */   extends Module {
/*     */   public static ReplenishModule INSTANCE;
/*     */   public static Setting<Double> percent = (new Setting("Percent", Double.valueOf(1.0D), Double.valueOf(70.0D), Double.valueOf(99.0D), 1)).setDescription("The percentage of the item stack size from 100% before replacing");
/*     */   public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.0D), Double.valueOf(100.0D), Double.valueOf(1000.0D), 1)).setDescription("The delay in ms before replenishing");
/*     */   public static Setting<Boolean> wait = (new Setting("Wait", Boolean.valueOf(false))).setDescription("If the item is a crystal and a combat module is on, it will wait for the combat module to be turned off");
/*     */   
/*     */   public ReplenishModule() {
/*  24 */     super("Replenish", Category.PLAYER, "Replaces items in your hotbar with items from your inventory");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.hotbar = new ConcurrentHashMap<>();
/*     */ 
/*     */     
/*  43 */     this.timer = new Timer();
/*     */ 
/*     */     
/*  46 */     this.refillSlot = -1;
/*     */     INSTANCE = this;
/*     */   }
/*     */   public void onDisable() {
/*  50 */     super.onDisable();
/*     */ 
/*     */     
/*  53 */     this.hotbar.clear();
/*  54 */     this.refillSlot = -1;
/*     */   }
/*     */   private final Map<Integer, ItemStack> hotbar;
/*     */   private final Timer timer;
/*     */   private int refillSlot;
/*     */   
/*     */   public void onTick() {
/*  61 */     if (this.refillSlot == -1) {
/*     */ 
/*     */       
/*  64 */       for (int i = 0; i < 9; i++) {
/*     */ 
/*     */         
/*  67 */         ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */ 
/*     */         
/*  70 */         if (this.hotbar.getOrDefault(Integer.valueOf(i), null) == null) {
/*     */ 
/*     */           
/*  73 */           if (!stack.getItem().equals(Items.AIR))
/*     */           {
/*     */ 
/*     */             
/*  77 */             this.hotbar.put(Integer.valueOf(i), stack);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/*  84 */           double percentage = stack.getCount() / stack.getMaxStackSize() * 100.0D;
/*     */ 
/*     */           
/*  87 */           if (percentage <= ((Double)percent.getValue()).doubleValue())
/*     */           {
/*     */             
/*  90 */             if (!stack.getItem().equals(Items.END_CRYSTAL) || !((Boolean)wait.getValue()).booleanValue() || !AutoCrystalModule.INSTANCE.isEnabled()) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  95 */               if (!this.timer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */                 
/*  98 */                 this.refillSlot = i;
/*     */ 
/*     */                 
/*     */                 break;
/*     */               } 
/*     */               
/* 104 */               fillStack(i, stack);
/*     */ 
/*     */               
/* 107 */               this.timer.resetTime();
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/* 117 */     } else if (this.timer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.MILLISECONDS)) {
/*     */ 
/*     */       
/* 120 */       fillStack(this.refillSlot, this.hotbar.get(Integer.valueOf(this.refillSlot)));
/*     */ 
/*     */       
/* 123 */       this.timer.resetTime();
/* 124 */       this.refillSlot = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillStack(int slot, ItemStack stack) {
/* 137 */     if (slot != -1 && stack != null) {
/*     */       
/* 139 */       int replenishSlot = -1;
/*     */ 
/*     */       
/* 142 */       for (int i = 9; i < 36; i++) {
/* 143 */         ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
/*     */ 
/*     */         
/* 146 */         if (!itemStack.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 151 */           if (!stack.getDisplayName().equals(itemStack.getDisplayName())) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 156 */           if (stack.getItem() instanceof ItemBlock) {
/*     */             
/* 158 */             if (!(itemStack.getItem() instanceof ItemBlock)) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 163 */             ItemBlock hotbarBlock = (ItemBlock)stack.getItem();
/* 164 */             ItemBlock inventoryBlock = (ItemBlock)itemStack.getItem();
/*     */ 
/*     */             
/* 167 */             if (!hotbarBlock.getBlock().equals(inventoryBlock.getBlock()))
/*     */             {
/*     */               continue;
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 174 */           else if (!stack.getItem().equals(itemStack.getItem())) {
/*     */             continue;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 180 */           replenishSlot = i;
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 185 */       if (replenishSlot != -1) {
/*     */ 
/*     */ 
/*     */         
/* 189 */         int total = stack.getCount() + mc.player.inventory.getStackInSlot(replenishSlot).getCount();
/*     */ 
/*     */         
/* 192 */         mc.playerController.windowClick(0, replenishSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */         
/* 195 */         mc.playerController.windowClick(0, (slot < 9) ? (slot + 36) : slot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 201 */         if (total >= stack.getMaxStackSize()) {
/* 202 */           mc.playerController.windowClick(0, replenishSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */         }
/*     */ 
/*     */         
/* 206 */         this.refillSlot = -1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\ReplenishModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
