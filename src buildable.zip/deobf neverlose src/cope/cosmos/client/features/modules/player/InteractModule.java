//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayerTryUseItemOnBlock;
/*     */ import cope.cosmos.client.events.block.LiquidInteractEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.combat.AutoCrystalModule;
/*     */ import cope.cosmos.client.features.modules.combat.BurrowModule;
/*     */ import cope.cosmos.client.features.modules.combat.HoleFillModule;
/*     */ import cope.cosmos.client.features.modules.combat.SurroundModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.world.ShiftBlocks;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.block.BlockLiquid;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InteractModule
/*     */   extends Module
/*     */ {
/*     */   public static InteractModule INSTANCE;
/*     */   
/*     */   public InteractModule() {
/*  34 */     super("Interact", Category.PLAYER, "Changes how you interact with blocks & entities");
/*  35 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static Setting<Boolean> ghostHand = (new Setting("GhostHand", Boolean.valueOf(false)))
/*  41 */     .setDescription("Allows you to interact with blocks through walls");
/*     */   
/*  43 */   public static Setting<Boolean> noSwing = (new Setting("NoSwing", Boolean.valueOf(false)))
/*  44 */     .setDescription("Cancels the server side animation for swinging");
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static Setting<Boolean> ignoreContainer = (new Setting("IgnoreContainers", Boolean.valueOf(false)))
/*  49 */     .setDescription("Ignores containers");
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static Setting<Boolean> liquid = (new Setting("Liquid", Boolean.valueOf(false)))
/*  54 */     .setDescription("Allows you to place blocks on liquid");
/*     */   
/*  56 */   public static Setting<Boolean> heightLimit = (new Setting("HeightLimit", Boolean.valueOf(true)))
/*  57 */     .setDescription("Allows you to interact with blocks at height limit");
/*     */   
/*  59 */   public static Setting<Boolean> worldBorder = (new Setting("WorldBorder", Boolean.valueOf(false)))
/*  60 */     .setDescription("Allows you to interact with blocks at the world border");
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLiquidInteract(LiquidInteractEvent event) {
/*  66 */     if (((Boolean)liquid.getValue()).booleanValue() || (event.getLiquidLevel() && ((Integer)event.getBlockState().getValue((IProperty)BlockLiquid.LEVEL)).intValue() == 0)) {
/*  67 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  75 */     if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
/*     */ 
/*     */       
/*  78 */       BlockPos limitPosition = ((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getPos();
/*     */ 
/*     */       
/*  81 */       if (((Boolean)heightLimit.getValue()).booleanValue() && limitPosition.getY() >= mc.world.getHeight() - 1 && ((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getDirection().equals(EnumFacing.UP)) {
/*  82 */         ((ICPacketPlayerTryUseItemOnBlock)event.getPacket()).setDirection(EnumFacing.DOWN);
/*     */       }
/*     */ 
/*     */       
/*  86 */       if (((Boolean)worldBorder.getValue()).booleanValue() && mc.world.getWorldBorder().contains(limitPosition)) {
/*     */ 
/*     */         
/*  89 */         EnumFacing oppositeFace = ((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getDirection().getOpposite();
/*     */ 
/*     */         
/*  92 */         ((ICPacketPlayerTryUseItemOnBlock)event.getPacket()).setDirection(oppositeFace);
/*     */       } 
/*     */ 
/*     */       
/*  96 */       if (((Boolean)ignoreContainer.getValue()).booleanValue() && 
/*  97 */         ShiftBlocks.contains(mc.world.getBlockState(limitPosition).getBlock())) {
/*  98 */         event.setCanceled(true);
/*     */       }
/*     */ 
/*     */       
/* 102 */       if (((Boolean)ghostHand.getValue()).booleanValue()) {
/*     */ 
/*     */         
/* 105 */         if (AutoCrystalModule.INSTANCE.isActive() || HoleFillModule.INSTANCE.isActive() || BurrowModule.INSTANCE.isEnabled() || SurroundModule.INSTANCE.isActive()) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 110 */         (new ArrayList(mc.world.loadedTileEntityList)).forEach(tileEntity -> {
/*     */               if (limitPosition.equals(tileEntity.getPos())) {
/*     */                 return;
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               if (limitPosition.getDistance(tileEntity.getPos().getX(), tileEntity.getPos().getY(), tileEntity.getPos().getZ()) <= 3.0D) {
/*     */                 mc.playerController.processRightClickBlock(mc.player, mc.world, tileEntity.getPos(), EnumFacing.UP, new Vec3d(0.0D, 0.0D, 0.0D), EnumHand.MAIN_HAND);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 126 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketAnimation && ((Boolean)noSwing.getValue()).booleanValue())
/* 127 */       event.setCanceled(true); 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\InteractModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
