//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*    */ import cope.cosmos.asm.mixins.accessor.IEntityPlayerSP;
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketEntityAction;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AntiHungerModule
/*    */   extends Module
/*    */ {
/*    */   public static AntiHungerModule INSTANCE;
/*    */   
/*    */   public AntiHungerModule() {
/* 22 */     super("AntiHunger", Category.PLAYER, "Attempts to negate hunger loss");
/* 23 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public static Setting<Boolean> stopSprint = (new Setting("StopSprint", Boolean.valueOf(true)))
/* 29 */     .setDescription("If to cancel sprint packets");
/*    */   
/* 31 */   public static Setting<Boolean> groundSpoof = (new Setting("GroundSpoof", Boolean.valueOf(true)))
/* 32 */     .setDescription("Spoof your on ground state");
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean previousSprint;
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 41 */     if (mc.player.isSprinting() || ((IEntityPlayerSP)mc.player).getServerSprintState()) {
/* 42 */       this.previousSprint = true;
/* 43 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
/*    */     } 
/*    */     
/* 46 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 51 */     super.onDisable();
/*    */ 
/*    */     
/* 54 */     if (this.previousSprint) {
/* 55 */       this.previousSprint = false;
/* 56 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 64 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketPlayer) {
/*    */       
/* 66 */       if (((Boolean)groundSpoof.getValue()).booleanValue())
/*    */       {
/*    */         
/* 69 */         if (!mc.player.isRiding() && !mc.player.isElytraFlying())
/*    */         {
/*    */           
/* 72 */           ((ICPacketPlayer)event.getPacket()).setOnGround(true);
/*    */         
/*    */         }
/*    */       
/*    */       }
/*    */     }
/* 78 */     else if (event.getPacket() instanceof CPacketEntityAction) {
/*    */ 
/*    */       
/* 81 */       CPacketEntityAction packet = (CPacketEntityAction)event.getPacket();
/*    */ 
/*    */       
/* 84 */       if (packet.getAction().equals(CPacketEntityAction.Action.START_SPRINTING) || packet.getAction().equals(CPacketEntityAction.Action.STOP_SPRINTING))
/*    */       {
/*    */         
/* 87 */         if (((Boolean)stopSprint.getValue()).booleanValue())
/*    */         {
/*    */           
/* 90 */           event.setCanceled(true);
/*    */         }
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\AntiHungerModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
