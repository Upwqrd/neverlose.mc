//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketConfirmTransaction;
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketKeepAlive;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PingSpoofModule
/*     */   extends Module
/*     */ {
/*     */   public static PingSpoofModule INSTANCE;
/*     */   
/*     */   public PingSpoofModule() {
/*  27 */     super("PingSpoof", Category.PLAYER, "Spoofs your latency to the server");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.packets = new CopyOnWriteArrayList<>();
/*     */ 
/*     */     
/*  48 */     this.packetTimer = new Timer();
/*     */     INSTANCE = this;
/*     */   }
/*     */   public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.1D), Double.valueOf(0.5D), Double.valueOf(5.0D), 1)).setDescription("The delay in seconds to hold off sending packets"); public static Setting<Boolean> reduction = (new Setting("Reduction", Boolean.valueOf(false))).setDescription("Lowers your ping on some servers");
/*     */   
/*     */   public void onUpdate() {
/*  54 */     if (this.packetTimer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.SECONDS)) {
/*     */ 
/*     */       
/*  57 */       if (!this.packets.isEmpty()) {
/*     */ 
/*     */         
/*  60 */         this.packets.forEach(packet -> {
/*     */               if (packet != null) {
/*     */                 if (((Boolean)reduction.getValue()).booleanValue()) {
/*     */                   if (packet instanceof net.minecraft.network.play.client.CPacketKeepAlive) {
/*     */                     ((ICPacketKeepAlive)packet).setKey(-1L);
/*     */                   } else if (packet instanceof net.minecraft.network.play.client.CPacketConfirmTransaction) {
/*     */                     ((ICPacketConfirmTransaction)packet).setUid((short)-6);
/*     */                   } 
/*     */                 }
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 mc.player.connection.sendPacket(packet);
/*     */               } 
/*     */             });
/*     */ 
/*     */ 
/*     */         
/*  79 */         this.packets.clear();
/*     */       } 
/*     */ 
/*     */       
/*  83 */       this.packetTimer.resetTime();
/*     */     } 
/*     */   }
/*     */   public static Setting<Boolean> transactions = (new Setting("Transactions", Boolean.valueOf(false))).setDescription("If to cancel confirm transaction packets as well"); private final List<Packet<?>> packets; private final Timer packetTimer;
/*     */   
/*     */   public void onDisable() {
/*  89 */     super.onDisable();
/*     */ 
/*     */     
/*  92 */     if (!this.packets.isEmpty()) {
/*     */ 
/*     */       
/*  95 */       this.packets.forEach(packet -> {
/*     */             if (packet != null) {
/*     */               mc.player.connection.sendPacket(packet);
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 102 */       this.packets.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 111 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketKeepAlive || (((Boolean)transactions.getValue()).booleanValue() && event.getPacket() instanceof net.minecraft.network.play.client.CPacketConfirmTransaction))
/*     */     {
/*     */       
/* 114 */       if (!this.packets.contains(event.getPacket())) {
/*     */ 
/*     */         
/* 117 */         event.setCanceled(true);
/* 118 */         this.packets.add(event.getPacket());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\PingSpoofModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
