//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.combat.EnemyUtil;
/*    */ import cope.cosmos.util.math.Timer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.client.event.GuiOpenEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoRespawnModule
/*    */   extends Module
/*    */ {
/*    */   public static AutoRespawnModule INSTANCE;
/*    */   
/*    */   public AutoRespawnModule() {
/* 21 */     super("AutoRespawn", Category.PLAYER, "Automatically respawns you");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 31 */     this.respawnTimer = new Timer();
/* 32 */     this.awaitRespawn = false;
/*    */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onGuiOpen(GuiOpenEvent event) {
/* 38 */     if (event.getGui() instanceof net.minecraft.client.gui.GuiGameOver) {
/* 39 */       this.respawnTimer.resetTime();
/* 40 */       this.awaitRespawn = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.0D), Double.valueOf(0.5D), Double.valueOf(5.0D), 1)).setDescription("The delay in seconds to hold off sending a respawn packet");
/*    */   
/*    */   public void onTick() {
/* 48 */     if (EnemyUtil.isDead((Entity)mc.player))
/*    */     {
/*    */       
/* 51 */       if (this.awaitRespawn)
/*    */       {
/*    */         
/* 54 */         if (this.respawnTimer.passedTime((long)(((Double)delay.getValue()).doubleValue() * 1000.0D), Timer.Format.MILLISECONDS)) {
/*    */ 
/*    */           
/* 57 */           mc.player.respawnPlayer();
/* 58 */           this.awaitRespawn = false;
/*    */         }  }  } 
/*    */   }
/*    */   
/*    */   private final Timer respawnTimer;
/*    */   private boolean awaitRespawn;
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\AutoRespawnModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
