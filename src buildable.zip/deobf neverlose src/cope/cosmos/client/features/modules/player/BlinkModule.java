//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.visual.BreadcrumbsModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlinkModule
/*     */   extends Module
/*     */ {
/*     */   public static BlinkModule INSTANCE;
/*     */   
/*     */   public BlinkModule() {
/*  33 */     super("Blink", Category.PLAYER, "Caches player packets and dumps them all at once");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.playerPackets = new CopyOnWriteArrayList<>();
/*     */ 
/*     */     
/*  60 */     this.packetTimer = new Timer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.positions = new LinkedList<>();
/*     */     INSTANCE = this;
/*     */   } public static Setting<Mode> mode = (new Setting("Mode", Mode.MANUAL)).setDescription("When to send packets"); public static Setting<Double> delay = (new Setting("Delay", Double.valueOf(0.1D), Double.valueOf(1.0D), Double.valueOf(10.0D), 1)).setDescription("The delay in seconds until sending all packets").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PULSE))); public static Setting<Double> packets = (new Setting("Packets", Double.valueOf(0.0D), Double.valueOf(10.0D), Double.valueOf(200.0D), 0)).setDescription("The amount of packets until sending all packets").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKETS))); public static Setting<Double> distance = (new Setting("Distance", Double.valueOf(1.0D), Double.valueOf(10.0D), Double.valueOf(20.0D), 0)).setDescription("The distance in blocks from the last position until sending all packets").setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.DISTANCE)));
/*     */   public void onEnable() {
/*  71 */     super.onEnable();
/*     */ 
/*     */     
/*  74 */     this.serverPosition = mc.player.getPosition();
/*     */ 
/*     */     
/*  77 */     EntityOtherPlayerMP serverPositionModel = new EntityOtherPlayerMP((World)mc.world, mc.player.getGameProfile());
/*     */ 
/*     */     
/*  80 */     serverPositionModel.copyLocationAndAnglesFrom((Entity)mc.player);
/*  81 */     serverPositionModel.rotationYawHead = mc.player.rotationYaw;
/*  82 */     serverPositionModel.inventory.copyInventory(mc.player.inventory);
/*  83 */     serverPositionModel.setSneaking(mc.player.isSneaking());
/*  84 */     serverPositionModel.setPrimaryHand(mc.player.getPrimaryHand());
/*     */ 
/*     */     
/*  87 */     mc.world.addEntityToWorld(-100, (Entity)serverPositionModel);
/*     */   }
/*     */   private final List<Packet<?>> playerPackets; private final Timer packetTimer; private BlockPos serverPosition; private final LinkedList<BreadcrumbsModule.Position> positions;
/*     */   
/*     */   public void onDisable() {
/*  92 */     super.onDisable();
/*     */ 
/*     */     
/*  95 */     if (!this.playerPackets.isEmpty()) {
/*  96 */       this.playerPackets.forEach(packet -> {
/*     */             if (packet != null) {
/*     */               mc.player.connection.sendPacket(packet);
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 103 */       this.playerPackets.clear();
/*     */     } 
/*     */ 
/*     */     
/* 107 */     mc.world.removeEntityFromWorld(-100);
/* 108 */     this.serverPosition = null;
/*     */ 
/*     */     
/* 111 */     this.positions.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 116 */     if (!nullCheck() || mc.player.ticksExisted <= 20) {
/*     */ 
/*     */       
/* 119 */       this.positions.clear();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 125 */     this.positions.add(new BreadcrumbsModule.Position(new Vec3d(mc.player.lastTickPosX, mc.player.lastTickPosY, mc.player.lastTickPosZ), System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 130 */     switch ((Mode)mode.getValue()) {
/*     */       case PULSE:
/* 132 */         if (this.packetTimer.passedTime(((Double)delay.getValue()).longValue(), Timer.Format.SECONDS)) {
/*     */ 
/*     */           
/* 135 */           mc.world.removeEntityFromWorld(-100);
/*     */ 
/*     */           
/* 138 */           this.serverPosition = mc.player.getPosition();
/*     */ 
/*     */           
/* 141 */           EntityOtherPlayerMP serverPositionModel = new EntityOtherPlayerMP((World)mc.world, mc.player.getGameProfile());
/*     */ 
/*     */           
/* 144 */           serverPositionModel.copyLocationAndAnglesFrom((Entity)mc.player);
/* 145 */           serverPositionModel.rotationYawHead = mc.player.rotationYaw;
/* 146 */           serverPositionModel.inventory.copyInventory(mc.player.inventory);
/* 147 */           serverPositionModel.setSneaking(mc.player.isSneaking());
/* 148 */           serverPositionModel.setPrimaryHand(mc.player.getPrimaryHand());
/*     */ 
/*     */           
/* 151 */           mc.world.addEntityToWorld(-100, (Entity)serverPositionModel);
/*     */ 
/*     */           
/* 154 */           if (!this.playerPackets.isEmpty()) {
/* 155 */             this.playerPackets.forEach(packet -> {
/*     */                   if (packet != null) {
/*     */                     mc.player.connection.sendPacket(packet);
/*     */                   }
/*     */                 });
/*     */ 
/*     */             
/* 162 */             this.playerPackets.clear();
/* 163 */             this.positions.clear();
/*     */           } 
/*     */ 
/*     */           
/* 167 */           this.packetTimer.resetTime();
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case PACKETS:
/* 174 */         if (this.playerPackets.size() >= ((Double)packets.getValue()).doubleValue()) {
/*     */ 
/*     */           
/* 177 */           mc.world.removeEntityFromWorld(-100);
/*     */ 
/*     */           
/* 180 */           this.serverPosition = mc.player.getPosition();
/*     */ 
/*     */           
/* 183 */           EntityOtherPlayerMP serverPositionModel = new EntityOtherPlayerMP((World)mc.world, mc.player.getGameProfile());
/*     */ 
/*     */           
/* 186 */           serverPositionModel.copyLocationAndAnglesFrom((Entity)mc.player);
/* 187 */           serverPositionModel.rotationYawHead = mc.player.rotationYaw;
/* 188 */           serverPositionModel.inventory.copyInventory(mc.player.inventory);
/* 189 */           serverPositionModel.setSneaking(mc.player.isSneaking());
/* 190 */           serverPositionModel.setPrimaryHand(mc.player.getPrimaryHand());
/*     */ 
/*     */           
/* 193 */           mc.world.addEntityToWorld(-100, (Entity)serverPositionModel);
/*     */ 
/*     */           
/* 196 */           if (!this.playerPackets.isEmpty()) {
/* 197 */             this.playerPackets.forEach(packet -> {
/*     */                   if (packet != null) {
/*     */                     mc.player.connection.sendPacket(packet);
/*     */                   }
/*     */                 });
/*     */ 
/*     */             
/* 204 */             this.playerPackets.clear();
/* 205 */             this.positions.clear();
/*     */           } 
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case DISTANCE:
/* 213 */         if (mc.player.getDistance(this.serverPosition.getX(), this.serverPosition.getY(), this.serverPosition.getZ()) >= ((Double)distance.getValue()).doubleValue()) {
/*     */ 
/*     */           
/* 216 */           mc.world.removeEntityFromWorld(-100);
/*     */ 
/*     */           
/* 219 */           this.serverPosition = mc.player.getPosition();
/*     */ 
/*     */           
/* 222 */           EntityOtherPlayerMP serverPositionModel = new EntityOtherPlayerMP((World)mc.world, mc.player.getGameProfile());
/*     */ 
/*     */           
/* 225 */           serverPositionModel.copyLocationAndAnglesFrom((Entity)mc.player);
/* 226 */           serverPositionModel.rotationYawHead = mc.player.rotationYaw;
/* 227 */           serverPositionModel.inventory.copyInventory(mc.player.inventory);
/* 228 */           serverPositionModel.setSneaking(mc.player.isSneaking());
/* 229 */           serverPositionModel.setPrimaryHand(mc.player.getPrimaryHand());
/*     */ 
/*     */           
/* 232 */           mc.world.addEntityToWorld(-100, (Entity)serverPositionModel);
/*     */ 
/*     */           
/* 235 */           if (!this.playerPackets.isEmpty()) {
/* 236 */             this.playerPackets.forEach(packet -> {
/*     */                   if (packet != null) {
/*     */                     mc.player.connection.sendPacket(packet);
/*     */                   }
/*     */                 });
/*     */ 
/*     */             
/* 243 */             this.playerPackets.clear();
/* 244 */             this.positions.clear();
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/* 254 */     GL11.glPushMatrix();
/* 255 */     GL11.glDisable(3553);
/* 256 */     GL11.glBlendFunc(770, 771);
/* 257 */     GL11.glEnable(2848);
/* 258 */     GL11.glEnable(3042);
/* 259 */     GL11.glDisable(2929);
/* 260 */     GL11.glLineWidth(1.5F);
/*     */ 
/*     */     
/* 263 */     mc.entityRenderer.disableLightmap();
/*     */     
/* 265 */     GL11.glBegin(3);
/*     */ 
/*     */     
/* 268 */     this.positions.forEach(position -> {
/*     */           GL11.glColor4f(ColorUtil.getPrimaryColor().getRed() / 255.0F, ColorUtil.getPrimaryColor().getGreen() / 255.0F, ColorUtil.getPrimaryColor().getBlue() / 255.0F, 1.0F);
/*     */ 
/*     */ 
/*     */           
/*     */           GL11.glVertex3d((position.getVec()).x - (mc.getRenderManager()).viewerPosX, (position.getVec()).y - (mc.getRenderManager()).viewerPosY, (position.getVec()).z - (mc.getRenderManager()).viewerPosZ);
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 278 */     GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
/*     */     
/* 280 */     GL11.glEnd();
/* 281 */     GL11.glEnable(2929);
/* 282 */     GL11.glDisable(2848);
/* 283 */     GL11.glDisable(3042);
/* 284 */     GL11.glEnable(3553);
/* 285 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 292 */     if (!(event.getPacket() instanceof net.minecraft.network.play.client.CPacketChatMessage) && !(event.getPacket() instanceof net.minecraft.network.play.client.CPacketConfirmTeleport) && !(event.getPacket() instanceof net.minecraft.network.play.client.CPacketKeepAlive) && !(event.getPacket() instanceof net.minecraft.network.play.client.CPacketTabComplete) && !(event.getPacket() instanceof net.minecraft.network.play.client.CPacketClientStatus))
/*     */     {
/*     */       
/* 295 */       if (!this.playerPackets.contains(event.getPacket())) {
/*     */ 
/*     */         
/* 298 */         event.setCanceled(true);
/* 299 */         this.playerPackets.add(event.getPacket());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 309 */     MANUAL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     PULSE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     PACKETS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     DISTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Position
/*     */   {
/*     */     private final Vec3d vec;
/*     */     
/*     */     private final long time;
/*     */ 
/*     */     
/*     */     public Position(Vec3d vec, long time) {
/* 336 */       this.vec = vec;
/* 337 */       this.time = time;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Vec3d getVec() {
/* 345 */       return this.vec;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long getTime() {
/* 353 */       return this.time;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\BlinkModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
