/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.client.events.entity.horse.HorseSaddledEvent;
/*    */ import cope.cosmos.client.events.entity.horse.HorseSteerEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityControlModule
/*    */   extends Module
/*    */ {
/*    */   public static EntityControlModule INSTANCE;
/*    */   
/*    */   public EntityControlModule() {
/* 17 */     super("EntityControl", Category.PLAYER, "Allows you to steer entities without saddles");
/* 18 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onHorseSteer(HorseSteerEvent event) {
/* 25 */     event.setCanceled(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onHorseSaddled(HorseSaddledEvent event) {
/* 32 */     event.setCanceled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\EntityControlModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */