//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.modules.player;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IPlayerControllerMP;
/*     */ import cope.cosmos.client.events.block.BlockResetEvent;
/*     */ import cope.cosmos.client.events.block.LeftClickBlockEvent;
/*     */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*     */ import cope.cosmos.client.events.entity.player.RotationUpdateEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.combat.AuraModule;
/*     */ import cope.cosmos.client.features.modules.combat.AutoCrystalModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.player.AngleUtil;
/*     */ import cope.cosmos.util.render.RenderBuilder;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import cope.cosmos.util.world.BlockUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketClickWindow;
/*     */ import net.minecraft.network.play.client.CPacketConfirmTransaction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ public class SpeedMineModule
/*     */   extends Module
/*     */ {
/*     */   public static SpeedMineModule INSTANCE;
/*     */   
/*     */   public SpeedMineModule() {
/*  56 */     super("SpeedMine", Category.PLAYER, "Mines faster", () -> StringFormatter.formatEnum((Enum)mode.getValue()) + (((Mode)mode.getValue()).equals(Mode.PACKET) ? (", " + MathHelper.clamp(MathUtil.roundFloat(mineDamage, 2), 0.0F, 1.0F)) : ""));
/*  57 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static Setting<Mode> mode = (new Setting("Mode", Mode.PACKET))
/*  63 */     .setDescription("Mode for SpeedMine");
/*     */   
/*  65 */   public static Setting<InventoryManager.Switch> mineSwitch = (new Setting("Switch", InventoryManager.Switch.PACKET))
/*  66 */     .setDescription("Mode when switching to a pickaxe")
/*  67 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */   
/*  69 */   public static Setting<Double> damage = (new Setting("Damage", Double.valueOf(0.0D), Double.valueOf(0.8D), Double.valueOf(1.0D), 1))
/*  70 */     .setDescription("Instant block damage")
/*  71 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.DAMAGE)));
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static Setting<Rotation.Rotate> rotate = (new Setting("Rotate", Rotation.Rotate.NONE))
/*  76 */     .setDescription("How to rotate to the mine");
/*     */   
/*  78 */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(true)))
/*  79 */     .setDescription("Mines on the correct direction")
/*  80 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */   
/*  82 */   public static Setting<Boolean> strictReMine = (new Setting("StrictBreak", Boolean.valueOf(true)))
/*  83 */     .setDescription("Limits re-mines")
/*  84 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */   
/*  86 */   public static Setting<Boolean> reset = (new Setting("Stabilize", Boolean.valueOf(false)))
/*  87 */     .setDescription("Doesn't allow block break progress to be reset");
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static Setting<Double> range = (new Setting("Range", Double.valueOf(0.0D), Double.valueOf(5.0D), Double.valueOf(6.0D), 1))
/*  92 */     .setDescription("Range to mine blocks")
/*  93 */     .setVisible(() -> Boolean.valueOf(((Mode)mode.getValue()).equals(Mode.PACKET)));
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static Setting<Boolean> render = (new Setting("Render", Boolean.valueOf(true)))
/*  98 */     .setDescription("Renders a visual over current mining block");
/*     */   
/* 100 */   public static Setting<RenderBuilder.Box> renderMode = (new Setting("RenderMode", RenderBuilder.Box.BOTH))
/* 101 */     .setDescription("Style for the visual")
/* 102 */     .setExclusion((Object[])new RenderBuilder.Box[] { RenderBuilder.Box.GLOW, RenderBuilder.Box.REVERSE, RenderBuilder.Box.NONE
/* 103 */       }).setVisible(() -> (Boolean)render.getValue());
/*     */ 
/*     */   
/*     */   private BlockPos minePosition;
/*     */ 
/*     */   
/*     */   private EnumFacing mineFacing;
/*     */ 
/*     */   
/*     */   private static float mineDamage;
/*     */   
/*     */   private int mineBreaks;
/*     */   
/*     */   private int previousHaste;
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 120 */     if (!mc.player.capabilities.isCreativeMode) {
/* 121 */       if (this.minePosition != null) {
/*     */ 
/*     */         
/* 124 */         double mineDistance = BlockUtil.getDistanceToCenter((EntityPlayer)mc.player, this.minePosition);
/*     */ 
/*     */         
/* 127 */         if ((this.mineBreaks >= 2 && ((Boolean)strictReMine.getValue()).booleanValue()) || mineDistance > ((Double)range.getValue()).doubleValue()) {
/*     */ 
/*     */           
/* 130 */           this.minePosition = null;
/* 131 */           this.mineFacing = null;
/* 132 */           mineDamage = 0.0F;
/* 133 */           this.mineBreaks = 0;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       if (((Mode)mode.getValue()).equals(Mode.DAMAGE)) {
/*     */ 
/*     */         
/* 145 */         if (((IPlayerControllerMP)mc.playerController).getCurrentBlockDamage() > ((Double)damage.getValue()).floatValue()) {
/* 146 */           ((IPlayerControllerMP)mc.playerController).setCurrentBlockDamage(1.0F);
/*     */ 
/*     */           
/* 149 */           mc.playerController.onPlayerDestroyBlock(this.minePosition);
/*     */         }
/*     */       
/*     */       }
/* 153 */       else if (((Mode)mode.getValue()).equals(Mode.PACKET)) {
/* 154 */         if (this.minePosition != null && !mc.world.isAirBlock(this.minePosition))
/*     */         {
/*     */           
/* 157 */           if (mineDamage >= 1.0F)
/*     */           {
/*     */             
/* 160 */             if (!AutoCrystalModule.INSTANCE.isActive() && !AuraModule.INSTANCE.isActive()) {
/*     */ 
/*     */               
/* 163 */               int previousSlot = mc.player.inventory.currentItem;
/*     */ 
/*     */               
/* 166 */               int swapSlot = getCosmos().getInventoryManager().searchSlot(getEfficientItem(mc.world.getBlockState(this.minePosition)).getItem(), InventoryManager.InventoryRegion.HOTBAR) + 36;
/*     */ 
/*     */               
/* 169 */               if (((Boolean)strict.getValue()).booleanValue()) {
/*     */ 
/*     */                 
/* 172 */                 short nextTransactionID = mc.player.openContainer.getNextTransactionID(mc.player.inventory);
/*     */ 
/*     */                 
/* 175 */                 ItemStack itemstack = mc.player.openContainer.slotClick(swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/* 176 */                 mc.player.connection.sendPacket((Packet)new CPacketClickWindow(mc.player.inventoryContainer.windowId, swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, itemstack, nextTransactionID));
/*     */               
/*     */               }
/*     */               else {
/*     */ 
/*     */                 
/* 182 */                 getCosmos().getInventoryManager().switchToItem(getEfficientItem(mc.world.getBlockState(this.minePosition)).getItem(), (InventoryManager.Switch)mineSwitch.getValue());
/*     */               } 
/*     */ 
/*     */               
/* 186 */               mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.minePosition, this.mineFacing));
/* 187 */               mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.minePosition, EnumFacing.UP));
/*     */ 
/*     */               
/* 190 */               if (((Boolean)strict.getValue()).booleanValue()) {
/* 191 */                 mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.minePosition, this.mineFacing));
/*     */               }
/*     */               
/* 194 */               mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.minePosition, this.mineFacing));
/*     */ 
/*     */               
/* 197 */               if (previousSlot != -1)
/*     */               {
/*     */                 
/* 200 */                 if (((Boolean)strict.getValue()).booleanValue()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 206 */                   short nextTransactionID = mc.player.openContainer.getNextTransactionID(mc.player.inventory);
/*     */ 
/*     */                   
/* 209 */                   ItemStack itemstack = mc.player.openContainer.slotClick(swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
/* 210 */                   mc.player.connection.sendPacket((Packet)new CPacketClickWindow(mc.player.inventoryContainer.windowId, swapSlot, mc.player.inventory.currentItem, ClickType.SWAP, itemstack, nextTransactionID));
/*     */ 
/*     */                   
/* 213 */                   mc.player.connection.sendPacket((Packet)new CPacketConfirmTransaction(mc.player.inventoryContainer.windowId, nextTransactionID, true));
/*     */                 
/*     */                 }
/*     */                 else {
/*     */ 
/*     */                   
/* 219 */                   getCosmos().getInventoryManager().switchToSlot(previousSlot, InventoryManager.Switch.PACKET);
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/* 224 */               mineDamage = 0.0F;
/* 225 */               this.mineBreaks++;
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/* 230 */           mineDamage += getBlockStrength(mc.world.getBlockState(this.minePosition), this.minePosition);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 243 */       else if (((Mode)mode.getValue()).equals(Mode.VANILLA)) {
/*     */ 
/*     */         
/* 246 */         ((IPlayerControllerMP)mc.playerController).setBlockHitDelay(0);
/* 247 */         mc.player.addPotionEffect(new PotionEffect(MobEffects.HASTE.setPotionName("SpeedMine"), 80950, 1, false, false));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/* 254 */     super.onEnable();
/*     */ 
/*     */     
/* 257 */     if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 258 */       this.previousHaste = mc.player.getActivePotionEffect(MobEffects.HASTE).getDuration();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 264 */     super.onDisable();
/*     */ 
/*     */     
/* 267 */     if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 268 */       mc.player.removePotionEffect(MobEffects.HASTE);
/*     */     }
/*     */     
/* 271 */     if (this.previousHaste > 0)
/*     */     {
/*     */       
/* 274 */       mc.player.addPotionEffect(new PotionEffect(MobEffects.HASTE, this.previousHaste));
/*     */     }
/*     */ 
/*     */     
/* 278 */     this.minePosition = null;
/* 279 */     this.mineFacing = null;
/* 280 */     mineDamage = 0.0F;
/* 281 */     this.mineBreaks = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D() {
/* 288 */     if (((Mode)mode.getValue()).equals(Mode.PACKET) && !mc.player.capabilities.isCreativeMode && 
/* 289 */       this.minePosition != null && !mc.world.isAirBlock(this.minePosition)) {
/*     */ 
/*     */       
/* 292 */       AxisAlignedBB mineBox = mc.world.getBlockState(this.minePosition).getSelectedBoundingBox((World)mc.world, this.minePosition);
/*     */ 
/*     */       
/* 295 */       Vec3d mineCenter = mineBox.getCenter();
/*     */ 
/*     */       
/* 298 */       AxisAlignedBB shrunkMineBox = new AxisAlignedBB(mineCenter.x, mineCenter.y, mineCenter.z, mineCenter.x, mineCenter.y, mineCenter.z);
/*     */ 
/*     */       
/* 301 */       RenderUtil.drawBox((new RenderBuilder())
/* 302 */           .position(shrunkMineBox.grow((mineBox.minX - mineBox.maxX) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F), (mineBox.minY - mineBox.maxY) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F), (mineBox.minZ - mineBox.maxZ) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F)))
/* 303 */           .color((mineDamage >= 0.95D) ? ColorUtil.getPrimaryAlphaColor(120) : new Color(255, 0, 0, 120))
/* 304 */           .box((RenderBuilder.Box)renderMode.getValue())
/* 305 */           .setup()
/* 306 */           .line(1.5F)
/* 307 */           .cull((((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.REVERSE)))
/* 308 */           .shade((((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.REVERSE)))
/* 309 */           .alpha((((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.GLOW) || ((RenderBuilder.Box)renderMode.getValue()).equals(RenderBuilder.Box.REVERSE)))
/* 310 */           .depth(true)
/* 311 */           .blend()
/* 312 */           .texture());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLeftClickBlock(LeftClickBlockEvent event) {
/* 322 */     if (BlockUtil.isBreakable(event.getPos()) && !mc.player.capabilities.isCreativeMode) {
/* 323 */       if (((Mode)mode.getValue()).equals(Mode.CREATIVE)) {
/*     */ 
/*     */         
/* 326 */         mc.playerController.onPlayerDestroyBlock(event.getPos());
/* 327 */         mc.world.setBlockToAir(event.getPos());
/*     */       } 
/*     */       
/* 330 */       if (((Mode)mode.getValue()).equals(Mode.PACKET))
/*     */       {
/*     */         
/* 333 */         if (!event.getPos().equals(this.minePosition)) {
/*     */ 
/*     */           
/* 336 */           this.minePosition = event.getPos();
/* 337 */           this.mineFacing = event.getFace();
/* 338 */           mineDamage = 0.0F;
/* 339 */           this.mineBreaks = 0;
/*     */           
/* 341 */           if (this.minePosition != null && this.mineFacing != null) {
/*     */ 
/*     */             
/* 344 */             mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.minePosition, this.mineFacing));
/* 345 */             mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.minePosition, EnumFacing.UP));
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRotationUpdate(RotationUpdateEvent event) {
/* 356 */     if (!((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.NONE))
/*     */     {
/*     */       
/* 359 */       if (mineDamage > 0.95D) {
/*     */ 
/*     */         
/* 362 */         event.setCanceled(true);
/*     */ 
/*     */         
/* 365 */         Rotation mineRotation = AngleUtil.calculateAngles((new Vec3d((Vec3i)this.minePosition)).add(0.5D, 0.5D, 0.5D));
/*     */ 
/*     */         
/* 368 */         if (((Rotation.Rotate)rotate.getValue()).equals(Rotation.Rotate.CLIENT)) {
/* 369 */           mc.player.rotationYaw = mineRotation.getYaw();
/* 370 */           mc.player.rotationYawHead = mineRotation.getYaw();
/* 371 */           mc.player.rotationPitch = mineRotation.getPitch();
/*     */         } 
/*     */ 
/*     */         
/* 375 */         getCosmos().getRotationManager().setRotation(mineRotation);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBlockReset(BlockResetEvent event) {
/* 384 */     if (((Boolean)reset.getValue()).booleanValue()) {
/* 385 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(SettingUpdateEvent event) {
/* 393 */     if (event.getSetting().equals(mode) && !event.getSetting().getValue().equals(Mode.VANILLA)) {
/* 394 */       if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 395 */         mc.player.removePotionEffect(MobEffects.HASTE);
/*     */       }
/*     */       
/* 398 */       if (this.previousHaste > 0)
/*     */       {
/*     */         
/* 401 */         mc.player.addPotionEffect(new PotionEffect(MobEffects.HASTE, this.previousHaste));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/* 410 */     if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketHeldItemChange)
/*     */     {
/*     */       
/* 413 */       if (((Boolean)strict.getValue()).booleanValue()) {
/* 414 */         mineDamage = 0.0F;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getEfficientItem(IBlockState state) {
/* 429 */     int bestSlot = -1;
/*     */ 
/*     */     
/* 432 */     double bestBreakSpeed = 0.0D;
/*     */ 
/*     */     
/* 435 */     for (int i = 0; i < 9; i++) {
/* 436 */       if (!mc.player.inventory.getStackInSlot(i).isEmpty()) {
/* 437 */         float breakSpeed = mc.player.inventory.getStackInSlot(i).getDestroySpeed(state);
/*     */ 
/*     */         
/* 440 */         if (breakSpeed > 1.0F) {
/*     */ 
/*     */           
/* 443 */           if (EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, mc.player.inventory.getStackInSlot(i)) > 0) {
/* 444 */             breakSpeed = (float)(breakSpeed + StrictMath.pow(EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, mc.player.inventory.getStackInSlot(i)), 2.0D) + 1.0D);
/*     */           }
/*     */ 
/*     */           
/* 448 */           if (breakSpeed > bestBreakSpeed) {
/* 449 */             bestBreakSpeed = breakSpeed;
/* 450 */             bestSlot = i;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 457 */     if (bestSlot != -1) {
/* 458 */       return mc.player.inventory.getStackInSlot(bestSlot);
/*     */     }
/*     */     
/* 461 */     return mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBlockStrength(IBlockState state, BlockPos position) {
/* 473 */     float hardness = state.getBlockHardness((World)mc.world, position);
/*     */ 
/*     */     
/* 476 */     if (hardness < 0.0F) {
/* 477 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/* 481 */     if (!canHarvestBlock(state.getBlock(), position)) {
/* 482 */       return getDigSpeed(state) / hardness / 100.0F;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 487 */     return getDigSpeed(state) / hardness / 30.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHarvestBlock(Block block, BlockPos position) {
/* 501 */     IBlockState worldState = mc.world.getBlockState(position);
/* 502 */     IBlockState state = worldState.getBlock().getActualState(worldState, (IBlockAccess)mc.world, position);
/*     */ 
/*     */     
/* 505 */     if (state.getMaterial().isToolNotRequired()) {
/* 506 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 510 */     ItemStack stack = getEfficientItem(state);
/* 511 */     String tool = block.getHarvestTool(state);
/*     */ 
/*     */     
/* 514 */     if (stack.isEmpty() || tool == null) {
/* 515 */       return mc.player.canHarvestBlock(state);
/*     */     }
/*     */ 
/*     */     
/* 519 */     int toolLevel = stack.getItem().getHarvestLevel(stack, tool, (EntityPlayer)mc.player, state);
/* 520 */     if (toolLevel < 0) {
/* 521 */       return mc.player.canHarvestBlock(state);
/*     */     }
/*     */ 
/*     */     
/* 525 */     return (toolLevel >= block.getHarvestLevel(state));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDigSpeed(IBlockState state) {
/* 537 */     float digSpeed = getDestroySpeed(state);
/*     */     
/* 539 */     if (digSpeed > 1.0F) {
/* 540 */       ItemStack itemstack = getEfficientItem(state);
/*     */ 
/*     */       
/* 543 */       int efficiencyModifier = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, itemstack);
/*     */ 
/*     */       
/* 546 */       if (efficiencyModifier > 0 && !itemstack.isEmpty()) {
/* 547 */         digSpeed = (float)(digSpeed + StrictMath.pow(efficiencyModifier, 2.0D) + 1.0D);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 552 */     if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 553 */       digSpeed *= 1.0F + (mc.player.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
/*     */     }
/*     */     
/* 556 */     if (mc.player.isPotionActive(MobEffects.MINING_FATIGUE)) {
/*     */       float fatigueScale;
/*     */ 
/*     */       
/* 560 */       switch (mc.player.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
/*     */         case 0:
/* 562 */           fatigueScale = 0.3F;
/*     */           break;
/*     */         case 1:
/* 565 */           fatigueScale = 0.09F;
/*     */           break;
/*     */         case 2:
/* 568 */           fatigueScale = 0.0027F;
/*     */           break;
/*     */         
/*     */         default:
/* 572 */           fatigueScale = 8.1E-4F;
/*     */           break;
/*     */       } 
/* 575 */       digSpeed *= fatigueScale;
/*     */     } 
/*     */ 
/*     */     
/* 579 */     if (mc.player.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier((EntityLivingBase)mc.player)) {
/* 580 */       digSpeed /= 5.0F;
/*     */     }
/*     */ 
/*     */     
/* 584 */     if (!mc.player.onGround) {
/* 585 */       digSpeed /= 5.0F;
/*     */     }
/*     */     
/* 588 */     return (digSpeed < 0.0F) ? 0.0F : digSpeed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDestroySpeed(IBlockState state) {
/* 599 */     float destroySpeed = 1.0F;
/*     */ 
/*     */     
/* 602 */     if (getEfficientItem(state) != null && !getEfficientItem(state).isEmpty()) {
/* 603 */       destroySpeed *= getEfficientItem(state).getDestroySpeed(state);
/*     */     }
/*     */     
/* 606 */     return destroySpeed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mode
/*     */   {
/* 614 */     PACKET,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 619 */     DAMAGE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 624 */     VANILLA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     CREATIVE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\SpeedMineModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
