//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.INetHandlerPlayClient;
/*    */ import cope.cosmos.asm.mixins.accessor.ISPacketPlayerPosLook;
/*    */ import cope.cosmos.client.events.network.PacketEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.util.holder.Rotation;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.network.play.server.SPacketPlayerPosLook;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ public class NoRotateModule
/*    */   extends Module
/*    */ {
/*    */   public static NoRotateModule INSTANCE;
/*    */   
/*    */   public NoRotateModule() {
/* 23 */     super("NoRotate", Category.PLAYER, "Prevents the server from rotating you");
/* 24 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 29 */   public static Setting<Boolean> strict = (new Setting("Strict", Boolean.valueOf(false)))
/* 30 */     .setDescription("Confirms packets to simulate rotating back");
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/* 35 */     if (nullCheck()) {
/*    */ 
/*    */       
/* 38 */       if (!((INetHandlerPlayClient)mc.player.connection).isDoneLoadingTerrain()) {
/*    */         return;
/*    */       }
/*    */ 
/*    */       
/* 43 */       if (event.getPacket() instanceof SPacketPlayerPosLook) {
/*    */ 
/*    */         
/* 46 */         float packetYaw = MathHelper.wrapDegrees(((SPacketPlayerPosLook)event.getPacket()).getYaw());
/* 47 */         float packetPitch = MathHelper.wrapDegrees(((SPacketPlayerPosLook)event.getPacket()).getPitch());
/*    */ 
/*    */         
/* 50 */         Rotation serverRotation = getCosmos().getRotationManager().getServerRotation();
/*    */ 
/*    */         
/* 53 */         float yaw = MathHelper.wrapDegrees(serverRotation.getYaw());
/*    */ 
/*    */         
/* 56 */         float clientYaw = MathHelper.wrapDegrees(serverRotation.getYaw());
/* 57 */         float clientPitch = MathHelper.wrapDegrees(serverRotation.getPitch());
/*    */         
/* 59 */         if (packetYaw != clientYaw || packetPitch != clientPitch) {
/*    */ 
/*    */           
/* 62 */           ((ISPacketPlayerPosLook)event.getPacket()).setYaw(mc.player.rotationYaw);
/* 63 */           ((ISPacketPlayerPosLook)event.getPacket()).setPitch(mc.player.rotationPitch);
/*    */           
/* 65 */           if (((Boolean)strict.getValue()).booleanValue()) {
/*    */ 
/*    */             
/* 68 */             float angleDifference = packetYaw - clientYaw;
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 73 */             if (Math.abs(angleDifference) > 180.0F) {
/*    */ 
/*    */               
/* 76 */               float adjust = (angleDifference > 0.0F) ? -360.0F : 360.0F;
/* 77 */               angleDifference += adjust;
/*    */             } 
/*    */ 
/*    */ 
/*    */             
/* 82 */             if (Math.abs(angleDifference) > 20.0F) {
/*    */ 
/*    */               
/* 85 */               int rotationDirection = (angleDifference > 0.0F) ? 1 : -1;
/*    */ 
/*    */               
/* 88 */               clientYaw += (20 * rotationDirection);
/*    */ 
/*    */               
/* 91 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(clientYaw, clientPitch, mc.player.onGround));
/*    */             } 
/*    */ 
/*    */             
/* 95 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(yaw, clientPitch, mc.player.onGround));
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\NoRotateModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
