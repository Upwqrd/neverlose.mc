//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.util.EnumHand;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwingModule
/*    */   extends Module
/*    */ {
/*    */   public static SwingModule INSTANCE;
/*    */   
/*    */   public SwingModule() {
/* 16 */     super("Swing", Category.PLAYER, "Modifies the swinging hand");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     this.hand = EnumHand.MAIN_HAND;
/*    */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 32 */     switch ((Mode)mode.getValue()) {
/*    */       case OFFHAND:
/* 34 */         this.hand = EnumHand.OFF_HAND;
/*    */         break;
/*    */       case MAINHAND:
/* 37 */         this.hand = EnumHand.MAIN_HAND;
/*    */         break;
/*    */ 
/*    */       
/*    */       case ALTERNATE:
/* 42 */         if (this.hand.equals(EnumHand.MAIN_HAND)) {
/* 43 */           this.hand = EnumHand.OFF_HAND;
/*    */           
/*    */           break;
/*    */         } 
/* 47 */         this.hand = EnumHand.MAIN_HAND;
/*    */         break;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 54 */     mc.player.swingingHand = this.hand;
/*    */   }
/*    */ 
/*    */   
/*    */   public static Setting<Mode> mode = (new Setting("Mode", Mode.MAINHAND)).setDescription("Swinging hand");
/*    */   private EnumHand hand;
/*    */   
/*    */   public EnumHand getHand() {
/* 62 */     return this.hand;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Mode
/*    */   {
/* 70 */     MAINHAND,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     OFFHAND,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     ALTERNATE;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\SwingModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
