//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.modules.player;
/*    */ 
/*    */ import cope.cosmos.client.events.entity.hitbox.EntityHitboxSizeEvent;
/*    */ import cope.cosmos.client.events.entity.player.interact.ReachEvent;
/*    */ import cope.cosmos.client.features.modules.Category;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReachModule
/*    */   extends Module
/*    */ {
/*    */   public static ReachModule INSTANCE;
/*    */   
/*    */   public ReachModule() {
/* 24 */     super("Reach", Category.PLAYER, "Extends your reach", () -> String.valueOf((mc.player.capabilities.isCreativeMode ? 5.0F : 4.5F) + ((Double)reach.getValue()).floatValue()));
/* 25 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public static Setting<Double> reach = (new Setting("Reach", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(3.0D), 2))
/* 31 */     .setDescription("Player reach extension");
/*    */ 
/*    */ 
/*    */   
/* 35 */   public static Setting<Boolean> hitBox = (new Setting("HitBox", Boolean.valueOf(true)))
/* 36 */     .setDescription("Ignores entity hitboxes");
/*    */   
/* 38 */   public static Setting<Double> hitBoxExtend = (new Setting("Extend", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(2.0D), 2))
/* 39 */     .setDescription("Entity hitbox extension")
/* 40 */     .setVisible(() -> Boolean.valueOf(!((Boolean)hitBox.getValue()).booleanValue()));
/*    */   
/* 42 */   public static Setting<Boolean> hitBoxPlayers = (new Setting("PlayersOnly", Boolean.valueOf(false)))
/* 43 */     .setDescription("Only ignores player hitboxes")
/* 44 */     .setVisible(() -> (Boolean)hitBox.getValue());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 50 */     if (((Boolean)hitBox.getValue()).booleanValue())
/*    */     {
/*    */       
/* 53 */       if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.ENTITY)) {
/*    */ 
/*    */         
/* 56 */         if (((Boolean)hitBoxPlayers.getValue()).booleanValue() && !(mc.objectMouseOver.entityHit instanceof net.minecraft.entity.player.EntityPlayer)) {
/*    */           return;
/*    */         }
/*    */ 
/*    */         
/* 61 */         RayTraceResult mineResult = mc.player.rayTrace(mc.playerController.getBlockReachDistance(), mc.getRenderPartialTicks());
/*    */ 
/*    */         
/* 64 */         if (mineResult != null && mineResult.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/*    */ 
/*    */           
/* 67 */           BlockPos minePos = mineResult.getBlockPos();
/*    */ 
/*    */           
/* 70 */           if (mc.gameSettings.keyBindAttack.isKeyDown()) {
/* 71 */             mc.playerController.onPlayerDamageBlock(minePos, EnumFacing.UP);
/* 72 */             mc.player.swingArm(EnumHand.MAIN_HAND);
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onHitboxSize(EntityHitboxSizeEvent event) {
/* 81 */     if (!((Boolean)hitBox.getValue()).booleanValue())
/*    */     {
/*    */       
/* 84 */       event.setHitboxSize(((Double)hitBoxExtend.getValue()).floatValue());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onReach(ReachEvent event) {
/* 92 */     event.setReach((mc.player.capabilities.isCreativeMode ? 5.0F : 4.5F) + ((Double)reach.getValue()).floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\modules\player\ReachModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
