/*    */ package cope.cosmos.client.features.command.commands;
/*    */ import com.mojang.brigadier.arguments.StringArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ 
/*    */ public class DrawnCommand extends Command {
/*    */   public DrawnCommand() {
/* 13 */     super("Drawn", "Hides or shows a module on the arraylist", (LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("drawn")
/* 14 */         .then(RequiredArgumentBuilder.argument("module", (ArgumentType)StringArgumentType.string())
/* 15 */           .executes(context -> {
/*    */               Module drawnModule = Cosmos.INSTANCE.getModuleManager().getModule(());
/*    */ 
/*    */               
/*    */               Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", StringArgumentType.getString(context, "name") + " has been " + (drawnModule.isDrawn() ? "hidden!" : "drawn!"));
/*    */               
/*    */               drawnModule.setDrawn(!drawnModule.isDrawn());
/*    */               
/*    */               return 1;
/* 24 */             }))).executes(context -> {
/*    */             Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the module to draw/hide!");
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\DrawnCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */