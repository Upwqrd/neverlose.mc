/*    */ package cope.cosmos.client.features.command.commands;
/*    */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.features.command.Command;
/*    */ import java.util.List;
/*    */ 
/*    */ public class HelpCommand extends Command {
/*    */   public HelpCommand() {
/* 14 */     super("Help", "Displays all commands", (LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("help")
/* 15 */         .then(RequiredArgumentBuilder.argument("page", (ArgumentType)IntegerArgumentType.integer())
/* 16 */           .executes(context -> {
/*    */               sendHelpList(IntegerArgumentType.getInteger(context, "page"));
/*    */ 
/*    */ 
/*    */               
/*    */               return 1;
/* 22 */             }))).executes(context -> {
/*    */             sendHelpList(1);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void sendHelpList(int page) {
/* 34 */     List<Command> commands = Cosmos.INSTANCE.getCommandManager().getAllCommands();
/*    */ 
/*    */     
/* 37 */     int maxLength = 5;
/*    */ 
/*    */     
/* 40 */     int total = (int)Math.ceil(commands.size() / maxLength);
/*    */ 
/*    */     
/* 43 */     if (page > total || page < 1) {
/* 44 */       page = 1;
/*    */     }
/*    */ 
/*    */     
/* 48 */     Cosmos.INSTANCE.getChatManager().sendHoverableMessage("Commands list", "Page " + page + "/" + total);
/*    */ 
/*    */ 
/*    */     
/* 52 */     commands.subList((page - 1) * maxLength, Math.min(page * maxLength, commands.size()))
/* 53 */       .forEach(command -> Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GRAY + command.getName().toLowerCase() + ChatFormatting.RESET, command.getDescription()));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\HelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */