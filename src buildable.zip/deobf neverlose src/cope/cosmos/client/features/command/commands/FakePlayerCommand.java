/*    */ package cope.cosmos.client.features.command.commands;
/*    */ 
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import cope.cosmos.client.features.command.Command;
/*    */ import cope.cosmos.client.features.modules.misc.FakePlayerModule;
/*    */ 
/*    */ 
/*    */ public class FakePlayerCommand
/*    */   extends Command
/*    */ {
/*    */   public FakePlayerCommand() {
/* 14 */     super("fakeplayer", "Manages the fakeplayer", (LiteralArgumentBuilder)LiteralArgumentBuilder.literal("fakeplayer")
/* 15 */         .executes(ctx -> {
/*    */             FakePlayerModule.INSTANCE.toggle();
/*    */             return 0;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\FakePlayerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */