//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.features.command.commands;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.arguments.StringArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.features.command.Command;
/*    */ import cope.cosmos.client.manager.managers.SocialManager;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class FriendCommand
/*    */   extends Command
/*    */ {
/*    */   public FriendCommand() {
/* 22 */     super("Friend", "Updates your friends list", (LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("friend")
/* 23 */         .then(((RequiredArgumentBuilder)RequiredArgumentBuilder.argument("action", (ArgumentType)StringArgumentType.string()).suggests((context, builder) -> suggestActions(builder)).then(RequiredArgumentBuilder.argument("name", (ArgumentType)StringArgumentType.string()).suggests((context, builder) -> suggestNames(builder))
/* 24 */             .executes(context -> {
/*    */                 String friend = StringArgumentType.getString(context, "name");
/*    */ 
/*    */ 
/*    */ 
/*    */                 
/*    */                 if (StringArgumentType.getString(context, "action").equals("add")) {
/*    */                   Cosmos.INSTANCE.getSocialManager().addSocial(friend, SocialManager.Relationship.FRIEND);
/*    */ 
/*    */ 
/*    */ 
/*    */                   
/*    */                   Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Added friend with name " + friend);
/*    */ 
/*    */ 
/*    */ 
/*    */                   
/*    */                   if (!mc.player.getName().equalsIgnoreCase(friend)) {
/*    */                     Cosmos.INSTANCE.getChatManager().sendChatMessage("/w " + friend + " I just added you as a friend on Cosmos!");
/*    */                   }
/*    */                 } else if (StringArgumentType.getString(context, "action").equals("remove")) {
/*    */                   Cosmos.INSTANCE.getSocialManager().removeSocial(friend);
/*    */ 
/*    */ 
/*    */                   
/*    */                   Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Removed friend with name " + friend);
/*    */                 } 
/*    */ 
/*    */ 
/*    */                 
/*    */                 return 1;
/* 55 */               }))).executes(context -> {
/*    */               Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the name of the person to friend!");
/*    */ 
/*    */ 
/*    */               
/*    */               return 1;
/* 61 */             }))).executes(context -> {
/*    */             Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the correct action, was expecting add or remove!");
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static CompletableFuture<Suggestions> suggestNames(SuggestionsBuilder suggestionsBuilder) {
/* 76 */     for (EntityPlayer entityPlayer : mc.world.playerEntities) {
/*    */ 
/*    */       
/* 79 */       if (Cosmos.INSTANCE.getSocialManager().getSocial(entityPlayer.getName()).equals(SocialManager.Relationship.FRIEND)) {
/*    */         continue;
/*    */       }
/*    */       
/* 83 */       suggestionsBuilder.suggest(entityPlayer.getName());
/*    */     } 
/*    */     
/* 86 */     return suggestionsBuilder.buildFuture();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static CompletableFuture<Suggestions> suggestActions(SuggestionsBuilder suggestionsBuilder) {
/* 95 */     suggestionsBuilder.suggest("add");
/* 96 */     suggestionsBuilder.suggest("remove");
/* 97 */     return suggestionsBuilder.buildFuture();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\FriendCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
