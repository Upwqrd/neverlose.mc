/*    */ package cope.cosmos.client.features.command.commands;
/*    */ import com.mojang.brigadier.arguments.StringArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ 
/*    */ public class ConfigCommand extends Command {
/*    */   public ConfigCommand() {
/* 12 */     super("Config", "Creates or Updates a preset", (LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("config")
/* 13 */         .then(((RequiredArgumentBuilder)RequiredArgumentBuilder.argument("action", (ArgumentType)StringArgumentType.string()).then(RequiredArgumentBuilder.argument("name", (ArgumentType)StringArgumentType.string())
/* 14 */             .executes(context -> {
/*    */                 switch (StringArgumentType.getString(context, "action")) {
/*    */                   case "save":
/*    */                     Cosmos.INSTANCE.getConfigManager().createPreset(StringArgumentType.getString(context, "name"));
/*    */                     Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Saved current config");
/*    */ 
/*    */                   
/*    */                   case "load":
/*    */                     Cosmos.INSTANCE.getConfigManager().loadPreset(StringArgumentType.getString(context, "name"));
/*    */                     Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Loaded current config");
/*    */                     break;
/*    */                   
/*    */                   case "remove":
/*    */                     Cosmos.INSTANCE.getConfigManager().deletePreset(StringArgumentType.getString(context, "name"));
/*    */                     Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Removed preset with name " + StringArgumentType.getString(context, "name"));
/*    */                     break;
/*    */                 } 
/*    */                 
/*    */                 return 1;
/* 33 */               }))).executes(context -> {
/*    */               Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the name of the preset!");
/*    */ 
/*    */               
/*    */               return 1;
/* 38 */             }))).executes(context -> {
/*    */             Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the correct action, was expecting save, remove, or load!");
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\ConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */