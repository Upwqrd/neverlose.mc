/*    */ package cope.cosmos.client.features.command.commands;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.arguments.StringArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.builder.RequiredArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.features.command.Command;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.features.setting.Bind;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import org.lwjgl.input.Mouse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindCommand
/*    */   extends Command
/*    */ {
/*    */   public BindCommand() {
/* 27 */     super("Bind", "Binds a module to the given keybind", (LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("bind")
/* 28 */         .then(((RequiredArgumentBuilder)RequiredArgumentBuilder.argument("module", (ArgumentType)StringArgumentType.string()).suggests((context, builder) -> suggestNames(builder))
/* 29 */           .then(RequiredArgumentBuilder.argument("key", (ArgumentType)StringArgumentType.string())
/*    */             
/* 31 */             .executes(context -> {
/*    */                 Module toBind = Cosmos.INSTANCE.getModuleManager().getModule(());
/*    */ 
/*    */ 
/*    */                 
/*    */                 String key = StringArgumentType.getString(context, "key").toUpperCase();
/*    */ 
/*    */ 
/*    */                 
/*    */                 if (key.contains("MOUSE") || key.contains("BUTTON")) {
/*    */                   key = key.replace("MOUSE", "BUTTON");
/*    */ 
/*    */ 
/*    */                   
/*    */                   int code = Mouse.getButtonIndex(key);
/*    */ 
/*    */ 
/*    */                   
/*    */                   toBind.getBind().setValue(new Bind(code, Bind.Device.MOUSE));
/*    */                 } else {
/*    */                   int code = Keyboard.getKeyIndex(key);
/*    */ 
/*    */ 
/*    */                   
/*    */                   toBind.getBind().setValue(new Bind(code, Bind.Device.KEYBOARD));
/*    */                 } 
/*    */ 
/*    */                 
/*    */                 if (((Bind)toBind.getBind().getValue()).getButtonCode() > 1) {
/*    */                   Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.GREEN + "Command dispatched successfully!", "Set " + toBind.getName() + "'s bind to " + ((Bind)toBind.getBind().getValue()).getButtonName());
/*    */                 } else {
/*    */                   Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter a correct bind!");
/*    */                 } 
/*    */ 
/*    */                 
/*    */                 return 1;
/* 67 */               }))).executes(context -> {
/*    */               Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter a correct bind!");
/*    */ 
/*    */               
/*    */               return 1;
/* 72 */             }))).executes(context -> {
/*    */             Cosmos.INSTANCE.getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "Please enter the name of the module!");
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ 
/*    */   
/*    */   private static CompletableFuture<Suggestions> suggestNames(SuggestionsBuilder suggestionsBuilder) {
/* 80 */     Cosmos.INSTANCE.getModuleManager().getAllModules().forEach(module -> suggestionsBuilder.suggest(module.getName()));
/*    */ 
/*    */ 
/*    */     
/* 84 */     return suggestionsBuilder.buildFuture();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\commands\BindCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */