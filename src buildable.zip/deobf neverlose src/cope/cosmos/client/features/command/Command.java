/*    */ package cope.cosmos.client.features.command;
/*    */ 
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.tree.CommandNode;
/*    */ import com.mojang.brigadier.tree.LiteralCommandNode;
/*    */ import cope.cosmos.client.features.Feature;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Command
/*    */   extends Feature
/*    */   implements Wrapper
/*    */ {
/*    */   private final LiteralArgumentBuilder<Object> command;
/*    */   
/*    */   public Command(String name, String description, LiteralArgumentBuilder<Object> command) {
/* 22 */     super(name, description);
/* 23 */     this.command = command;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LiteralArgumentBuilder<Object> getCommand() {
/* 31 */     return this.command;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static LiteralArgumentBuilder<Object> redirectBuilder(String alias, LiteralCommandNode<?> destination) {
/* 42 */     LiteralArgumentBuilder<Object> literalArgumentBuilder = (LiteralArgumentBuilder<Object>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(alias.toLowerCase()).requires(destination.getRequirement())).forward(destination.getRedirect(), destination.getRedirectModifier(), destination.isFork())).executes(destination.getCommand());
/*    */     
/* 44 */     for (CommandNode<?> child : (Iterable<CommandNode<?>>)destination.getChildren()) {
/* 45 */       literalArgumentBuilder.then(child);
/*    */     }
/*    */     
/* 48 */     return literalArgumentBuilder;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\command\Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */