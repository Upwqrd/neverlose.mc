//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.features.setting;
/*     */ 
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bind
/*     */   implements Wrapper
/*     */ {
/*     */   private final int buttonCode;
/*     */   private final Device device;
/*     */   private boolean alreadyPressed;
/*     */   
/*     */   public Bind(int buttonCode, Device device) {
/*  24 */     this.buttonCode = buttonCode;
/*  25 */     this.device = device;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPressed() {
/*  34 */     if (this.buttonCode <= 1 || mc.currentScreen != null) {
/*  35 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  39 */     boolean pressed = ((this.device.equals(Device.KEYBOARD) && Keyboard.isKeyDown(this.buttonCode)) || (this.device.equals(Device.MOUSE) && Mouse.isButtonDown(this.buttonCode)));
/*     */     
/*  41 */     if (pressed) {
/*     */ 
/*     */       
/*  44 */       if (!this.alreadyPressed) {
/*  45 */         this.alreadyPressed = true;
/*  46 */         return true;
/*     */       } 
/*     */ 
/*     */       
/*  50 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.alreadyPressed = false;
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Device
/*     */   {
/*  65 */     KEYBOARD,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     MOUSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getButtonName() {
/*  80 */     if (this.buttonCode < 1) {
/*  81 */       return "None";
/*     */     }
/*     */     
/*  84 */     if (this.device.equals(Device.KEYBOARD)) {
/*  85 */       return Keyboard.getKeyName(this.buttonCode);
/*     */     }
/*     */     
/*  88 */     if (this.device.equals(Device.MOUSE)) {
/*  89 */       return Mouse.getButtonName(this.buttonCode);
/*     */     }
/*     */     
/*  92 */     return "Unrecognized";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getButtonCode() {
/* 100 */     return this.buttonCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Device getDevice() {
/* 108 */     return this.device;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\setting\Bind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
