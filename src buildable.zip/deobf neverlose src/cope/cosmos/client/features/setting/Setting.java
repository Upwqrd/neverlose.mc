/*     */ package cope.cosmos.client.features.setting;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*     */ import cope.cosmos.client.features.Feature;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Setting<T>
/*     */   extends Feature
/*     */   implements Wrapper
/*     */ {
/*     */   private T value;
/*     */   private T min;
/*     */   private T max;
/*     */   private int scale;
/*     */   private int index;
/*     */   private Module module;
/*     */   private Supplier<Boolean> visible;
/*  41 */   private final List<T> exclusions = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private Setting<?> parentSetting;
/*     */ 
/*     */   
/*  47 */   private final List<Setting<?>> subSettings = new ArrayList<>();
/*     */   
/*     */   public Setting(String name, T value) {
/*  50 */     super(name);
/*  51 */     this.value = value;
/*     */   }
/*     */   
/*     */   public Setting(String name, T min, T value, T max, int scale) {
/*  55 */     this(name, value);
/*     */     
/*  57 */     this.min = min;
/*  58 */     this.max = max;
/*  59 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMin() {
/*  67 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T in) {
/*  75 */     this.value = in;
/*     */ 
/*     */     
/*  78 */     if (nullCheck()) {
/*  79 */       SettingUpdateEvent settingUpdateEvent = new SettingUpdateEvent(this);
/*  80 */       Cosmos.EVENT_BUS.post((Event)settingUpdateEvent);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/*  89 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMin(T in) {
/*  97 */     this.min = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMax() {
/* 105 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMax(T in) {
/* 113 */     this.max = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getNextMode() {
/* 122 */     if (this.value instanceof Enum) {
/* 123 */       Enum<?> enumVal = (Enum)this.value;
/*     */ 
/*     */       
/* 126 */       String[] values = (String[])Arrays.stream(enumVal.getClass().getEnumConstants()).filter(in -> !isExclusion((T)in)).map(Enum::name).toArray(x$0 -> new String[x$0]);
/* 127 */       this.index = (this.index + 1 > values.length - 1) ? 0 : (this.index + 1);
/*     */ 
/*     */       
/* 130 */       return (T)Enum.valueOf(enumVal.getClass(), values[this.index]);
/*     */     } 
/*     */     
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getLastMode() {
/* 142 */     if (this.value instanceof Enum) {
/* 143 */       Enum<?> enumVal = (Enum)this.value;
/*     */ 
/*     */       
/* 146 */       String[] values = (String[])Arrays.stream(enumVal.getClass().getEnumConstants()).filter(in -> !isExclusion((T)in)).map(Enum::name).toArray(x$0 -> new String[x$0]);
/* 147 */       this.index = (this.index - 1 < 0) ? (values.length - 1) : (this.index - 1);
/*     */ 
/*     */       
/* 150 */       return (T)Enum.valueOf(enumVal.getClass(), values[this.index]);
/*     */     } 
/*     */     
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRoundingScale() {
/* 161 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModule(Module in) {
/* 169 */     this.module = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module getModule() {
/* 177 */     return this.module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExclusion(T in) {
/* 186 */     return this.exclusions.contains(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final Setting<T> setExclusion(T... in) {
/* 197 */     this.exclusions.addAll(Arrays.asList(in));
/*     */ 
/*     */     
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 208 */     return (this.visible != null) ? ((Boolean)this.visible.get()).booleanValue() : true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Setting<T> setVisible(Supplier<Boolean> in) {
/* 218 */     this.visible = in;
/*     */ 
/*     */     
/* 221 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasParent() {
/* 229 */     return (this.parentSetting != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Setting<?> getParentSetting() {
/* 237 */     return this.parentSetting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Setting<T> setParent(Setting<?> in) {
/* 247 */     in.getSubSettings().add(this);
/*     */ 
/*     */     
/* 250 */     this.parentSetting = in;
/*     */ 
/*     */     
/* 253 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Setting<?>> getSubSettings() {
/* 261 */     return this.subSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Setting<T> setDescription(String in) {
/* 271 */     this.description = in;
/*     */ 
/*     */     
/* 274 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 279 */     return (this.description != null) ? this.description : "";
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\setting\Setting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */