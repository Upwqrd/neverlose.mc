/*    */ package cope.cosmos.client.features;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Feature
/*    */ {
/*    */   protected String name;
/*    */   protected String description;
/*    */   
/*    */   public Feature(String name, String description) {
/* 15 */     this.name = name;
/* 16 */     this.description = description;
/*    */   }
/*    */   
/*    */   public Feature(String name) {
/* 20 */     this(name, "");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 36 */     return this.description;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\features\Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */