//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.shader.shaders;
/*    */ 
/*    */ import cope.cosmos.client.shader.Shader;
/*    */ import java.awt.Color;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DotShader
/*    */   extends Shader
/*    */ {
/*    */   public DotShader() {
/* 17 */     super("/assets/cosmos/shaders/glsl/dot.frag");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupConfiguration() {
/* 22 */     setupConfigurations("texture");
/* 23 */     setupConfigurations("texelSize");
/* 24 */     setupConfigurations("colorDot");
/* 25 */     setupConfigurations("colorFilled");
/* 26 */     setupConfigurations("divider");
/* 27 */     setupConfigurations("radius");
/* 28 */     setupConfigurations("maxSample");
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateConfiguration(int radius, Color color) {
/* 33 */     GL20.glUniform1i(getConfigurations("texture"), 0);
/* 34 */     GL20.glUniform2f(getConfigurations("texelSize"), 1.0F / mc.displayWidth, 1.0F / mc.displayHeight);
/* 35 */     GL20.glUniform4f(getConfigurations("colorFilled"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 0.39215687F);
/* 36 */     GL20.glUniform4f(getConfigurations("colorDot"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 37 */     GL20.glUniform1f(getConfigurations("radius"), radius);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\shader\shaders\DotShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
