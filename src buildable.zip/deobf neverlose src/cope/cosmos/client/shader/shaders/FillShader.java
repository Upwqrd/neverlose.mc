//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.shader.shaders;
/*    */ 
/*    */ import cope.cosmos.client.shader.Shader;
/*    */ import java.awt.Color;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FillShader
/*    */   extends Shader
/*    */ {
/*    */   public FillShader() {
/* 16 */     super("/assets/cosmos/shaders/glsl/fill.frag");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupConfiguration() {
/* 21 */     setupConfigurations("texture");
/* 22 */     setupConfigurations("texelSize");
/* 23 */     setupConfigurations("color");
/* 24 */     setupConfigurations("divider");
/* 25 */     setupConfigurations("radius");
/* 26 */     setupConfigurations("maxSample");
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateConfiguration(int radius, Color color) {
/* 31 */     GL20.glUniform1i(getConfigurations("texture"), 0);
/* 32 */     GL20.glUniform2f(getConfigurations("texelSize"), 1.0F / mc.displayWidth, 1.0F / mc.displayHeight);
/* 33 */     GL20.glUniform4f(getConfigurations("color"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 34 */     GL20.glUniform1f(getConfigurations("radius"), radius);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\shader\shaders\FillShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
