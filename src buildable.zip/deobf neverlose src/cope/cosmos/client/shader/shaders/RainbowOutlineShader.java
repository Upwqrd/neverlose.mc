//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.shader.shaders;
/*    */ 
/*    */ import cope.cosmos.client.shader.Shader;
/*    */ import java.awt.Color;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RainbowOutlineShader
/*    */   extends Shader
/*    */ {
/*    */   public RainbowOutlineShader() {
/* 16 */     super("/assets/cosmos/shaders/glsl/rainbow_outline.frag");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupConfiguration() {
/* 21 */     setupConfigurations("texture");
/* 22 */     setupConfigurations("texelSize");
/* 23 */     setupConfigurations("color");
/* 24 */     setupConfigurations("radius");
/* 25 */     setupConfigurations("rainbowStrength");
/* 26 */     setupConfigurations("rainbowSpeed");
/* 27 */     setupConfigurations("saturation");
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateConfiguration(int radius, Color color) {
/* 32 */     GL20.glUniform1i(getConfigurations("texture"), 0);
/* 33 */     GL20.glUniform2f(getConfigurations("texelSize"), 1.0F / mc.displayWidth, 1.0F / mc.displayHeight);
/* 34 */     GL20.glUniform4f(getConfigurations("color"), color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
/* 35 */     GL20.glUniform1f(getConfigurations("radius"), radius);
/* 36 */     GL20.glUniform2f(getConfigurations("rainbowStrength"), -0.0033333334F, -0.0033333334F);
/* 37 */     GL20.glUniform1f(getConfigurations("rainbowSpeed"), 0.4F);
/* 38 */     GL20.glUniform1f(getConfigurations("saturation"), 0.5F);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\shader\shaders\RainbowOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
