/*     */ package cope.cosmos.client.shader;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.awt.Color;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.lwjgl.opengl.ARBShaderObjects;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Shader
/*     */   implements Wrapper
/*     */ {
/*     */   private int program;
/*     */   private Map<String, Integer> configurationMap;
/*     */   
/*     */   public Shader(String fragmentShader) {
/*  38 */     int vertexShaderID = 0;
/*  39 */     int fragmentShaderID = 0;
/*     */ 
/*     */     
/*     */     try {
/*  43 */       InputStream vertexStream = getClass().getResourceAsStream("/assets/cosmos/shaders/glsl/vertex.vert");
/*     */ 
/*     */       
/*  46 */       if (vertexStream != null) {
/*     */ 
/*     */         
/*  49 */         vertexShaderID = createShader(IOUtils.toString(vertexStream, Charset.defaultCharset()), 35633);
/*  50 */         IOUtils.closeQuietly(vertexStream);
/*     */       } 
/*     */ 
/*     */       
/*  54 */       InputStream fragmentStream = getClass().getResourceAsStream(fragmentShader);
/*     */ 
/*     */       
/*  57 */       if (fragmentStream != null)
/*     */       {
/*     */         
/*  60 */         fragmentShaderID = createShader(IOUtils.toString(fragmentStream, Charset.defaultCharset()), 35632);
/*  61 */         IOUtils.closeQuietly(fragmentStream);
/*     */       }
/*     */     
/*  64 */     } catch (Exception exception) {
/*     */ 
/*     */       
/*  67 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*  68 */         exception.printStackTrace();
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  75 */     if (vertexShaderID != 0 && fragmentShaderID != 0) {
/*  76 */       this.program = ARBShaderObjects.glCreateProgramObjectARB();
/*     */ 
/*     */       
/*  79 */       if (this.program != 0) {
/*  80 */         ARBShaderObjects.glAttachObjectARB(this.program, vertexShaderID);
/*  81 */         ARBShaderObjects.glAttachObjectARB(this.program, fragmentShaderID);
/*  82 */         ARBShaderObjects.glLinkProgramARB(this.program);
/*  83 */         ARBShaderObjects.glValidateProgramARB(this.program);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startShader(int radius, Color color) {
/*  94 */     GL20.glUseProgram(this.program);
/*     */ 
/*     */     
/*  97 */     if (this.configurationMap == null) {
/*  98 */       this.configurationMap = new HashMap<>();
/*  99 */       setupConfiguration();
/*     */     } 
/*     */ 
/*     */     
/* 103 */     updateConfiguration(radius, color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setupConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void updateConfiguration(int paramInt, Color paramColor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int createShader(String shaderSource, int shaderType) {
/* 123 */     int shader = 0;
/*     */ 
/*     */     
/*     */     try {
/* 127 */       shader = ARBShaderObjects.glCreateShaderObjectARB(shaderType);
/*     */ 
/*     */       
/* 130 */       if (shader != 0) {
/*     */ 
/*     */         
/* 133 */         ARBShaderObjects.glShaderSourceARB(shader, shaderSource);
/* 134 */         ARBShaderObjects.glCompileShaderARB(shader);
/*     */ 
/*     */         
/* 137 */         if (ARBShaderObjects.glGetObjectParameteriARB(shader, 35713) == 0) {
/* 138 */           throw new RuntimeException("Error creating shader: " + ARBShaderObjects.glGetInfoLogARB(shader, ARBShaderObjects.glGetObjectParameteriARB(shader, 35716)));
/*     */         }
/*     */ 
/*     */         
/* 142 */         return shader;
/*     */       } 
/*     */ 
/*     */       
/* 146 */       return 0;
/*     */     
/*     */     }
/* 149 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 152 */       ARBShaderObjects.glDeleteObjectARB(shader);
/* 153 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupConfigurations(String configurationName) {
/* 162 */     this.configurationMap.put(configurationName, Integer.valueOf(GL20.glGetUniformLocation(this.program, configurationName)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConfigurations(String configurationName) {
/* 171 */     return ((Integer)this.configurationMap.get(configurationName)).intValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\shader\Shader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */