//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ import cope.cosmos.asm.mixins.accessor.IEntityLivingBase;
/*     */ import cope.cosmos.asm.mixins.accessor.IMinecraft;
/*     */ import cope.cosmos.client.features.modules.player.SwingModule;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import cope.cosmos.util.player.AngleUtil;
/*     */ import cope.cosmos.util.world.ShiftBlocks;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.network.play.server.SPacketAnimation;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.WorldServer;
/*     */ 
/*     */ public class InteractionManager extends Manager {
/*     */   public InteractionManager() {
/*  33 */     super("InteractionManager", "Manages all player interactions");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  39 */     this.placing = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean placing;
/*     */ 
/*     */   
/*     */   public void placeBlock(BlockPos position, Rotation.Rotate rotate, boolean strict) {
/*  48 */     for (EnumFacing direction : EnumFacing.values()) {
/*     */ 
/*     */       
/*  51 */       BlockPos directionOffset = position.offset(direction);
/*     */ 
/*     */       
/*  54 */       for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(position))) {
/*  55 */         if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  61 */       EnumFacing oppositeFacing = direction.getOpposite();
/*     */ 
/*     */       
/*  64 */       if (!strict || getVisibleSides(directionOffset).contains(direction.getOpposite()))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*  69 */         if (!mc.world.getBlockState(directionOffset).getMaterial().isReplaceable()) {
/*     */ 
/*     */ 
/*     */           
/*  73 */           this.placing = true;
/*     */ 
/*     */           
/*  76 */           boolean sprint = mc.player.isSprinting();
/*  77 */           if (sprint);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  83 */           boolean sneak = (ShiftBlocks.contains(mc.world.getBlockState(directionOffset).getBlock()) && !mc.player.isSneaking());
/*  84 */           if (sneak) {
/*  85 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*  90 */           Rotation rotation = getAnglesToBlock(directionOffset, oppositeFacing);
/*     */ 
/*     */           
/*  93 */           Vec3d interactVector = null;
/*     */           
/*  95 */           if (strict) {
/*  96 */             RayTraceResult result = getTraceResult(getReachDistance(), rotation);
/*  97 */             if (result != null && result.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/*  98 */               interactVector = result.hitVec;
/*     */             }
/*     */           } 
/*     */           
/* 102 */           if (interactVector == null) {
/* 103 */             interactVector = (new Vec3d((Vec3i)directionOffset)).add(0.5D, 0.5D, 0.5D);
/* 104 */             rotation = AngleUtil.calculateAngles(interactVector);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 110 */           if (!rotate.equals(Rotation.Rotate.NONE) && rotation.isValid())
/*     */           {
/* 112 */             switch (rotate) {
/*     */               case CLIENT:
/* 114 */                 mc.player.rotationYaw = rotation.getYaw();
/* 115 */                 mc.player.rotationYawHead = rotation.getYaw();
/* 116 */                 mc.player.rotationPitch = rotation.getPitch();
/*     */                 break;
/*     */ 
/*     */               
/*     */               case PACKET:
/* 121 */                 mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotation.getYaw(), rotation.getPitch(), mc.player.onGround));
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 132 */           float facingX = (float)(interactVector.x - directionOffset.getZ());
/* 133 */           float facingY = (float)(interactVector.y - directionOffset.getY());
/* 134 */           float facingZ = (float)(interactVector.z - directionOffset.getZ());
/*     */ 
/*     */           
/* 137 */           String ip = (mc.getCurrentServerData() != null) ? (mc.getCurrentServerData()).serverIP : "";
/*     */ 
/*     */           
/* 140 */           if (ip.equalsIgnoreCase("2b2t.org") && mc.getConnection() != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 145 */             mc.playerController.processRightClickBlock(mc.player, mc.world, directionOffset, direction
/*     */ 
/*     */ 
/*     */                 
/* 149 */                 .getOpposite(), interactVector, EnumHand.MAIN_HAND);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 158 */             mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(directionOffset, direction.getOpposite(), EnumHand.MAIN_HAND, facingX, facingY, facingZ));
/*     */           } 
/*     */ 
/*     */           
/* 162 */           if (sneak) {
/* 163 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 168 */           if (sprint) {
/* 169 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 175 */           ItemStack stack = mc.player.getHeldItem(EnumHand.MAIN_HAND);
/*     */ 
/*     */           
/* 178 */           if (!stack.isEmpty() && 
/* 179 */             !stack.getItem().onEntitySwing((EntityLivingBase)mc.player, stack))
/*     */           {
/*     */             
/* 182 */             if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= ((IEntityLivingBase)mc.player).hookGetArmSwingAnimationEnd() / 2 || mc.player.swingProgressInt < 0) {
/* 183 */               mc.player.swingProgressInt = -1;
/* 184 */               mc.player.isSwingInProgress = true;
/* 185 */               mc.player.swingingHand = SwingModule.INSTANCE.isEnabled() ? SwingModule.INSTANCE.getHand() : EnumHand.MAIN_HAND;
/*     */ 
/*     */               
/* 188 */               if (mc.player.world instanceof WorldServer) {
/* 189 */                 ((WorldServer)mc.player.world).getEntityTracker().sendToTracking((Entity)mc.player, (Packet)new SPacketAnimation((Entity)mc.player, 0));
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 196 */           mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/* 197 */           ((IMinecraft)mc).setRightClickDelayTimer(4);
/*     */ 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 207 */     this.placing = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void placeBlock(BlockPos position, Rotation.Rotate rotate, boolean strict, List<Class<? extends Entity>> safeEntities) {
/* 218 */     for (EnumFacing direction : EnumFacing.values()) {
/*     */ 
/*     */       
/* 221 */       BlockPos directionOffset = position.offset(direction);
/*     */ 
/*     */       
/* 224 */       EnumFacing oppositeFacing = direction.getOpposite();
/*     */ 
/*     */       
/* 227 */       if (!strict || getVisibleSides(directionOffset).contains(direction.getOpposite())) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(position))) {
/* 233 */           if (!safeEntities.contains(entity.getClass())) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 239 */         if (!mc.world.getBlockState(directionOffset).getMaterial().isReplaceable()) {
/*     */ 
/*     */ 
/*     */           
/* 243 */           this.placing = true;
/*     */ 
/*     */           
/* 246 */           boolean sprint = mc.player.isSprinting();
/* 247 */           if (sprint);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 253 */           boolean sneak = (ShiftBlocks.contains(mc.world.getBlockState(directionOffset).getBlock()) && !mc.player.isSneaking());
/* 254 */           if (sneak) {
/* 255 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 260 */           Rotation rotation = getAnglesToBlock(directionOffset, oppositeFacing);
/*     */ 
/*     */           
/* 263 */           Vec3d interactVector = null;
/*     */           
/* 265 */           if (strict) {
/* 266 */             RayTraceResult result = getTraceResult(getReachDistance(), rotation);
/* 267 */             if (result != null && result.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/* 268 */               interactVector = result.hitVec;
/*     */             }
/*     */           } 
/*     */           
/* 272 */           if (interactVector == null) {
/* 273 */             interactVector = (new Vec3d((Vec3i)directionOffset)).add(0.5D, 0.5D, 0.5D);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 279 */           if (!rotate.equals(Rotation.Rotate.NONE) && rotation.isValid())
/*     */           {
/* 281 */             switch (rotate) {
/*     */               case CLIENT:
/* 283 */                 mc.player.rotationYaw = rotation.getYaw();
/* 284 */                 mc.player.rotationYawHead = rotation.getYaw();
/* 285 */                 mc.player.rotationPitch = rotation.getPitch();
/*     */                 break;
/*     */ 
/*     */               
/*     */               case PACKET:
/* 290 */                 mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotation.getYaw(), rotation.getPitch(), mc.player.onGround));
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 301 */           float facingX = (float)(interactVector.x - directionOffset.getZ());
/* 302 */           float facingY = (float)(interactVector.y - directionOffset.getY());
/* 303 */           float facingZ = (float)(interactVector.z - directionOffset.getZ());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 309 */           String ip = (mc.getCurrentServerData() != null) ? (mc.getCurrentServerData()).serverIP : "";
/*     */ 
/*     */           
/* 312 */           if (ip.equalsIgnoreCase("2b2t.org") && mc.getConnection() != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 317 */             mc.playerController.processRightClickBlock(mc.player, mc.world, directionOffset, direction
/*     */ 
/*     */ 
/*     */                 
/* 321 */                 .getOpposite(), interactVector, EnumHand.MAIN_HAND);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 330 */             mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(directionOffset, direction.getOpposite(), EnumHand.MAIN_HAND, facingX, facingY, facingZ));
/*     */           } 
/*     */ 
/*     */           
/* 334 */           if (sneak) {
/* 335 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 340 */           if (sprint) {
/* 341 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 348 */           ItemStack stack = mc.player.getHeldItem(EnumHand.MAIN_HAND);
/*     */ 
/*     */           
/* 351 */           if (!stack.isEmpty() && 
/* 352 */             !stack.getItem().onEntitySwing((EntityLivingBase)mc.player, stack))
/*     */           {
/*     */             
/* 355 */             if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= ((IEntityLivingBase)mc.player).hookGetArmSwingAnimationEnd() / 2 || mc.player.swingProgressInt < 0) {
/* 356 */               mc.player.swingProgressInt = -1;
/* 357 */               mc.player.isSwingInProgress = true;
/* 358 */               mc.player.swingingHand = SwingModule.INSTANCE.isEnabled() ? SwingModule.INSTANCE.getHand() : EnumHand.MAIN_HAND;
/*     */ 
/*     */               
/* 361 */               if (mc.player.world instanceof WorldServer) {
/* 362 */                 ((WorldServer)mc.player.world).getEntityTracker().sendToTracking((Entity)mc.player, (Packet)new SPacketAnimation((Entity)mc.player, 0));
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 369 */           mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/* 370 */           ((IMinecraft)mc).setRightClickDelayTimer(4);
/*     */ 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 380 */     this.placing = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void swingArm(EnumHand in) {
/* 388 */     mc.player.swingArm(in);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void attackEntity(Entity entity, boolean packet, double variation) {
/* 394 */     if (Math.random() <= variation / 100.0D)
/*     */     {
/*     */       
/* 397 */       if (packet) {
/* 398 */         mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/*     */ 
/*     */ 
/*     */         
/* 402 */         mc.player.resetCooldown();
/*     */       }
/*     */       else {
/*     */         
/* 406 */         mc.playerController.attackEntity((EntityPlayer)mc.player, entity);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFaceVisible(BlockPos position, EnumFacing facing) {
/* 418 */     RayTraceResult result = getTraceResult(getReachDistance(), getCosmos().getRotationManager().getServerRotation());
/* 419 */     if (result == null || !result.typeOfHit.equals(RayTraceResult.Type.BLOCK)) {
/* 420 */       return false;
/*     */     }
/*     */     
/* 423 */     return (position.equals(result.getBlockPos()) && result.sideHit.equals(facing));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RayTraceResult getTraceResult(double distance, Rotation rotation) {
/* 432 */     Vec3d eyes = mc.player.getPositionEyes(1.0F);
/*     */     
/* 434 */     if (!rotation.isValid()) {
/* 435 */       rotation = getCosmos().getRotationManager().getServerRotation();
/*     */     }
/*     */     
/* 438 */     Vec3d rotationVector = AngleUtil.getVectorForRotation(rotation);
/*     */     
/* 440 */     return mc.world.rayTraceBlocks(eyes, eyes
/*     */         
/* 442 */         .add(rotationVector.x * distance, rotationVector.y * distance, rotationVector.z * distance), false, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rotation getAnglesToBlock(BlockPos pos, EnumFacing facing) {
/* 452 */     double x = mc.player.posX;
/* 453 */     double y = mc.player.posY;
/* 454 */     double z = mc.player.posZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     Vec3d diff = new Vec3d(pos.getX() + 0.5D - x + facing.getXOffset() / 2.0D, pos.getY() + 0.5D, pos.getZ() + 0.5D - z + facing.getZOffset() / 2.0D);
/*     */ 
/*     */ 
/*     */     
/* 464 */     double distance = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
/*     */ 
/*     */     
/* 467 */     float yaw = (float)(Math.atan2(diff.z, diff.x) * 180.0D / Math.PI - 90.0D);
/* 468 */     float pitch = (float)(Math.atan2(y + mc.player.getEyeHeight() - diff.y, distance) * 180.0D / Math.PI);
/*     */ 
/*     */     
/* 471 */     return new Rotation(MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getReachDistance() {
/* 479 */     return mc.playerController.getBlockReachDistance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EnumFacing> getVisibleSides(BlockPos position) {
/* 488 */     List<EnumFacing> visibleSides = new ArrayList<>();
/*     */ 
/*     */     
/* 491 */     Vec3d positionVector = (new Vec3d((Vec3i)position)).add(0.5D, 0.5D, 0.5D);
/*     */ 
/*     */     
/* 494 */     double facingX = (mc.player.getPositionEyes(1.0F)).x - positionVector.x;
/* 495 */     double facingY = (mc.player.getPositionEyes(1.0F)).y - positionVector.y;
/* 496 */     double facingZ = (mc.player.getPositionEyes(1.0F)).z - positionVector.z;
/*     */ 
/*     */ 
/*     */     
/* 500 */     if (facingX < -0.5D) {
/* 501 */       visibleSides.add(EnumFacing.WEST);
/*     */     
/*     */     }
/* 504 */     else if (facingX > 0.5D) {
/* 505 */       visibleSides.add(EnumFacing.EAST);
/*     */     
/*     */     }
/* 508 */     else if (!mc.world.getBlockState(position).isFullBlock() || !mc.world.isAirBlock(position)) {
/* 509 */       visibleSides.add(EnumFacing.WEST);
/* 510 */       visibleSides.add(EnumFacing.EAST);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 516 */     if (facingY < -0.5D) {
/* 517 */       visibleSides.add(EnumFacing.DOWN);
/*     */     
/*     */     }
/* 520 */     else if (facingY > 0.5D) {
/* 521 */       visibleSides.add(EnumFacing.UP);
/*     */     }
/*     */     else {
/*     */       
/* 525 */       visibleSides.add(EnumFacing.DOWN);
/* 526 */       visibleSides.add(EnumFacing.UP);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 532 */     if (facingZ < -0.5D) {
/* 533 */       visibleSides.add(EnumFacing.NORTH);
/*     */     
/*     */     }
/* 536 */     else if (facingZ > 0.5D) {
/* 537 */       visibleSides.add(EnumFacing.SOUTH);
/*     */     
/*     */     }
/* 540 */     else if (!mc.world.getBlockState(position).isFullBlock() || !mc.world.isAirBlock(position)) {
/* 541 */       visibleSides.add(EnumFacing.NORTH);
/* 542 */       visibleSides.add(EnumFacing.SOUTH);
/*     */     } 
/*     */ 
/*     */     
/* 546 */     return visibleSides;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPlacing() {
/* 554 */     return this.placing;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\InteractionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
