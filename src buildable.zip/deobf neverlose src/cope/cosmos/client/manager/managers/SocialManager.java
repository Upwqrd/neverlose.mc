/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocialManager
/*    */   extends Manager
/*    */ {
/* 15 */   private final Map<String, Relationship> socials = new ConcurrentHashMap<>();
/*    */   
/*    */   public SocialManager() {
/* 18 */     super("SocialManager", "Manages the client's social system");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addSocial(String socialName, Relationship social) {
/* 27 */     this.socials.put(socialName, social);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeSocial(String socialName) {
/* 35 */     this.socials.remove(socialName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Relationship> getSocials() {
/* 43 */     return this.socials;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Relationship getSocial(String socialName) {
/* 52 */     return this.socials.getOrDefault(socialName, Relationship.NONE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum Relationship
/*    */   {
/* 60 */     FRIEND,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     ENEMY,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\SocialManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */