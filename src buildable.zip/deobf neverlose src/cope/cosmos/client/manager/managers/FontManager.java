/*   */ package cope.cosmos.client.manager.managers;
/*   */ 
/*   */ import cope.cosmos.client.manager.Manager;
/*   */ 
/*   */ public class FontManager extends Manager {
/*   */   public FontManager() {
/* 7 */     super("FontManager", "Manages and renders client fonts");
/*   */   }
/*   */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\FontManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */