//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReloadManager
/*    */   extends Manager
/*    */   implements Wrapper
/*    */ {
/*    */   public ReloadManager() {
/* 18 */     super("ReloadManager", "Reloads all modules when loading a new world");
/* 19 */     Cosmos.EVENT_BUS.register(this);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onEntitySpawn(EntityWorldEvent.EntitySpawnEvent event) {
/* 25 */     if (event.getEntity().equals(mc.player)) {
/*    */       
/* 27 */       List<Module> enabledModules = getCosmos().getModuleManager().getModules(Module::isEnabled);
/*    */ 
/*    */       
/* 30 */       getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*    */             if (!module.isExempt()) {
/*    */               module.disable(false);
/*    */             }
/*    */           });
/*    */ 
/*    */       
/* 37 */       enabledModules.forEach(module -> {
/*    */             if (!module.isExempt())
/*    */               module.enable(false); 
/*    */           });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ReloadManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
