//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IMinecraft;
/*     */ import cope.cosmos.asm.mixins.accessor.ITimer;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TickManager
/*     */   extends Manager
/*     */ {
/*  20 */   private final float[] latestTicks = new float[20];
/*     */   
/*     */   private long time;
/*     */   
/*     */   private int tick;
/*     */   
/*     */   public TickManager() {
/*  27 */     super("TickManager", "Keeps track of the server ticks");
/*     */     
/*  29 */     this.time = -1L;
/*     */ 
/*     */     
/*  32 */     for (int i = 0, len = this.latestTicks.length; i < len; i++) {
/*  33 */       this.latestTicks[i] = 0.0F;
/*     */     }
/*     */     
/*  36 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
/*  43 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate) {
/*     */ 
/*     */       
/*  46 */       if (this.time != -1L) {
/*  47 */         this.latestTicks[this.tick % this.latestTicks.length] = MathHelper.clamp(20.0F / (float)(System.currentTimeMillis() - this.time) / 1000.0F, 0.0F, 20.0F);
/*  48 */         this.tick++;
/*     */       } 
/*     */ 
/*     */       
/*  52 */       this.time = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getTPS(TPS tps) {
/*  64 */     if (mc.isSingleplayer() || tps.equals(TPS.NONE)) {
/*  65 */       return 20.0F;
/*     */     }
/*     */ 
/*     */     
/*  69 */     switch (tps) {
/*     */       
/*     */       case CURRENT:
/*  72 */         return MathUtil.roundFloat(MathHelper.clamp(this.latestTicks[0], 0.0F, 20.0F), 2);
/*     */     } 
/*     */     
/*  75 */     int tickCount = 0;
/*  76 */     float tickRate = 0.0F;
/*     */ 
/*     */     
/*  79 */     for (float tick : this.latestTicks) {
/*  80 */       if (tick > 0.0F) {
/*  81 */         tickRate += tick;
/*  82 */         tickCount++;
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return MathUtil.roundFloat(MathHelper.clamp(tickRate / tickCount, 0.0F, 20.0F), 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClientTicks(float ticks) {
/*  96 */     ((ITimer)((IMinecraft)mc).getTimer()).setTickLength(50.0F / ticks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getTickLength() {
/* 104 */     return ((ITimer)((IMinecraft)mc).getTimer()).getTickLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum TPS
/*     */   {
/* 112 */     CURRENT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     AVERAGE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\TickManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
