/*     */ package cope.cosmos.client.manager.managers;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.client.ColorsModule;
/*     */ import cope.cosmos.client.features.modules.client.DiscordPresenceModule;
/*     */ import cope.cosmos.client.features.modules.client.HUDModule;
/*     */ import cope.cosmos.client.features.modules.client.SocialModule;
/*     */ import cope.cosmos.client.features.modules.combat.BurrowModule;
/*     */ import cope.cosmos.client.features.modules.misc.AntiAimModule;
/*     */ import cope.cosmos.client.features.modules.misc.TimerModule;
/*     */ import cope.cosmos.client.features.modules.movement.FastFallModule;
/*     */ import cope.cosmos.client.features.modules.movement.NoSlowModule;
/*     */ import cope.cosmos.client.features.modules.movement.SpeedModule;
/*     */ import cope.cosmos.client.features.modules.visual.ChamsModule;
/*     */ import cope.cosmos.client.features.modules.visual.FullBrightModule;
/*     */ import cope.cosmos.client.features.modules.visual.HoleESPModule;
/*     */ import cope.cosmos.client.features.modules.visual.NewChunksModule;
/*     */ import cope.cosmos.client.features.modules.visual.TracersModule;
/*     */ import cope.cosmos.client.features.modules.visual.ViewModelModule;
/*     */ import cope.cosmos.client.features.setting.Bind;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ public class ModuleManager extends Manager {
/*     */   public ModuleManager() {
/*  27 */     super("ModuleManager", "Manages all the client modules");
/*     */ 
/*     */     
/*  30 */     this.modules = Arrays.asList(new Module[] { (Module)new AutoBackUpModule(), (Module)new AutoDupeModule(), (Module)new AutoNeoPlayerModule(), (Module)new ClickGUIModule(), (Module)new ColorsModule(), (Module)new DiscordPresenceModule(), (Module)new FontModule(), (Module)new HUDModule(), (Module)new SocialModule(), (Module)new StreamerModeModule(), (Module)new AuraModule(), (Module)new AutoArmorModule(), (Module)new AutoBowReleaseModule(), (Module)new AutoCrystalModule(), (Module)new AutoTotemModule(), (Module)new BurrowModule(), (Module)new CriticalsModule(), (Module)new FastProjectileModule(), (Module)new HoleFillModule(), (Module)new SurroundModule(), (Module)new AntiAFKModule(), (Module)new AntiAimModule(), (Module)new AntiCrashModule(), (Module)new AutoDisconnectModule(), (Module)new ChatModificationsModule(), (Module)new ExtraTabModule(), (Module)new FakePlayerModule(), (Module)new MiddleClickModule(), (Module)new MultiTaskModule(), (Module)new NotifierModule(), (Module)new PortalModule(), (Module)new TimerModule(), (Module)new XCarryModule(), (Module)new ElytraFlightModule(), (Module)new EntitySpeedModule(), (Module)new FastFallModule(), (Module)new FlightModule(), (Module)new JesusModule(), (Module)new LongJumpModule(), (Module)new NoSlowModule(), (Module)new PacketFlightModule(), (Module)new SpeedModule(), (Module)new SprintModule(), (Module)new StepModule(), (Module)new VelocityModule(), (Module)new AntiHungerModule(), (Module)new AntiVoidModule(), (Module)new AutoRespawnModule(), (Module)new BlinkModule(), (Module)new EntityControlModule(), (Module)new FastUseModule(), (Module)new InteractModule(), (Module)new NoFallModule(), (Module)new NoRotateModule(), (Module)new PingSpoofModule(), (Module)new ReachModule(), (Module)new ReplenishModule(), (Module)new SpeedMineModule(), (Module)new SwingModule(), (Module)new BlockHighlightModule(), (Module)new BreadcrumbsModule(), (Module)new BreakHighlightModule(), (Module)new CameraClipModule(), (Module)new ChamsModule(), (Module)new ESPModule(), (Module)new FullBrightModule(), (Module)new HoleESPModule(), (Module)new NametagsModule(), (Module)new NewChunksModule(), (Module)new NoRenderModule(), (Module)new NoWeatherModule(), (Module)new SkyColorModule(), (Module)new TracersModule(), (Module)new ViewModelModule(), (Module)new WallhackModule() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<Module> modules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onThread() {
/* 128 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */           if (((Bind)module.getBind().getValue()).isPressed()) {
/*     */             module.toggle();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Module> getAllModules() {
/* 140 */     return this.modules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Module> getModules(Predicate<? super Module> predicate) {
/* 149 */     return (List<Module>)this.modules.stream()
/* 150 */       .filter(predicate)
/* 151 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module getModule(Predicate<? super Module> predicate) {
/* 160 */     return this.modules.stream()
/* 161 */       .filter(predicate)
/* 162 */       .findFirst()
/* 163 */       .orElse(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ModuleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */