//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.world.BlockUtil;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HoleManager
/*     */   extends Manager
/*     */ {
/*  20 */   private List<Hole> holes = new CopyOnWriteArrayList<>();
/*     */   
/*     */   public HoleManager() {
/*  23 */     super("HoleManager", "Manages all nearby holes");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   public static final Vec3i[] HOLE = new Vec3i[] { new Vec3i(1, 0, 0), new Vec3i(-1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final Vec3i[] DOUBLE_HOLE_X = new Vec3i[] { new Vec3i(2, 0, 0), new Vec3i(-1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(1, 0, 1), new Vec3i(0, 0, -1), new Vec3i(1, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final Vec3i[] DOUBLE_HOLE_Z = new Vec3i[] { new Vec3i(1, 0, 0), new Vec3i(1, 0, 1), new Vec3i(-1, 0, 0), new Vec3i(-1, 0, 1), new Vec3i(0, 0, 2), new Vec3i(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final Vec3i[] QUAD_HOLE = new Vec3i[] { new Vec3i(2, 0, 0), new Vec3i(2, 0, 1), new Vec3i(1, 0, 2), new Vec3i(0, 0, 2), new Vec3i(-1, 0, 0), new Vec3i(-1, 0, 1), new Vec3i(0, 0, -1), new Vec3i(1, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onThread() {
/*  77 */     this.holes = searchHoles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Hole> searchHoles() {
/*  87 */     List<Hole> searchedHoles = new CopyOnWriteArrayList<>();
/*     */ 
/*     */     
/*  90 */     for (BlockPos blockPosition : BlockUtil.getBlocksInArea((EntityPlayer)mc.player, new AxisAlignedBB(-10.0D, -10.0D, -10.0D, 10.0D, 10.0D, 10.0D))) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (BlockUtil.isBreakable(blockPosition) && ((mc.player.dimension == -1) ? (blockPosition.getY() == 0 || blockPosition.getY() == 127) : (blockPosition.getY() == 0))) {
/*  96 */         searchedHoles.add(new Hole(blockPosition, Type.VOID));
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 101 */       if (mc.world.getBlockState(blockPosition).getMaterial().isReplaceable())
/*     */       {
/*     */         
/* 104 */         if (!mc.world.getBlockState(blockPosition.add(0, -1, 0)).getMaterial().isReplaceable()) {
/*     */ 
/*     */           
/* 107 */           boolean standable = false;
/*     */ 
/*     */           
/* 110 */           if (mc.world.getBlockState(blockPosition.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 0)).getMaterial().isReplaceable()) {
/* 111 */             standable = true;
/*     */           }
/*     */ 
/*     */           
/* 115 */           int resistantSides = 0;
/* 116 */           int unbreakableSides = 0;
/*     */ 
/*     */           
/* 119 */           for (Vec3i holeSide : HOLE) {
/*     */ 
/*     */             
/* 122 */             BlockPos holeOffset = blockPosition.add(holeSide);
/*     */ 
/*     */             
/* 125 */             if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.RESISTANT)) {
/* 126 */               resistantSides++;
/*     */ 
/*     */             
/*     */             }
/* 130 */             else if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.UNBREAKABLE)) {
/* 131 */               unbreakableSides++;
/*     */             }
/*     */             else {
/*     */               
/* 135 */               resistantSides = 0;
/* 136 */               unbreakableSides = 0;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           
/* 142 */           if (standable) {
/*     */ 
/*     */             
/* 145 */             if (unbreakableSides == HOLE.length) {
/* 146 */               searchedHoles.add(new Hole(blockPosition, Type.BEDROCK));
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 151 */             if (resistantSides == HOLE.length) {
/* 152 */               searchedHoles.add(new Hole(blockPosition, Type.OBSIDIAN));
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 157 */             if (unbreakableSides + resistantSides == HOLE.length) {
/* 158 */               searchedHoles.add(new Hole(blockPosition, Type.MIXED));
/*     */ 
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 164 */             resistantSides = 0;
/* 165 */             unbreakableSides = 0;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 170 */           if (mc.world.getBlockState(blockPosition.add(1, 0, 0)).getMaterial().isReplaceable())
/*     */           {
/*     */             
/* 173 */             if (!mc.world.getBlockState(blockPosition.add(1, -1, 0)).getMaterial().isReplaceable()) {
/*     */ 
/*     */               
/* 176 */               boolean doubleXStandable = false;
/*     */ 
/*     */               
/* 179 */               if ((mc.world.getBlockState(blockPosition.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 0)).getMaterial().isReplaceable()) || (mc.world.getBlockState(blockPosition.add(1, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(1, 2, 0)).getMaterial().isReplaceable())) {
/* 180 */                 doubleXStandable = true;
/*     */               }
/*     */ 
/*     */               
/* 184 */               for (Vec3i holeSide : DOUBLE_HOLE_X) {
/*     */ 
/*     */                 
/* 187 */                 BlockPos holeOffset = blockPosition.add(holeSide);
/*     */ 
/*     */                 
/* 190 */                 if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.RESISTANT)) {
/* 191 */                   resistantSides++;
/*     */ 
/*     */                 
/*     */                 }
/* 195 */                 else if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.UNBREAKABLE)) {
/* 196 */                   unbreakableSides++;
/*     */                 }
/*     */                 else {
/*     */                   
/* 200 */                   resistantSides = 0;
/* 201 */                   unbreakableSides = 0;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               
/* 207 */               if (doubleXStandable) {
/*     */ 
/*     */                 
/* 210 */                 if (unbreakableSides == DOUBLE_HOLE_X.length) {
/* 211 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_BEDROCK_X));
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 216 */                 if (resistantSides == DOUBLE_HOLE_X.length) {
/* 217 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_OBSIDIAN_X));
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 222 */                 if (unbreakableSides + resistantSides == DOUBLE_HOLE_X.length) {
/* 223 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_MIXED_X));
/*     */ 
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 229 */                 resistantSides = 0;
/* 230 */                 unbreakableSides = 0;
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 237 */           if (mc.world.getBlockState(blockPosition.add(0, 0, 1)).getMaterial().isReplaceable())
/*     */           {
/*     */             
/* 240 */             if (!mc.world.getBlockState(blockPosition.add(0, -1, 1)).getMaterial().isReplaceable()) {
/*     */ 
/*     */               
/* 243 */               boolean doubleZStandable = false;
/*     */ 
/*     */               
/* 246 */               if ((mc.world.getBlockState(blockPosition.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 0)).getMaterial().isReplaceable()) || (mc.world.getBlockState(blockPosition.add(0, 1, 1)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 1)).getMaterial().isReplaceable())) {
/* 247 */                 doubleZStandable = true;
/*     */               }
/*     */ 
/*     */               
/* 251 */               for (Vec3i holeSide : DOUBLE_HOLE_Z) {
/*     */ 
/*     */                 
/* 254 */                 BlockPos holeOffset = blockPosition.add(holeSide);
/*     */ 
/*     */                 
/* 257 */                 if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.RESISTANT)) {
/* 258 */                   resistantSides++;
/*     */ 
/*     */                 
/*     */                 }
/* 262 */                 else if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.UNBREAKABLE)) {
/* 263 */                   unbreakableSides++;
/*     */                 }
/*     */                 else {
/*     */                   
/* 267 */                   resistantSides = 0;
/* 268 */                   unbreakableSides = 0;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               
/* 274 */               if (doubleZStandable) {
/*     */                 
/* 276 */                 if (unbreakableSides == DOUBLE_HOLE_Z.length) {
/* 277 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_BEDROCK_Z));
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 282 */                 if (resistantSides == DOUBLE_HOLE_Z.length) {
/* 283 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_OBSIDIAN_Z));
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 288 */                 if (unbreakableSides + resistantSides == DOUBLE_HOLE_Z.length) {
/* 289 */                   searchedHoles.add(new Hole(blockPosition, Type.DOUBLE_MIXED_Z));
/*     */ 
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/* 295 */                 resistantSides = 0;
/* 296 */                 unbreakableSides = 0;
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 303 */           if (mc.world.getBlockState(blockPosition.add(0, 0, 1)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(1, 0, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(1, 0, 1)).getMaterial().isReplaceable())
/*     */           {
/*     */             
/* 306 */             if (!mc.world.getBlockState(blockPosition.add(0, -1, 1)).getMaterial().isReplaceable() && !mc.world.getBlockState(blockPosition.add(1, -1, 0)).getMaterial().isReplaceable() && !mc.world.getBlockState(blockPosition.add(1, -1, 1)).getMaterial().isReplaceable()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 312 */               int stopBlocks = 0;
/* 313 */               if (mc.world.getBlockState(blockPosition.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 0)).getMaterial().isReplaceable()) {
/* 314 */                 stopBlocks++;
/*     */               }
/*     */               
/* 317 */               if (mc.world.getBlockState(blockPosition.add(1, 1, 0)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(1, 2, 0)).getMaterial().isReplaceable()) {
/* 318 */                 stopBlocks++;
/*     */               }
/*     */               
/* 321 */               if (mc.world.getBlockState(blockPosition.add(0, 1, 1)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(0, 2, 1)).getMaterial().isReplaceable()) {
/* 322 */                 stopBlocks++;
/*     */               }
/*     */               
/* 325 */               if (mc.world.getBlockState(blockPosition.add(1, 1, 1)).getMaterial().isReplaceable() && mc.world.getBlockState(blockPosition.add(1, 2, 1)).getMaterial().isReplaceable()) {
/* 326 */                 stopBlocks++;
/*     */               }
/*     */ 
/*     */               
/* 330 */               boolean quadStandable = (stopBlocks != 3);
/*     */ 
/*     */               
/* 333 */               for (Vec3i holeSide : QUAD_HOLE) {
/*     */ 
/*     */                 
/* 336 */                 BlockPos holeOffset = blockPosition.add(holeSide);
/*     */ 
/*     */                 
/* 339 */                 if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.RESISTANT)) {
/* 340 */                   resistantSides++;
/*     */ 
/*     */                 
/*     */                 }
/* 344 */                 else if (BlockUtil.getResistance(holeOffset).equals(BlockUtil.Resistance.UNBREAKABLE)) {
/* 345 */                   unbreakableSides++;
/*     */                 }
/*     */                 else {
/*     */                   
/* 349 */                   resistantSides = 0;
/* 350 */                   unbreakableSides = 0;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               
/* 356 */               if (quadStandable) {
/*     */                 
/* 358 */                 if (unbreakableSides == QUAD_HOLE.length) {
/* 359 */                   searchedHoles.add(new Hole(blockPosition, Type.QUAD_BEDROCK));
/*     */                   
/*     */                   continue;
/*     */                 } 
/* 363 */                 if (resistantSides == QUAD_HOLE.length) {
/* 364 */                   searchedHoles.add(new Hole(blockPosition, Type.QUAD_OBSIDIAN));
/*     */                   
/*     */                   continue;
/*     */                 } 
/* 368 */                 if (unbreakableSides + resistantSides == QUAD_HOLE.length) {
/* 369 */                   searchedHoles.add(new Hole(blockPosition, Type.QUAD_MIXED));
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 378 */     return searchedHoles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Hole> getHoles() {
/* 386 */     return this.holes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHole(BlockPos in) {
/* 396 */     for (Vec3i holeOffset : HOLE) {
/*     */ 
/*     */       
/* 399 */       BlockPos holeSide = in.add(holeOffset);
/*     */ 
/*     */       
/* 402 */       if (!BlockUtil.getResistance(holeSide).equals(BlockUtil.Resistance.RESISTANT) && !BlockUtil.getResistance(holeSide).equals(BlockUtil.Resistance.UNBREAKABLE)) {
/* 403 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 407 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 416 */     OBSIDIAN,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 421 */     MIXED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     BEDROCK,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     DOUBLE_OBSIDIAN_X,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 436 */     DOUBLE_OBSIDIAN_Z,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 441 */     DOUBLE_MIXED_X,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 446 */     DOUBLE_MIXED_Z,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     DOUBLE_BEDROCK_X,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 456 */     DOUBLE_BEDROCK_Z,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 461 */     QUAD_OBSIDIAN,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 466 */     QUAD_MIXED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 471 */     QUAD_BEDROCK,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 476 */     VOID;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Hole
/*     */   {
/*     */     private final BlockPos hole;
/*     */     private final HoleManager.Type type;
/*     */     
/*     */     public Hole(BlockPos hole, HoleManager.Type type) {
/* 486 */       this.hole = hole;
/* 487 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockPos getHole() {
/* 495 */       return this.hole;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public HoleManager.Type getType() {
/* 503 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDouble() {
/* 511 */       return (this.type.equals(HoleManager.Type.DOUBLE_OBSIDIAN_X) || this.type.equals(HoleManager.Type.DOUBLE_MIXED_X) || this.type.equals(HoleManager.Type.DOUBLE_BEDROCK_X) || this.type.equals(HoleManager.Type.DOUBLE_OBSIDIAN_Z) || this.type.equals(HoleManager.Type.DOUBLE_MIXED_Z) || this.type.equals(HoleManager.Type.DOUBLE_BEDROCK_Z));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isQuad() {
/* 519 */       return (this.type.equals(HoleManager.Type.QUAD_OBSIDIAN) || this.type.equals(HoleManager.Type.QUAD_MIXED) || this.type.equals(HoleManager.Type.QUAD_BEDROCK));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\HoleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
