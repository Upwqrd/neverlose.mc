//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.IPlayerControllerMP;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryManager
/*     */   extends Manager
/*     */ {
/*  20 */   private int serverSlot = -1;
/*     */   
/*     */   public InventoryManager() {
/*  23 */     super("InventoryManager", "Manages player hotbar and inventory actions");
/*  24 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  31 */     if (event.getPacket() instanceof CPacketHeldItemChange) {
/*     */ 
/*     */       
/*  34 */       if (!InventoryPlayer.isHotbar(((CPacketHeldItemChange)event.getPacket()).getSlotId())) {
/*  35 */         event.setCanceled(true);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  40 */       this.serverSlot = ((CPacketHeldItemChange)event.getPacket()).getSlotId();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToSlot(int in, Switch swap) {
/*  52 */     if (InventoryPlayer.isHotbar(in))
/*     */     {
/*     */       
/*  55 */       if (mc.player.inventory.currentItem != in) {
/*  56 */         switch (swap) {
/*     */           
/*     */           case NORMAL:
/*  59 */             mc.player.inventory.currentItem = in;
/*  60 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(in));
/*     */             break;
/*     */           
/*     */           case PACKET:
/*  64 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(in));
/*  65 */             ((IPlayerControllerMP)mc.playerController).setCurrentPlayerItem(in);
/*     */             break;
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToItem(Item in, Switch swap) {
/*  81 */     int slot = searchSlot(in, InventoryRegion.HOTBAR);
/*     */ 
/*     */     
/*  84 */     switchToSlot(slot, swap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToItem(Class<? extends Item> in, Switch swap) {
/*  95 */     int slot = searchSlot(in, InventoryRegion.HOTBAR);
/*     */ 
/*     */     
/*  98 */     switchToSlot(slot, swap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToItem(Item[] in, Switch swap) {
/* 108 */     int slot = -1;
/*     */ 
/*     */     
/* 111 */     for (int i = InventoryRegion.HOTBAR.getStart(); i < InventoryRegion.HOTBAR.getBound(); i++) {
/*     */ 
/*     */       
/* 114 */       for (Item item : in) {
/* 115 */         if (mc.player.inventory.getStackInSlot(i).getItem().equals(item)) {
/* 116 */           slot = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 122 */       if (slot != -1) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 128 */     switchToSlot(slot, swap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToBlock(Block in, Switch swap) {
/* 137 */     switchToItem(Item.getItemFromBlock(in), swap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchToBlock(Block[] in, Switch swap) {
/* 148 */     Item[] blockItems = new Item[in.length];
/*     */ 
/*     */     
/* 151 */     for (int i = 0; i < in.length; i++) {
/* 152 */       blockItems[i] = Item.getItemFromBlock(in[i]);
/*     */     }
/*     */ 
/*     */     
/* 156 */     switchToItem(blockItems, swap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchSlot(Item in, InventoryRegion inventoryRegion) {
/* 168 */     int slot = -1;
/*     */ 
/*     */     
/* 171 */     for (int i = inventoryRegion.getStart(); i < inventoryRegion.getBound(); i++) {
/*     */ 
/*     */       
/* 174 */       if (mc.player.inventory.getStackInSlot(i).getItem().equals(in)) {
/* 175 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 180 */     return slot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchSlot(Block[] in, InventoryRegion inventoryRegion) {
/* 192 */     int slot = -1;
/*     */ 
/*     */     
/* 195 */     for (int i = inventoryRegion.getStart(); i < inventoryRegion.getBound(); i++) {
/*     */ 
/*     */       
/* 198 */       for (Block block : in) {
/*     */ 
/*     */         
/* 201 */         if (slot == -1 && mc.player.inventory.getStackInSlot(i).getItem().equals(Item.getItemFromBlock(block))) {
/* 202 */           slot = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 208 */     return slot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchSlot(Class<? extends Item> in, InventoryRegion inventoryRegion) {
/* 219 */     int slot = -1;
/*     */ 
/*     */     
/* 222 */     for (int i = inventoryRegion.getStart(); i <= inventoryRegion.getBound(); i++) {
/*     */ 
/*     */       
/* 225 */       if (in.isInstance(mc.player.inventory.getStackInSlot(i).getItem())) {
/* 226 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 231 */     return slot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getServerSlot() {
/* 239 */     return this.serverSlot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncSlot() {
/* 246 */     if (this.serverSlot != mc.player.inventory.currentItem) {
/* 247 */       mc.player.inventory.currentItem = this.serverSlot;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Switch
/*     */   {
/* 256 */     NORMAL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     PACKET,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum InventoryRegion
/*     */   {
/* 274 */     INVENTORY(0, 45),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     HOTBAR(0, 8),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     CRAFTING(80, 83),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     ARMOR(100, 103);
/*     */     
/*     */     private final int start;
/*     */     private final int bound;
/*     */     
/*     */     InventoryRegion(int start, int bound) {
/* 295 */       this.start = start;
/* 296 */       this.bound = bound;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getStart() {
/* 304 */       return this.start;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getBound() {
/* 312 */       return this.bound;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\InventoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
