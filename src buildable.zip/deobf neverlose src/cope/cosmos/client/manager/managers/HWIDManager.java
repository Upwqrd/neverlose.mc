/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.util.hwid.DisplayUtil;
/*    */ import cope.cosmos.util.hwid.NoStackTraceThrowable;
/*    */ import cope.cosmos.util.hwid.SystemUtil;
/*    */ import cope.cosmos.util.hwid.URLReader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HWIDManager
/*    */ {
/*    */   public static final String pastebinURL = "https://pastebin.com/raw/7Rn4nekT";
/* 17 */   public static List<String> hwids = new ArrayList<>();
/*    */   
/*    */   public static void hwidCheck() {
/* 20 */     hwids = URLReader.readURL();
/* 21 */     boolean isHwidPresent = hwids.contains(SystemUtil.getSystemInfo());
/* 22 */     if (!isHwidPresent) {
/* 23 */       DisplayUtil.Display();
/* 24 */       throw new NoStackTraceThrowable("");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\HWIDManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */