//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.block.LeftClickBlockEvent;
/*     */ import cope.cosmos.client.events.combat.CriticalModifierEvent;
/*     */ import cope.cosmos.client.events.combat.DeathEvent;
/*     */ import cope.cosmos.client.events.combat.TotemPopEvent;
/*     */ import cope.cosmos.client.events.entity.player.interact.EntityUseItemEvent;
/*     */ import cope.cosmos.client.events.entity.player.interact.ItemInputUpdateEvent;
/*     */ import cope.cosmos.client.events.entity.player.interact.RightClickItemEvent;
/*     */ import cope.cosmos.client.events.entity.potion.PotionEffectEvent;
/*     */ import cope.cosmos.client.events.motion.movement.KnockBackEvent;
/*     */ import cope.cosmos.client.events.motion.movement.PushOutOfBlocksEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.events.render.gui.RenderOverlayEvent;
/*     */ import cope.cosmos.client.events.render.world.RenderFogColorEvent;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.ClientChatEvent;
/*     */ import net.minecraftforge.client.event.EntityViewRenderEvent;
/*     */ import net.minecraftforge.client.event.InputUpdateEvent;
/*     */ import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
/*     */ import net.minecraftforge.client.event.RenderBlockOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
/*     */ import net.minecraftforge.event.entity.living.PotionEvent;
/*     */ import net.minecraftforge.event.entity.player.CriticalHitEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ 
/*     */ public class EventManager extends Manager implements Wrapper {
/*     */   public EventManager() {
/*  41 */     super("EventManager", "Manages Forge events");
/*     */ 
/*     */     
/*  44 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdate(LivingEvent.LivingUpdateEvent event) {
/*  51 */     mc.profiler.startSection("cosmos-update");
/*     */     
/*  53 */     if ((event.getEntity().getEntityWorld()).isRemote && event.getEntityLiving().equals(mc.player)) {
/*     */ 
/*     */       
/*  56 */       getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */ 
/*     */             
/*     */             if (nullCheck() || getCosmos().getNullSafeFeatures().contains(module)) {
/*     */               if (module.isEnabled()) {
/*     */                 try {
/*     */                   module.onUpdate();
/*  63 */                 } catch (Exception exception) {
/*     */                   if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                     exception.printStackTrace();
/*     */                   }
/*     */                 } 
/*     */               }
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  75 */       getCosmos().getManagers().forEach(manager -> {
/*     */ 
/*     */             
/*     */             if (nullCheck() || getCosmos().getNullSafeFeatures().contains(manager)) {
/*     */               try {
/*     */                 manager.onUpdate();
/*  81 */               } catch (Exception exception) {
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   exception.printStackTrace();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  92 */     mc.profiler.endSection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTick(TickEvent.ClientTickEvent event) {
/*  99 */     mc.profiler.startSection("cosmos-root-tick");
/*     */ 
/*     */     
/* 102 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(module)) {
/*     */             if (module.isEnabled()) {
/*     */               try {
/*     */                 module.onTick();
/* 109 */               } catch (Exception exception) {
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   exception.printStackTrace();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     getCosmos().getManagers().forEach(manager -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(manager)) {
/*     */             try {
/*     */               manager.onTick();
/* 127 */             } catch (Exception exception) {
/*     */               if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                 exception.printStackTrace();
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 137 */     mc.profiler.endSection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRender2d(RenderGameOverlayEvent.Text event) {
/* 144 */     mc.profiler.startSection("cosmos-render-2D");
/*     */ 
/*     */     
/* 147 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(module)) {
/*     */             if (module.isEnabled()) {
/*     */               try {
/*     */                 module.onRender2D();
/* 154 */               } catch (Exception exception) {
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   exception.printStackTrace();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     getCosmos().getManagers().forEach(manager -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(manager)) {
/*     */             try {
/*     */               manager.onRender2D();
/* 172 */             } catch (Exception exception) {
/*     */               if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                 exception.printStackTrace();
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 182 */     mc.profiler.endSection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRender3D(RenderWorldLastEvent event) {
/* 189 */     mc.profiler.startSection("cosmos-render-3D");
/*     */ 
/*     */     
/* 192 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(module)) {
/*     */             if (module.isEnabled()) {
/*     */               try {
/*     */                 module.onRender3D();
/* 199 */               } catch (Exception exception) {
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   exception.printStackTrace();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     getCosmos().getManagers().forEach(manager -> {
/*     */ 
/*     */           
/*     */           if (nullCheck() || getCosmos().getNullSafeFeatures().contains(manager)) {
/*     */             try {
/*     */               manager.onRender3D();
/* 217 */             } catch (Exception exception) {
/*     */               if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                 exception.printStackTrace();
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 227 */     mc.profiler.endSection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onChatInput(ClientChatEvent event) {
/* 234 */     if (event.getMessage().startsWith(Cosmos.PREFIX)) {
/* 235 */       event.setCanceled(true);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 240 */         getCosmos().getCommandDispatcher().execute(getCosmos().getCommandDispatcher()
/* 241 */             .parse(event.getOriginalMessage().substring(1), Integer.valueOf(1)));
/*     */       }
/* 243 */       catch (Exception exception) {
/*     */         
/* 245 */         getCosmos().getChatManager().sendHoverableMessage(ChatFormatting.RED + "An error occurred!", "No such command was found");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTotemPop(PacketEvent.PacketReceiveEvent event) {
/* 254 */     if (event.getPacket() instanceof SPacketEntityStatus && ((SPacketEntityStatus)event.getPacket()).getOpCode() == 35) {
/* 255 */       TotemPopEvent totemPopEvent = new TotemPopEvent(((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world));
/* 256 */       Cosmos.EVENT_BUS.post((Event)totemPopEvent);
/*     */       
/* 258 */       if (totemPopEvent.isCanceled()) {
/* 259 */         event.setCanceled(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onCriticalHit(CriticalHitEvent event) {
/* 266 */     CriticalModifierEvent criticalModifierEvent = new CriticalModifierEvent();
/* 267 */     Cosmos.EVENT_BUS.post((Event)criticalModifierEvent);
/*     */ 
/*     */     
/* 270 */     event.setDamageModifier(criticalModifierEvent.getDamageModifier());
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onInputUpdate(InputUpdateEvent event) {
/* 275 */     ItemInputUpdateEvent itemInputUpdateEvent = new ItemInputUpdateEvent(event.getMovementInput());
/* 276 */     Cosmos.EVENT_BUS.post((Event)itemInputUpdateEvent);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingEntityUseItem(LivingEntityUseItemEvent event) {
/* 281 */     EntityUseItemEvent entityUseItemEvent = new EntityUseItemEvent();
/* 282 */     Cosmos.EVENT_BUS.post((Event)entityUseItemEvent);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onKnockback(LivingKnockBackEvent event) {
/* 287 */     KnockBackEvent knockBackEvent = new KnockBackEvent();
/* 288 */     Cosmos.EVENT_BUS.post((Event)knockBackEvent);
/*     */     
/* 290 */     if (knockBackEvent.isCanceled()) {
/* 291 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
/* 297 */     if (event.getEntityPlayer().equals(mc.player)) {
/* 298 */       RightClickItemEvent rightClickItemEvent = new RightClickItemEvent(event.getItemStack());
/* 299 */       Cosmos.EVENT_BUS.post((Event)rightClickItemEvent);
/*     */       
/* 301 */       if (rightClickItemEvent.isCanceled()) {
/* 302 */         event.setCanceled(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
/* 309 */     LeftClickBlockEvent leftClickBlockEvent = new LeftClickBlockEvent(event.getPos(), event.getFace());
/* 310 */     Cosmos.EVENT_BUS.post((Event)leftClickBlockEvent);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPushOutOfBlocks(PlayerSPPushOutOfBlocksEvent event) {
/* 315 */     if (event.getEntity().equals(mc.player)) {
/* 316 */       PushOutOfBlocksEvent pushOutOfBlocksEvent = new PushOutOfBlocksEvent();
/* 317 */       Cosmos.EVENT_BUS.post((Event)pushOutOfBlocksEvent);
/*     */       
/* 319 */       if (pushOutOfBlocksEvent.isCanceled()) {
/* 320 */         event.setCanceled(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onDeath(LivingDeathEvent event) {
/* 327 */     DeathEvent deathEvent = new DeathEvent(event.getEntity());
/* 328 */     Cosmos.EVENT_BUS.post((Event)deathEvent);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderBlockOverlay(RenderBlockOverlayEvent event) {
/* 333 */     RenderOverlayEvent renderOverlayEvent = new RenderOverlayEvent(event.getOverlayType());
/* 334 */     Cosmos.EVENT_BUS.post((Event)renderOverlayEvent);
/*     */     
/* 336 */     if (renderOverlayEvent.isCanceled()) {
/* 337 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onFogColor(EntityViewRenderEvent.FogColors event) {
/* 343 */     RenderFogColorEvent fogColorEvent = new RenderFogColorEvent();
/* 344 */     Cosmos.EVENT_BUS.post((Event)fogColorEvent);
/*     */ 
/*     */     
/* 347 */     if (fogColorEvent.isCanceled()) {
/* 348 */       event.setRed(fogColorEvent.getColor().getRed() / 255.0F);
/* 349 */       event.setGreen(fogColorEvent.getColor().getGreen() / 255.0F);
/* 350 */       event.setBlue(fogColorEvent.getColor().getBlue() / 255.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPotionAdd(PotionEvent.PotionApplicableEvent event) {
/* 357 */     if (nullCheck() && mc.player.equals(event.getEntity())) {
/* 358 */       PotionEffectEvent.PotionAdd potionAddEvent = new PotionEffectEvent.PotionAdd(event.getPotionEffect());
/* 359 */       Cosmos.EVENT_BUS.post((Event)potionAddEvent);
/*     */       
/* 361 */       if (potionAddEvent.isCanceled()) {
/* 362 */         event.setResult(Event.Result.DENY);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPotionRemove(PotionEvent.PotionRemoveEvent event) {
/* 370 */     if (nullCheck() && mc.player.equals(event.getEntity())) {
/*     */       
/* 372 */       PotionEffectEvent.PotionRemove potionRemoveEvent = new PotionEffectEvent.PotionRemove(event.getPotion());
/* 373 */       Cosmos.EVENT_BUS.post((Event)potionRemoveEvent);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPotionExpiry(PotionEvent.PotionExpiryEvent event) {
/* 380 */     if (nullCheck() && mc.player.equals(event.getEntity())) {
/*     */       
/* 382 */       PotionEffectEvent.PotionRemove potionRemoveEvent = new PotionEffectEvent.PotionRemove(event.getPotionEffect());
/* 383 */       Cosmos.EVENT_BUS.post((Event)potionRemoveEvent);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
