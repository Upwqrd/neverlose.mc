/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.client.ui.altgui.AltEntry;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AltManager
/*    */   extends Manager
/*    */ {
/* 16 */   private final List<AltEntry> altEntries = new ArrayList<>();
/*    */   
/*    */   public AltManager() {
/* 19 */     super("AltManager", "Manages client's saved alternate accounts");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<AltEntry> getAltEntries() {
/* 27 */     return this.altEntries;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\AltManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */