//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.client.audio.Sound;
/*    */ import net.minecraft.client.audio.SoundEventAccessor;
/*    */ import net.minecraft.client.audio.SoundHandler;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.SoundCategory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SoundManager
/*    */   extends Manager
/*    */ {
/*    */   public SoundManager() {
/* 19 */     super("SoundManager", "Manages client sounds");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void playSound(final String in) {
/* 27 */     mc.getSoundHandler().playSound(new ISound()
/*    */         {
/*    */           @Nonnull
/*    */           public ResourceLocation getSoundLocation()
/*    */           {
/* 32 */             return new ResourceLocation("cosmos", "sounds/" + in + ".ogg");
/*    */           }
/*    */ 
/*    */ 
/*    */           
/*    */           @Nonnull
/*    */           public SoundEventAccessor createAccessor(SoundHandler handler) {
/* 39 */             return new SoundEventAccessor(new ResourceLocation("cosmos", "sounds/" + in + ".ogg"), in);
/*    */           }
/*    */ 
/*    */           
/*    */           @Nonnull
/*    */           public Sound getSound() {
/* 45 */             return new Sound(in, 1.0F, 1.0F, 1, Sound.Type.SOUND_EVENT, false);
/*    */           }
/*    */ 
/*    */           
/*    */           @Nonnull
/*    */           public SoundCategory getCategory() {
/* 51 */             return SoundCategory.PLAYERS;
/*    */           }
/*    */ 
/*    */           
/*    */           public boolean canRepeat() {
/* 56 */             return false;
/*    */           }
/*    */ 
/*    */           
/*    */           public int getRepeatDelay() {
/* 61 */             return 0;
/*    */           }
/*    */ 
/*    */           
/*    */           public float getVolume() {
/* 66 */             return 1.0F;
/*    */           }
/*    */ 
/*    */           
/*    */           public float getPitch() {
/* 71 */             return 1.0F;
/*    */           }
/*    */ 
/*    */           
/*    */           public float getXPosF() {
/* 76 */             return (Wrapper.mc.player != null) ? (float)Wrapper.mc.player.posX : 0.0F;
/*    */           }
/*    */ 
/*    */           
/*    */           public float getYPosF() {
/* 81 */             return (Wrapper.mc.player != null) ? (float)Wrapper.mc.player.posY : 0.0F;
/*    */           }
/*    */ 
/*    */           
/*    */           public float getZPosF() {
/* 86 */             return (Wrapper.mc.player != null) ? (float)Wrapper.mc.player.posZ : 0.0F;
/*    */           }
/*    */ 
/*    */           
/*    */           @Nonnull
/*    */           public ISound.AttenuationType getAttenuationType() {
/* 92 */             return ISound.AttenuationType.LINEAR;
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\SoundManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
