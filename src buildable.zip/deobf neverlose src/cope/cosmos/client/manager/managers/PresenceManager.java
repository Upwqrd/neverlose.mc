//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import club.minnced.discord.rpc.DiscordEventHandlers;
/*     */ import club.minnced.discord.rpc.DiscordRPC;
/*     */ import club.minnced.discord.rpc.DiscordRichPresence;
/*     */ import cope.cosmos.client.features.modules.combat.AutoCrystalModule;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PresenceManager
/*     */   extends Manager
/*     */ {
/*  19 */   private static final DiscordRPC discordPresence = DiscordRPC.INSTANCE;
/*  20 */   private static final DiscordRichPresence richPresence = new DiscordRichPresence();
/*  21 */   private static final DiscordEventHandlers presenceHandlers = new DiscordEventHandlers();
/*     */   
/*     */   private static Thread presenceThread;
/*     */ 
/*     */   
/*     */   public PresenceManager() {
/*  27 */     super("PresenceManager", "Manages the client Discord RPC");
/*     */   }
/*     */ 
/*     */   
/*  31 */   private static final String[] presenceDetails = new String[] { "neverlose.mc", "fuck off niggas", "autowin.cc gradient shaders (pasted from gs++)", "renat muratov?????", "Owning spawn", "kumatroll zatrolen`", "Biggest player by weight", "Putting on femboy socks", "Sending CPacketDoTroll", "Removing konas from mods folder", "Installing trojan", "Лингудом не фейку�? отвеча�?", "soso podelay", "Regearing ...", "Nomming on some corn", "Гетните ре�?ов на 5б", "Watching GrandOlive through his webcam", "Forcing PapaQuill to make packs", "Leaking Kotira227's alts", "Deleting First's configs", "Backdooring impurity.me", "Cracking latest konas :yawn:", "Autoduping on oldfag.org", "Tater", "I am a " + (
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  56 */       (((Double)AutoCrystalModule.damage.getValue()).doubleValue() < 4.0D) ? "faggot." : "good config person :)"), "Injecting estrogen", "Shadow wizard money gang", "Legalize Nuclear Bombs", "5k klipov na montazh", "Я УБИЛ �?ВТ�?ВИ�?ЕР�? �?Х�?Х�?Х�?Х�?Х�?", "Stealing future beta", "My game is going sicko mode", "Overdosing on crack cocaine", "Enjoying goth рыбнадзор", "Pasting phobos", "автовин не па�?та отвеча�?", "Sending credentials to webhook", "BurrowBypass enabled!", "Consuming soy products", "/killing ...", "ты нуб |го 1в1 флат ноу бурров | нет | почему | потому что ты нуб", "Live-Action Role Playing", "Running Bruce client beta", "java.lang.NullPointerException", "Becoming overweight", "Ordering SevJ6 pizzas", "Putting 29 on the bin", "we.devs.forever", "SSing my address", "back up me", "commendant mc", "candice", "pastebin/war thunder", "Mineral?", "Loading class -> FontRenderer.class", "Trashing 5 auto32k fags", "Packetflying on crystalpvp.cc", "Sending double the packets to do double the damage", "Sending shift packets", "Dueling in vanilla cpvp", "Larping about staircases", "Average autowin user" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startPresence() {
/* 102 */     discordPresence.Discord_Initialize("1124066028687736893", presenceHandlers, true, "");
/* 103 */     richPresence.startTimestamp = System.currentTimeMillis() / 1000L;
/* 104 */     discordPresence.Discord_UpdatePresence(richPresence);
/*     */ 
/*     */     
/* 107 */     presenceThread = new Thread(() -> {
/*     */           while (!Thread.currentThread().isInterrupted()) {
/*     */             try {
/*     */               richPresence.largeImageKey = "map_art";
/*     */               
/*     */               richPresence.largeImageText = "neverlose.mc";
/*     */               
/*     */               richPresence.smallImageKey = "legit";
/*     */               richPresence.smallImageText = "1.0b";
/*     */               richPresence.details = mc.isIntegratedServerRunning() ? "SinglePlayer" : ((mc.getCurrentServerData() != null) ? (mc.getCurrentServerData()).serverIP.toLowerCase() : "Menus");
/*     */               richPresence.state = presenceDetails[(new Random()).nextInt(presenceDetails.length)];
/*     */               discordPresence.Discord_UpdatePresence(richPresence);
/*     */               Thread.sleep(3000L);
/* 120 */             } catch (Exception exception) {}
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 126 */     presenceThread.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void interruptPresence() {
/* 133 */     if (presenceThread != null && !presenceThread.isInterrupted()) {
/* 134 */       presenceThread.interrupt();
/*     */     }
/*     */ 
/*     */     
/* 138 */     discordPresence.Discord_Shutdown();
/* 139 */     discordPresence.Discord_ClearPresence();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getPresenceDetails() {
/* 147 */     return presenceDetails;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\PresenceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
