/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadManager
/*     */   extends Manager
/*     */ {
/*  18 */   private final ClientService clientService = new ClientService();
/*     */ 
/*     */   
/*  21 */   private static final Queue<Runnable> clientProcesses = new ArrayDeque<>();
/*     */   
/*     */   public ThreadManager() {
/*  24 */     super("ThreadManager", "Manages the main client service thread");
/*     */ 
/*     */     
/*  27 */     this.clientService.setName("cosmos-client-thread");
/*  28 */     this.clientService.setDaemon(true);
/*  29 */     this.clientService.start();
/*     */   }
/*     */   
/*     */   public static class ClientService
/*     */     extends Thread
/*     */     implements Wrapper {
/*     */     public void run() {
/*  36 */       while (!Thread.currentThread().isInterrupted()) {
/*     */         
/*     */         try {
/*  39 */           if (nullCheck()) {
/*     */ 
/*     */             
/*  42 */             if (!ThreadManager.clientProcesses.isEmpty()) {
/*  43 */               ((Runnable)ThreadManager.clientProcesses.poll()).run();
/*     */             }
/*     */             
/*  46 */             getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */                   try {
/*     */                     if (module.isEnabled()) {
/*     */                       module.onThread();
/*     */                     }
/*  51 */                   } catch (Exception exception) {
/*     */                     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                       exception.printStackTrace();
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */ 
/*     */ 
/*     */             
/*  60 */             getCosmos().getManagers().forEach(manager -> {
/*     */                   try {
/*     */                     manager.onThread();
/*  63 */                   } catch (Exception exception) {
/*     */                     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                       exception.printStackTrace();
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */ 
/*     */           
/*  75 */           Thread.yield();
/*     */         
/*     */         }
/*  78 */         catch (Exception exception) {
/*     */ 
/*     */           
/*  81 */           if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*  82 */             exception.printStackTrace();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void submit(Runnable in) {
/*  94 */     clientProcesses.add(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientService getService() {
/* 102 */     return this.clientService;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ThreadManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */