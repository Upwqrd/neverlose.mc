//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.client.ModuleToggleEvent;
/*     */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*     */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.combat.BurrowModule;
/*     */ import cope.cosmos.client.features.modules.movement.ElytraFlightModule;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatchManager
/*     */   extends Manager
/*     */   implements Wrapper
/*     */ {
/*  26 */   private final Map<Patch, PatchState> patchMap = new ConcurrentHashMap<>();
/*     */   
/*     */   public PatchManager() {
/*  29 */     super("PatchManager", "Makes sure certain features are toggled safely");
/*  30 */     Cosmos.EVENT_BUS.register(this);
/*     */ 
/*     */     
/*  33 */     updatePatches();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntitySpawn(EntityWorldEvent.EntitySpawnEvent event) {
/*  38 */     if (event.getEntity().equals(mc.player)) {
/*     */       
/*  40 */       this.patchMap.clear();
/*  41 */       updatePatches();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onModuleEnable(ModuleToggleEvent.ModuleEnableEvent event) {
/*  47 */     if (!mc.isIntegratedServerRunning() && mc.getCurrentServerData() != null && mc.player.ticksExisted >= 40) {
/*  48 */       this.patchMap.forEach((patch, patchState) -> {
/*     */             if (patch.getModule() != null && patch.getModule().equals(event.getModule()) && patch.getServers().contains((mc.getCurrentServerData()).serverIP.toLowerCase())) {
/*     */               switch (patchState) {
/*     */                 case PATCHED:
/*     */                   pushPatchSafety(patch.getModule().getName() + " is likely patched on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case UNPATCHED:
/*     */                   pushPatchSafety(patch.getModule().getName() + " is likely not patched on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case LIMITED:
/*     */                   pushPatchSafety(patch.getModule().getName() + " is likely limited on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case INCONSISTENT:
/*     */                   pushPatchSafety(patch.getModule().getName() + " is likely inconsistent on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */               } 
/*     */               this.patchMap.remove(patch);
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(SettingUpdateEvent event) {
/*  73 */     if (!mc.isIntegratedServerRunning() && mc.getCurrentServerData() != null && mc.player.ticksExisted >= 40) {
/*  74 */       this.patchMap.forEach((patch, patchState) -> {
/*     */             if (patch.getSetting() != null && patch.getSetting().equals(event.getSetting()) && patch.getState() && patch.getServers().contains((mc.getCurrentServerData()).serverIP.toLowerCase())) {
/*     */               switch (patchState) {
/*     */                 case PATCHED:
/*     */                   pushPatchSafety(event.getSetting().getName() + " is likely patched on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case UNPATCHED:
/*     */                   pushPatchSafety(event.getSetting().getName() + " is likely not patched on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case LIMITED:
/*     */                   pushPatchSafety(event.getSetting().getName() + " is likely limited on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */                 case INCONSISTENT:
/*     */                   pushPatchSafety(event.getSetting().getName() + " is likely inconsistent on " + (mc.getCurrentServerData()).serverIP.toLowerCase() + "!");
/*     */                   break;
/*     */               } 
/*     */               this.patchMap.remove(patch);
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePatches() {
/*  98 */     this.patchMap.put(new Patch((Module)BurrowModule.INSTANCE, new String[] { "crystalpvp.cc", "us.crystalpvp.cc", "constantiam.org", "2b2tpvp.net", "strict.2b2tpvp.net", "eliteanarchy.net" }), PatchState.PATCHED);
/*  99 */     this.patchMap.put(new Patch((Module)ElytraFlightModule.INSTANCE, new String[] { "2b2t.org", "constantiam.org" }), PatchState.PATCHED);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushPatchSafety(String message) {
/* 104 */     if (mc.currentScreen == null) {
/* 105 */       NotificationManager.Notification patchError = new NotificationManager.Notification(message, NotificationManager.Type.WARNING);
/* 106 */       Cosmos.INSTANCE.getNotificationManager().addNotification(patchError);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum PatchState
/*     */   {
/* 118 */     PATCHED, UNPATCHED, INCONSISTENT, LIMITED;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Patch
/*     */   {
/*     */     private Module module;
/*     */     
/*     */     private Setting<?> setting;
/*     */     private boolean state;
/* 128 */     private final List<String> patchedServers = new ArrayList<>();
/*     */     
/*     */     public Patch(Module module, String... servers) {
/* 131 */       this.module = module;
/* 132 */       this.patchedServers.addAll(Arrays.asList(servers));
/*     */     }
/*     */     
/*     */     public Patch(Setting<?> setting, boolean state, String... servers) {
/* 136 */       this.setting = setting;
/* 137 */       this.state = state;
/* 138 */       this.patchedServers.addAll(Arrays.asList(servers));
/*     */     }
/*     */     
/*     */     public Module getModule() {
/* 142 */       return this.module;
/*     */     }
/*     */     
/*     */     public Setting<?> getSetting() {
/* 146 */       return this.setting;
/*     */     }
/*     */     
/*     */     public boolean getState() {
/* 150 */       return this.state;
/*     */     }
/*     */     
/*     */     public List<String> getServers() {
/* 154 */       return this.patchedServers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\PatchManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
