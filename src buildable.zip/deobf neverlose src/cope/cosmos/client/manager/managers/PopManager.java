/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.combat.TotemPopEvent;
/*    */ import cope.cosmos.client.events.entity.EntityWorldEvent;
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.PlayerEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PopManager
/*    */   extends Manager
/*    */   implements Wrapper
/*    */ {
/* 24 */   private final Map<Entity, Integer> totemPops = new HashMap<>();
/*    */   
/*    */   public PopManager() {
/* 27 */     super("PopManager", "Keeps track of all the totem pops");
/* 28 */     Cosmos.EVENT_BUS.register(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTotemPop(TotemPopEvent event) {
/* 35 */     this.totemPops.put(event.getPopEntity(), Integer.valueOf(this.totemPops.containsKey(event.getPopEntity()) ? (((Integer)this.totemPops.get(event.getPopEntity())).intValue() + 1) : 1));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRemoveEntity(EntityWorldEvent.EntityRemoveEvent event) {
/* 42 */     this.totemPops.remove(event.getEntity());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
/* 49 */     this.totemPops.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getTotemPops(Entity entity) {
/* 58 */     return ((Integer)this.totemPops.getOrDefault(entity, Integer.valueOf(0))).intValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removePops(Entity entity) {
/* 66 */     this.totemPops.remove(entity);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\PopManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */