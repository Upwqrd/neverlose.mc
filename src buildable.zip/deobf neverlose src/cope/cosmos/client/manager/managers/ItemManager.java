//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.play.client.CPacketClickWindow;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemManager
/*     */   extends Manager
/*     */ {
/*  20 */   private int serverHeldItem = -1;
/*     */   
/*     */   Slot heldSlot;
/*     */   
/*     */   Slot swapSlot;
/*     */   
/*     */   ItemStack heldStack;
/*     */   
/*     */   ItemStack swapStack;
/*     */   
/*     */   public ItemManager() {
/*  31 */     super("ItemManager", "Manages serverside item syncing");
/*  32 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onTick() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  47 */     if (event.getPacket() instanceof CPacketHeldItemChange) {
/*     */ 
/*     */       
/*  50 */       this.serverHeldItem = ((CPacketHeldItemChange)event.getPacket()).getSlotId();
/*     */ 
/*     */       
/*  53 */       if (mc.player.inventory.currentItem != ((CPacketHeldItemChange)event.getPacket()).getSlotId())
/*     */       {
/*     */         
/*  56 */         mc.player.inventory.currentItem = ((CPacketHeldItemChange)event.getPacket()).getSlotId();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  61 */     if (event.getPacket() instanceof CPacketClickWindow)
/*     */     {
/*     */       
/*  64 */       if (((CPacketClickWindow)event.getPacket()).getClickType().equals(ClickType.SWAP))
/*     */       {
/*     */         
/*  67 */         if (((CPacketClickWindow)event.getPacket()).getWindowId() == 0)
/*     */         {
/*     */           
/*  70 */           if (((CPacketClickWindow)event.getPacket()).getUsedButton() >= 0 && ((CPacketClickWindow)event.getPacket()).getUsedButton() < 9) {
/*     */ 
/*     */             
/*  73 */             this.swapSlot = mc.player.inventoryContainer.getSlot(((CPacketClickWindow)event.getPacket()).getSlotId());
/*  74 */             this.heldSlot = mc.player.inventoryContainer.getSlot(((CPacketClickWindow)event.getPacket()).getUsedButton() + 36);
/*     */ 
/*     */             
/*  77 */             this.swapStack = this.swapSlot.getStack();
/*  78 */             this.heldStack = this.heldSlot.getStack();
/*     */ 
/*     */             
/*  81 */             if (this.swapSlot.getStack() != this.heldStack);
/*     */ 
/*     */ 
/*     */             
/*  85 */             if (this.heldSlot.getStack() != this.swapStack);
/*     */           } 
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncItem() {
/* 100 */     if (this.serverHeldItem != -1)
/*     */     {
/*     */       
/* 103 */       if (mc.player.inventory.currentItem != this.serverHeldItem)
/*     */       {
/*     */         
/* 106 */         mc.player.inventory.currentItem = this.serverHeldItem;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncSlots() {
/* 117 */     if (this.swapSlot.getStack() != this.heldStack) {
/* 118 */       this.swapSlot.putStack(this.heldStack);
/*     */     }
/*     */     
/* 121 */     if (this.heldSlot.getStack() != this.swapStack)
/* 122 */       this.heldSlot.putStack(this.swapStack); 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ItemManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
