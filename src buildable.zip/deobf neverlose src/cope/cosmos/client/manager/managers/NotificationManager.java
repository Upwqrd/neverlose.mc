/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.math.Timer;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationManager
/*     */   extends Manager
/*     */ {
/*  18 */   private final List<Notification> notifications = new CopyOnWriteArrayList<>();
/*     */   
/*     */   public NotificationManager() {
/*  21 */     super("NotificationManager", "Handles sending client notifications");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNotification(Notification notification) {
/*  29 */     if (!this.notifications.contains(notification)) {
/*  30 */       this.notifications.add(notification);
/*     */ 
/*     */       
/*  33 */       notification.getAnimation().setState(true);
/*  34 */       notification.getTimer().resetTime();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Notification> getNotifications() {
/*  44 */     return this.notifications;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/*  52 */     INFO((String)new ResourceLocation("cosmos", "textures/icons/info.png")),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     SAFETY((String)new ResourceLocation("cosmos", "textures/icons/warning.png")),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     WARNING((String)new ResourceLocation("cosmos", "textures/icons/warning.png"));
/*     */     
/*     */     private final ResourceLocation resourceLocation;
/*     */ 
/*     */     
/*     */     Type(ResourceLocation resourceLocation) {
/*  68 */       this.resourceLocation = resourceLocation;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ResourceLocation getResourceLocation() {
/*  76 */       return this.resourceLocation;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Notification
/*     */   {
/*     */     private final String message;
/*     */     
/*     */     private final NotificationManager.Type type;
/*     */     
/*  87 */     private final Animation animation = new Animation(300, false);
/*  88 */     private final Timer timer = new Timer();
/*     */     
/*     */     public Notification(String message, NotificationManager.Type type) {
/*  91 */       this.message = message;
/*  92 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 100 */       return this.message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NotificationManager.Type getType() {
/* 108 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Animation getAnimation() {
/* 116 */       return this.animation;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Timer getTimer() {
/* 124 */       return this.timer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\NotificationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */