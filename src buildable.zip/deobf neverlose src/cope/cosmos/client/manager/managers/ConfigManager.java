//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import com.moandjiezana.toml.Toml;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.modules.visual.WallhackModule;
/*     */ import cope.cosmos.client.features.setting.Bind;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.client.ui.altgui.Alt;
/*     */ import cope.cosmos.client.ui.altgui.AltEntry;
/*     */ import cope.cosmos.client.ui.altgui.AltManagerGUI;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category.CategoryFrameComponent;
/*     */ import cope.cosmos.util.file.FileSystemUtil;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigManager
/*     */   extends Manager
/*     */ {
/*  35 */   private final List<String> presets = new CopyOnWriteArrayList<>();
/*     */ 
/*     */   
/*  38 */   private String preset = "default";
/*     */   private Path presetPath;
/*     */   
/*     */   public ConfigManager() {
/*  42 */     super("ConfigManager", "Handles the client's configurations (presets)");
/*     */ 
/*     */     
/*  45 */     loadInfo();
/*     */ 
/*     */     
/*  48 */     loadPreset(this.preset);
/*     */     
/*  50 */     loadSocial();
/*  51 */     loadAlts();
/*  52 */     loadWallhack();
/*     */ 
/*     */     
/*  55 */     Runtime.getRuntime().addShutdownHook(new Thread(() -> { System.out.println("[Cosmos] Saving presets..."); saveInfo(); saveModules(); saveSocial(); saveAlts(); saveWallhack(); saveGUI(); System.out.println("[Cosmos] Saved presets successfully! See you next time :)"); }"PresetManager-Shutdown-Save-Thread"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadPreset(String name) {
/*  76 */     this.preset = name;
/*  77 */     this.presetPath = FileSystemUtil.PRESETS.resolve(name + ".toml");
/*     */     
/*  79 */     if (!this.presets.contains(name)) {
/*  80 */       this.presets.add(name);
/*     */     }
/*     */     
/*  83 */     if (Files.exists(this.presetPath, new java.nio.file.LinkOption[0])) {
/*  84 */       long time = System.currentTimeMillis();
/*     */       
/*  86 */       loadModules();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       System.out.println("[Cosmos] Loaded preset " + name + " in " + (System.currentTimeMillis() - time) + "ms");
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  97 */       createPreset(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createPreset(String name) {
/* 104 */     this.presetPath = FileSystemUtil.PRESETS.resolve(name + ".toml");
/*     */ 
/*     */     
/* 107 */     if (!Files.exists(this.presetPath, new java.nio.file.LinkOption[0])) {
/* 108 */       FileSystemUtil.create(this.presetPath);
/*     */     }
/*     */     
/* 111 */     this.preset = name;
/*     */ 
/*     */ 
/*     */     
/* 115 */     long time = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     saveModules();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     System.out.println("[Cosmos] Saved preset " + name + " in " + (System.currentTimeMillis() - time) + "ms");
/*     */   }
/*     */ 
/*     */   
/*     */   public void deletePreset(String name) {
/* 131 */     Path path = FileSystemUtil.PRESETS.resolve(name + ".toml");
/* 132 */     if (Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       try {
/* 134 */         this.presets.remove(name);
/* 135 */         Files.deleteIfExists(path);
/* 136 */         System.out.println("[Cosmos] Deleted preset successfully");
/* 137 */       } catch (IOException e) {
/* 138 */         e.printStackTrace();
/*     */       } 
/*     */ 
/*     */       
/* 142 */       if (this.preset.equals(name)) {
/* 143 */         loadPreset(this.preset = "default");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadInfo() {
/* 149 */     String content = FileSystemUtil.read(FileSystemUtil.INFO, true);
/* 150 */     if (content == null || content.isEmpty()) {
/* 151 */       saveInfo();
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 158 */         Toml toml = (new Toml()).read(content);
/*     */ 
/*     */         
/* 161 */         if (toml.contains("Info")) {
/*     */ 
/*     */ 
/*     */           
/* 165 */           if (toml.contains("Info.Setup")) {
/* 166 */             Cosmos.SETUP = toml.getBoolean("Info.Setup").booleanValue();
/*     */           }
/*     */           
/* 169 */           if (toml.contains("Info.Prefix")) {
/* 170 */             Cosmos.PREFIX = toml.getString("Info.Prefix");
/*     */           }
/*     */           
/* 173 */           if (toml.contains("Info.Preset")) {
/* 174 */             this.preset = toml.getString("Info.Preset");
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 179 */         System.out.println("[Cosmos] Read info.toml successfully!");
/* 180 */       } catch (IllegalStateException e) {
/*     */ 
/*     */         
/* 183 */         e.printStackTrace();
/* 184 */         System.out.println("[Cosmos] Could not load info file. Will revert to default configuration.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     File[] files = FileSystemUtil.PRESETS.toFile().listFiles();
/* 191 */     if (files != null && files.length > 0) {
/* 192 */       for (File file : files) {
/* 193 */         String[] path = file.getName().split("\\.");
/* 194 */         if (path.length > 0) {
/* 195 */           this.presets.add(path[0]);
/*     */         }
/*     */       } 
/*     */       
/* 199 */       System.out.println("[Cosmos] " + this.presets.size() + " presets were found in the presets directory");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadModules() {
/* 208 */     String content = FileSystemUtil.read(this.presetPath, true);
/* 209 */     if (content == null || content.isEmpty()) {
/* 210 */       saveModules();
/*     */     }
/*     */ 
/*     */     
/* 214 */     Toml inputTOML = (new Toml()).read(content);
/*     */     
/* 216 */     if (inputTOML != null) {
/* 217 */       getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */             if (module != null) {
/*     */               try {
/*     */                 if (inputTOML.getBoolean(module.getName() + ".Enabled") != null) {
/*     */                   boolean state = inputTOML.getBoolean(module.getName() + ".Enabled", Boolean.valueOf(false)).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   if (state) {
/*     */                     module.enable(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/*     */                     module.getAnimation().setState(true);
/*     */                   } else {
/*     */                     module.disable(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/*     */                     module.getAnimation().setState(false);
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 if (inputTOML.getBoolean(module.getName() + ".Drawn") != null) {
/*     */                   boolean drawn = inputTOML.getBoolean(module.getName() + ".Drawn", Boolean.valueOf(true)).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   module.setDrawn(drawn);
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 module.getSettings().forEach(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   System.out.println("[Cosmos] " + module.getName() + " was loaded successfully!");
/*     */                 }
/* 314 */               } catch (Exception exception) {
/*     */                 if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                   exception.printStackTrace();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadSocial() {
/* 330 */     String content = FileSystemUtil.read(FileSystemUtil.SOCIAL, true);
/* 331 */     if (content == null || content.isEmpty()) {
/* 332 */       saveModules();
/*     */     }
/*     */ 
/*     */     
/* 336 */     getCosmos().getSocialManager().getSocials().clear();
/*     */ 
/*     */     
/* 339 */     Toml inputTOML = (new Toml()).read(content);
/*     */ 
/*     */     
/* 342 */     if (inputTOML != null) {
/*     */       try {
/* 344 */         if (inputTOML.getList("Social.Friends") != null)
/*     */         {
/* 346 */           for (Object o : inputTOML.getList("Social.Friends", new CopyOnWriteArrayList())) {
/* 347 */             String friend = (String)o;
/* 348 */             getCosmos().getSocialManager().addSocial(friend, SocialManager.Relationship.FRIEND);
/*     */           } 
/*     */         }
/* 351 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 354 */         if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 355 */           exception.printStackTrace();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 361 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 362 */       System.out.println("[Cosmos] Socials were loaded successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadAlts() {
/* 371 */     String content = FileSystemUtil.read(FileSystemUtil.ALTS, true);
/* 372 */     if (content == null || content.isEmpty()) {
/* 373 */       saveModules();
/*     */     }
/*     */ 
/*     */     
/* 377 */     getCosmos().getAltManager().getAltEntries().clear();
/*     */ 
/*     */     
/* 380 */     Toml input = (new Toml()).read(content);
/*     */     
/* 382 */     if (input != null) {
/*     */       try {
/* 384 */         if (input.getList("Alts.Alts") != null) {
/* 385 */           input.getList("Alts.Alts").forEach(object -> {
/*     */                 String[] altInfo = ((String)object).split(":");
/*     */ 
/*     */ 
/*     */                 
/*     */                 Alt.AltType type = Alt.AltType.valueOf(altInfo[2]);
/*     */ 
/*     */ 
/*     */                 
/*     */                 Alt alt = new Alt(altInfo[0], altInfo[1], type);
/*     */ 
/*     */                 
/*     */                 getCosmos().getAltManager().getAltEntries().add(new AltEntry(alt, AltManagerGUI.altEntryOffset));
/*     */ 
/*     */                 
/*     */                 AltManagerGUI.altEntryOffset += 32.0F;
/*     */               });
/*     */         }
/* 403 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 406 */         if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 407 */           exception.printStackTrace();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 413 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 414 */       System.out.println("[Cosmos] Alts were loaded successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadWallhack() {
/* 420 */     String content = FileSystemUtil.read(FileSystemUtil.WALLHACK, true);
/* 421 */     if (content == null || content.isEmpty()) {
/* 422 */       saveModules();
/*     */     }
/*     */ 
/*     */     
/* 426 */     WallhackModule.WHITELIST.clear();
/*     */ 
/*     */     
/* 429 */     Toml toml = (new Toml()).read(content);
/*     */     
/* 431 */     if (toml != null && 
/* 432 */       toml.getList("blocks") != null) {
/* 433 */       toml.getList("blocks").forEach(blockId -> {
/*     */             Block block = Block.getBlockFromName(blockId);
/*     */ 
/*     */             
/*     */             if (block != null) {
/*     */               WallhackModule.WHITELIST.add(block);
/*     */             }
/*     */           });
/*     */     }
/*     */     
/* 443 */     if (WallhackModule.WHITELIST.isEmpty()) {
/* 444 */       WallhackModule.WHITELIST.addAll(WallhackModule.DEFAULT_BLOCKS);
/*     */     }
/*     */ 
/*     */     
/* 448 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 449 */       System.out.println("[Cosmos] Wallhack blocks were loaded successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadGUI() {
/* 458 */     String content = FileSystemUtil.read(FileSystemUtil.GUI, true);
/* 459 */     if (content == null || content.isEmpty()) {
/* 460 */       saveModules();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 466 */       Toml toml = (new Toml()).read(content);
/*     */       
/* 468 */       if (toml != null)
/*     */       {
/* 470 */         getCosmos().getClickGUI().getCategoryFrameComponents().forEach(component -> {
/*     */               if (toml.getDouble(((Category)component.getValue()).name() + ".X") != null && toml.getDouble(((Category)component.getValue()).name() + ".Y") != null) {
/*     */                 component.setPosition(new Vec2f(toml.getDouble(((Category)component.getValue()).name() + ".X").floatValue(), toml.getDouble(((Category)component.getValue()).name() + ".Y").floatValue()));
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               if (toml.getDouble(((Category)component.getValue()).name() + ".Height") != null) {
/*     */                 component.setHeight(toml.getDouble(((Category)component.getValue()).name() + ".Height").floatValue());
/*     */               }
/*     */             });
/*     */       }
/*     */ 
/*     */       
/* 484 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 485 */         System.out.println("[Cosmos] GUI was loaded successfully!");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void saveInfo() {
/* 491 */     if (!Files.exists(FileSystemUtil.INFO, new java.nio.file.LinkOption[0])) {
/* 492 */       FileSystemUtil.create(FileSystemUtil.INFO);
/*     */     }
/*     */     
/* 495 */     String builder = "[Info]\nSetup = false\nPrefix = \"" + Cosmos.PREFIX + "\"\nPreset = \"" + this.preset + "\"";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 518 */     FileSystemUtil.write(FileSystemUtil.INFO, builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveModules() {
/* 527 */     StringBuilder outputTOML = new StringBuilder();
/*     */     
/* 529 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */           if (module != null) {
/*     */             try {
/*     */               outputTOML.append("[").append(module.getName()).append("]").append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               outputTOML.append("Enabled = ").append(module.isEnabled()).append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               outputTOML.append("Drawn = ").append(module.isDrawn()).append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               module.getSettings().forEach(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               outputTOML.append("\r\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                 System.out.println("[Cosmos] " + module.getName() + " was saved successfully!");
/*     */               }
/* 583 */             } catch (Exception exception) {
/*     */               if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/*     */                 exception.printStackTrace();
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 593 */     FileSystemUtil.write(this.presetPath, outputTOML.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveSocial() {
/* 603 */     StringBuilder outputTOML = new StringBuilder();
/*     */     
/*     */     try {
/* 606 */       outputTOML.append("[Social]").append("\r\n");
/*     */ 
/*     */       
/* 609 */       outputTOML.append("Friends").append(" = ").append("[");
/* 610 */       for (Map.Entry<String, SocialManager.Relationship> social : getCosmos().getSocialManager().getSocials().entrySet()) {
/* 611 */         outputTOML.append('"').append(social.getKey()).append('"').append(", ");
/*     */       }
/*     */       
/* 614 */       outputTOML.append("]").append("\r\n");
/* 615 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 618 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 619 */         exception.printStackTrace();
/*     */       }
/*     */     } 
/*     */     
/* 623 */     FileSystemUtil.write(FileSystemUtil.SOCIAL, outputTOML.toString());
/*     */ 
/*     */     
/* 626 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 627 */       System.out.println("[Cosmos] Socials were saved successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveAlts() {
/* 635 */     StringBuilder output = new StringBuilder();
/*     */     
/*     */     try {
/* 638 */       output.append("[Alts]").append("\r\n");
/*     */       
/* 640 */       output.append("Alts").append(" = ").append("[");
/*     */ 
/*     */       
/* 643 */       for (AltEntry altEntry : getCosmos().getAltManager().getAltEntries()) {
/* 644 */         output.append('"').append(altEntry.getAlt().getLogin()).append(":").append(altEntry.getAlt().getPassword()).append(":").append(altEntry.getAlt().getAltType().name()).append('"').append(",");
/*     */       }
/*     */       
/* 647 */       output.append("]").append("\r\n");
/*     */     }
/* 649 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 652 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 653 */         exception.printStackTrace();
/*     */       }
/*     */     } 
/*     */     
/* 657 */     FileSystemUtil.write(FileSystemUtil.ALTS, output.toString());
/*     */ 
/*     */     
/* 660 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 661 */       System.out.println("[Cosmos] Alts were saved successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveWallhack() {
/* 669 */     StringBuilder output = new StringBuilder("blocks = [");
/*     */ 
/*     */     
/* 672 */     List<Block> blocksToSave = WallhackModule.WHITELIST;
/*     */ 
/*     */     
/* 675 */     if (blocksToSave.isEmpty()) {
/* 676 */       blocksToSave = WallhackModule.DEFAULT_BLOCKS;
/* 677 */       WallhackModule.WHITELIST.addAll(WallhackModule.DEFAULT_BLOCKS);
/*     */     } 
/*     */ 
/*     */     
/* 681 */     blocksToSave.forEach(block -> output.append("\"").append(block.getRegistryName()).append("\"").append(","));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 687 */     output.append("]");
/*     */     
/* 689 */     FileSystemUtil.write(FileSystemUtil.WALLHACK, output.toString());
/*     */ 
/*     */     
/* 692 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 693 */       System.out.println("[Cosmos] Wallhack blocks were saved successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveGUI() {
/* 704 */     StringBuilder output = new StringBuilder();
/*     */ 
/*     */     
/*     */     try {
/* 708 */       getCosmos().getClickGUI().getCategoryFrameComponents().forEach(component -> {
/*     */             output.append("[").append(((Category)component.getValue()).name()).append("]").append("\r\n");
/*     */             output.append("X = ").append((component.getPosition()).x).append("\r\n");
/*     */             output.append("Y = ").append((component.getPosition()).y).append("\r\n");
/*     */             output.append("Height = ").append(component.getHeight()).append("\r\n");
/*     */             output.append("\r\n");
/*     */           });
/* 715 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 718 */       if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 719 */         exception.printStackTrace();
/*     */       }
/*     */     } 
/*     */     
/* 723 */     FileSystemUtil.write(FileSystemUtil.GUI, output.toString());
/*     */ 
/*     */     
/* 726 */     if (Cosmos.CLIENT_TYPE.equals(Cosmos.ClientType.DEVELOPMENT)) {
/* 727 */       System.out.println("[Cosmos] GUI was saved successfully!");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPreset() {
/* 733 */     return this.preset;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ConfigManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
