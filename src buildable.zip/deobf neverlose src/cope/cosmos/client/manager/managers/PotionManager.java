//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.asm.mixins.accessor.IEntityLivingBase;
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.events.entity.potion.PotionEffectEvent;
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.client.ui.util.animation.Animation;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PotionManager
/*    */   extends Manager
/*    */ {
/* 21 */   private final Map<PotionEffect, Animation> activePotions = new ConcurrentHashMap<>();
/*    */   
/*    */   public PotionManager() {
/* 24 */     super("PotionManager", "Manages player's potion effects");
/*    */ 
/*    */     
/* 27 */     Cosmos.EVENT_BUS.register(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 34 */     this.activePotions.forEach((potionEffect, animation) -> {
/*    */           if (animation.getAnimationFactor() <= 0.05D) {
/*    */             this.activePotions.remove(potionEffect);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPotionAdd(PotionEffectEvent.PotionAdd event) {
/* 45 */     event.setCanceled(true);
/*    */ 
/*    */     
/* 48 */     PotionEffect potioneffect = (PotionEffect)((IEntityLivingBase)mc.player).getActivePotionMap().get(event.getPotionEffect().getPotion());
/*    */ 
/*    */     
/* 51 */     if (potioneffect == null) {
/* 52 */       ((IEntityLivingBase)mc.player).getActivePotionMap().put(event.getPotionEffect().getPotion(), event.getPotionEffect());
/*    */ 
/*    */       
/* 55 */       this.activePotions.put(event.getPotionEffect(), new Animation(300, false));
/* 56 */       ((Animation)this.activePotions.get(event.getPotionEffect())).setState(true);
/*    */ 
/*    */       
/* 59 */       ((IEntityLivingBase)mc.player).hookOnNewPotionEffect(event.getPotionEffect());
/*    */ 
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */       
/* 66 */       potioneffect.combine(event.getPotionEffect());
/* 67 */       ((IEntityLivingBase)mc.player).hookOnChangedPotionEffect(potioneffect, true);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPotionRemove(PotionEffectEvent.PotionRemove event) {
/* 75 */     this.activePotions.forEach((potionEffect, animation) -> {
/*    */           if (event.getPotionEffect().getEffectName().equals(potionEffect.getEffectName())) {
/*    */             animation.setState(false);
/*    */           }
/*    */         });
/*    */ 
/*    */     
/* 82 */     event.setCanceled(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<PotionEffect, Animation> getActivePotions() {
/* 90 */     return this.activePotions;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\PotionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
