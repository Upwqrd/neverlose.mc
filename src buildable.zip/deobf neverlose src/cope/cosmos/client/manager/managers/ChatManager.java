//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.util.chat.ChatBuilder;
/*    */ import cope.cosmos.util.chat.ChatUtil;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ThreadLocalRandom;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketChatMessage;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.Style;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.event.HoverEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChatManager
/*    */   extends Manager
/*    */ {
/* 26 */   private final Map<Module, Integer> messageMap = new HashMap<>();
/*    */   
/*    */   public ChatManager() {
/* 29 */     super("ChatManager", "Manages client chat messages");
/*    */ 
/*    */     
/* 32 */     getCosmos().getModuleManager().getAllModules().forEach(mod -> (Integer)this.messageMap.put(mod, Integer.valueOf(ThreadLocalRandom.current().nextInt(32767))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendMessage(String in) {
/* 40 */     mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)new TextComponentString(in), ThreadLocalRandom.current().nextInt(32767));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendChatMessage(String in) {
/* 48 */     mc.player.connection.sendPacket((Packet)new CPacketChatMessage(in));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendClientMessage(String in, int identifier) {
/* 56 */     mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)new TextComponentString(ChatUtil.getPrefix() + in), identifier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendClientMessage(Number in, int identifier) {
/* 64 */     mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)new TextComponentString(ChatUtil.getPrefix() + in), identifier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendClientMessage(String in) {
/* 72 */     sendClientMessage(in, ThreadLocalRandom.current().nextInt(32767));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendClientMessage(Number in) {
/* 80 */     sendClientMessage(in, ThreadLocalRandom.current().nextInt(32767));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendClientMessage(Module in) {
/* 88 */     mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)new TextComponentString(ChatUtil.getPrefix() + in.getName() + (in.isEnabled() ? (ChatFormatting.GREEN + " enabled!") : (ChatFormatting.RED + " disabled!"))), ((Integer)this.messageMap.get(in)).intValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendHoverableMessage(String in, String hoverable) {
/* 97 */     (new ChatBuilder()).append(ChatUtil.getPrefix() + in, (new Style()).setColor(TextFormatting.DARK_PURPLE).setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (new ChatBuilder()).append("neverlose.mc", (new Style()).setColor(TextFormatting.DARK_PURPLE)).append("\n" + hoverable, (new Style()).setColor(TextFormatting.BLUE)).component()))).append(" ", (new Style()).setColor(TextFormatting.DARK_PURPLE)).push();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ChatManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
