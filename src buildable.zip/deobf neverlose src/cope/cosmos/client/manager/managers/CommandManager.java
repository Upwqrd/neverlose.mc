/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.features.command.Command;
/*    */ import cope.cosmos.client.features.command.commands.BindCommand;
/*    */ import cope.cosmos.client.features.command.commands.ConfigCommand;
/*    */ import cope.cosmos.client.features.command.commands.DrawnCommand;
/*    */ import cope.cosmos.client.features.command.commands.FakePlayerCommand;
/*    */ import cope.cosmos.client.features.command.commands.FriendCommand;
/*    */ import cope.cosmos.client.features.command.commands.HelpCommand;
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ public class CommandManager
/*    */   extends Manager
/*    */ {
/*    */   private final List<Command> commands;
/*    */   
/*    */   public CommandManager() {
/* 23 */     super("CommandManager", "Manages client commands");
/*    */ 
/*    */     
/* 26 */     this.commands = Arrays.asList(new Command[] { (Command)new FriendCommand(), (Command)new ConfigCommand(), (Command)new HelpCommand(), (Command)new DrawnCommand(), (Command)new BindCommand(), (Command)new FakePlayerCommand() });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     getAllCommands().forEach(command -> {
/*    */           Cosmos.INSTANCE.getCommandDispatcher().register(command.getCommand());
/*    */           Cosmos.INSTANCE.getCommandDispatcher().register(Command.redirectBuilder(command.getName(), command.getCommand().build()));
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Command> getAllCommands() {
/* 47 */     return this.commands;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Command> getCommands(Predicate<? super Command> predicate) {
/* 56 */     return (List<Command>)this.commands.stream()
/* 57 */       .filter(predicate)
/* 58 */       .collect(Collectors.toList());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Command getCommand(Predicate<? super Command> predicate) {
/* 67 */     return this.commands.stream()
/* 68 */       .filter(predicate)
/* 69 */       .findFirst()
/* 70 */       .orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */