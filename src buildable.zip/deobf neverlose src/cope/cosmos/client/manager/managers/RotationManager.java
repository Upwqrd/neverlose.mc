//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.manager.managers;
/*     */ 
/*     */ import cope.cosmos.asm.mixins.accessor.ICPacketPlayer;
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.motion.movement.MotionUpdateEvent;
/*     */ import cope.cosmos.client.events.network.PacketEvent;
/*     */ import cope.cosmos.client.events.render.entity.RenderRotationsEvent;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.holder.Rotation;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RotationManager
/*     */   extends Manager
/*     */   implements Wrapper
/*     */ {
/*  24 */   private final Rotation serverRotation = new Rotation(Float.NaN, Float.NaN);
/*     */ 
/*     */   
/*  27 */   private Rotation rotation = new Rotation(Float.NaN, Float.NaN);
/*  28 */   private long stay = 0L;
/*     */   
/*     */   public RotationManager() {
/*  31 */     super("RotationManager", "Keeps track of server rotations");
/*  32 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  37 */     if (System.currentTimeMillis() - this.stay >= 250L && this.rotation.isValid()) {
/*  38 */       this.rotation = new Rotation(Float.NaN, Float.NaN);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onPacketSend(PacketEvent.PacketSendEvent event) {
/*  46 */     if (event.getPacket() instanceof CPacketPlayer) {
/*     */ 
/*     */       
/*  49 */       CPacketPlayer packet = (CPacketPlayer)event.getPacket();
/*     */ 
/*     */       
/*  52 */       if (((ICPacketPlayer)packet).isRotating()) {
/*     */ 
/*     */         
/*  55 */         this.serverRotation.setYaw(packet.getYaw(0.0F));
/*  56 */         this.serverRotation.setPitch(packet.getPitch(0.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMotionUpdate(MotionUpdateEvent event) {
/*  63 */     if (this.rotation.isValid()) {
/*     */ 
/*     */       
/*  66 */       event.setCanceled(true);
/*     */ 
/*     */       
/*  69 */       event.setOnGround(mc.player.onGround);
/*  70 */       event.setX(mc.player.posX);
/*  71 */       event.setY((mc.player.getEntityBoundingBox()).minY);
/*  72 */       event.setZ(mc.player.posZ);
/*     */ 
/*     */       
/*  75 */       event.setYaw(this.rotation.getYaw());
/*  76 */       event.setPitch(this.rotation.getPitch());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderRotations(RenderRotationsEvent event) {
/*  84 */     if (this.rotation.isValid()) {
/*     */ 
/*     */       
/*  87 */       event.setCanceled(true);
/*     */ 
/*     */ 
/*     */       
/*  91 */       event.setYaw(this.serverRotation.getYaw());
/*  92 */       event.setPitch(this.serverRotation.getPitch());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotation(Rotation in) {
/* 101 */     this.rotation = in;
/* 102 */     this.stay = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation getRotation() {
/* 110 */     return this.rotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rotation getServerRotation() {
/* 118 */     return this.serverRotation;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\RotationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
