//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class ProgressManager extends Manager implements Wrapper {
/*    */   private static ResourceLocation splash;
/*    */   
/*    */   public ProgressManager() {
/* 16 */     super("ProgressManager", "Renders the client custom splash screen");
/*    */   }
/*    */ 
/*    */   
/*    */   private static TextureManager textureManager;
/*    */   
/*    */   public static void update() {
/* 23 */     if (mc == null || mc.getLanguageManager() == null) {
/*    */       return;
/*    */     }
/* 26 */     drawSplash(mc.getTextureManager());
/*    */   }
/*    */   
/*    */   public static void setProgress() {
/* 30 */     update();
/*    */   }
/*    */   
/*    */   public static void drawSplash(TextureManager mcTextureManager) {
/* 34 */     if (textureManager == null) {
/* 35 */       textureManager = mcTextureManager;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 41 */       ScaledResolution scaledresolution = new ScaledResolution(mc);
/* 42 */       int scaleFactor = scaledresolution.getScaleFactor();
/*    */       
/* 44 */       Framebuffer framebuffer = new Framebuffer(scaledresolution.getScaledWidth() * scaleFactor, scaledresolution.getScaledHeight() * scaleFactor, true);
/* 45 */       framebuffer.bindFramebuffer(false);
/*    */       
/* 47 */       GlStateManager.matrixMode(5889);
/* 48 */       GlStateManager.loadIdentity();
/* 49 */       GlStateManager.ortho(0.0D, scaledresolution.getScaledWidth(), scaledresolution.getScaledHeight(), 0.0D, 1000.0D, 3000.0D);
/* 50 */       GlStateManager.matrixMode(5888);
/* 51 */       GlStateManager.loadIdentity();
/* 52 */       GlStateManager.translate(0.0F, 0.0F, -2000.0F);
/* 53 */       GlStateManager.disableLighting();
/* 54 */       GlStateManager.disableFog();
/* 55 */       GlStateManager.disableDepth();
/* 56 */       GlStateManager.enableTexture2D();
/*    */       
/* 58 */       if (splash == null) {
/* 59 */         splash = new ResourceLocation("cosmos", "textures/imgs/splash.jpg");
/*    */       }
/* 61 */       mcTextureManager.bindTexture(splash);
/*    */       
/* 63 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 64 */       Gui.drawScaledCustomSizeModalRect(0, 0, 0.0F, 0.0F, 1920, 1080, scaledresolution.getScaledWidth(), scaledresolution.getScaledHeight(), 1920.0F, 1080.0F);
/*    */       
/* 66 */       framebuffer.unbindFramebuffer();
/* 67 */       framebuffer.framebufferRender(scaledresolution.getScaledWidth() * scaleFactor, scaledresolution.getScaledHeight() * scaleFactor);
/*    */       
/* 69 */       GlStateManager.enableAlpha();
/* 70 */       GlStateManager.alphaFunc(516, 0.1F);
/*    */       
/* 72 */       mc.updateDisplay();
/* 73 */     } catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ProgressManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
