/*    */ package cope.cosmos.client.manager.managers;
/*    */ 
/*    */ import cope.cosmos.client.manager.Manager;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collector;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangelogManager
/*    */   extends Manager
/*    */ {
/* 19 */   private final List<String> changelog = new ArrayList<>();
/*    */   
/*    */   public ChangelogManager() {
/* 22 */     super("ChangelogManager", "Manages the client changelog");
/*    */ 
/*    */     
/*    */     try {
/* 26 */       URL url = new URL("https://raw.githubusercontent.com/momentumdevelopment/cosmos/main/resources/changelog.json");
/* 27 */       BufferedReader inputStream = new BufferedReader(new InputStreamReader(url.openStream()));
/*    */ 
/*    */       
/* 30 */       this.changelog.addAll(inputStream.lines().collect((Collector)Collectors.toList()));
/*    */     }
/* 32 */     catch (Exception exception) {
/* 33 */       exception.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getChangelog() {
/* 42 */     return this.changelog;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\managers\ChangelogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */