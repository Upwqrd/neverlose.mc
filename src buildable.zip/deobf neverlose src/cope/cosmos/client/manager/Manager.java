/*    */ package cope.cosmos.client.manager;
/*    */ 
/*    */ import cope.cosmos.client.features.Feature;
/*    */ import cope.cosmos.util.Wrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Manager
/*    */   extends Feature
/*    */   implements Wrapper
/*    */ {
/*    */   public Manager(String name, String description) {
/* 13 */     super(name, description);
/*    */   }
/*    */   
/*    */   public void onUpdate() {}
/*    */   
/*    */   public void onTick() {}
/*    */   
/*    */   public void onThread() {}
/*    */   
/*    */   public void onRender2D() {}
/*    */   
/*    */   public void onRender3D() {}
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\manager\Manager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */