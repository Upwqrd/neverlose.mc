/*     */ package cope.cosmos.client;
/*     */ 
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import cope.cosmos.client.features.Feature;
/*     */ import cope.cosmos.client.features.modules.client.ColorsModule;
/*     */ import cope.cosmos.client.features.modules.client.DiscordPresenceModule;
/*     */ import cope.cosmos.client.features.modules.client.FontModule;
/*     */ import cope.cosmos.client.features.modules.client.SocialModule;
/*     */ import cope.cosmos.client.manager.Manager;
/*     */ import cope.cosmos.client.manager.managers.AltManager;
/*     */ import cope.cosmos.client.manager.managers.ChangelogManager;
/*     */ import cope.cosmos.client.manager.managers.ChatManager;
/*     */ import cope.cosmos.client.manager.managers.CommandManager;
/*     */ import cope.cosmos.client.manager.managers.ConfigManager;
/*     */ import cope.cosmos.client.manager.managers.EventManager;
/*     */ import cope.cosmos.client.manager.managers.HoleManager;
/*     */ import cope.cosmos.client.manager.managers.InteractionManager;
/*     */ import cope.cosmos.client.manager.managers.InventoryManager;
/*     */ import cope.cosmos.client.manager.managers.ItemManager;
/*     */ import cope.cosmos.client.manager.managers.ModuleManager;
/*     */ import cope.cosmos.client.manager.managers.NotificationManager;
/*     */ import cope.cosmos.client.manager.managers.PatchManager;
/*     */ import cope.cosmos.client.manager.managers.PopManager;
/*     */ import cope.cosmos.client.manager.managers.PotionManager;
/*     */ import cope.cosmos.client.manager.managers.PresenceManager;
/*     */ import cope.cosmos.client.manager.managers.ReloadManager;
/*     */ import cope.cosmos.client.manager.managers.RotationManager;
/*     */ import cope.cosmos.client.manager.managers.SocialManager;
/*     */ import cope.cosmos.client.manager.managers.SoundManager;
/*     */ import cope.cosmos.client.manager.managers.ThreadManager;
/*     */ import cope.cosmos.client.manager.managers.TickManager;
/*     */ import cope.cosmos.client.ui.clickgui.ClickGUIScreen;
/*     */ import cope.cosmos.client.ui.tabgui.TabGUI;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.Mod.Instance;
/*     */ import net.minecraftforge.fml.common.ProgressManager;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventBus;
/*     */ import org.lwjgl.opengl.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mod(modid = "neverlose", name = "neverlose.mc", version = "1.0b", acceptedMinecraftVersions = "[1.12.2]")
/*     */ public class Cosmos
/*     */ {
/*  65 */   private final List<Manager> managers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVersion() {
/*  90 */     return "1.0b";
/*     */   }
/*     */   
/*     */   public Cosmos() {
/*  94 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event) {
/*  99 */     this.startupTime = System.currentTimeMillis();
/* 100 */     FontUtil.load();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/* 105 */     ProgressManager.ProgressBar progressManager = ProgressManager.push("neverlose.mc", 22);
/* 106 */     this.moduleManager = new ModuleManager();
/* 107 */     this.managers.add(this.moduleManager);
/* 108 */     progressManager.step("[neverlose.mc] Loading Modules");
/* 109 */     this.eventManager = new EventManager();
/* 110 */     this.managers.add(this.eventManager);
/* 111 */     progressManager.step("[neverlose.mc] Registering Events");
/* 112 */     this.commandDispatcher = new CommandDispatcher();
/* 113 */     this.commandManager = new CommandManager();
/* 114 */     this.managers.add(this.commandManager);
/* 115 */     progressManager.step("[neverlose.mc] Loading Commands");
/* 116 */     this.tickManager = new TickManager();
/* 117 */     this.managers.add(this.tickManager);
/* 118 */     progressManager.step("[neverlose.mc] Setting up Tick Manager");
/* 119 */     this.rotationManager = new RotationManager();
/* 120 */     this.managers.add(this.rotationManager);
/* 121 */     progressManager.step("[neverlose.mc] Setting up Rotation Manager");
/* 122 */     this.socialManager = new SocialManager();
/* 123 */     this.managers.add(this.socialManager);
/* 124 */     progressManager.step("[neverlose.mc] Setting up Social Manager");
/* 125 */     this.altManager = new AltManager();
/* 126 */     this.managers.add(this.altManager);
/* 127 */     progressManager.step("[neverlose.mc] Setting up Alt Manager");
/* 128 */     this.configManager = new ConfigManager();
/* 129 */     this.managers.add(this.configManager);
/* 130 */     progressManager.step("[neverlose.mc] Setting up Config Manager");
/* 131 */     this.clickGUI = new ClickGUIScreen();
/* 132 */     this.tabGUI = new TabGUI();
/* 133 */     progressManager.step("[neverlose.mc] Setting up GUI's");
/* 134 */     this.configManager.loadGUI();
/* 135 */     this.reloadManager = new ReloadManager();
/* 136 */     this.managers.add(this.reloadManager);
/* 137 */     progressManager.step("[neverlose.mc] Setting up Reload Manager");
/* 138 */     this.notificationManager = new NotificationManager();
/* 139 */     this.managers.add(this.notificationManager);
/* 140 */     progressManager.step("[neverlose.mc] Setting up Notification Manager");
/* 141 */     this.patchManager = new PatchManager();
/* 142 */     this.managers.add(this.patchManager);
/* 143 */     progressManager.step("[neverlose.mc] Setting up Patch Helper");
/* 144 */     this.popManager = new PopManager();
/* 145 */     this.managers.add(this.popManager);
/* 146 */     progressManager.step("[neverlose.mc] Setting up Pop Manager");
/* 147 */     this.threadManager = new ThreadManager();
/* 148 */     this.managers.add(this.threadManager);
/* 149 */     progressManager.step("[neverlose.mc] Setting up Threads");
/* 150 */     this.holeManager = new HoleManager();
/* 151 */     this.managers.add(this.holeManager);
/* 152 */     progressManager.step("[neverlose.mc] Setting up Hole Manager");
/* 153 */     this.interactionManager = new InteractionManager();
/* 154 */     this.managers.add(this.interactionManager);
/* 155 */     progressManager.step("[neverlose.mc] Setting up Interaction Manager");
/* 156 */     this.inventoryManager = new InventoryManager();
/* 157 */     this.managers.add(this.inventoryManager);
/* 158 */     progressManager.step("[neverlose.mc] Setting up Inventory Manager");
/* 159 */     progressManager.step("[neverlose.mc] Setting up Item Manager");
/* 160 */     this.changelogManager = new ChangelogManager();
/* 161 */     this.managers.add(this.changelogManager);
/* 162 */     progressManager.step("[neverlose.mc] Setting up Changelog Manager");
/* 163 */     this.soundManager = new SoundManager();
/* 164 */     this.managers.add(this.soundManager);
/* 165 */     progressManager.step("[neverlose.mc] Setting up Sound System");
/* 166 */     this.chatManager = new ChatManager();
/* 167 */     this.managers.add(this.chatManager);
/* 168 */     progressManager.step("[neverlose.mc] Setting up Chat Manager");
/* 169 */     this.potionManager = new PotionManager();
/* 170 */     this.managers.add(this.potionManager);
/* 171 */     progressManager.step("[neverlose.mc] Setting up Potion Manager");
/* 172 */     ProgressManager.pop(progressManager);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 177 */     Display.setTitle("neverlose.mc - freeware edition - 1.0b");
/* 178 */     PresenceManager.startPresence();
/* 179 */     SETUP = true;
/* 180 */     long initializeTime = System.currentTimeMillis() - this.startupTime;
/* 181 */     System.out.println("ethanol waz here :^)");
/* 182 */     System.out.println("[neverlose.mc] Initialized in " + initializeTime + "ms!");
/*     */   }
/*     */   
/*     */   public List<Manager> getManagers() {
/* 186 */     return this.managers;
/*     */   }
/*     */   
/*     */   public ClickGUIScreen getClickGUI() {
/* 190 */     return this.clickGUI;
/*     */   }
/*     */   
/*     */   public TabGUI getTabGUI() {
/* 194 */     return this.tabGUI;
/*     */   }
/*     */   
/*     */   public ModuleManager getModuleManager() {
/* 198 */     return this.moduleManager;
/*     */   }
/*     */   
/*     */   public CommandManager getCommandManager() {
/* 202 */     return this.commandManager;
/*     */   }
/*     */   
/*     */   public EventManager getEventManager() {
/* 206 */     return this.eventManager;
/*     */   }
/*     */   
/*     */   public CommandDispatcher<Object> getCommandDispatcher() {
/* 210 */     return this.commandDispatcher;
/*     */   }
/*     */   
/*     */   public TickManager getTickManager() {
/* 214 */     return this.tickManager;
/*     */   }
/*     */   
/*     */   public SocialManager getSocialManager() {
/* 218 */     return this.socialManager;
/*     */   }
/*     */   
/*     */   public AltManager getAltManager() {
/* 222 */     return this.altManager;
/*     */   }
/*     */   
/*     */   public ConfigManager getConfigManager() {
/* 226 */     return this.configManager;
/*     */   }
/*     */   
/*     */   public RotationManager getRotationManager() {
/* 230 */     return this.rotationManager;
/*     */   }
/*     */   
/*     */   public ThreadManager getThreadManager() {
/* 234 */     return this.threadManager;
/*     */   }
/*     */   
/*     */   public HoleManager getHoleManager() {
/* 238 */     return this.holeManager;
/*     */   }
/*     */   
/*     */   public ReloadManager getReloadManager() {
/* 242 */     return this.reloadManager;
/*     */   }
/*     */   
/*     */   public PatchManager getPatchManager() {
/* 246 */     return this.patchManager;
/*     */   }
/*     */   
/*     */   public PopManager getPopManager() {
/* 250 */     return this.popManager;
/*     */   }
/*     */   
/*     */   public InteractionManager getInteractionManager() {
/* 254 */     return this.interactionManager;
/*     */   }
/*     */   
/*     */   public InventoryManager getInventoryManager() {
/* 258 */     return this.inventoryManager;
/*     */   }
/*     */   
/*     */   public ItemManager getItemManager() {
/* 262 */     return this.itemManager;
/*     */   }
/*     */   
/*     */   public ChangelogManager getChangelogManager() {
/* 266 */     return this.changelogManager;
/*     */   }
/*     */   
/*     */   public SoundManager getSoundManager() {
/* 270 */     return this.soundManager;
/*     */   }
/*     */   
/*     */   public ChatManager getChatManager() {
/* 274 */     return this.chatManager;
/*     */   }
/*     */   
/*     */   public PotionManager getPotionManager() {
/* 278 */     return this.potionManager;
/*     */   }
/*     */   
/*     */   public NotificationManager getNotificationManager() {
/* 282 */     return this.notificationManager;
/*     */   }
/*     */   
/*     */   public List<Feature> getNullSafeFeatures() {
/* 286 */     return Arrays.asList(new Feature[] { (Feature)DiscordPresenceModule.INSTANCE, (Feature)ColorsModule.INSTANCE, (Feature)FontModule.INSTANCE, (Feature)SocialModule.INSTANCE, (Feature)FontModule.INSTANCE });
/*     */   }
/*     */ 
/*     */   
/* 290 */   public static final ClientType CLIENT_TYPE = ClientType.RELEASE;
/* 291 */   public static EventBus EVENT_BUS = MinecraftForge.EVENT_BUS; public static boolean SETUP = false; @Instance
/* 292 */   public static Cosmos INSTANCE; public static final String MOD_ID = "neverlose"; public static final String NAME = "neverlose.mc"; public static final String VERSION = "1.0b"; private long startupTime; private ClickGUIScreen clickGUI; private TabGUI tabGUI; private ModuleManager moduleManager; private CommandManager commandManager; private EventManager eventManager; private TickManager tickManager; private SocialManager socialManager; private AltManager altManager; private ConfigManager configManager; public static String PREFIX = "*"; private RotationManager rotationManager; private ThreadManager threadManager; private HoleManager holeManager; private NotificationManager notificationManager; private ReloadManager reloadManager; private PatchManager patchManager; private PopManager popManager; private InteractionManager interactionManager; private InventoryManager inventoryManager; private ItemManager itemManager; private ChangelogManager changelogManager; private SoundManager soundManager;
/*     */   private ChatManager chatManager;
/*     */   private PotionManager potionManager;
/*     */   private CommandDispatcher<Object> commandDispatcher;
/*     */   
/* 297 */   public enum ClientType { RELEASE(""),
/* 298 */     BETA("-beta"),
/* 299 */     DEVELOPMENT("-dev");
/*     */     
/*     */     private final String tag;
/*     */     
/*     */     ClientType(String tag) {
/* 304 */       this.tag = tag;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 308 */       return this.tag;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\Cosmos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */