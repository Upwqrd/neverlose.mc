/*    */ package cope.cosmos.client.events.network;
/*    */ 
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class PacketEvent
/*    */   extends Event {
/*    */   private final Packet<?> packet;
/*    */   
/*    */   public PacketEvent(Packet<?> packet) {
/* 12 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public Packet<?> getPacket() {
/* 16 */     return this.packet;
/*    */   }
/*    */   
/*    */   @Cancelable
/*    */   public static class PacketReceiveEvent extends PacketEvent {
/*    */     public PacketReceiveEvent(Packet<?> packet) {
/* 22 */       super(packet);
/*    */     }
/*    */   }
/*    */   
/*    */   @Cancelable
/*    */   public static class PacketSendEvent extends PacketEvent {
/*    */     public PacketSendEvent(Packet<?> packet) {
/* 29 */       super(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\network\PacketEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */