/*    */ package cope.cosmos.client.events.motion.collision;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class CollisionBoundingBoxEvent
/*    */   extends Event
/*    */ {
/*    */   private final Block block;
/*    */   private final BlockPos position;
/*    */   private final Entity entity;
/*    */   private final AxisAlignedBB collisionBox;
/*    */   private final List<AxisAlignedBB> collisionList;
/*    */   
/*    */   public CollisionBoundingBoxEvent(Block block, BlockPos position, Entity entity, AxisAlignedBB collisionBox, List<AxisAlignedBB> collisionList) {
/* 30 */     this.block = block;
/* 31 */     this.position = position;
/* 32 */     this.entity = entity;
/* 33 */     this.collisionBox = collisionBox;
/* 34 */     this.collisionList = collisionList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Block getBlock() {
/* 42 */     return this.block;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BlockPos getPosition() {
/* 50 */     return this.position;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Entity getEntity() {
/* 58 */     return this.entity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB getCollisionBox() {
/* 66 */     return this.collisionBox;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<AxisAlignedBB> getCollisionList() {
/* 74 */     return this.collisionList;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\motion\collision\CollisionBoundingBoxEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */