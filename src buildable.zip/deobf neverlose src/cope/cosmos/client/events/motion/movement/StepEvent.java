/*    */ package cope.cosmos.client.events.motion.movement;
/*    */ 
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class StepEvent
/*    */   extends Event
/*    */ {
/*    */   private final AxisAlignedBB axisAlignedBB;
/*    */   private float height;
/*    */   
/*    */   public StepEvent(AxisAlignedBB axisAlignedBB, float height) {
/* 20 */     this.axisAlignedBB = axisAlignedBB;
/* 21 */     this.height = height;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB getAxisAlignedBB() {
/* 29 */     return this.axisAlignedBB;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHeight(float in) {
/* 37 */     this.height = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getHeight() {
/* 45 */     return this.height;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\motion\movement\StepEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */