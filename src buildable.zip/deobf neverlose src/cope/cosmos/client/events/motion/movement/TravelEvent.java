/*    */ package cope.cosmos.client.events.motion.movement;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class TravelEvent
/*    */   extends Event {
/*    */   private final float strafe;
/*    */   
/*    */   public TravelEvent(float strafe, float vertical, float forward) {
/* 12 */     this.strafe = strafe;
/* 13 */     this.vertical = vertical;
/* 14 */     this.forward = forward;
/*    */   }
/*    */   private final float vertical; private final float forward;
/*    */   public float getStrafe() {
/* 18 */     return this.strafe;
/*    */   }
/*    */   
/*    */   public float getVertical() {
/* 22 */     return this.vertical;
/*    */   }
/*    */   
/*    */   public float getForward() {
/* 26 */     return this.forward;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\motion\movement\TravelEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */