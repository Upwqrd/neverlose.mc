/*    */ package cope.cosmos.client.events.motion.movement;
/*    */ 
/*    */ import net.minecraft.entity.MoverType;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class MotionEvent
/*    */   extends Event {
/*    */   private MoverType type;
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public MotionEvent(MoverType type, double x, double y, double z) {
/* 16 */     this.type = type;
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/* 19 */     this.z = z;
/*    */   }
/*    */   
/*    */   public MoverType getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(MoverType in) {
/* 27 */     this.type = in;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 31 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(double in) {
/* 35 */     this.x = in;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 39 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(double in) {
/* 43 */     this.y = in;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 47 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(double in) {
/* 51 */     this.z = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\motion\movement\MotionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */