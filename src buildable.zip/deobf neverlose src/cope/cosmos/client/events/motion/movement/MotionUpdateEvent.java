/*    */ package cope.cosmos.client.events.motion.movement;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class MotionUpdateEvent
/*    */   extends Event {
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public double getX() {
/* 14 */     return this.x;
/*    */   }
/*    */   private float yaw; private float pitch; private boolean onGround;
/*    */   public void setX(double in) {
/* 18 */     this.x = in;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 22 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(double in) {
/* 26 */     this.y = in;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 30 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(double in) {
/* 34 */     this.z = in;
/*    */   }
/*    */   
/*    */   public float getYaw() {
/* 38 */     return this.yaw;
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 42 */     return this.pitch;
/*    */   }
/*    */   
/*    */   public void setYaw(float in) {
/* 46 */     this.yaw = in;
/*    */   }
/*    */   
/*    */   public void setPitch(float in) {
/* 50 */     this.pitch = in;
/*    */   }
/*    */   
/*    */   public boolean getOnGround() {
/* 54 */     return this.onGround;
/*    */   }
/*    */   
/*    */   public void setOnGround(boolean in) {
/* 58 */     this.onGround = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\motion\movement\MotionUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */