/*    */ package cope.cosmos.client.events.entity.player.interact;
/*    */ 
/*    */ import net.minecraft.util.MovementInput;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemInputUpdateEvent
/*    */   extends Event
/*    */ {
/*    */   private final MovementInput movementInput;
/*    */   
/*    */   public ItemInputUpdateEvent(MovementInput movementInput) {
/* 17 */     this.movementInput = movementInput;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MovementInput getMovementInput() {
/* 25 */     return this.movementInput;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\player\interact\ItemInputUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */