package cope.cosmos.client.events.entity.player.interact;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EntityUseItemEvent extends Event {}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\player\interact\EntityUseItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */