/*    */ package cope.cosmos.client.events.entity.player.interact;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class ReachEvent
/*    */   extends Event {
/*    */   private float reach;
/*    */   
/*    */   public void setReach(float reach) {
/* 12 */     this.reach = reach;
/*    */   }
/*    */   
/*    */   public float getReach() {
/* 16 */     return this.reach;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\player\interact\ReachEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */