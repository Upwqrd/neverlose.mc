//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.events.entity.potion;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class PotionEffectEvent
/*    */   extends Event
/*    */   implements Wrapper
/*    */ {
/*    */   private final PotionEffect potionEffect;
/*    */   
/*    */   public PotionEffectEvent(PotionEffect potionEffect) {
/* 21 */     this.potionEffect = potionEffect;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PotionEffect getPotionEffect() {
/* 29 */     return this.potionEffect;
/*    */   }
/*    */   
/*    */   public static class PotionAdd extends PotionEffectEvent {
/*    */     public PotionAdd(PotionEffect potionEffect) {
/* 34 */       super(potionEffect);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class PotionRemove
/*    */     extends PotionEffectEvent
/*    */   {
/*    */     private final Potion potion;
/*    */     
/*    */     public PotionRemove(Potion potion) {
/* 44 */       super(mc.player.getActivePotionEffect(potion));
/* 45 */       this.potion = potion;
/*    */     }
/*    */     
/*    */     public PotionRemove(PotionEffect potionEffect) {
/* 49 */       super(potionEffect);
/* 50 */       this.potion = potionEffect.getPotion();
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Potion getPotion() {
/* 58 */       return this.potion;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\potion\PotionEffectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
