/*    */ package cope.cosmos.client.events.entity;
/*    */ 
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class LivingUpdateEvent
/*    */   extends Event
/*    */ {
/*    */   private final EntityPlayerSP entityPlayerSP;
/*    */   private final boolean sprinting;
/*    */   
/*    */   public LivingUpdateEvent(EntityPlayerSP entityPlayerSP, boolean sprinting) {
/* 21 */     this.entityPlayerSP = entityPlayerSP;
/* 22 */     this.sprinting = sprinting;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityPlayerSP getEntityPlayerSP() {
/* 30 */     return this.entityPlayerSP;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSprinting() {
/* 38 */     return this.sprinting;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\LivingUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */