/*    */ package cope.cosmos.client.events.entity;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class EntityWorldEvent
/*    */   extends Event {
/*    */   private final Entity entity;
/*    */   
/*    */   public EntityWorldEvent(Entity entity) {
/* 13 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public static class EntitySpawnEvent extends EntityWorldEvent {
/*    */     public EntitySpawnEvent(Entity entity) {
/* 18 */       super(entity);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class EntityRemoveEvent extends EntityWorldEvent {
/*    */     public EntityRemoveEvent(Entity entity) {
/* 24 */       super(entity);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class EntityUpdateEvent extends EntityWorldEvent {
/*    */     public EntityUpdateEvent(Entity entity) {
/* 30 */       super(entity);
/*    */     }
/*    */   }
/*    */   
/*    */   public Entity getEntity() {
/* 35 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\EntityWorldEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */