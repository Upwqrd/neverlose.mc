/*    */ package cope.cosmos.client.events.entity.hitbox;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class EntityHitboxSizeEvent
/*    */   extends Event {
/*    */   private float hitboxSize;
/*    */   
/*    */   public void setHitboxSize(float in) {
/* 12 */     this.hitboxSize = in;
/*    */   }
/*    */   
/*    */   public float getHitboxSize() {
/* 16 */     return this.hitboxSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\entity\hitbox\EntityHitboxSizeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */