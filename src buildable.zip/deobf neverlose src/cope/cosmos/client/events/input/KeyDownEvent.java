/*    */ package cope.cosmos.client.events.input;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class KeyDownEvent
/*    */   extends Event {
/*    */   private final int keyCode;
/*    */   private boolean pressed;
/*    */   
/*    */   public KeyDownEvent(int keyCode, boolean pressed) {
/* 13 */     this.pressed = pressed;
/* 14 */     this.keyCode = keyCode;
/*    */   }
/*    */   
/*    */   public int getKeyCode() {
/* 18 */     return this.keyCode;
/*    */   }
/*    */   
/*    */   public boolean isPressed() {
/* 22 */     return this.pressed;
/*    */   }
/*    */   
/*    */   public void setPressed(boolean pressed) {
/* 26 */     this.pressed = pressed;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\input\KeyDownEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */