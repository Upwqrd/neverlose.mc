/*    */ package cope.cosmos.client.events.block;
/*    */ 
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeftClickBlockEvent
/*    */   extends Event
/*    */ {
/*    */   private final BlockPos blockPos;
/*    */   private final EnumFacing blockFace;
/*    */   
/*    */   public LeftClickBlockEvent(BlockPos blockPos, EnumFacing blockFace) {
/* 19 */     this.blockPos = blockPos;
/* 20 */     this.blockFace = blockFace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BlockPos getPos() {
/* 28 */     return this.blockPos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EnumFacing getFace() {
/* 36 */     return this.blockFace;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\block\LeftClickBlockEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */