/*    */ package cope.cosmos.client.events.block;
/*    */ 
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class BlockBreakEvent
/*    */   extends Event {
/*    */   private final BlockPos blockPos;
/*    */   
/*    */   public BlockBreakEvent(BlockPos blockPos) {
/* 13 */     this.blockPos = blockPos;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos() {
/* 17 */     return this.blockPos;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\block\BlockBreakEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */