/*    */ package cope.cosmos.client.events.client;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class ModuleToggleEvent
/*    */   extends Event {
/*    */   private final Module module;
/*    */   
/*    */   public ModuleToggleEvent(Module module) {
/* 11 */     this.module = module;
/*    */   }
/*    */   
/*    */   public static class ModuleEnableEvent extends ModuleToggleEvent {
/*    */     public ModuleEnableEvent(Module module) {
/* 16 */       super(module);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class ModuleDisableEvent extends ModuleToggleEvent {
/*    */     public ModuleDisableEvent(Module module) {
/* 22 */       super(module);
/*    */     }
/*    */   }
/*    */   
/*    */   public Module getModule() {
/* 27 */     return this.module;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\client\ModuleToggleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */