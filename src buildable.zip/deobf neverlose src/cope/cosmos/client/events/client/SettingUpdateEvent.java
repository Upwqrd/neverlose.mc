/*    */ package cope.cosmos.client.events.client;
/*    */ 
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class SettingUpdateEvent
/*    */   extends Event {
/*    */   private final Setting<?> setting;
/*    */   
/*    */   public SettingUpdateEvent(Setting<?> setting) {
/* 13 */     this.setting = setting;
/*    */   }
/*    */   
/*    */   public Setting<?> getSetting() {
/* 17 */     return this.setting;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\client\SettingUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */