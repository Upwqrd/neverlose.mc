/*    */ package cope.cosmos.client.events.combat;
/*    */ 
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class CrystalAttackEvent
/*    */   extends Event {
/*    */   private final DamageSource damageSource;
/*    */   
/*    */   public CrystalAttackEvent(DamageSource damageSource) {
/* 13 */     this.damageSource = damageSource;
/*    */   }
/*    */   
/*    */   public DamageSource getDamageSource() {
/* 17 */     return this.damageSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\combat\CrystalAttackEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */