/*    */ package cope.cosmos.client.events.combat;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class TotemPopEvent
/*    */   extends Event {
/*    */   private final Entity popEntity;
/*    */   
/*    */   public TotemPopEvent(Entity popEntity) {
/* 13 */     this.popEntity = popEntity;
/*    */   }
/*    */   
/*    */   public Entity getPopEntity() {
/* 17 */     return this.popEntity;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\combat\TotemPopEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */