/*    */ package cope.cosmos.client.events.combat;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CriticalModifierEvent
/*    */   extends Event
/*    */ {
/* 12 */   private float damageModifier = 1.5F;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDamageModifier(float in) {
/* 19 */     this.damageModifier = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getDamageModifier() {
/* 27 */     return this.damageModifier;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\combat\CriticalModifierEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */