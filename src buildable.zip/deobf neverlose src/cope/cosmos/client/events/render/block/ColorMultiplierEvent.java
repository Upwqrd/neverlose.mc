/*    */ package cope.cosmos.client.events.render.block;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class ColorMultiplierEvent
/*    */   extends Event
/*    */ {
/*    */   private int opacity;
/*    */   
/*    */   public ColorMultiplierEvent(int opacity) {
/* 18 */     this.opacity = opacity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOpacity(int in) {
/* 26 */     this.opacity = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOpacity() {
/* 34 */     return this.opacity;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\block\ColorMultiplierEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */