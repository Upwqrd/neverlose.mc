/*    */ package cope.cosmos.client.events.render.entity;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderRotationsEvent extends Event {
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   
/*    */   public float getYaw() {
/* 12 */     return this.yaw;
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 16 */     return this.pitch;
/*    */   }
/*    */   
/*    */   public void setYaw(float in) {
/* 20 */     this.yaw = in;
/*    */   }
/*    */   
/*    */   public void setPitch(float in) {
/* 24 */     this.pitch = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderRotationsEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */