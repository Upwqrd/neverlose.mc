/*    */ package cope.cosmos.client.events.render.entity.tile;
/*    */ 
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderTileEntityEvent
/*    */   extends Event
/*    */ {
/*    */   private final TileEntity tileEntity;
/*    */   private final double x;
/*    */   private final double y;
/*    */   private final double z;
/*    */   private final float partialTicks;
/*    */   private final int destroyStage;
/*    */   private final float partial;
/*    */   private final Tessellator buffer;
/*    */   
/*    */   public RenderTileEntityEvent(TileEntity tileEntity, double x, double y, double z, float partialTicks, int destroyStage, float partial, Tessellator buffer) {
/* 28 */     this.tileEntity = tileEntity;
/* 29 */     this.x = x;
/* 30 */     this.y = y;
/* 31 */     this.z = z;
/* 32 */     this.partialTicks = partialTicks;
/* 33 */     this.destroyStage = destroyStage;
/* 34 */     this.partial = partial;
/* 35 */     this.buffer = buffer;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 39 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 43 */     return this.y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 47 */     return this.z;
/*    */   }
/*    */   
/*    */   public float getPartialTicks() {
/* 51 */     return this.partialTicks;
/*    */   }
/*    */   
/*    */   public int getDestroyStage() {
/* 55 */     return this.destroyStage;
/*    */   }
/*    */   
/*    */   public float getPartial() {
/* 59 */     return this.partial;
/*    */   }
/*    */   
/*    */   public Tessellator getBuffer() {
/* 63 */     return this.buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TileEntity getTileEntity() {
/* 71 */     return this.tileEntity;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\tile\RenderTileEntityEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */