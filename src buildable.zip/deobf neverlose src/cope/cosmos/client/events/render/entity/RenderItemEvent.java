/*    */ package cope.cosmos.client.events.render.entity;
/*    */ 
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderItemEvent
/*    */   extends Event
/*    */ {
/*    */   private final EntityItem entityItem;
/*    */   private final double x;
/*    */   private final double y;
/*    */   private final double z;
/*    */   private final float entityYaw;
/*    */   private final float partialTicks;
/*    */   
/*    */   public RenderItemEvent(EntityItem entityItem, double x, double y, double z, float entityYaw, float partialTicks) {
/* 22 */     this.entityItem = entityItem;
/* 23 */     this.x = x;
/* 24 */     this.y = y;
/* 25 */     this.z = z;
/* 26 */     this.entityYaw = entityYaw;
/* 27 */     this.partialTicks = partialTicks;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityItem getEntityItem() {
/* 35 */     return this.entityItem;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getX() {
/* 43 */     return this.x;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getY() {
/* 51 */     return this.y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getZ() {
/* 59 */     return this.z;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getEntityYaw() {
/* 67 */     return this.entityYaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getPartialTicks() {
/* 75 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */