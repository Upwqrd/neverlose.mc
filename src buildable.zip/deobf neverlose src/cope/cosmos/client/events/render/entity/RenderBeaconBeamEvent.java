package cope.cosmos.client.events.render.entity;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderBeaconBeamEvent extends Event {}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderBeaconBeamEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */