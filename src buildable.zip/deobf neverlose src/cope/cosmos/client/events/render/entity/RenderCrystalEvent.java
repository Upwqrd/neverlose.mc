/*     */ package cope.cosmos.client.events.render.entity;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityEnderCrystal;
/*     */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Cancelable
/*     */ public class RenderCrystalEvent
/*     */   extends Event
/*     */ {
/*     */   public static class RenderCrystalPreEvent
/*     */     extends RenderCrystalEvent
/*     */   {
/*     */     private final ModelBase modelBase;
/*     */     private final Entity entity;
/*     */     private final float limbSwing;
/*     */     private final float limbSwingAmount;
/*     */     private final float ageInTicks;
/*     */     private final float netHeadYaw;
/*     */     private final float headPitch;
/*     */     private final float scaleFactor;
/*     */     
/*     */     public RenderCrystalPreEvent(ModelBase modelBase, Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor) {
/*  30 */       this.modelBase = modelBase;
/*  31 */       this.entity = entity;
/*  32 */       this.limbSwing = limbSwing;
/*  33 */       this.limbSwingAmount = limbSwingAmount;
/*  34 */       this.ageInTicks = ageInTicks;
/*  35 */       this.netHeadYaw = netHeadYaw;
/*  36 */       this.headPitch = headPitch;
/*  37 */       this.scaleFactor = scaleFactor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ModelBase getModelBase() {
/*  45 */       return this.modelBase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Entity getEntity() {
/*  53 */       return this.entity;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getLimbSwing() {
/*  61 */       return this.limbSwing;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getLimbSwingAmount() {
/*  69 */       return this.limbSwingAmount;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getAgeInTicks() {
/*  77 */       return this.ageInTicks;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getNetHeadYaw() {
/*  85 */       return this.netHeadYaw;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getHeadPitch() {
/*  93 */       return this.headPitch;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getScaleFactor() {
/* 101 */       return this.scaleFactor;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RenderCrystalPostEvent
/*     */     extends RenderCrystalEvent
/*     */   {
/*     */     private final ModelBase modelBase;
/*     */     private final ModelBase modelNoBase;
/*     */     private final EntityEnderCrystal entityEnderCrystal;
/*     */     private final double x;
/*     */     private final double y;
/*     */     private final double z;
/*     */     private final float entityYaw;
/*     */     private final float partialTicks;
/*     */     
/*     */     public RenderCrystalPostEvent(ModelBase modelBase, ModelBase modelNoBase, EntityEnderCrystal entityEnderCrystal, double x, double y, double z, float entityYaw, float partialTicks) {
/* 118 */       this.modelBase = modelBase;
/* 119 */       this.modelNoBase = modelNoBase;
/* 120 */       this.entityEnderCrystal = entityEnderCrystal;
/* 121 */       this.x = x;
/* 122 */       this.y = y;
/* 123 */       this.z = z;
/* 124 */       this.entityYaw = entityYaw;
/* 125 */       this.partialTicks = partialTicks;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ModelBase getModelBase() {
/* 133 */       return this.modelBase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ModelBase getModelNoBase() {
/* 141 */       return this.modelNoBase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EntityEnderCrystal getEntityEnderCrystal() {
/* 149 */       return this.entityEnderCrystal;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getX() {
/* 157 */       return this.x;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getY() {
/* 165 */       return this.y;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double getZ() {
/* 173 */       return this.z;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getEntityYaw() {
/* 181 */       return this.entityYaw;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getPartialTicks() {
/* 189 */       return this.partialTicks;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderCrystalEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */