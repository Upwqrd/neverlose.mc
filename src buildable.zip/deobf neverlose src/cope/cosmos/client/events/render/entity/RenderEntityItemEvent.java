/*    */ package cope.cosmos.client.events.render.entity;
/*    */ 
/*    */ import net.minecraft.client.renderer.RenderItem;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderEntityItemEvent
/*    */   extends Event
/*    */ {
/*    */   private final RenderItem itemRenderer;
/*    */   private final EntityItem entityItem;
/*    */   private final double x;
/*    */   private final double y;
/*    */   private final double z;
/*    */   private final float entityYaw;
/*    */   private final float partialTicks;
/*    */   
/*    */   public RenderEntityItemEvent(RenderItem itemRenderer, EntityItem entityItem, double x, double y, double z, float entityYaw, float partialTicks) {
/* 27 */     this.itemRenderer = itemRenderer;
/* 28 */     this.entityItem = entityItem;
/* 29 */     this.x = x;
/* 30 */     this.y = y;
/* 31 */     this.z = z;
/* 32 */     this.entityYaw = entityYaw;
/* 33 */     this.partialTicks = partialTicks;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RenderItem getItemRenderer() {
/* 41 */     return this.itemRenderer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityItem getEntityItem() {
/* 49 */     return this.entityItem;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getX() {
/* 57 */     return this.x;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getY() {
/* 65 */     return this.y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getZ() {
/* 73 */     return this.z;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getEntityYaw() {
/* 81 */     return this.entityYaw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getPartialTicks() {
/* 89 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderEntityItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */