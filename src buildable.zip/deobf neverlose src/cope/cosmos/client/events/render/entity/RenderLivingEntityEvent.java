/*     */ package cope.cosmos.client.events.render.entity;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Cancelable
/*     */ public class RenderLivingEntityEvent
/*     */   extends Event
/*     */ {
/*     */   private final ModelBase modelBase;
/*     */   private final EntityLivingBase entityLivingBase;
/*     */   private final float limbSwing;
/*     */   private final float limbSwingAmount;
/*     */   private final float ageInTicks;
/*     */   private final float netHeadYaw;
/*     */   private final float headPitch;
/*     */   private final float scaleFactor;
/*     */   
/*     */   public RenderLivingEntityEvent(ModelBase modelBase, EntityLivingBase entityLivingBase, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor) {
/*  27 */     this.modelBase = modelBase;
/*  28 */     this.entityLivingBase = entityLivingBase;
/*  29 */     this.limbSwing = limbSwing;
/*  30 */     this.limbSwingAmount = limbSwingAmount;
/*  31 */     this.ageInTicks = ageInTicks;
/*  32 */     this.netHeadYaw = netHeadYaw;
/*  33 */     this.headPitch = headPitch;
/*  34 */     this.scaleFactor = scaleFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelBase getModelBase() {
/*  42 */     return this.modelBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityLivingBase getEntityLivingBase() {
/*  50 */     return this.entityLivingBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLimbSwing() {
/*  58 */     return this.limbSwing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLimbSwingAmount() {
/*  66 */     return this.limbSwingAmount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAgeInTicks() {
/*  74 */     return this.ageInTicks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getNetHeadYaw() {
/*  82 */     return this.netHeadYaw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeadPitch() {
/*  90 */     return this.headPitch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getScaleFactor() {
/*  98 */     return this.scaleFactor;
/*     */   }
/*     */   
/*     */   public static class RenderLivingEntityPreEvent
/*     */     extends RenderLivingEntityEvent
/*     */   {
/*     */     public RenderLivingEntityPreEvent(ModelBase modelBase, EntityLivingBase entityLivingBase, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor) {
/* 105 */       super(modelBase, entityLivingBase, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RenderLivingEntityPostEvent
/*     */     extends RenderLivingEntityEvent
/*     */   {
/*     */     public RenderLivingEntityPostEvent(ModelBase modelBase, EntityLivingBase entityLivingBase, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor) {
/* 113 */       super(modelBase, entityLivingBase, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\entity\RenderLivingEntityEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */