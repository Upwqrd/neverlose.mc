package cope.cosmos.client.events.render.player;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderSelectionBoxEvent extends Event {}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\player\RenderSelectionBoxEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */