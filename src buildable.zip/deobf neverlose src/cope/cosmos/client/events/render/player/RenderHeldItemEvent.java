/*    */ package cope.cosmos.client.events.render.player;
/*    */ 
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderHeldItemEvent
/*    */   extends Event
/*    */ {
/*    */   private EnumHandSide side;
/*    */   
/*    */   public RenderHeldItemEvent(EnumHandSide enumHandSide) {
/* 18 */     this.side = enumHandSide;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EnumHandSide getSide() {
/* 26 */     return this.side;
/*    */   }
/*    */   
/*    */   public static class Pre extends RenderHeldItemEvent {
/*    */     public Pre(EnumHandSide enumHandSide) {
/* 31 */       super(enumHandSide);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Post extends RenderHeldItemEvent {
/*    */     public Post(EnumHandSide enumHandSide) {
/* 37 */       super(enumHandSide);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\player\RenderHeldItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */