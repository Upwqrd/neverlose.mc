/*    */ package cope.cosmos.client.events.render.world;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderSkyEvent
/*    */   extends Event
/*    */ {
/*    */   private Color color;
/*    */   
/*    */   public void setColor(Color in) {
/* 24 */     this.color = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Color getColor() {
/* 32 */     return this.color;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\world\RenderSkyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */