/*    */ package cope.cosmos.client.events.render.world;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderFogColorEvent
/*    */   extends Event
/*    */ {
/*    */   private Color color;
/*    */   
/*    */   public Color getColor() {
/* 24 */     return this.color;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setColor(Color in) {
/* 32 */     this.color = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\world\RenderFogColorEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */