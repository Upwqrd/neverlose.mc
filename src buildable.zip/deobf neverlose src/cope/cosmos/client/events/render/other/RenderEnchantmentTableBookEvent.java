package cope.cosmos.client.events.render.other;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderEnchantmentTableBookEvent extends Event {}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\other\RenderEnchantmentTableBookEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */