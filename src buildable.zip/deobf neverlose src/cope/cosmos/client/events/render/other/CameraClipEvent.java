/*    */ package cope.cosmos.client.events.render.other;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class CameraClipEvent
/*    */   extends Event {
/*    */   private double distance;
/*    */   
/*    */   public CameraClipEvent(double distance) {
/* 10 */     this.distance = distance;
/*    */   }
/*    */   
/*    */   public double getDistance() {
/* 14 */     return this.distance;
/*    */   }
/*    */   
/*    */   public void setDistance(double in) {
/* 18 */     this.distance = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\other\CameraClipEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */