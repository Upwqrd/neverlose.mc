/*    */ package cope.cosmos.client.events.render.other;
/*    */ 
/*    */ import net.minecraft.util.EnumParticleTypes;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderParticleEvent
/*    */   extends Event
/*    */ {
/*    */   private final EnumParticleTypes particleTypes;
/*    */   
/*    */   public RenderParticleEvent(EnumParticleTypes particleTypes) {
/* 19 */     this.particleTypes = particleTypes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EnumParticleTypes getParticleType() {
/* 27 */     return this.particleTypes;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\other\RenderParticleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */