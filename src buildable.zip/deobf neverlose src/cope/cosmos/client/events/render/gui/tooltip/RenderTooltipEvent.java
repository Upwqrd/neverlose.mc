/*    */ package cope.cosmos.client.events.render.gui.tooltip;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderTooltipEvent
/*    */   extends Event
/*    */ {
/*    */   private final ItemStack itemStack;
/*    */   private final int x;
/*    */   private final int y;
/*    */   
/*    */   public RenderTooltipEvent(ItemStack itemStack, int x, int y) {
/* 17 */     this.itemStack = itemStack;
/* 18 */     this.x = x;
/* 19 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack getItemStack() {
/* 27 */     return this.itemStack;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getX() {
/* 35 */     return this.x;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getY() {
/* 43 */     return this.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\gui\tooltip\RenderTooltipEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */