/*    */ package cope.cosmos.client.events.render.gui;
/*    */ 
/*    */ import net.minecraftforge.client.event.RenderBlockOverlayEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class RenderOverlayEvent
/*    */   extends Event
/*    */ {
/*    */   private final RenderBlockOverlayEvent.OverlayType overlayType;
/*    */   
/*    */   public RenderOverlayEvent(RenderBlockOverlayEvent.OverlayType overlayType) {
/* 19 */     this.overlayType = overlayType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RenderBlockOverlayEvent.OverlayType getOverlayType() {
/* 27 */     return this.overlayType;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\gui\RenderOverlayEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */