/*    */ package cope.cosmos.client.events.render.gui;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class TabOverlayEvent
/*    */   extends Event {
/*    */   private String information;
/*    */   
/*    */   public TabOverlayEvent(String information) {
/* 12 */     this.information = information;
/*    */   }
/*    */   
/*    */   public void setInformation(String in) {
/* 16 */     this.information = in;
/*    */   }
/*    */   
/*    */   public String getInformation() {
/* 20 */     return this.information;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\client\events\render\gui\TabOverlayEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */