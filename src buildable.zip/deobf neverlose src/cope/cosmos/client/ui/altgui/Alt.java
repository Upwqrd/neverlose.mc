//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.altgui;
/*     */ 
/*     */ import com.mojang.authlib.Agent;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
/*     */ import cope.cosmos.asm.mixins.accessor.IMinecraft;
/*     */ import fr.litarvan.openauth.microsoft.MicrosoftAuthResult;
/*     */ import fr.litarvan.openauth.microsoft.MicrosoftAuthenticationException;
/*     */ import fr.litarvan.openauth.microsoft.MicrosoftAuthenticator;
/*     */ import java.net.Proxy;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.util.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Alt
/*     */ {
/*     */   private final AltType altType;
/*     */   private final String login;
/*     */   private final String password;
/*     */   private Session altSession;
/*     */   
/*     */   public Alt(String altLogin, String altPassword, AltType altType) {
/*  36 */     this.login = altLogin;
/*  37 */     this.password = altPassword;
/*  38 */     this.altType = altType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void login() {
/*  45 */     if (this.altSession == null) {
/*  46 */       MicrosoftAuthenticator authenticator; YggdrasilAuthenticationService service; YggdrasilUserAuthentication auth; switch (getAltType()) {
/*     */         
/*     */         case MICROSOFT:
/*  49 */           authenticator = new MicrosoftAuthenticator();
/*     */           
/*     */           try {
/*  52 */             MicrosoftAuthResult result = authenticator.loginWithCredentials(this.login, this.password);
/*     */ 
/*     */             
/*  55 */             this.altSession = new Session(result.getProfile().getName(), result.getProfile().getId(), result.getAccessToken(), "legacy");
/*  56 */           } catch (MicrosoftAuthenticationException e) {
/*  57 */             e.printStackTrace();
/*     */           } 
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case MOJANG:
/*  64 */           service = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
/*  65 */           auth = (YggdrasilUserAuthentication)service.createUserAuthentication(Agent.MINECRAFT);
/*     */ 
/*     */           
/*  68 */           auth.setUsername(getLogin());
/*  69 */           auth.setPassword(getPassword());
/*     */ 
/*     */           
/*     */           try {
/*  73 */             auth.logIn();
/*     */ 
/*     */             
/*  76 */             this.altSession = new Session(auth.getSelectedProfile().getName(), auth.getSelectedProfile().getId().toString(), auth.getAuthenticatedToken(), "mojang");
/*  77 */           } catch (AuthenticationException localAuthenticationException) {
/*  78 */             localAuthenticationException.printStackTrace();
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case CRACKED:
/*  84 */           this.altSession = new Session(getLogin(), UUID.randomUUID().toString(), "", "legacy");
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  89 */     if (this.altSession != null) {
/*  90 */       ((IMinecraft)Minecraft.getMinecraft()).setSession(this.altSession);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AltType getAltType() {
/*  99 */     return this.altType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLogin() {
/* 107 */     return this.login;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 115 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session getAltSession() {
/* 123 */     return this.altSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum AltType
/*     */   {
/* 133 */     MICROSOFT,
/*     */ 
/*     */ 
/*     */     
/* 137 */     MOJANG,
/*     */ 
/*     */ 
/*     */     
/* 141 */     CRACKED;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\altgui\Alt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
