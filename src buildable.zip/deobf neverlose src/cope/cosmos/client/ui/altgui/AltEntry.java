//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.altgui;
/*     */ 
/*     */ import cope.cosmos.client.ui.util.InterfaceWrapper;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AltEntry
/*     */   implements Wrapper, InterfaceWrapper
/*     */ {
/*     */   private final Alt alt;
/*     */   private float offset;
/*     */   public boolean isSelected;
/*     */   
/*     */   public AltEntry(Alt alt, float offset) {
/*  32 */     this.alt = alt;
/*  33 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawAltEntry(int mouseX, int mouseY) {
/*  43 */     ScaledResolution scaledResolution = new ScaledResolution(mc);
/*     */ 
/*     */     
/*  46 */     RenderUtil.drawRect(scaledResolution.getScaledWidth() / 2.0F - 150.0F, getOffset(), 300.0F, 30.0F, -1795162112);
/*     */ 
/*     */     
/*  49 */     if (isMouseOverButton(mouseX, mouseY)) {
/*  50 */       RenderUtil.drawBorder(scaledResolution.getScaledWidth() / 2.0F - 150.0F, getOffset(), 300.0F, 30.0F, ColorUtil.getPrimaryColor().darker().darker());
/*     */     }
/*     */ 
/*     */     
/*  54 */     if (this.isSelected) {
/*  55 */       RenderUtil.drawBorder(scaledResolution.getScaledWidth() / 2.0F - 150.0F, getOffset(), 300.0F, 30.0F, ColorUtil.getPrimaryColor());
/*     */     }
/*     */ 
/*     */     
/*  59 */     if (getAlt().getAltSession() != null) {
/*  60 */       GL11.glPushMatrix();
/*     */ 
/*     */       
/*  63 */       GL11.glTranslatef(scaledResolution.getScaledWidth() / 2.0F - 148.0F + 10.0F, getOffset() + 17.0F, 1.0F);
/*  64 */       GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/*  65 */       GL11.glTranslatef(-(scaledResolution.getScaledWidth() / 2.0F - 148.0F + 10.0F), -(getOffset() + 17.0F), 1.0F);
/*     */ 
/*     */       
/*  68 */       GL11.glColor4f(255.0F, 255.0F, 255.0F, 255.0F);
/*     */ 
/*     */       
/*  71 */       if (mc.getSession().getPlayerID().equalsIgnoreCase(getAlt().getAltSession().getPlayerID())) {
/*  72 */         GL11.glColor3f(ColorUtil.getPrimaryColor().getRed() / 255.0F, ColorUtil.getPrimaryColor().getGreen() / 255.0F, ColorUtil.getPrimaryColor().getBlue() / 255.0F);
/*     */       }
/*     */ 
/*     */       
/*  76 */       mc.getTextureManager().bindTexture(new ResourceLocation("cosmos", "textures/icons/dropdown.png"));
/*     */ 
/*     */       
/*  79 */       Gui.drawModalRectWithCustomSizedTexture(scaledResolution.getScaledWidth() / 2 - 148, (int)(getOffset() + 9.0F), 0.0F, 0.0F, 25, 25, 25.0F, 25.0F);
/*     */       
/*  81 */       GL11.glPopMatrix();
/*     */     } 
/*     */ 
/*     */     
/*  85 */     String loginString = "";
/*     */ 
/*     */     
/*  88 */     if (getAlt().getLogin().contains("@") && getAlt().getLogin().length() > 4 && getAlt().getAltType() != Alt.AltType.CRACKED) {
/*  89 */       loginString = getAlt().getLogin().substring(0, 3) + getAlt().getLogin().substring(3, getAlt().getLogin().indexOf('@')).replaceAll(".", "*") + getAlt().getLogin().substring(getAlt().getLogin().indexOf('@'));
/*     */     
/*     */     }
/*  92 */     else if (getAlt().getAltType() == Alt.AltType.CRACKED) {
/*  93 */       loginString = getAlt().getLogin();
/*     */     } 
/*     */ 
/*     */     
/*  97 */     FontUtil.drawStringWithShadow(loginString + ((getAlt().getAltType() != Alt.AltType.CRACKED) ? (String)TextFormatting.GRAY : ""), scaledResolution.getScaledWidth() / 2.0F - 120.0F, getOffset() + 5.0F, 16777215);
/*     */ 
/*     */     
/* 100 */     if (getAlt().getAltType() != Alt.AltType.CRACKED) {
/* 101 */       FontUtil.drawStringWithShadow(getAlt().getPassword().replaceAll(".", "*"), scaledResolution.getScaledWidth() / 2.0F - 120.0F, getOffset() + 17.0F, 16777215);
/*     */     }
/*     */ 
/*     */     
/* 105 */     FontUtil.drawStringWithShadow((getAlt().getAltSession() != null) ? getAlt().getAltType().name() : "[NO SESSION]", scaledResolution.getScaledWidth() / 2.0F + (145 - FontUtil.getStringWidth((getAlt().getAltSession() != null) ? getAlt().getAltType().name() : "[NO SESSION]")), getOffset() + 11.0F, 16777215);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMouseOverButton(int mouseX, int mouseY) {
/* 113 */     ScaledResolution scaledResolution = new ScaledResolution(mc);
/* 114 */     return AltManagerGUI.mouseOver((scaledResolution.getScaledWidth() / 2.0F - 150.0F), getOffset(), 300.0D, 30.0D, mouseX, mouseY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void whenClicked() {
/* 122 */     getAlt().login();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Alt getAlt() {
/* 130 */     return this.alt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getOffset() {
/* 138 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOffset(float offset) {
/* 146 */     this.offset = offset;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\altgui\AltEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
