//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.altgui;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import java.io.IOException;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiTextField;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddAltGUI
/*     */   extends GuiScreen
/*     */ {
/*     */   private final GuiScreen lastScreen;
/*     */   private GuiTextField loginField;
/*     */   private GuiTextField passwordField;
/*  31 */   private Alt.AltType currentType = Alt.AltType.MICROSOFT;
/*     */   
/*     */   public AddAltGUI(GuiScreen lastScreen) {
/*  34 */     this.lastScreen = lastScreen;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initGui() {
/*  40 */     this.loginField = new GuiTextField(1, this.mc.fontRenderer, this.width / 2 - 100, this.height / 2 - 42, 200, 15);
/*  41 */     this.passwordField = new GuiTextField(2, this.mc.fontRenderer, this.width / 2 - 100, this.height / 2 - 20, 200, 15);
/*     */ 
/*     */     
/*  44 */     this.buttonList.add(new GuiButton(3, this.width / 2 - 51, this.height / 2 + 8, 50, 20, "Add"));
/*  45 */     this.buttonList.add(new GuiButton(4, this.width / 2 + 1, this.height / 2 + 8, 50, 20, "Cancel"));
/*     */ 
/*     */     
/*  48 */     this.buttonList.add(new GuiButton(5, this.width / 2 - 210, this.height / 2 - 42, 100, 20, "Use Microsoft"));
/*  49 */     this.buttonList.add(new GuiButton(6, this.width / 2 - 210, this.height / 2 - 21, 100, 20, "Use Mojang"));
/*  50 */     this.buttonList.add(new GuiButton(7, this.width / 2 - 210, this.height / 2, 100, 20, "Use Cracked"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  55 */     ScaledResolution scaledResolution = new ScaledResolution(this.mc);
/*     */     
/*  57 */     drawDefaultBackground();
/*     */ 
/*     */     
/*  60 */     drawCenteredString(this.mc.fontRenderer, "Add Alt Account", scaledResolution.getScaledWidth() / 2, 10, 16777215);
/*     */ 
/*     */     
/*  63 */     this.loginField.drawTextBox();
/*     */     
/*  65 */     if (this.loginField.getText().isEmpty() && !this.loginField.isFocused() && this.loginField.getVisible()) {
/*  66 */       FontUtil.drawStringWithShadow(TextFormatting.GRAY + "Login", (this.loginField.x + 3), this.loginField.y + 3.5F, -1);
/*     */     }
/*     */ 
/*     */     
/*  70 */     this.passwordField.drawTextBox();
/*  71 */     if (this.passwordField.getText().isEmpty() && !this.passwordField.isFocused() && this.passwordField.getVisible()) {
/*  72 */       FontUtil.drawStringWithShadow(TextFormatting.GRAY + "Password", (this.passwordField.x + 3), this.passwordField.y + 3.5F, -1);
/*     */     }
/*     */     
/*  75 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void actionPerformed(GuiButton button) throws IOException {
/*  80 */     super.actionPerformed(button);
/*     */     
/*  82 */     switch (button.id) {
/*     */       
/*     */       case 3:
/*  85 */         if (!this.loginField.getText().isEmpty()) {
/*     */           
/*  87 */           Cosmos.INSTANCE.getAltManager().getAltEntries().add(new AltEntry(new Alt(this.loginField.getText(), this.passwordField.getText(), this.currentType), AltManagerGUI.altEntryOffset));
/*     */           
/*  89 */           AltManagerGUI.altEntryOffset += 32.0F;
/*     */           
/*  91 */           this.mc.displayGuiScreen(this.lastScreen);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/*  98 */         this.mc.displayGuiScreen(this.lastScreen);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/* 103 */         this.currentType = Alt.AltType.MICROSOFT;
/* 104 */         this.loginField.setVisible(true);
/* 105 */         this.passwordField.setVisible(true);
/*     */         break;
/*     */       
/*     */       case 6:
/* 109 */         this.currentType = Alt.AltType.MOJANG;
/* 110 */         this.loginField.setVisible(true);
/* 111 */         this.passwordField.setVisible(true);
/*     */         break;
/*     */       
/*     */       case 7:
/* 115 */         this.currentType = Alt.AltType.CRACKED;
/* 116 */         this.loginField.setVisible(true);
/* 117 */         this.passwordField.setVisible(false);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
/* 124 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */ 
/*     */     
/* 127 */     this.loginField.mouseClicked(mouseX, mouseY, mouseButton);
/* 128 */     this.passwordField.mouseClicked(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void keyTyped(char typedChar, int keyCode) throws IOException {
/* 140 */     if (keyCode == 1) {
/* 141 */       this.mc.displayGuiScreen(this.lastScreen);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 146 */     this.loginField.textboxKeyTyped(typedChar, keyCode);
/* 147 */     this.passwordField.textboxKeyTyped(typedChar, keyCode);
/*     */ 
/*     */     
/* 150 */     if (keyCode == 28) {
/* 151 */       this.loginField.setFocused(false);
/* 152 */       this.passwordField.setFocused(false);
/*     */     } 
/*     */     
/* 155 */     super.keyTyped(typedChar, keyCode);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\altgui\AddAltGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
