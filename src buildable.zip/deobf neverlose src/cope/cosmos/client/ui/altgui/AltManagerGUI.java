//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.altgui;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.ui.util.ScissorStack;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import java.io.IOException;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AltManagerGUI
/*     */   extends GuiScreen
/*     */ {
/*     */   private final GuiScreen lastScreen;
/*  27 */   public static float altEntryOffset = 41.0F;
/*     */   
/*  29 */   private final ScissorStack scissorStack = new ScissorStack();
/*     */   
/*     */   public AltManagerGUI(GuiScreen lastScreen) {
/*  32 */     this.lastScreen = lastScreen;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initGui() {
/*  38 */     ScaledResolution scaledResolution = new ScaledResolution(this.mc);
/*     */     
/*  40 */     this.buttonList.add(new GuiButton(0, scaledResolution.getScaledWidth() / 2 - 150, scaledResolution.getScaledHeight() - 23, 100, 20, "Add Alt"));
/*  41 */     this.buttonList.add(new GuiButton(1, scaledResolution.getScaledWidth() / 2 - 50, scaledResolution.getScaledHeight() - 23, 100, 20, "Delete Selected"));
/*  42 */     this.buttonList.add(new GuiButton(2, scaledResolution.getScaledWidth() / 2 + 50, scaledResolution.getScaledHeight() - 23, 100, 20, "Back"));
/*     */     
/*  44 */     altEntryOffset = 41.0F;
/*     */     
/*  46 */     if (!Cosmos.INSTANCE.getAltManager().getAltEntries().isEmpty()) {
/*  47 */       getFirstAlt().setOffset(altEntryOffset);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  53 */     ScaledResolution scaledResolution = new ScaledResolution(this.mc);
/*     */ 
/*     */     
/*  56 */     drawDefaultBackground();
/*     */ 
/*     */     
/*  59 */     drawCenteredString(this.mc.fontRenderer, "Neverlose.mc Alt Manager", scaledResolution.getScaledWidth() / 2, 10, 16777215);
/*     */ 
/*     */     
/*  62 */     RenderUtil.drawRect(scaledResolution.getScaledWidth() / 2.0F - 155.0F, 36.0F, 310.0F, (scaledResolution.getScaledHeight() - 38), -1879048192);
/*     */ 
/*     */     
/*  65 */     this.scissorStack.pushScissor(scaledResolution.getScaledWidth() / 2 - 151, 40, scaledResolution.getScaledWidth() / 2 + 151, scaledResolution.getScaledHeight() - 24);
/*     */ 
/*     */     
/*  68 */     Cosmos.INSTANCE.getAltManager().getAltEntries().forEach(entry -> entry.drawAltEntry(mouseX, mouseY));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.scissorStack.popScissor();
/*     */ 
/*     */     
/*  76 */     if (Cosmos.INSTANCE.getAltManager().getAltEntries().isEmpty()) {
/*  77 */       FontUtil.drawCenteredStringWithShadow("No alts!", scaledResolution.getScaledWidth() / 2.0F, 50.0F, 16777215);
/*     */     }
/*     */ 
/*     */     
/*  81 */     FontUtil.drawStringWithShadow("Currently logged in as " + TextFormatting.GRAY + this.mc.getSession().getUsername(), 3.0F, 3.0F, 16777215);
/*     */ 
/*     */     
/*  84 */     scroll(mouseX, mouseY);
/*     */     
/*  86 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scroll(int mouseX, int mouseY) {
/*  93 */     ScaledResolution scaledResolution = new ScaledResolution(this.mc);
/*     */ 
/*     */     
/*  96 */     if (Cosmos.INSTANCE.getAltManager().getAltEntries().isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 101 */     refreshOffsets();
/*     */ 
/*     */     
/* 104 */     if (mouseOver((scaledResolution.getScaledWidth() / 2.0F - 151.0F), 40.0D, 302.0D, (scaledResolution.getScaledHeight() - 25), mouseX, mouseY)) {
/* 105 */       int scroll = Mouse.getDWheel();
/* 106 */       if (scroll < 0) {
/*     */         
/* 108 */         if (getLastAlt().getOffset() - 1.0F < (scaledResolution.getScaledHeight() - 49)) {
/*     */           return;
/*     */         }
/*     */         
/* 112 */         Cosmos.INSTANCE.getAltManager().getAltEntries().forEach(entry -> entry.setOffset(entry.getOffset() - 16.0F));
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 117 */       else if (scroll > 0) {
/*     */         
/* 119 */         if (getFirstAlt().getOffset() >= 41.0F) {
/*     */           return;
/*     */         }
/*     */         
/* 123 */         Cosmos.INSTANCE.getAltManager().getAltEntries().forEach(entry -> entry.setOffset(entry.getOffset() + 16.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void actionPerformed(GuiButton button) throws IOException {
/* 132 */     super.actionPerformed(button);
/*     */     
/* 134 */     switch (button.id) {
/*     */       
/*     */       case 0:
/* 137 */         this.mc.displayGuiScreen(new AddAltGUI(this));
/*     */         break;
/*     */       
/*     */       case 1:
/* 141 */         if (getSelectedAltEntry() != null) {
/*     */           
/* 143 */           Cosmos.INSTANCE.getAltManager().getAltEntries().remove(getSelectedAltEntry());
/*     */ 
/*     */           
/* 146 */           altEntryOffset -= 32.0F;
/*     */ 
/*     */           
/* 149 */           if (!Cosmos.INSTANCE.getAltManager().getAltEntries().isEmpty()) {
/* 150 */             getFirstAlt().setOffset(41.0F);
/*     */           }
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 2:
/* 156 */         this.mc.displayGuiScreen(this.lastScreen);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onGuiClosed() {
/* 167 */     Cosmos.INSTANCE.getConfigManager().saveAlts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshOffsets() {
/* 175 */     float altOffset = getFirstAlt().getOffset();
/*     */     
/* 177 */     for (AltEntry altEntry : Cosmos.INSTANCE.getAltManager().getAltEntries()) {
/*     */       
/* 179 */       altEntry.setOffset(altOffset);
/*     */       
/* 181 */       altOffset += 32.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AltEntry getFirstAlt() {
/* 190 */     return Cosmos.INSTANCE.getAltManager().getAltEntries().get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AltEntry getLastAlt() {
/* 199 */     return Cosmos.INSTANCE.getAltManager().getAltEntries().get(Cosmos.INSTANCE.getAltManager().getAltEntries().size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AltEntry getSelectedAltEntry() {
/* 207 */     for (AltEntry altEntry : Cosmos.INSTANCE.getAltManager().getAltEntries()) {
/*     */       
/* 209 */       if (altEntry.isSelected) {
/* 210 */         return altEntry;
/*     */       }
/*     */     } 
/*     */     
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSelectedAltEntry(AltEntry newSelected) {
/* 223 */     for (AltEntry altEntry : Cosmos.INSTANCE.getAltManager().getAltEntries()) {
/* 224 */       altEntry.isSelected = (altEntry == newSelected);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void keyTyped(char typedChar, int keyCode) throws IOException {
/* 237 */     if (keyCode == 1) {
/* 238 */       this.mc.displayGuiScreen(this.lastScreen);
/*     */       
/*     */       return;
/*     */     } 
/* 242 */     super.keyTyped(typedChar, keyCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
/* 254 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */     
/* 256 */     for (AltEntry altEntry : Cosmos.INSTANCE.getAltManager().getAltEntries()) {
/* 257 */       if (altEntry.isMouseOverButton(mouseX, mouseY)) {
/*     */         
/* 259 */         if (altEntry.isSelected) {
/* 260 */           altEntry.whenClicked();
/*     */         }
/*     */ 
/*     */         
/* 264 */         setSelectedAltEntry(altEntry);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean mouseOver(double x, double y, double width, double height, int mouseX, int mouseY) {
/* 281 */     return (mouseX >= x && mouseY >= y && mouseX <= x + width && mouseY <= y + height);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\altgui\AltManagerGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
