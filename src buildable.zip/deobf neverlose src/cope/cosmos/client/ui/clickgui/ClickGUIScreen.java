//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.client.ClickGUIModule;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category.CategoryFrameComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.taskbar.Taskbar;
/*     */ import cope.cosmos.client.ui.util.InterfaceWrapper;
/*     */ import cope.cosmos.client.ui.util.MousePosition;
/*     */ import cope.cosmos.client.ui.util.ScissorStack;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClickGUIScreen
/*     */   extends GuiScreen
/*     */   implements InterfaceWrapper
/*     */ {
/*  31 */   private final MousePosition mouse = new MousePosition(Vec2f.ZERO, false, false, false, false);
/*     */ 
/*     */   
/*  34 */   private final LinkedList<CategoryFrameComponent> categoryFrameComponents = new LinkedList<>();
/*     */ 
/*     */   
/*  37 */   private final ScissorStack scissorStack = new ScissorStack();
/*     */ 
/*     */   
/*  40 */   private final Taskbar taskbar = new Taskbar();
/*     */ 
/*     */ 
/*     */   
/*     */   public ClickGUIScreen() {
/*  45 */     int frameSpace = 0;
/*  46 */     for (Category category : Category.values()) {
/*  47 */       if (!category.equals(Category.HIDDEN)) {
/*  48 */         this.categoryFrameComponents.add(new CategoryFrameComponent(category, new Vec2f((10 + frameSpace), 20.0F)));
/*  49 */         frameSpace += 110;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  56 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*     */ 
/*     */     
/*     */     try {
/*  60 */       drawDefaultBackground();
/*  61 */     } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.categoryFrameComponents.forEach(categoryFrameComponent -> categoryFrameComponent.drawComponent());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     CategoryFrameComponent focusedFrameComponent = this.categoryFrameComponents.stream().filter(categoryFrameComponent -> isMouseOver((categoryFrameComponent.getPosition()).x, (categoryFrameComponent.getPosition()).y + categoryFrameComponent.getTitle(), categoryFrameComponent.getWidth(), categoryFrameComponent.getHeight())).findFirst().orElse(null);
/*     */     
/*  76 */     if (focusedFrameComponent != null && Mouse.hasWheel()) {
/*     */ 
/*     */       
/*  79 */       int scroll = Mouse.getDWheel();
/*  80 */       focusedFrameComponent.onScroll(scroll);
/*     */     } 
/*     */ 
/*     */     
/*  84 */     this.taskbar.drawComponent();
/*     */     
/*  86 */     this.mouse.setLeftClick(false);
/*  87 */     this.mouse.setRightClick(false);
/*  88 */     this.mouse.setPosition(new Vec2f(mouseX, mouseY));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
/*  93 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */ 
/*     */     
/*  96 */     List<CategoryFrameComponent> reverseCategoryFrameComponents = new ArrayList<>();
/*     */     
/*  98 */     this.categoryFrameComponents.forEach(categoryFrameComponent -> reverseCategoryFrameComponents.add(categoryFrameComponent));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     Collections.reverse(reverseCategoryFrameComponents);
/*     */     
/* 105 */     switch (mouseButton) {
/*     */       case 0:
/* 107 */         this.mouse.setLeftClick(true);
/* 108 */         this.mouse.setLeftHeld(true);
/*     */ 
/*     */         
/* 111 */         for (CategoryFrameComponent categoryFrameComponent : reverseCategoryFrameComponents) {
/* 112 */           if (isMouseOver((categoryFrameComponent.getPosition()).x, (categoryFrameComponent.getPosition()).y, categoryFrameComponent.getWidth(), categoryFrameComponent.getTitle() + categoryFrameComponent.getHeight() + 2.0F)) {
/*     */ 
/*     */             
/* 115 */             categoryFrameComponent.onClick(ClickType.LEFT);
/*     */             
/* 117 */             int index = this.categoryFrameComponents.indexOf(categoryFrameComponent);
/*     */ 
/*     */             
/* 120 */             this.categoryFrameComponents.addLast(categoryFrameComponent);
/* 121 */             this.categoryFrameComponents.remove(index);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 1:
/* 129 */         this.mouse.setRightClick(true);
/* 130 */         this.mouse.setRightHeld(true);
/*     */ 
/*     */         
/* 133 */         for (CategoryFrameComponent categoryFrameComponent : reverseCategoryFrameComponents) {
/* 134 */           if (isMouseOver((categoryFrameComponent.getPosition()).x, (categoryFrameComponent.getPosition()).y, categoryFrameComponent.getWidth(), categoryFrameComponent.getTitle() + categoryFrameComponent.getHeight() + 2.0F)) {
/*     */ 
/*     */             
/* 137 */             categoryFrameComponent.onClick(ClickType.RIGHT);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 145 */     if (ClickType.getByIdentifier(mouseButton) != null) {
/* 146 */       for (CategoryFrameComponent categoryFrameComponent : reverseCategoryFrameComponents) {
/* 147 */         categoryFrameComponent.onClick(ClickType.getByIdentifier(mouseButton));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(int mouseX, int mouseY, int state) {
/* 157 */     super.mouseReleased(mouseX, mouseY, state);
/*     */     
/* 159 */     if (state == 0) {
/* 160 */       this.mouse.setLeftHeld(false);
/* 161 */       this.mouse.setRightHeld(false);
/*     */       
/* 163 */       this.categoryFrameComponents.forEach(categoryFrameComponent -> {
/*     */             categoryFrameComponent.setDragging(false);
/*     */             categoryFrameComponent.setExpanding(false);
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyTyped(char typedChar, int keyCode) throws IOException {
/* 172 */     super.keyTyped(typedChar, keyCode);
/*     */     
/* 174 */     this.categoryFrameComponents.forEach(categoryFrameComponent -> categoryFrameComponent.onType(keyCode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onGuiClosed() {
/* 181 */     super.onGuiClosed();
/*     */ 
/*     */     
/* 184 */     this.categoryFrameComponents.forEach(categoryFrameComponent -> categoryFrameComponent.setOpen(false));
/*     */ 
/*     */ 
/*     */     
/* 188 */     Cosmos.EVENT_BUS.unregister(this);
/*     */ 
/*     */     
/* 191 */     ClickGUIModule.INSTANCE.disable(true);
/*     */ 
/*     */     
/* 194 */     Cosmos.INSTANCE.getConfigManager().saveGUI();
/*     */     
/* 196 */     if (this.mc.entityRenderer.isShaderActive()) {
/* 197 */       this.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesGuiPauseGame() {
/* 203 */     return ((Boolean)ClickGUIModule.pauseGame.getValue()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderHUD(RenderGameOverlayEvent.Pre event) {
/* 210 */     if (!event.getType().equals(RenderGameOverlayEvent.ElementType.TEXT) && !event.getType().equals(RenderGameOverlayEvent.ElementType.CHAT)) {
/* 211 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedList<CategoryFrameComponent> getCategoryFrameComponents() {
/* 220 */     return this.categoryFrameComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScissorStack getScissorStack() {
/* 228 */     return this.scissorStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MousePosition getMouse() {
/* 236 */     return this.mouse;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\ClickGUIScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
