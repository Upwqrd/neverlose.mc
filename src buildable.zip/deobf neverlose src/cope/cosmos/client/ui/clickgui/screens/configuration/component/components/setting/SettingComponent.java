/*    */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*    */ 
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.client.ui.clickgui.screens.DrawableComponent;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SettingComponent<T>
/*    */   extends DrawableComponent
/*    */ {
/*    */   private final ModuleComponent moduleComponent;
/*    */   private final Setting<T> setting;
/* 20 */   public int HEIGHT = 14;
/*    */   
/*    */   public SettingComponent(ModuleComponent moduleComponent, Setting<T> setting) {
/* 23 */     this.moduleComponent = moduleComponent;
/* 24 */     this.setting = setting;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void drawComponent() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClick(ClickType in) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onType(int in) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onScroll(int in) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHeight(int in) {
/* 52 */     this.HEIGHT = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 60 */     return this.HEIGHT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ModuleComponent getModuleComponent() {
/* 68 */     return this.moduleComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Setting<T> getSetting() {
/* 76 */     return this.setting;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\SettingComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */