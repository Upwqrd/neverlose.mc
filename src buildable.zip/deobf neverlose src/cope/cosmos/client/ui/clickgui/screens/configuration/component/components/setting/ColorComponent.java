//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*     */ 
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*     */ import cope.cosmos.client.ui.util.ColorHSB;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorComponent
/*     */   extends SettingComponent<Color>
/*     */ {
/*     */   private float featureHeight;
/*     */   private boolean open;
/*     */   private final ColorHSB selectedColor;
/*  36 */   private final Animation animation = new Animation(300, false);
/*     */   private int hoverAnimation;
/*     */   
/*     */   public ColorComponent(ModuleComponent moduleComponent, Setting<Color> setting) {
/*  40 */     super(moduleComponent, setting);
/*     */ 
/*     */     
/*  43 */     this.selectedColor = new ColorHSB((Color)setting.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  48 */     super.drawComponent();
/*     */ 
/*     */     
/*  51 */     this.featureHeight = (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getSettingComponentOffset() + getModuleComponent().getCategoryFrameComponent().getScroll() + 2.0F;
/*     */ 
/*     */     
/*  54 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation < 25) {
/*  55 */       this.hoverAnimation += 5;
/*     */     
/*     */     }
/*  58 */     else if (!isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation > 0) {
/*  59 */       this.hoverAnimation -= 5;
/*     */     } 
/*     */ 
/*     */     
/*  63 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT, new Color(12 + this.hoverAnimation, 12 + this.hoverAnimation, 17 + this.hoverAnimation, 255));
/*  64 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, 2.0F, this.HEIGHT, ColorUtil.getPrimaryColor());
/*     */ 
/*     */     
/*  67 */     RenderUtil.drawRoundedRect(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 12.0F), (this.featureHeight + 2.0F), 10.0D, 10.0D, 2.0D, (Color)getSetting().getValue());
/*     */ 
/*     */     
/*  70 */     GL11.glScaled(0.55D, 0.55D, 0.55D);
/*  71 */     float scaledX = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F) * 1.8181818F;
/*  72 */     float scaledY = (this.featureHeight + 5.0F) * 1.8181818F;
/*  73 */     FontUtil.drawStringWithShadow(getSetting().getName(), scaledX, scaledY, -1);
/*     */ 
/*     */     
/*  76 */     GL11.glScaled(1.81818181D, 1.81818181D, 1.81818181D);
/*     */     
/*  78 */     if (this.animation.getAnimationFactor() > 0.0D) {
/*     */ 
/*     */       
/*  81 */       Vec2f circleCenter = new Vec2f((getModuleComponent().getCategoryFrameComponent().getPosition()).x + (getModuleComponent().getCategoryFrameComponent().getWidth() - 34) / 2.0F + 4.0F, this.featureHeight + this.HEIGHT + 34.0F);
/*     */       
/*  83 */       if (getMouse().isLeftHeld()) {
/*  84 */         if (isWithinCircle(circleCenter.x, circleCenter.y, 32.0D)) {
/*     */ 
/*     */           
/*  87 */           float xDistance = (getMouse().getPosition()).x - circleCenter.x;
/*  88 */           float yDistance = (getMouse().getPosition()).y - circleCenter.y;
/*     */ 
/*     */           
/*  91 */           double radius = Math.hypot(xDistance, yDistance);
/*  92 */           double angle = -Math.toDegrees(Math.atan2(yDistance, xDistance) + 1.5707963267948966D) % 360.0D;
/*     */ 
/*     */           
/*  95 */           this.selectedColor.setHue(angle / 360.0D);
/*  96 */           this.selectedColor.setSaturation(radius / 32.0D);
/*     */         } 
/*     */         
/*  99 */         if (isWithinRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 24.0F, this.featureHeight + this.HEIGHT + 4.0F, 62.0F)) {
/* 100 */           this.selectedColor.setBrightness((1.0F - ((getMouse().getPosition()).y - this.featureHeight + this.HEIGHT + 4.0F) / 64.0F));
/*     */         }
/*     */         
/* 103 */         if (isWithinRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 10.0F, this.featureHeight + this.HEIGHT + 4.0F, 62.0F)) {
/* 104 */           this.selectedColor.setTransparency((1.0F - ((getMouse().getPosition()).y - this.featureHeight + this.HEIGHT + 4.0F) / 64.0F));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 109 */       int color = Color.HSBtoRGB((float)this.selectedColor.getHue(), (float)this.selectedColor.getSaturation(), (float)this.selectedColor.getBrightness());
/*     */ 
/*     */       
/* 112 */       getSetting().setValue(new Color((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, MathHelper.clamp((float)this.selectedColor.getTransparency(), 0.0F, 1.0F)));
/*     */ 
/*     */       
/* 115 */       mc.getTextureManager().bindTexture(new ResourceLocation("cosmos", "textures/imgs/picker.png"));
/* 116 */       Gui.drawModalRectWithCustomSizedTexture((int)(getModuleComponent().getCategoryFrameComponent().getPosition()).x + 4, (int)this.featureHeight + this.HEIGHT + 2, 0.0F, 0.0F, getModuleComponent().getCategoryFrameComponent().getWidth() - 34, 64, (getModuleComponent().getCategoryFrameComponent().getWidth() - 34), 64.0F);
/* 117 */       RenderUtil.drawPolygon((float)(circleCenter.x + this.selectedColor.getSaturation() * 32.0D * Math.cos(Math.toRadians(this.selectedColor.getHue() * 360.0D) + 1.5707963267948966D)), (float)(circleCenter.y - this.selectedColor.getSaturation() * 32.0D * Math.sin(Math.toRadians(this.selectedColor.getHue() * 360.0D) + 1.5707963267948966D)), 1.5F, 360, Color.WHITE);
/*     */ 
/*     */       
/* 120 */       drawGradientRoundedRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 24.0F, this.featureHeight + this.HEIGHT + 2.0F, 3.0F, 62.0F, 2, false);
/* 121 */       RenderUtil.drawPolygon(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth()) - 22.5D, (this.featureHeight + this.HEIGHT) + 64.0D * (1.0D - this.selectedColor.getBrightness()) + 2.0D, 2.0F, 360, Color.WHITE);
/*     */ 
/*     */       
/* 124 */       drawGradientRoundedRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 10.0F, this.featureHeight + this.HEIGHT + 2.0F, 3.0F, 62.0F, 2, true);
/* 125 */       RenderUtil.drawPolygon(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth()) - 8.5D, (this.featureHeight + this.HEIGHT) + 64.0D * (1.0D - this.selectedColor.getTransparency()) + 2.0D, 2.0F, 360, Color.WHITE);
/*     */ 
/*     */       
/* 128 */       getModuleComponent().addSettingComponentOffset((float)(this.HEIGHT * 4.857D * this.animation.getAnimationFactor()));
/* 129 */       getModuleComponent().getCategoryFrameComponent().addComponentOffset(this.HEIGHT * 4.857D * this.animation.getAnimationFactor());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/* 136 */     if (in.equals(ClickType.RIGHT) && isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT)) {
/*     */ 
/*     */       
/* 139 */       float highestPoint = this.featureHeight;
/* 140 */       float lowestPoint = highestPoint + this.HEIGHT;
/*     */ 
/*     */       
/* 143 */       if (highestPoint >= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + 2.0F && lowestPoint <= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getCategoryFrameComponent().getHeight() + 2.0F) {
/* 144 */         this.open = !this.open;
/* 145 */         this.animation.setState(this.open);
/*     */       } 
/*     */ 
/*     */       
/* 149 */       getCosmos().getSoundManager().playSound("click");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawGradientRoundedRect(float x, float y, float width, float height, int radius, boolean transparency) {
/* 163 */     GL11.glPushAttrib(0);
/*     */     
/* 165 */     GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 166 */     x *= 2.0F;
/* 167 */     y *= 2.0F;
/* 168 */     width *= 2.0F;
/* 169 */     height *= 2.0F;
/*     */     
/* 171 */     width += x;
/* 172 */     height += y;
/*     */     
/* 174 */     GL11.glEnable(3042);
/* 175 */     GL11.glDisable(3553);
/* 176 */     GL11.glEnable(2848);
/* 177 */     GL11.glBegin(9);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     int color = Color.HSBtoRGB((float)this.selectedColor.getHue(), (float)this.selectedColor.getSaturation(), 1.0F);
/* 183 */     float red = (color >> 16 & 0xFF) / 255.0F;
/* 184 */     float green = (color >> 8 & 0xFF) / 255.0F;
/* 185 */     float blue = (color & 0xFF) / 255.0F;
/*     */     
/* 187 */     GL11.glColor4f(red, green, blue, 1.0F); int i;
/* 188 */     for (i = 0; i <= 90; i++) {
/* 189 */       GL11.glVertex2d((x + radius) + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, (y + radius) + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
/*     */     }
/*     */     
/* 192 */     if (transparency) {
/* 193 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } else {
/* 195 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/*     */     } 
/*     */     
/* 198 */     for (i = 90; i <= 180; i++) {
/* 199 */       GL11.glVertex2d((x + radius) + Math.sin(i * Math.PI / 180.0D) * radius * -1.0D, (height - radius) + Math.cos(i * Math.PI / 180.0D) * radius * -1.0D);
/*     */     }
/*     */     
/* 202 */     if (transparency) {
/* 203 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     }
/*     */     else {
/*     */       
/* 207 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
/*     */     } 
/*     */     
/* 210 */     for (i = 0; i <= 90; i++) {
/* 211 */       GL11.glVertex2d((width - radius) + Math.sin(i * Math.PI / 180.0D) * radius, (height - radius) + Math.cos(i * Math.PI / 180.0D) * radius);
/*     */     }
/*     */     
/* 214 */     GL11.glColor4f(red, green, blue, 1.0F);
/* 215 */     for (i = 90; i <= 180; i++) {
/* 216 */       GL11.glVertex2d((width - radius) + Math.sin(i * Math.PI / 180.0D) * radius, (y + radius) + Math.cos(i * Math.PI / 180.0D) * radius);
/*     */     }
/*     */     
/* 219 */     GL11.glEnd();
/* 220 */     GL11.glEnable(3553);
/* 221 */     GL11.glDisable(3042);
/* 222 */     GL11.glDisable(2848);
/* 223 */     GL11.glDisable(3042);
/* 224 */     GL11.glEnable(3553);
/*     */ 
/*     */     
/* 227 */     GL11.glScaled(2.0D, 2.0D, 2.0D);
/* 228 */     GL11.glPopAttrib();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWithinCircle(double x, double y, double radius) {
/* 239 */     return (Math.sqrt(StrictMath.pow((getMouse().getPosition()).x - x, 2.0D) + StrictMath.pow((getMouse().getPosition()).y - y, 2.0D)) <= radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWithinRect(float x, float y, float height) {
/* 250 */     return ((getMouse().getPosition()).x > x - 2.0F && (getMouse().getPosition()).y > y && (getMouse().getPosition()).x < x + 6.0F && (getMouse().getPosition()).y < y + height);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\ColorComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
