/*    */ package cope.cosmos.client.ui.clickgui.screens.configuration.component;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ClickType
/*    */ {
/* 14 */   LEFT(0),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 19 */   RIGHT(1),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   MIDDLE(2),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   SIDE_TOP(3),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   SIDE_BOTTOM(4);
/*    */   
/*    */   private final int identifier;
/*    */ 
/*    */   
/*    */   ClickType(int identifier) {
/* 40 */     this.identifier = identifier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getIdentifier() {
/* 48 */     return this.identifier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ClickType getByIdentifier(int in) {
/* 57 */     return Arrays.<ClickType>stream(values())
/* 58 */       .filter(value -> (value.getIdentifier() == in))
/* 59 */       .findFirst()
/* 60 */       .orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\ClickType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */