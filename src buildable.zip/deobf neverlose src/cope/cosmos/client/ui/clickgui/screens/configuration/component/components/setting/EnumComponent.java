//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*    */ 
/*    */ import cope.cosmos.client.features.setting.Setting;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*    */ import cope.cosmos.util.render.FontUtil;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import cope.cosmos.util.string.StringFormatter;
/*    */ import java.awt.Color;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumComponent
/*    */   extends SettingComponent<Enum<?>>
/*    */ {
/*    */   private float featureHeight;
/*    */   private int hoverAnimation;
/*    */   
/*    */   public EnumComponent(ModuleComponent moduleComponent, Setting<Enum<?>> setting) {
/* 28 */     super(moduleComponent, setting);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawComponent() {
/* 33 */     super.drawComponent();
/*    */ 
/*    */     
/* 36 */     this.featureHeight = (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getSettingComponentOffset() + getModuleComponent().getCategoryFrameComponent().getScroll() + 2.0F;
/*    */ 
/*    */     
/* 39 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation < 25) {
/* 40 */       this.hoverAnimation += 5;
/*    */     
/*    */     }
/* 43 */     else if (!isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation > 0) {
/* 44 */       this.hoverAnimation -= 5;
/*    */     } 
/*    */ 
/*    */     
/* 48 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT, new Color(12 + this.hoverAnimation, 12 + this.hoverAnimation, 17 + this.hoverAnimation, 255));
/* 49 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, 2.0F, this.HEIGHT, ColorUtil.getPrimaryColor());
/*    */     
/* 51 */     GL11.glScaled(0.55D, 0.55D, 0.55D);
/* 52 */     float scaledX = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F) * 1.8181818F;
/* 53 */     float scaledY = (this.featureHeight + 5.0F) * 1.8181818F;
/* 54 */     float scaledWidth = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - FontUtil.getStringWidth(StringFormatter.formatEnum((Enum)getSetting().getValue())) * 0.55F - 3.0F) * 1.8181818F;
/*    */ 
/*    */     
/* 57 */     FontUtil.drawStringWithShadow(getSetting().getName(), scaledX, scaledY, -1);
/*    */ 
/*    */     
/* 60 */     FontUtil.drawStringWithShadow(StringFormatter.formatEnum((Enum)getSetting().getValue()), scaledWidth, scaledY, -1);
/*    */ 
/*    */     
/* 63 */     GL11.glScaled(1.81818181D, 1.81818181D, 1.81818181D);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClick(ClickType in) {
/* 70 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT)) {
/*    */ 
/*    */       
/* 73 */       float highestPoint = this.featureHeight;
/* 74 */       float lowestPoint = highestPoint + this.HEIGHT;
/*    */ 
/*    */       
/* 77 */       if (highestPoint >= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + 2.0F && lowestPoint <= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getCategoryFrameComponent().getHeight() + 2.0F) {
/* 78 */         Enum<?> nextValue = null;
/*    */         
/* 80 */         if (in.equals(ClickType.LEFT)) {
/* 81 */           nextValue = (Enum)getSetting().getNextMode();
/*    */         
/*    */         }
/* 84 */         else if (in.equals(ClickType.RIGHT)) {
/* 85 */           nextValue = (Enum)getSetting().getLastMode();
/*    */         } 
/*    */ 
/*    */         
/* 89 */         if (nextValue != null) {
/* 90 */           getSetting().setValue(nextValue);
/*    */         }
/*    */       } 
/*    */ 
/*    */       
/* 95 */       getCosmos().getSoundManager().playSound("click");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\EnumComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
