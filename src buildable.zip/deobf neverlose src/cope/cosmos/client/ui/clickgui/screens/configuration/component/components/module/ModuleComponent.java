//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.clickgui.screens.DrawableComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category.CategoryFrameComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.BindComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.BooleanComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.ColorComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.DrawnComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.EnumComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.NumberComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting.SettingComponent;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleComponent
/*     */   extends DrawableComponent
/*     */ {
/*     */   public static final int HEIGHT = 14;
/*     */   private final CategoryFrameComponent categoryFrameComponent;
/*     */   private float featureHeight;
/*     */   private final Module module;
/*  40 */   private final List<SettingComponent<?>> settingComponents = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private float settingComponentOffset;
/*     */ 
/*     */   
/*  46 */   private final Animation animation = new Animation(300, false);
/*     */   
/*     */   private int hoverAnimation;
/*     */   
/*     */   private boolean open;
/*     */ 
/*     */   
/*     */   public ModuleComponent(CategoryFrameComponent categoryFrameComponent, Module module) {
/*  54 */     this.categoryFrameComponent = categoryFrameComponent;
/*  55 */     this.module = module;
/*     */     
/*  57 */     if (module != null) {
/*     */ 
/*     */       
/*  60 */       module.getSettings().forEach(setting -> {
/*     */             if (setting.getValue() instanceof Boolean) {
/*     */               this.settingComponents.add(new BooleanComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof Enum) {
/*     */               this.settingComponents.add(new EnumComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof cope.cosmos.client.features.setting.Bind) {
/*     */               this.settingComponents.add(new BindComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof AtomicBoolean) {
/*     */               this.settingComponents.add(new DrawnComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof Float) {
/*     */               this.settingComponents.add(new NumberComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof Double) {
/*     */               this.settingComponents.add(new NumberComponent(this, setting));
/*     */             } else if (setting.getValue() instanceof Color) {
/*     */               this.settingComponents.add(new ColorComponent(this, setting));
/*     */             } 
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       this.settingComponents.add(new DrawnComponent(this, new Setting("Drawn", new AtomicBoolean(true))));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  98 */     this.featureHeight = (float)(((this.categoryFrameComponent.getPosition()).y + this.categoryFrameComponent.getTitle()) + this.categoryFrameComponent.getComponentOffset() + this.categoryFrameComponent.getScroll() + 2.0D);
/*     */     
/* 100 */     if (this.module != null)
/*     */     {
/*     */       
/* 103 */       if (isMouseOver((this.categoryFrameComponent.getPosition()).x, this.featureHeight, this.categoryFrameComponent.getWidth(), 14.0F) && this.hoverAnimation < 25 && !this.categoryFrameComponent.isExpanding()) {
/* 104 */         this.hoverAnimation += 5;
/*     */       
/*     */       }
/* 107 */       else if (!isMouseOver((this.categoryFrameComponent.getPosition()).x, this.featureHeight, this.categoryFrameComponent.getWidth(), 14.0F) && this.hoverAnimation > 0) {
/* 108 */         this.hoverAnimation -= 5;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 113 */     this.categoryFrameComponent.addComponentOffset(14.0D);
/*     */     
/* 115 */     if (this.module != null)
/*     */     {
/*     */       
/* 118 */       if (this.animation.getAnimationFactor() > 0.0D) {
/* 119 */         this.settingComponentOffset = (int)this.categoryFrameComponent.getComponentOffset();
/* 120 */         this.settingComponents.forEach(settingComponent -> {
/*     */               if (settingComponent.getSetting().isVisible()) {
/*     */                 settingComponent.drawComponent();
/*     */ 
/*     */ 
/*     */                 
/*     */                 this.settingComponentOffset += settingComponent.getHeight();
/*     */ 
/*     */                 
/*     */                 this.categoryFrameComponent.addComponentOffset(settingComponent.getHeight() * this.animation.getAnimationFactor());
/*     */               } 
/*     */             });
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 136 */     RenderUtil.drawRect((this.categoryFrameComponent.getPosition()).x, this.featureHeight, this.categoryFrameComponent.getWidth(), 14.0F, new Color(23 + this.hoverAnimation, 23 + this.hoverAnimation, 29 + this.hoverAnimation, 255));
/*     */     
/* 138 */     if (this.module != null) {
/*     */ 
/*     */       
/* 141 */       GL11.glScaled(0.8D, 0.8D, 0.8D);
/*     */ 
/*     */       
/* 144 */       float scaledX = ((this.categoryFrameComponent.getPosition()).x + 4.0F) * 1.25F;
/* 145 */       float scaledY = (this.featureHeight + 4.5F) * 1.25F;
/* 146 */       float scaledWidth = ((this.categoryFrameComponent.getPosition()).x + this.categoryFrameComponent.getWidth() - FontUtil.getStringWidth("...") * 0.8F - 3.0F) * 1.25F;
/*     */       
/* 148 */       FontUtil.drawStringWithShadow(getModule().getName(), scaledX, scaledY, getModule().isEnabled() ? ColorUtil.getPrimaryColor().getRGB() : Color.WHITE.getRGB());
/* 149 */       FontUtil.drawStringWithShadow("...", scaledWidth, scaledY - 3.0F, (new Color(255, 255, 255)).getRGB());
/*     */ 
/*     */       
/* 152 */       GL11.glScaled(1.25D, 1.25D, 1.25D);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/* 158 */     if (this.module != null) {
/*     */ 
/*     */       
/* 161 */       if (isMouseOver((this.categoryFrameComponent.getPosition()).x, this.featureHeight, this.categoryFrameComponent.getWidth(), 14.0F)) {
/*     */ 
/*     */         
/* 164 */         float highestPoint = this.featureHeight;
/* 165 */         float lowestPoint = highestPoint + 14.0F;
/*     */ 
/*     */         
/* 168 */         if (highestPoint >= (this.categoryFrameComponent.getPosition()).y + this.categoryFrameComponent.getTitle() + 2.0F && lowestPoint <= (this.categoryFrameComponent.getPosition()).y + this.categoryFrameComponent.getTitle() + this.categoryFrameComponent.getHeight() + 2.0F) {
/* 169 */           if (in.equals(ClickType.LEFT)) {
/* 170 */             this.module.toggle();
/*     */           
/*     */           }
/* 173 */           else if (in.equals(ClickType.RIGHT)) {
/* 174 */             this.open = !this.open;
/* 175 */             this.animation.setState(this.open);
/*     */           } 
/*     */ 
/*     */           
/* 179 */           getCosmos().getSoundManager().playSound("click");
/*     */         } 
/*     */       } 
/*     */       
/* 183 */       if (this.open) {
/* 184 */         this.settingComponents.forEach(settingComponent -> settingComponent.onClick(in));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onType(int in) {
/* 193 */     if (this.module != null && 
/* 194 */       this.open) {
/* 195 */       this.settingComponents.forEach(settingComponent -> settingComponent.onType(in));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onScroll(int in) {
/* 204 */     if (this.module != null && 
/* 205 */       this.open) {
/* 206 */       this.settingComponents.forEach(settingComponent -> settingComponent.onScroll(in));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryFrameComponent getCategoryFrameComponent() {
/* 218 */     return this.categoryFrameComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module getModule() {
/* 226 */     return this.module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSettingComponentOffset(float in) {
/* 234 */     this.settingComponentOffset += in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSettingComponentOffset() {
/* 242 */     return this.settingComponentOffset;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\module\ModuleComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
