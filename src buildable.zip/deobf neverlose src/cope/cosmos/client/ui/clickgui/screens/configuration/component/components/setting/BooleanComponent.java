//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.events.client.SettingUpdateEvent;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanComponent
/*     */   extends SettingComponent<Boolean>
/*     */ {
/*     */   private float featureHeight;
/*  28 */   private final Animation animation = new Animation(100, ((Boolean)getSetting().getValue()).booleanValue());
/*     */   private int hoverAnimation;
/*     */   
/*     */   public BooleanComponent(ModuleComponent moduleComponent, Setting<Boolean> setting) {
/*  32 */     super(moduleComponent, setting);
/*  33 */     Cosmos.EVENT_BUS.register(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  38 */     super.drawComponent();
/*     */ 
/*     */     
/*  41 */     this.featureHeight = (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getSettingComponentOffset() + getModuleComponent().getCategoryFrameComponent().getScroll() + 2.0F;
/*     */ 
/*     */     
/*  44 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation < 25) {
/*  45 */       this.hoverAnimation += 5;
/*     */     
/*     */     }
/*  48 */     else if (!isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation > 0) {
/*  49 */       this.hoverAnimation -= 5;
/*     */     } 
/*     */ 
/*     */     
/*  53 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT, new Color(12 + this.hoverAnimation, 12 + this.hoverAnimation, 17 + this.hoverAnimation, 255));
/*  54 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, 2.0F, this.HEIGHT, ColorUtil.getPrimaryColor());
/*     */ 
/*     */     
/*  57 */     RenderUtil.drawRoundedRect(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 12.0F), (this.featureHeight + 2.0F), 10.0D, 10.0D, 2.0D, new Color(22 + this.hoverAnimation, 22 + this.hoverAnimation, 28 + this.hoverAnimation));
/*     */     
/*  59 */     if (this.animation.getAnimationFactor() > 0.0D) {
/*  60 */       RenderUtil.drawRoundedRect(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - 7.0F) - 5.0D * this.animation.getAnimationFactor(), (this.featureHeight + 7.0F) - 5.0D * this.animation.getAnimationFactor(), 10.0D * this.animation.getAnimationFactor(), 10.0D * this.animation.getAnimationFactor(), 2.0D, ColorUtil.getPrimaryColor());
/*     */     }
/*     */ 
/*     */     
/*  64 */     GL11.glScaled(0.55D, 0.55D, 0.55D);
/*  65 */     float scaledX = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F) * 1.8181818F;
/*  66 */     float scaledY = (this.featureHeight + 5.0F) * 1.8181818F;
/*  67 */     FontUtil.drawStringWithShadow(getSetting().getName(), scaledX, scaledY, -1);
/*     */ 
/*     */     
/*  70 */     GL11.glScaled(1.81818181D, 1.81818181D, 1.81818181D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/*  76 */     if (in.equals(ClickType.LEFT) && isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT)) {
/*     */ 
/*     */       
/*  79 */       float highestPoint = this.featureHeight;
/*  80 */       float lowestPoint = highestPoint + this.HEIGHT;
/*     */ 
/*     */       
/*  83 */       if (highestPoint >= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + 2.0F && lowestPoint <= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getCategoryFrameComponent().getHeight() + 2.0F) {
/*  84 */         boolean previousValue = ((Boolean)getSetting().getValue()).booleanValue();
/*     */ 
/*     */         
/*  87 */         this.animation.setState(!previousValue);
/*  88 */         getSetting().setValue(Boolean.valueOf(!previousValue));
/*     */       } 
/*     */ 
/*     */       
/*  92 */       getCosmos().getSoundManager().playSound("click");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingUpdate(SettingUpdateEvent event) {
/* 101 */     if (event.getSetting().equals(getSetting()))
/*     */     {
/*     */       
/* 104 */       this.animation.setStateHard(((Boolean)event.getSetting().getValue()).booleanValue());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\BooleanComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
