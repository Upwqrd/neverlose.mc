//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.FrameComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JFrame;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CategoryFrameComponent
/*     */   extends FrameComponent<Category>
/*     */   implements Wrapper
/*     */ {
/*  30 */   private final List<ModuleComponent> moduleComponents = new ArrayList<>();
/*     */ 
/*     */   
/*  33 */   private float height = 196.0F;
/*     */ 
/*     */   
/*     */   private boolean open = true;
/*     */ 
/*     */   
/*     */   private boolean expand;
/*     */   
/*     */   private double featureOffset;
/*     */   
/*     */   private float scroll;
/*     */   
/*     */   private int hoverAnimation;
/*     */   
/*  47 */   private final Animation animation = new Animation(300, true);
/*     */ 
/*     */   
/*  50 */   private final JFrame frame = new JFrame();
/*     */   
/*     */   public CategoryFrameComponent(Category value, Vec2f position) {
/*  53 */     super(value, position);
/*     */ 
/*     */     
/*  56 */     getCosmos().getModuleManager().getAllModules().forEach(module -> {
/*     */           if (module.getCategory().equals(getValue())) {
/*     */             this.moduleComponents.add(new ModuleComponent(this, module));
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  63 */     for (int i = 0; i < 100; i++) {
/*  64 */       this.moduleComponents.add(new ModuleComponent(this, null));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  71 */     if (this.open) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       long interactingWindows = getGUI().getCategoryFrameComponents().stream().filter(categoryFrameComponent -> !categoryFrameComponent.equals(this)).filter(categoryFrameComponent -> (categoryFrameComponent.isExpanding() || categoryFrameComponent.isDragging())).count();
/*     */       
/*  78 */       if (interactingWindows <= 0L) {
/*  79 */         if (isMouseOver((getPosition()).x, (getPosition()).y + 20.0F + this.height + 2.0F, 100.0F, 4.0F) && getMouse().isLeftHeld()) {
/*  80 */           setExpanding(true);
/*     */         }
/*     */         
/*  83 */         if (isExpanding()) {
/*  84 */           this.height = MathHelper.clamp((getMouse().getPosition()).y - (getPosition()).y - 20.0F - 2.0F, 0.0F, 350.0F);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  89 */     super.drawComponent();
/*     */ 
/*     */     
/*  92 */     double scaledComponentOffset = getComponentOffset() - 1400.0D;
/*  93 */     this.scroll = (float)MathHelper.clamp(this.scroll, -Math.max(0.0D, scaledComponentOffset - this.height), 0.0D);
/*     */ 
/*     */     
/*  96 */     GL11.glScaled(1.05D, 1.05D, 1.05D);
/*  97 */     String windowTitle = StringFormatter.formatEnum((Enum)getValue());
/*     */ 
/*     */     
/* 100 */     float scaledX = ((getPosition()).x + ((getPosition()).x + 100.0F - (getPosition()).x) / 2.0F - FontUtil.getStringWidth(windowTitle) / 2.0F - 2.0F) * 0.95238096F;
/* 101 */     float scaledY = ((getPosition()).y + 20.0F - 14.0F) * 0.95238096F;
/*     */ 
/*     */     
/* 104 */     FontUtil.drawStringWithShadow(windowTitle, scaledX, scaledY, (new Color(255, 255, 255)).getRGB());
/*     */ 
/*     */     
/* 107 */     GL11.glScaled(0.95238095D, 0.95238095D, 0.95238095D);
/*     */ 
/*     */     
/* 110 */     if (this.animation.getAnimationFactor() > 0.0D) {
/*     */ 
/*     */       
/* 113 */       getScissorStack().pushScissor((int)(getPosition()).x, (int)(getPosition()).y + 20 + 2, 100, (int)(this.height * this.animation.getAnimationFactor()));
/*     */ 
/*     */       
/* 116 */       RenderUtil.drawRect((getPosition()).x, (getPosition()).y + 20.0F + 2.0F, 100.0F, (float)(this.height * this.animation.getAnimationFactor()), new Color(23, 23, 29, 255));
/*     */       
/* 118 */       this.featureOffset = 0.0D;
/* 119 */       this.moduleComponents.forEach(moduleComponent -> moduleComponent.drawComponent());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 124 */       getScissorStack().popScissor();
/*     */     } 
/*     */ 
/*     */     
/* 128 */     ScaledResolution resolution = new ScaledResolution(mc);
/* 129 */     this.frame.setSize(resolution.getScaledWidth(), resolution.getScaledHeight());
/*     */ 
/*     */     
/* 132 */     if (isMouseOver((getPosition()).x, (getPosition()).y + 20.0F + this.height + 2.0F, 100.0F, 4.0F)) {
/* 133 */       if (this.hoverAnimation < 25) {
/* 134 */         this.hoverAnimation += 5;
/*     */       }
/*     */ 
/*     */       
/* 138 */       this.frame.setCursor(new Cursor(9));
/*     */     
/*     */     }
/* 141 */     else if (!isMouseOver((getPosition()).x, (getPosition()).y + 20.0F + this.height + 2.0F, 100.0F, 4.0F)) {
/* 142 */       if (this.hoverAnimation > 0) {
/* 143 */         this.hoverAnimation -= 5;
/*     */       }
/*     */ 
/*     */       
/* 147 */       this.frame.setCursor(Cursor.getDefaultCursor());
/*     */     } 
/*     */ 
/*     */     
/* 151 */     RenderUtil.drawRect((getPosition()).x, (float)(((getPosition()).y + 20.0F) + this.height * this.animation.getAnimationFactor() + 2.0D), 100.0F, 4.0F, new Color(23 + this.hoverAnimation, 23 + this.hoverAnimation, 29 + this.hoverAnimation, 255));
/*     */ 
/*     */     
/* 154 */     updatePreviousPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/* 159 */     super.onClick(in);
/*     */     
/* 161 */     if (!isInteracting()) {
/*     */ 
/*     */       
/* 164 */       if (in.equals(ClickType.RIGHT) && isMouseOver((getPosition()).x, (getPosition()).y, 100.0F, 20.0F)) {
/* 165 */         this.open = !this.open;
/* 166 */         this.animation.setState(this.open);
/*     */ 
/*     */         
/* 169 */         getCosmos().getSoundManager().playSound("click");
/*     */       } 
/*     */       
/* 172 */       if (this.open) {
/* 173 */         this.moduleComponents.forEach(moduleComponent -> moduleComponent.onClick(in));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onType(int in) {
/* 182 */     super.onType(in);
/*     */     
/* 184 */     if (this.open) {
/* 185 */       this.moduleComponents.forEach(moduleComponent -> moduleComponent.onType(in));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onScroll(int in) {
/* 194 */     super.onScroll(in);
/*     */     
/* 196 */     if (this.open) {
/*     */ 
/*     */       
/* 199 */       this.scroll = (float)(this.scroll + in * 0.05D);
/*     */       
/* 201 */       this.moduleComponents.forEach(moduleComponent -> moduleComponent.onScroll(in));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getScroll() {
/* 212 */     return this.scroll;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 220 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeight(float in) {
/* 228 */     this.height = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInteracting() {
/* 236 */     return (isExpanding() || isDragging());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpanding() {
/* 244 */     return this.expand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpanding(boolean in) {
/* 252 */     this.expand = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getComponentOffset() {
/* 260 */     return this.featureOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addComponentOffset(double in) {
/* 268 */     this.featureOffset += in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOpen(boolean in) {
/* 276 */     this.open = in;
/* 277 */     this.animation.setState(in);
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\category\CategoryFrameComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
