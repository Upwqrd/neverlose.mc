//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components;
/*     */ 
/*     */ import cope.cosmos.client.ui.clickgui.screens.DrawableComponent;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.category.CategoryFrameComponent;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameComponent<T>
/*     */   extends DrawableComponent
/*     */ {
/*     */   public static final int WIDTH = 100;
/*     */   public static final int TITLE = 20;
/*     */   private final T value;
/*     */   private Vec2f position;
/*     */   private Vec2f previousPosition;
/*     */   private boolean drag;
/*     */   private int hoverAnimation;
/*     */   
/*     */   public FrameComponent(T value, Vec2f position) {
/*  34 */     this.value = value;
/*  35 */     this.position = position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  44 */     long interactingWindows = getGUI().getCategoryFrameComponents().stream().filter(categoryFrameComponent -> !categoryFrameComponent.equals(this)).filter(categoryFrameComponent -> (categoryFrameComponent.isExpanding() || categoryFrameComponent.isDragging())).count();
/*     */ 
/*     */     
/*  47 */     if (interactingWindows <= 0L) {
/*  48 */       if (isMouseOver(this.position.x, this.position.y, 100.0F, 20.0F) && getMouse().isLeftHeld()) {
/*  49 */         setDragging(true);
/*     */       }
/*     */ 
/*     */       
/*  53 */       if (isDragging()) {
/*  54 */         setPosition(new Vec2f(this.position.x + (getMouse().getPosition()).x - this.previousPosition.x, this.position.y + (getMouse().getPosition()).y - this.previousPosition.y));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  59 */     if (isMouseOver(this.position.x, this.position.y, 100.0F, 20.0F) && this.hoverAnimation < 25) {
/*  60 */       this.hoverAnimation += 5;
/*     */     
/*     */     }
/*  63 */     else if (!isMouseOver(this.position.x, this.position.y, 100.0F, 20.0F) && this.hoverAnimation > 0) {
/*  64 */       this.hoverAnimation -= 5;
/*     */     } 
/*     */ 
/*     */     
/*  68 */     RenderUtil.drawRect(this.position.x, this.position.y, 100.0F, 20.0F, new Color(23 + this.hoverAnimation, 23 + this.hoverAnimation, 29 + this.hoverAnimation, 255));
/*  69 */     RenderUtil.drawRect(this.position.x, this.position.y + 20.0F, 100.0F, 2.0F, ColorUtil.getPrimaryColor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onType(int in) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onScroll(int in) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  88 */     return 100;
/*     */   }
/*     */   
/*     */   public int getTitle() {
/*  92 */     return 20;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/* 100 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec2f getPosition() {
/* 108 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Vec2f in) {
/* 116 */     this.position = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec2f getPreviousPosition() {
/* 124 */     return this.previousPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updatePreviousPosition() {
/* 131 */     this.previousPosition = new Vec2f((getMouse().getPosition()).x, (getMouse().getPosition()).y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDragging() {
/* 139 */     return this.drag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDragging(boolean in) {
/* 147 */     this.drag = in;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\FrameComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
