package cope.cosmos.client.ui.clickgui.screens;

import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
import cope.cosmos.client.ui.util.InterfaceWrapper;
import cope.cosmos.util.Wrapper;

public abstract class DrawableComponent implements InterfaceWrapper, Wrapper {
  public abstract void drawComponent();
  
  public abstract void onClick(ClickType paramClickType);
  
  public abstract void onType(int paramInt);
  
  public abstract void onScroll(int paramInt);
}


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\DrawableComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */