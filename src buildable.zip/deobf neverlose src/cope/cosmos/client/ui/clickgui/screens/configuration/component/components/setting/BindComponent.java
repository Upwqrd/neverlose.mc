//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*     */ 
/*     */ import cope.cosmos.client.features.setting.Bind;
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindComponent
/*     */   extends SettingComponent<Bind>
/*     */ {
/*     */   private float featureHeight;
/*     */   private int hoverAnimation;
/*     */   private boolean binding;
/*     */   
/*     */   public BindComponent(ModuleComponent moduleComponent, Setting<Bind> setting) {
/*  33 */     super(moduleComponent, setting);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  38 */     super.drawComponent();
/*     */ 
/*     */     
/*  41 */     this.featureHeight = (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getSettingComponentOffset() + getModuleComponent().getCategoryFrameComponent().getScroll() + 2.0F;
/*     */ 
/*     */     
/*  44 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation < 25) {
/*  45 */       this.hoverAnimation += 5;
/*     */     
/*     */     }
/*  48 */     else if (!isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation > 0) {
/*  49 */       this.hoverAnimation -= 5;
/*     */     } 
/*     */ 
/*     */     
/*  53 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT, new Color(12 + this.hoverAnimation, 12 + this.hoverAnimation, 17 + this.hoverAnimation, 255));
/*  54 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, 2.0F, this.HEIGHT, ColorUtil.getPrimaryColor());
/*     */     
/*  56 */     GL11.glScaled(0.55D, 0.55D, 0.55D);
/*     */ 
/*     */     
/*  59 */     String keyName = ((Bind)getSetting().getValue()).getButtonName();
/*     */     
/*  61 */     float scaledX = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F) * 1.8181818F;
/*  62 */     float scaledY = (this.featureHeight + 5.0F) * 1.8181818F;
/*  63 */     float scaledWidth = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - FontUtil.getStringWidth(this.binding ? "Listening ..." : keyName) * 0.55F - 3.0F) * 1.8181818F;
/*     */ 
/*     */     
/*  66 */     FontUtil.drawStringWithShadow(getSetting().getName(), scaledX, scaledY, -1);
/*     */ 
/*     */     
/*  69 */     FontUtil.drawStringWithShadow(this.binding ? "Listening ..." : keyName, scaledWidth, scaledY, -1);
/*     */ 
/*     */     
/*  72 */     GL11.glScaled(1.81818181D, 1.81818181D, 1.81818181D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/*  78 */     if (in.equals(ClickType.LEFT) && isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT)) {
/*     */ 
/*     */       
/*  81 */       float highestPoint = this.featureHeight;
/*  82 */       float lowestPoint = highestPoint + this.HEIGHT;
/*     */ 
/*     */       
/*  85 */       if (highestPoint >= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + 2.0F && lowestPoint <= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getCategoryFrameComponent().getHeight() + 2.0F) {
/*  86 */         this.binding = !this.binding;
/*     */       }
/*     */ 
/*     */       
/*  90 */       getCosmos().getSoundManager().playSound("click");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  96 */     if (this.binding) {
/*  97 */       getSetting().setValue(new Bind(in.getIdentifier(), Bind.Device.MOUSE));
/*     */       
/*  99 */       this.binding = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onType(int in) {
/* 105 */     if (this.binding && 
/* 106 */       in != -1 && in != 1) {
/*     */ 
/*     */       
/* 109 */       if (in == 14 || in == 211) {
/* 110 */         getSetting().setValue(new Bind(0, Bind.Device.KEYBOARD));
/*     */       }
/*     */       else {
/*     */         
/* 114 */         getSetting().setValue(new Bind(in, Bind.Device.KEYBOARD));
/*     */       } 
/*     */ 
/*     */       
/* 118 */       this.binding = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\BindComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
