//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.clickgui.screens.configuration.component.components.setting;
/*     */ 
/*     */ import cope.cosmos.client.features.setting.Setting;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*     */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.components.module.ModuleComponent;
/*     */ import cope.cosmos.util.math.MathUtil;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberComponent
/*     */   extends SettingComponent<Number>
/*     */ {
/*     */   private float featureHeight;
/*     */   private int hoverAnimation;
/*     */   
/*     */   public NumberComponent(ModuleComponent moduleComponent, Setting<Number> setting) {
/*  29 */     super(moduleComponent, setting);
/*     */ 
/*     */     
/*  32 */     this.HEIGHT = 20;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawComponent() {
/*  37 */     super.drawComponent();
/*     */ 
/*     */     
/*  40 */     this.featureHeight = (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getSettingComponentOffset() + getModuleComponent().getCategoryFrameComponent().getScroll() + 2.0F;
/*     */ 
/*     */     
/*  43 */     if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation < 25) {
/*  44 */       this.hoverAnimation += 5;
/*     */     
/*     */     }
/*  47 */     else if (!isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT) && this.hoverAnimation > 0) {
/*  48 */       this.hoverAnimation -= 5;
/*     */     } 
/*     */ 
/*     */     
/*  52 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), this.HEIGHT, new Color(12 + this.hoverAnimation, 12 + this.hoverAnimation, 17 + this.hoverAnimation, 255));
/*  53 */     RenderUtil.drawRect((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, 2.0F, this.HEIGHT, ColorUtil.getPrimaryColor());
/*     */     
/*  55 */     GL11.glScaled(0.55D, 0.55D, 0.55D);
/*  56 */     float scaledX = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F) * 1.8181818F;
/*  57 */     float scaledY = (this.featureHeight + 5.0F) * 1.8181818F;
/*  58 */     float scaledWidth = ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + getModuleComponent().getCategoryFrameComponent().getWidth() - FontUtil.getStringWidth(String.valueOf(getSetting().getValue())) * 0.55F - 3.0F) * 1.8181818F;
/*     */ 
/*     */     
/*  61 */     FontUtil.drawStringWithShadow(getSetting().getName(), scaledX, scaledY, -1);
/*     */ 
/*     */     
/*  64 */     FontUtil.drawStringWithShadow(String.valueOf(getSetting().getValue()), scaledWidth, scaledY, -1);
/*     */ 
/*     */     
/*  67 */     GL11.glScaled(1.81818181D, 1.81818181D, 1.81818181D);
/*     */ 
/*     */     
/*  70 */     float highestPoint = this.featureHeight;
/*  71 */     float lowestPoint = highestPoint + this.HEIGHT;
/*     */ 
/*     */     
/*  74 */     if (highestPoint >= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + 2.0F && lowestPoint <= (getModuleComponent().getCategoryFrameComponent().getPosition()).y + getModuleComponent().getCategoryFrameComponent().getTitle() + getModuleComponent().getCategoryFrameComponent().getHeight() + 2.0F && 
/*  75 */       getMouse().isLeftHeld()) {
/*  76 */       if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight + 13.0F, getModuleComponent().getCategoryFrameComponent().getWidth(), (this.HEIGHT - 13))) {
/*     */         
/*  78 */         float percentFilled = ((getMouse().getPosition()).x - (getModuleComponent().getCategoryFrameComponent().getPosition()).x) * 130.0F / ((getModuleComponent().getCategoryFrameComponent().getPosition()).x + (getModuleComponent().getCategoryFrameComponent().getWidth() - 6) - (getModuleComponent().getCategoryFrameComponent().getPosition()).x);
/*     */         
/*  80 */         Number max = (Number)getSetting().getMax();
/*  81 */         Number min = (Number)getSetting().getMin();
/*     */ 
/*     */         
/*  84 */         if (getSetting().getValue() instanceof Double) {
/*  85 */           double valueSlid = MathHelper.clamp(MathUtil.roundDouble(percentFilled * (max.doubleValue() - min.doubleValue()) / 130.0D + min.doubleValue(), getSetting().getRoundingScale()), min.doubleValue(), max.doubleValue());
/*     */ 
/*     */           
/*  88 */           if (getSetting().isExclusion(Double.valueOf(valueSlid))) {
/*  89 */             getSetting().setValue(Double.valueOf(valueSlid + Math.pow(1.0D, -getSetting().getRoundingScale())));
/*     */           }
/*     */           else {
/*     */             
/*  93 */             getSetting().setValue(Double.valueOf(valueSlid));
/*     */           }
/*     */         
/*     */         }
/*  97 */         else if (getSetting().getValue() instanceof Float) {
/*  98 */           float valueSlid = MathHelper.clamp(MathUtil.roundFloat((percentFilled * (float)((max.floatValue() - min.floatValue()) / 130.0D) + min.floatValue()), getSetting().getRoundingScale()), min.floatValue(), max.floatValue());
/*     */ 
/*     */           
/* 101 */           if (getSetting().isExclusion(Float.valueOf(valueSlid))) {
/* 102 */             getSetting().setValue(Double.valueOf(valueSlid + Math.pow(1.0D, -getSetting().getRoundingScale())));
/*     */           }
/*     */           else {
/*     */             
/* 106 */             getSetting().setValue(Float.valueOf(valueSlid));
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 112 */       else if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight + 13.0F, 5.0F, (this.HEIGHT - 13))) {
/* 113 */         getSetting().setValue(getSetting().getMin());
/*     */ 
/*     */       
/*     */       }
/* 117 */       else if (isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x + (getModuleComponent().getCategoryFrameComponent().getWidth() - 5), this.featureHeight + 13.0F, 5.0F, (this.HEIGHT - 13))) {
/* 118 */         getSetting().setValue(getSetting().getMax());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 124 */     float sliderWidth = 91.0F * (((Number)getSetting().getValue()).floatValue() - ((Number)getSetting().getMin()).floatValue()) / (((Number)getSetting().getMax()).floatValue() - ((Number)getSetting().getMin()).floatValue());
/*     */ 
/*     */     
/* 127 */     if (sliderWidth < 2.0F) {
/* 128 */       sliderWidth = 2.0F;
/*     */     }
/*     */     
/* 131 */     if (sliderWidth > 91.0F) {
/* 132 */       sliderWidth = 91.0F;
/*     */     }
/*     */ 
/*     */     
/* 136 */     RenderUtil.drawRoundedRect(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F), (this.featureHeight + 14.0F), (getModuleComponent().getCategoryFrameComponent().getWidth() - 10), 3.0D, 2.0D, new Color(23 + this.hoverAnimation, 23 + this.hoverAnimation, 29 + this.hoverAnimation, 255));
/*     */     
/* 138 */     if (((Number)getSetting().getValue()).doubleValue() > ((Number)getSetting().getMin()).doubleValue()) {
/* 139 */       RenderUtil.drawRoundedRect(((getModuleComponent().getCategoryFrameComponent().getPosition()).x + 6.0F), (this.featureHeight + 14.0F), sliderWidth, 3.0D, 2.0D, ColorUtil.getPrimaryAlphaColor(255));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(ClickType in) {
/* 147 */     if (in.equals(ClickType.LEFT) && isMouseOver((getModuleComponent().getCategoryFrameComponent().getPosition()).x, this.featureHeight, getModuleComponent().getCategoryFrameComponent().getWidth(), (this.HEIGHT - 13)))
/*     */     {
/* 149 */       getCosmos().getSoundManager().playSound("click");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\component\components\setting\NumberComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
