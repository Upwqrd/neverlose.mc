//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.ui.clickgui.screens.configuration.taskbar;
/*    */ 
/*    */ import cope.cosmos.client.ui.clickgui.screens.DrawableComponent;
/*    */ import cope.cosmos.client.ui.clickgui.screens.configuration.component.ClickType;
/*    */ import cope.cosmos.util.render.FontUtil;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Taskbar
/*    */   extends DrawableComponent
/*    */ {
/*    */   public void drawComponent() {
/* 24 */     ScaledResolution resolution = new ScaledResolution(mc);
/*    */ 
/*    */     
/* 27 */     RenderUtil.drawRect(0.0F, (resolution.getScaledHeight() - 34), resolution.getScaledWidth(), 34.0F, new Color(23, 23, 29));
/*    */     
/* 29 */     GL11.glPushMatrix();
/*    */     
/* 31 */     GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
/*    */ 
/*    */     
/* 34 */     mc.getTextureManager().bindTexture(new ResourceLocation("cosmos", "textures/imgs/logotransparent.png"));
/* 35 */     GuiScreen.drawModalRectWithCustomSizedTexture(resolution.getScaledWidth() - 104, resolution.getScaledHeight() - 31, 0.0F, 0.0F, 104, 28, 104.0F, 28.0F);
/*    */     
/* 37 */     GL11.glPopMatrix();
/*    */     
/* 39 */     GL11.glPushMatrix();
/*    */ 
/*    */     
/* 42 */     float scaledWidth = (FontUtil.getStringWidth(mc.player.getName()) + 8) * 2.75F;
/*    */     
/* 44 */     RenderUtil.drawRect(0.0F, (resolution.getScaledHeight() - 44), scaledWidth, 44.0F, new Color(23, 23, 29));
/*    */ 
/*    */     
/* 47 */     GL11.glScaled(2.75D, 2.75D, 2.75D);
/* 48 */     float scaledX = 2.5454545F;
/* 49 */     float scaledY = (resolution.getScaledHeight() - 35) * 0.36363637F;
/* 50 */     FontUtil.drawStringWithShadow(mc.player.getName(), scaledX, scaledY, ColorUtil.getPrimaryColor().getRGB());
/*    */ 
/*    */     
/* 53 */     GL11.glScaled(0.3636363744735718D, 0.3636363744735718D, 0.3636363744735718D);
/*    */     
/* 55 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public void onClick(ClickType in) {}
/*    */   
/*    */   public void onType(int in) {}
/*    */   
/*    */   public void onScroll(int in) {}
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\clickgui\screens\configuration\taskbar\Taskbar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
