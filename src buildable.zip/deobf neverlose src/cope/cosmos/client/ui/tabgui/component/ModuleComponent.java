/*    */ package cope.cosmos.client.ui.tabgui.component;
/*    */ 
/*    */ import cope.cosmos.client.features.modules.Module;
/*    */ import cope.cosmos.client.ui.util.animation.Animation;
/*    */ import cope.cosmos.util.render.FontUtil;
/*    */ import cope.cosmos.util.render.RenderUtil;
/*    */ import cope.cosmos.util.string.ColorUtil;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleComponent
/*    */ {
/*    */   private final Module module;
/*    */   private final float x;
/*    */   private final float y;
/*    */   private final float width;
/* 30 */   private final Animation animation = new Animation(300, false);
/*    */   
/*    */   public ModuleComponent(float x, float y, float width, Module module) {
/* 33 */     this.x = x;
/* 34 */     this.y = y;
/* 35 */     this.width = width;
/* 36 */     this.module = module;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render() {
/* 41 */     RenderUtil.drawRect(this.x, this.y, this.width, 15.0F, (new Color(23, 23, 29, 255)).getRGB());
/*    */ 
/*    */     
/* 44 */     RenderUtil.drawRect(this.x, this.y, (float)(this.width * this.animation.getAnimationFactor()), 15.0F, (new Color(30, 30, 35, 255)).getRGB());
/*    */ 
/*    */     
/* 47 */     FontUtil.drawStringWithShadow(this.module.getName(), this.x + 6.0F, this.y + 4.0F, this.module.isEnabled() ? ColorUtil.getPrimaryColor().getRGB() : -1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRightArrow() {
/* 56 */     this.module.toggle();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelected(boolean selected) {
/* 64 */     this.animation.setState(selected);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\tabgui\component\ModuleComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */