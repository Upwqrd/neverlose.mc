//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.tabgui.component;
/*     */ 
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.features.modules.Module;
/*     */ import cope.cosmos.client.ui.util.ScissorStack;
/*     */ import cope.cosmos.client.ui.util.animation.Animation;
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import cope.cosmos.util.render.FontUtil;
/*     */ import cope.cosmos.util.render.RenderUtil;
/*     */ import cope.cosmos.util.string.ColorUtil;
/*     */ import cope.cosmos.util.string.StringFormatter;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CategoryComponent
/*     */   implements Wrapper
/*     */ {
/*     */   private final Category category;
/*     */   private final float x;
/*     */   private final float y;
/*     */   private boolean selected;
/*  38 */   private final Animation selectedAnimation = new Animation(300, false);
/*     */ 
/*     */   
/*  41 */   private final Animation expandAnimation = new Animation(300, false);
/*     */ 
/*     */   
/*  44 */   private final List<ModuleComponent> moduleComponents = new ArrayList<>();
/*     */ 
/*     */   
/*  47 */   private final ScissorStack scissorStack = new ScissorStack();
/*     */   
/*     */   private ModuleComponent currentSelected;
/*     */   
/*  51 */   private int currentSelectedIndex = 0;
/*     */   
/*     */   public CategoryComponent(float x, float y, Category category) {
/*  54 */     this.x = x;
/*  55 */     this.y = y;
/*  56 */     this.category = category;
/*     */ 
/*     */     
/*  59 */     float maxWidth = 4.0F;
/*  60 */     for (Module module : getCosmos().getModuleManager().getModules(module -> module.getCategory().equals(category))) {
/*     */ 
/*     */ 
/*     */       
/*  64 */       if ((mc.fontRenderer.getStringWidth(module.getName()) + 16) > maxWidth) {
/*  65 */         maxWidth = (mc.fontRenderer.getStringWidth(module.getName()) + 16);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  70 */     float yOffset = 0.0F;
/*  71 */     for (Module module : getCosmos().getModuleManager().getModules(module -> module.getCategory().equals(category))) {
/*     */       
/*  73 */       this.moduleComponents.add(new ModuleComponent(x + 73.0F, y + yOffset, maxWidth, module));
/*     */ 
/*     */       
/*  76 */       yOffset += 15.0F;
/*     */     } 
/*     */ 
/*     */     
/*  80 */     this.currentSelected = this.moduleComponents.get(0);
/*  81 */     this.currentSelected.setSelected(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void render() {
/*  86 */     RenderUtil.drawRect(this.x, this.y, 70.0F, 15.0F, (new Color(23, 23, 29, 255)).getRGB());
/*     */ 
/*     */     
/*  89 */     RenderUtil.drawRect(this.x, this.y, (float)(70.0D * this.selectedAnimation.getAnimationFactor()), 15.0F, (new Color(30, 30, 35, 255)).getRGB());
/*     */ 
/*     */     
/*  92 */     FontUtil.drawStringWithShadow(StringFormatter.formatEnum((Enum)this.category), this.x + 6.0F, this.y + 4.0F, this.selected ? ColorUtil.getPrimaryColor().getRGB() : -1);
/*     */ 
/*     */     
/*  95 */     if (this.expandAnimation.getAnimationFactor() > 0.0D) {
/*     */       
/*  97 */       this.scissorStack.pushScissor((int)(this.x + 73.0F), (int)this.y, (int)(100.0D * this.expandAnimation.getAnimationFactor()), (int)((this.moduleComponents.size() * 15 + 1) * this.expandAnimation.getAnimationFactor()));
/*     */ 
/*     */       
/* 100 */       this.moduleComponents.forEach(moduleComponent -> moduleComponent.render());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       this.scissorStack.popScissor();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 115 */     if (Keyboard.getEventKey() == 208) {
/* 116 */       this.currentSelected.setSelected(false);
/*     */ 
/*     */       
/* 119 */       this.currentSelectedIndex++;
/*     */ 
/*     */       
/* 122 */       if (this.currentSelectedIndex >= this.moduleComponents.size()) {
/* 123 */         this.currentSelectedIndex = 0;
/*     */       }
/*     */ 
/*     */       
/* 127 */       this.currentSelected = this.moduleComponents.get(this.currentSelectedIndex);
/* 128 */       this.currentSelected.setSelected(true);
/*     */ 
/*     */     
/*     */     }
/* 132 */     else if (Keyboard.getEventKey() == 200) {
/* 133 */       this.currentSelected.setSelected(false);
/*     */ 
/*     */       
/* 136 */       this.currentSelectedIndex--;
/*     */ 
/*     */       
/* 139 */       if (this.currentSelectedIndex < 0) {
/* 140 */         this.currentSelectedIndex = this.moduleComponents.size() - 1;
/*     */       }
/*     */ 
/*     */       
/* 144 */       this.currentSelected = this.moduleComponents.get(this.currentSelectedIndex);
/* 145 */       this.currentSelected.setSelected(true);
/*     */ 
/*     */     
/*     */     }
/* 149 */     else if (Keyboard.getEventKey() == 205) {
/* 150 */       this.currentSelected.onRightArrow();
/*     */ 
/*     */     
/*     */     }
/* 154 */     else if (Keyboard.getEventKey() == 203) {
/* 155 */       setExpanded(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelected(boolean selected) {
/* 164 */     this.selected = selected;
/* 165 */     this.selectedAnimation.setState(selected);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpanded(boolean expanded) {
/* 173 */     this.expandAnimation.setState(expanded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Animation getExpandAnimation() {
/* 181 */     return this.expandAnimation;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\tabgui\component\CategoryComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
