/*     */ package cope.cosmos.client.ui.tabgui;
/*     */ 
/*     */ import cope.cosmos.client.Cosmos;
/*     */ import cope.cosmos.client.features.modules.Category;
/*     */ import cope.cosmos.client.ui.tabgui.component.CategoryComponent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabGUI
/*     */ {
/*  19 */   private final List<CategoryComponent> categoryComponents = new ArrayList<>();
/*     */   
/*     */   private CategoryComponent currentSelected;
/*     */   
/*  23 */   private int currentSelectedIndex = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public TabGUI() {
/*  28 */     Cosmos.EVENT_BUS.register(this);
/*     */     
/*  30 */     float yOffset = 0.0F;
/*  31 */     for (Category category : Category.values()) {
/*     */ 
/*     */       
/*  34 */       if (!category.equals(Category.HIDDEN)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  39 */         this.categoryComponents.add(new CategoryComponent(4.0F, 16.0F + yOffset, category));
/*     */ 
/*     */         
/*  42 */         yOffset += 15.0F;
/*     */       } 
/*     */     } 
/*     */     
/*  46 */     this.currentSelected = this.categoryComponents.get(0);
/*  47 */     this.currentSelected.setSelected(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/*  53 */     this.categoryComponents.forEach(categoryComponent -> categoryComponent.render());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onKeyPress(InputEvent.KeyInputEvent event) {
/*  61 */     if (Keyboard.getEventKeyState())
/*     */     {
/*     */       
/*  64 */       if (this.currentSelected.getExpandAnimation().getAnimationFactor() < 1.0D) {
/*     */ 
/*     */         
/*  67 */         if (Keyboard.getEventKey() == 208) {
/*  68 */           this.currentSelected.setSelected(false);
/*     */ 
/*     */           
/*  71 */           this.currentSelectedIndex++;
/*     */ 
/*     */           
/*  74 */           if (this.currentSelectedIndex >= this.categoryComponents.size()) {
/*  75 */             this.currentSelectedIndex = 0;
/*     */           }
/*     */ 
/*     */           
/*  79 */           this.currentSelected = this.categoryComponents.get(this.currentSelectedIndex);
/*  80 */           this.currentSelected.setSelected(true);
/*     */ 
/*     */         
/*     */         }
/*  84 */         else if (Keyboard.getEventKey() == 200) {
/*  85 */           this.currentSelected.setSelected(false);
/*     */ 
/*     */           
/*  88 */           this.currentSelectedIndex--;
/*     */ 
/*     */           
/*  91 */           if (this.currentSelectedIndex < 0) {
/*  92 */             this.currentSelectedIndex = this.categoryComponents.size() - 1;
/*     */           }
/*     */ 
/*     */           
/*  96 */           this.currentSelected = this.categoryComponents.get(this.currentSelectedIndex);
/*  97 */           this.currentSelected.setSelected(true);
/*     */ 
/*     */         
/*     */         }
/* 101 */         else if (Keyboard.getEventKey() == 205) {
/*     */ 
/*     */           
/* 104 */           this.currentSelected.setExpanded(true);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 110 */         this.currentSelected.onKeyInput(event);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\ui\tabgui\TabGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */