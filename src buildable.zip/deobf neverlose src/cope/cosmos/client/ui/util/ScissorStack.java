//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.ui.util;
/*    */ 
/*    */ import cope.cosmos.util.Wrapper;
/*    */ import java.awt.Rectangle;
/*    */ import java.util.LinkedList;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScissorStack
/*    */   implements Wrapper
/*    */ {
/* 18 */   private final LinkedList<Rectangle> scissorStack = new LinkedList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void pushScissor(int x, int y, int width, int height) {
/*    */     Rectangle scissor;
/* 31 */     ScaledResolution resolution = new ScaledResolution(mc);
/*    */ 
/*    */     
/* 34 */     int sx = x * resolution.getScaleFactor();
/* 35 */     int sy = (resolution.getScaledHeight() - y + height) * resolution.getScaleFactor();
/* 36 */     int sWidth = (x + width - x) * resolution.getScaleFactor();
/* 37 */     int sHeight = (y + height - y) * resolution.getScaleFactor();
/*    */     
/* 39 */     if (!this.scissorStack.isEmpty()) {
/* 40 */       GL11.glDisable(3089);
/*    */       
/* 42 */       Rectangle last = this.scissorStack.getLast();
/*    */       
/* 44 */       int nx = Math.max(sx, last.x);
/* 45 */       int ny = Math.max(sy, last.y);
/*    */       
/* 47 */       int hDiff = sx - nx;
/* 48 */       int nWidth = Math.min(Math.min(last.width + last.x - sx, last.width), sWidth + hDiff);
/*    */       
/* 50 */       int diff = sy - ny;
/* 51 */       int nHeight = Math.min(Math.min(last.height + last.y - sy, last.height), hDiff + diff);
/*    */       
/* 53 */       scissor = new Rectangle(nx, ny, nWidth, nHeight);
/*    */     }
/*    */     else {
/*    */       
/* 57 */       scissor = new Rectangle(sx, sy, sWidth, sHeight);
/*    */     } 
/*    */     
/* 60 */     GL11.glEnable(3089);
/*    */     
/* 62 */     if (scissor.width > 0 && scissor.height > 0) {
/* 63 */       GL11.glScissor(scissor.x, scissor.y, scissor.width, scissor.height);
/*    */     }
/*    */     else {
/*    */       
/* 67 */       GL11.glScissor(0, 0, 0, 0);
/*    */     } 
/*    */     
/* 70 */     this.scissorStack.add(scissor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void popScissor() {
/* 77 */     if (!this.scissorStack.isEmpty()) {
/* 78 */       GL11.glDisable(3089);
/* 79 */       this.scissorStack.removeLast();
/*    */       
/* 81 */       if (!this.scissorStack.isEmpty()) {
/* 82 */         Rectangle scissor = this.scissorStack.getLast();
/* 83 */         GL11.glEnable(3089);
/* 84 */         GL11.glScissor(scissor.x, scissor.y, scissor.width, scissor.height);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\ScissorStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
