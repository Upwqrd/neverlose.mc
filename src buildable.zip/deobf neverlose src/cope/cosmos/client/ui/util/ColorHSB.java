/*    */ package cope.cosmos.client.ui.util;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorHSB
/*    */ {
/*    */   private double hue;
/*    */   private double saturation;
/*    */   private double brightness;
/*    */   private double transparency;
/*    */   
/*    */   public ColorHSB(double hue, double saturation, double brightness, double transparency) {
/* 16 */     this.hue = hue;
/* 17 */     this.saturation = saturation;
/* 18 */     this.brightness = brightness;
/* 19 */     this.transparency = transparency;
/*    */   }
/*    */   
/*    */   public ColorHSB(Color color) {
/* 23 */     float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
/*    */ 
/*    */     
/* 26 */     this.hue = hsb[0];
/* 27 */     this.saturation = hsb[1];
/* 28 */     this.brightness = hsb[2];
/* 29 */     this.transparency = (color.getAlpha() / 255.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getHue() {
/* 37 */     return this.hue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHue(double in) {
/* 45 */     this.hue = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getSaturation() {
/* 53 */     return this.saturation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSaturation(double in) {
/* 61 */     this.saturation = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getBrightness() {
/* 69 */     return this.brightness;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBrightness(double in) {
/* 77 */     this.brightness = in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getTransparency() {
/* 85 */     return this.transparency;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransparency(double in) {
/* 93 */     this.transparency = in;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\ColorHSB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */