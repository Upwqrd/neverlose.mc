/*    */ package cope.cosmos.client.ui.util;
/*    */ 
/*    */ import net.minecraft.util.math.Vec2f;
/*    */ 
/*    */ public class MousePosition
/*    */ {
/*    */   private Vec2f mousePosition;
/*    */   private boolean leftClick;
/*    */   
/*    */   public MousePosition(Vec2f mousePosition, boolean leftClick, boolean rightClick, boolean leftHeld, boolean rightHeld) {
/* 11 */     this.mousePosition = mousePosition;
/* 12 */     this.leftClick = leftClick;
/* 13 */     this.rightClick = rightClick;
/* 14 */     this.leftHeld = leftHeld;
/* 15 */     this.rightHeld = rightHeld;
/*    */   }
/*    */   private boolean rightClick; private boolean leftHeld; private boolean rightHeld;
/*    */   public boolean isLeftClick() {
/* 19 */     return this.leftClick;
/*    */   }
/*    */   
/*    */   public void setLeftClick(boolean in) {
/* 23 */     this.leftClick = in;
/*    */   }
/*    */   
/*    */   public boolean isRightClick() {
/* 27 */     return this.rightClick;
/*    */   }
/*    */   
/*    */   public void setRightClick(boolean in) {
/* 31 */     this.rightClick = in;
/*    */   }
/*    */   
/*    */   public boolean isLeftHeld() {
/* 35 */     return this.leftHeld;
/*    */   }
/*    */   
/*    */   public void setLeftHeld(boolean in) {
/* 39 */     this.leftHeld = in;
/*    */   }
/*    */   
/*    */   public boolean isRightHeld() {
/* 43 */     return this.rightHeld;
/*    */   }
/*    */   
/*    */   public void setRightHeld(boolean in) {
/* 47 */     this.rightHeld = in;
/*    */   }
/*    */   
/*    */   public void setPosition(Vec2f in) {
/* 51 */     this.mousePosition = in;
/*    */   }
/*    */   
/*    */   public Vec2f getPosition() {
/* 55 */     return this.mousePosition;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\MousePosition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */