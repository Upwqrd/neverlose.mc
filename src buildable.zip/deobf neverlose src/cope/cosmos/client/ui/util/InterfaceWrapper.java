//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*    */ package cope.cosmos.client.ui.util;
/*    */ 
/*    */ import cope.cosmos.client.Cosmos;
/*    */ import cope.cosmos.client.ui.clickgui.ClickGUIScreen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InterfaceWrapper
/*    */ {
/*    */   default boolean isMouseOver(float x, float y, float width, float height) {
/* 21 */     return ((getMouse().getPosition()).x >= x && (getMouse().getPosition()).y >= y && (getMouse().getPosition()).x <= x + width && (getMouse().getPosition()).y <= y + height);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MousePosition getMouse() {
/* 29 */     return getGUI().getMouse();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ScissorStack getScissorStack() {
/* 37 */     return getGUI().getScissorStack();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ClickGUIScreen getGUI() {
/* 45 */     return Cosmos.INSTANCE.getClickGUI();
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\InterfaceWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
