/*     */ package cope.cosmos.client.ui.util.animation;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Easing
/*     */ {
/*     */   LINEAR, SINE_IN, SINE_OUT, SINE_IN_OUT, QUAD_IN, QUAD_OUT, QUAD_IN_OUT, CUBIC_IN, CUBIC_OUT, CUBIC_IN_OUT, QUART_IN, QUART_OUT, QUART_IN_OUT, QUINT_IN, QUINT_OUT, QUINT_IN_OUT, EXPO_IN, EXPO_OUT, EXPO_IN_OUT, CIRC_IN, CIRC_OUT, CIRC_IN_OUT;
/*     */   private final Function<Double, Double> easeFunction;
/*     */   
/*     */   static {
/*  15 */     LINEAR = new Easing("LINEAR", 0, input -> input);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  20 */     SINE_IN = new Easing("SINE_IN", 1, input -> Double.valueOf(1.0D - Math.cos(input.doubleValue() * Math.PI) / 2.0D));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  25 */     SINE_OUT = new Easing("SINE_OUT", 2, input -> Double.valueOf(Math.sin(input.doubleValue() * Math.PI / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  30 */     SINE_IN_OUT = new Easing("SINE_IN_OUT", 3, input -> Double.valueOf(-(Math.cos(Math.PI * input.doubleValue()) - 1.0D) / 2.0D));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  35 */     QUAD_IN = new Easing("QUAD_IN", 4, input -> Double.valueOf(input.doubleValue() * input.doubleValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     QUAD_OUT = new Easing("QUAD_OUT", 5, input -> Double.valueOf(1.0D - (1.0D - input.doubleValue()) * (1.0D - input.doubleValue())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     QUAD_IN_OUT = new Easing("QUAD_IN_OUT", 6, input -> Double.valueOf((input.doubleValue() < 0.5D) ? (2.0D * input.doubleValue() * input.doubleValue()) : (1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 2.0D) / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     CUBIC_IN = new Easing("CUBIC_IN", 7, input -> Double.valueOf(input.doubleValue() * input.doubleValue() * input.doubleValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     CUBIC_OUT = new Easing("CUBIC_OUT", 8, input -> Double.valueOf(1.0D - Math.pow(1.0D - input.doubleValue(), 3.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     CUBIC_IN_OUT = new Easing("CUBIC_IN_OUT", 9, input -> Double.valueOf((input.doubleValue() < 0.5D) ? (4.0D * input.doubleValue() * input.doubleValue() * input.doubleValue()) : (1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 3.0D) / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     QUART_IN = new Easing("QUART_IN", 10, input -> Double.valueOf(input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     QUART_OUT = new Easing("QUART_OUT", 11, input -> Double.valueOf(1.0D - Math.pow(1.0D - input.doubleValue(), 4.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     QUART_IN_OUT = new Easing("QUART_IN_OUT", 12, input -> Double.valueOf((input.doubleValue() < 0.5D) ? (8.0D * input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue()) : (1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 4.0D) / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     QUINT_IN = new Easing("QUINT_IN", 13, input -> Double.valueOf(input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     QUINT_OUT = new Easing("QUINT_OUT", 14, input -> Double.valueOf(1.0D - Math.pow(1.0D - input.doubleValue(), 5.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     QUINT_IN_OUT = new Easing("QUINT_IN_OUT", 15, input -> Double.valueOf((input.doubleValue() < 0.5D) ? (16.0D * input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue() * input.doubleValue()) : (1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 5.0D) / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     EXPO_IN = new Easing("EXPO_IN", 16, input -> Double.valueOf((input.doubleValue() == 0.0D) ? 0.0D : Math.pow(2.0D, 10.0D * input.doubleValue() - 10.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     EXPO_OUT = new Easing("EXPO_OUT", 17, input -> Double.valueOf((input.doubleValue() == 1.0D) ? 1.0D : (1.0D - Math.pow(2.0D, -10.0D * input.doubleValue()))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     EXPO_IN_OUT = new Easing("EXPO_IN_OUT", 18, input -> Double.valueOf((input.doubleValue() < 0.5D) ? (4.0D * input.doubleValue() * input.doubleValue() * input.doubleValue()) : (1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 3.0D) / 2.0D)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     CIRC_IN = new Easing("CIRC_IN", 19, input -> Double.valueOf(1.0D - Math.sqrt(1.0D - Math.pow(input.doubleValue(), 2.0D))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     CIRC_OUT = new Easing("CIRC_OUT", 20, input -> Double.valueOf(Math.sqrt(1.0D - Math.pow(input.doubleValue() - 1.0D, 2.0D))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     CIRC_IN_OUT = new Easing("CIRC_IN_OUT", 21, input -> Double.valueOf((input.doubleValue() < 0.5D) ? ((1.0D - Math.sqrt(1.0D - Math.pow(2.0D * input.doubleValue(), 2.0D))) / 2.0D) : ((Math.sqrt(1.0D - Math.pow(-2.0D * input.doubleValue() + 2.0D, 2.0D)) + 1.0D) / 2.0D)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Easing(Function<Double, Double> easeFunction) {
/* 126 */     this.easeFunction = easeFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double ease(double input) {
/* 135 */     return ((Double)this.easeFunction.apply(Double.valueOf(input))).doubleValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\animation\Easing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */