//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.client.ui.util.animation;
/*     */ 
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Animation
/*     */ {
/*     */   private final int time;
/*  15 */   private State currentState = State.STATIC;
/*  16 */   private long currentStateStart = 0L;
/*     */ 
/*     */   
/*  19 */   private State previousState = State.STATIC;
/*     */ 
/*     */   
/*     */   private boolean initialState;
/*     */   
/*  24 */   private final Easing easing = Easing.EXPO_IN_OUT;
/*     */   
/*     */   public Animation(int time, boolean initialState) {
/*  27 */     this.time = time;
/*  28 */     this.initialState = initialState;
/*     */ 
/*     */     
/*  31 */     if (initialState) {
/*  32 */       this.previousState = State.EXPANDING;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAnimationFactor() {
/*  41 */     if (this.currentState.equals(State.EXPANDING)) {
/*  42 */       return this.easing.ease(MathHelper.clamp((System.currentTimeMillis() - this.currentStateStart) / this.time, 0.0D, 1.0D));
/*     */     }
/*     */     
/*  45 */     if (this.currentState.equals(State.RETRACTING)) {
/*  46 */       return this.easing.ease(MathHelper.clamp((this.time - System.currentTimeMillis() - this.currentStateStart) / this.time, 0.0D, 1.0D));
/*     */     }
/*     */     
/*  49 */     return this.previousState.equals(State.EXPANDING) ? 1.0D : 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getState() {
/*  57 */     return this.initialState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setState(boolean expand) {
/*  65 */     if (expand) {
/*  66 */       this.currentState = State.EXPANDING;
/*  67 */       this.initialState = true;
/*     */     }
/*     */     else {
/*     */       
/*  71 */       this.currentState = State.RETRACTING;
/*     */     } 
/*     */ 
/*     */     
/*  75 */     this.currentStateStart = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStateHard(boolean expand) {
/*  83 */     if (expand) {
/*  84 */       this.currentState = State.EXPANDING;
/*  85 */       this.initialState = true;
/*     */ 
/*     */       
/*  88 */       this.currentStateStart = System.currentTimeMillis();
/*     */     }
/*     */     else {
/*     */       
/*  92 */       this.previousState = State.RETRACTING;
/*  93 */       this.currentState = State.RETRACTING;
/*  94 */       this.initialState = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum State
/*     */   {
/* 103 */     EXPANDING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     RETRACTING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     STATIC;
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\clien\\u\\util\animation\Animation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
