//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.font;
/*     */ 
/*     */ import cope.cosmos.util.Wrapper;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.Random;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.resources.IResourceManager;
/*     */ import net.minecraft.util.ChatAllowedCharacters;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class FontRenderer implements Wrapper {
/*     */   private final ImageAWT defaultFont;
/*     */   public final int FONT_HEIGHT;
/*     */   
/*     */   public FontRenderer(Font font) {
/*  19 */     this.defaultFont = new ImageAWT(font);
/*  20 */     this.FONT_HEIGHT = (int)getHeight();
/*     */   }
/*     */   
/*     */   public float getHeight() {
/*  24 */     return this.defaultFont.getHeight() / 2.0F;
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  28 */     return this.defaultFont.getFont().getSize();
/*     */   }
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   public int drawStringWithShadow(String text, float x, float y, int color) {
/*  33 */     return drawString(text, x, y, color, true);
/*     */   }
/*     */   
/*     */   public int drawString(String text, float x, float y, int color, boolean dropShadow) {
/*  37 */     float currY = y - 3.0F;
/*  38 */     if (text.contains("\n")) {
/*  39 */       String[] parts = text.split("\n");
/*  40 */       float newY = 0.0F;
/*     */       
/*  42 */       for (String s : parts) {
/*  43 */         drawText(s, x, currY + newY, color, dropShadow);
/*  44 */         newY += getHeight();
/*     */       } 
/*     */       
/*  47 */       return 0;
/*     */     } 
/*     */     
/*  50 */     if (dropShadow) {
/*  51 */       drawText(text, x + 0.4F, currY + 0.3F, (new Color(0, 0, 0, 150)).getRGB(), true);
/*     */     }
/*  53 */     return drawText(text, x, currY, color, false);
/*     */   }
/*     */   
/*     */   private int drawText(String text, float x, float y, int color, boolean ignoreColor) {
/*  57 */     if (text == null) {
/*  58 */       return 0;
/*     */     }
/*  60 */     if (text.isEmpty()) {
/*  61 */       return (int)x;
/*     */     }
/*  63 */     GlStateManager.translate(x - 1.5D, y + 0.5D, 0.0D);
/*  64 */     GlStateManager.enableAlpha();
/*  65 */     GlStateManager.enableBlend();
/*  66 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/*  67 */     GlStateManager.enableTexture2D();
/*     */     
/*  69 */     GL11.glEnable(2848);
/*     */     
/*  71 */     int currentColor = color;
/*     */     
/*  73 */     if ((currentColor & 0xFC000000) == 0) {
/*  74 */       currentColor |= 0xFF000000;
/*     */     }
/*  76 */     int alpha = currentColor >> 24 & 0xFF;
/*  77 */     if (text.contains("§")) {
/*  78 */       String[] parts = text.split("§");
/*  79 */       ImageAWT currentFont = this.defaultFont;
/*  80 */       double width = 0.0D;
/*  81 */       boolean randomCase = false;
/*     */       
/*  83 */       for (int index = 0; index < parts.length; index++) {
/*  84 */         String part = parts[index];
/*     */         
/*  86 */         if (!part.isEmpty())
/*     */         {
/*     */           
/*  89 */           if (index == 0) {
/*  90 */             currentFont.drawString(part, width, 0.0D, currentColor);
/*  91 */             width += currentFont.getStringWidth(part);
/*     */           }
/*     */           else {
/*     */             
/*  95 */             String words = part.substring(1);
/*  96 */             char type = part.charAt(0);
/*  97 */             int colorIndex = "0123456789abcdefklmnor".indexOf(type);
/*  98 */             switch (colorIndex) {
/*     */               case 0:
/*     */               case 1:
/*     */               case 2:
/*     */               case 3:
/*     */               case 4:
/*     */               case 5:
/*     */               case 6:
/*     */               case 7:
/*     */               case 8:
/*     */               case 9:
/*     */               case 10:
/*     */               case 11:
/*     */               case 12:
/*     */               case 13:
/*     */               case 14:
/*     */               case 15:
/* 115 */                 if (!ignoreColor) {
/* 116 */                   currentColor = ColorUtils.hexColors[colorIndex] | alpha << 24;
/*     */                 }
/* 118 */                 randomCase = false;
/*     */                 break;
/*     */               case 16:
/* 121 */                 randomCase = true;
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               case 21:
/* 127 */                 currentColor = color;
/* 128 */                 if ((currentColor & 0xFC000000) == 0) {
/* 129 */                   currentColor |= 0xFF000000;
/*     */                 }
/* 131 */                 randomCase = false;
/*     */                 break;
/*     */             } 
/* 134 */             currentFont = this.defaultFont;
/* 135 */             if (randomCase) {
/* 136 */               currentFont.drawString(ColorUtils.randomMagicText(words), width, 0.0D, currentColor);
/*     */             } else {
/* 138 */               currentFont.drawString(words, width, 0.0D, currentColor);
/*     */             } 
/* 140 */             width += currentFont.getStringWidth(words);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } else {
/* 145 */       this.defaultFont.drawString(text, 0.0D, 0.0D, currentColor);
/*     */     } 
/* 147 */     GL11.glDisable(2848);
/*     */     
/* 149 */     GlStateManager.disableBlend();
/* 150 */     GlStateManager.translate(-(x - 1.5D), -(y + 0.5D), 0.0D);
/*     */     
/* 152 */     return (int)(x + getStringWidth(text));
/*     */   }
/*     */   
/*     */   public int getColorCode(char charCode) {
/* 156 */     return ColorUtils.hexColors[getColorIndex(charCode)];
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/* 160 */     if (text.contains("§")) {
/* 161 */       String[] parts = text.split("§");
/* 162 */       ImageAWT currentFont = this.defaultFont;
/* 163 */       int width = 0;
/*     */       
/* 165 */       for (int index = 0; index < parts.length; index++) {
/* 166 */         String part = parts[index];
/*     */         
/* 168 */         if (!part.isEmpty())
/*     */         {
/*     */           
/* 171 */           if (index == 0) {
/* 172 */             width += currentFont.getStringWidth(part);
/*     */           }
/*     */           else {
/*     */             
/* 176 */             String words = part.substring(1);
/*     */             
/* 178 */             currentFont = this.defaultFont;
/* 179 */             width += currentFont.getStringWidth(words);
/*     */           }  } 
/*     */       } 
/* 182 */       return width / 2;
/*     */     } 
/*     */     
/* 185 */     return this.defaultFont.getStringWidth(text) / 2;
/*     */   }
/*     */   
/*     */   public int getCharWidth(char character) {
/* 189 */     return getStringWidth(String.valueOf(character));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   public void onResourceManagerReload(IResourceManager resourceManager) {}
/*     */ 
/*     */   
/*     */   @ParametersAreNonnullByDefault
/*     */   protected void bindTexture(ResourceLocation location) {}
/*     */ 
/*     */   
/*     */   public static int getColorIndex(char type) {
/* 203 */     switch (type) {
/*     */       case '0':
/*     */       case '1':
/*     */       case '2':
/*     */       case '3':
/*     */       case '4':
/*     */       case '5':
/*     */       case '6':
/*     */       case '7':
/*     */       case '8':
/*     */       case '9':
/* 214 */         return type - 48;
/*     */       case 'a':
/*     */       case 'b':
/*     */       case 'c':
/*     */       case 'd':
/*     */       case 'e':
/*     */       case 'f':
/* 221 */         return type - 97 + 10;
/*     */       case 'k':
/*     */       case 'l':
/*     */       case 'm':
/*     */       case 'n':
/*     */       case 'o':
/* 227 */         return type - 107 + 16;
/*     */       case 'r':
/* 229 */         return 21;
/*     */     } 
/* 231 */     return -1;
/*     */   }
/*     */   
/*     */   private static class ColorUtils {
/* 235 */     public static int[] hexColors = new int[16];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String randomMagicText(String text) {
/* 244 */       StringBuilder stringBuilder = new StringBuilder();
/* 245 */       for (char ch : text.toCharArray()) {
/*     */         
/* 247 */         if (ChatAllowedCharacters.isAllowedCharacter(ch)) {
/*     */ 
/*     */           
/* 250 */           int index = random.nextInt("À�?ÂÈÊË�?ÓÔÕÚßãõğİıŒœ�?şŴŵžȇ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗�?╜╛�?└┴┬├─┼�?╟╚╔╩╦╠�?╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌�?▀αβΓπΣσμτΦΘΩδ�?∅∈∩≡±≥≤⌠⌡÷≈°∙·√�?�²■".length());
/* 251 */           stringBuilder.append("À�?ÂÈÊË�?ÓÔÕÚßãõğİıŒœ�?şŴŵžȇ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗�?╜╛�?└┴┬├─┼�?╟╚╔╩╦╠�?╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌�?▀αβΓπΣσμτΦΘΩδ�?∅∈∩≡±≥≤⌠⌡÷≈°∙·√�?�²■".charAt(index));
/*     */         } 
/*     */       } 
/* 254 */       return stringBuilder.toString();
/*     */     }
/*     */     
/*     */     static {
/* 258 */       hexColors[0] = 0;
/* 259 */       hexColors[1] = 170;
/* 260 */       hexColors[2] = 43520;
/* 261 */       hexColors[3] = 43690;
/* 262 */       hexColors[4] = 11141120;
/* 263 */       hexColors[5] = 11141290;
/* 264 */       hexColors[6] = 16755200;
/* 265 */       hexColors[7] = 11184810;
/* 266 */       hexColors[8] = 5592405;
/* 267 */       hexColors[9] = 5592575;
/* 268 */       hexColors[10] = 5635925;
/* 269 */       hexColors[11] = 5636095;
/* 270 */       hexColors[12] = 16733525;
/* 271 */       hexColors[13] = 16733695;
/* 272 */       hexColors[14] = 16777045;
/* 273 */       hexColors[15] = 16777215;
/* 274 */     } private static final Random random = new Random();
/*     */     private static final String magicAllowedCharacters = "À�?ÂÈÊË�?ÓÔÕÚßãõğİıŒœ�?şŴŵžȇ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗�?╜╛�?└┴┬├─┼�?╟╚╔╩╦╠�?╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌�?▀αβΓπΣσμτΦΘΩδ�?∅∈∩≡±≥≤⌠⌡÷≈°∙·√�?�²■";
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\font\FontRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
