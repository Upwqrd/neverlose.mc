//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\PC\Downloads\Minecraft-Deobfuscator3000-master\Minecraft-Deobfuscator3000-master\1.12 stable mappings"!

/*     */ package cope.cosmos.font;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.texture.TextureUtil;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ImageAWT implements Wrapper {
/*  19 */   private static final ArrayList<ImageAWT> activeFontRenderers = new ArrayList<>();
/*  20 */   private static int gcTicks = 0;
/*     */   private final Font font;
/*  22 */   private int fontHeight = -1;
/*     */   private final CharLocation[] charLocations;
/*  24 */   private final HashMap<String, FontCache> cachedStrings = new HashMap<>();
/*  25 */   private int textureID = 0;
/*  26 */   private int textureWidth = 0;
/*  27 */   private int textureHeight = 0;
/*     */   
/*     */   public static void garbageCollectionTick() {
/*  30 */     if (gcTicks++ > 600) {
/*  31 */       activeFontRenderers.forEach(ImageAWT::collectGarbage);
/*  32 */       gcTicks = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ImageAWT(Font font, int startChar, int stopChar) {
/*  37 */     this.font = font;
/*  38 */     this.charLocations = new CharLocation[stopChar];
/*  39 */     renderBitmap(startChar, stopChar);
/*  40 */     activeFontRenderers.add(this);
/*     */   }
/*     */   
/*     */   public ImageAWT(Font font) {
/*  44 */     this(font, 0, 255);
/*     */   }
/*     */   
/*     */   private void collectGarbage() {
/*  48 */     long currentTime = System.currentTimeMillis();
/*  49 */     this.cachedStrings.entrySet().stream().filter(entry -> (currentTime - ((FontCache)entry.getValue()).getLastUsage() > 30000L)).forEach(entry -> {
/*     */           GL11.glDeleteLists(((FontCache)entry.getValue()).getDisplayList(), 1);
/*     */           ((FontCache)entry.getValue()).setDeleted(true);
/*     */           this.cachedStrings.remove(entry.getKey());
/*     */         });
/*     */   }
/*     */   
/*     */   public float getHeight() {
/*  57 */     return (this.fontHeight - 8.0F) / 2.0F;
/*     */   }
/*     */   
/*     */   public void drawString(String text, double x, double y, int color) {
/*  61 */     GlStateManager.pushMatrix();
/*  62 */     GlStateManager.scale(0.25D, 0.25D, 0.25D);
/*  63 */     GL11.glTranslated(x * 2.0D, y * 2.0D - 2.0D, 0.0D);
/*  64 */     GlStateManager.bindTexture(this.textureID);
/*  65 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  66 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  67 */     float blue = (color & 0xFF) / 255.0F;
/*  68 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  69 */     GlStateManager.color(red, green, blue, alpha);
/*  70 */     double currX = 0.0D;
/*  71 */     FontCache cached = this.cachedStrings.get(text);
/*     */     
/*  73 */     if (cached != null) {
/*  74 */       GL11.glCallList(cached.getDisplayList());
/*  75 */       cached.setLastUsage(System.currentTimeMillis());
/*  76 */       GlStateManager.popMatrix();
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     int list = -1;
/*  81 */     boolean assumeNonVolatile = false;
/*     */     
/*  83 */     if (assumeNonVolatile) {
/*  84 */       list = GL11.glGenLists(1);
/*  85 */       GL11.glNewList(list, 4865);
/*     */     } 
/*     */     
/*  88 */     GL11.glBegin(7);
/*  89 */     for (char ch : text.toCharArray()) {
/*     */       
/*  91 */       if (Character.getNumericValue(ch) >= this.charLocations.length) {
/*  92 */         GL11.glEnd();
/*  93 */         GlStateManager.scale(4.0D, 4.0D, 4.0D);
/*  94 */         mc.fontRenderer.drawString(String.valueOf(ch), (float)currX * 0.25F + 1.0F, 2.0F, color, false);
/*  95 */         currX += mc.fontRenderer.getStringWidth(String.valueOf(ch)) * 4.0D;
/*  96 */         GlStateManager.scale(0.25D, 0.25D, 0.25D);
/*  97 */         GlStateManager.bindTexture(this.textureID);
/*  98 */         GlStateManager.color(red, green, blue, alpha);
/*  99 */         GL11.glBegin(7);
/*     */       } else {
/*     */         CharLocation fontChar;
/*     */         
/* 103 */         if (this.charLocations.length > ch && (fontChar = this.charLocations[ch]) != null) {
/*     */ 
/*     */           
/* 106 */           drawChar(fontChar, (float)currX, 0.0F);
/* 107 */           currX += fontChar.width - 8.0D;
/*     */         } 
/*     */       } 
/* 110 */     }  GL11.glEnd();
/*     */     
/* 112 */     if (assumeNonVolatile) {
/* 113 */       this.cachedStrings.put(text, new FontCache(list, System.currentTimeMillis()));
/* 114 */       GL11.glEndList();
/*     */     } 
/*     */     
/* 117 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   private void drawChar(CharLocation ch, float x, float y) {
/* 121 */     float width = ch.width;
/* 122 */     float height = ch.height;
/* 123 */     float srcX = ch.x;
/* 124 */     float srcY = ch.y;
/* 125 */     float renderX = srcX / this.textureWidth;
/* 126 */     float renderY = srcY / this.textureHeight;
/* 127 */     float renderWidth = width / this.textureWidth;
/* 128 */     float renderHeight = height / this.textureHeight;
/* 129 */     GL11.glTexCoord2f(renderX, renderY);
/* 130 */     GL11.glVertex2f(x, y);
/* 131 */     GL11.glTexCoord2f(renderX, renderY + renderHeight);
/* 132 */     GL11.glVertex2f(x, y + height);
/* 133 */     GL11.glTexCoord2f(renderX + renderWidth, renderY + renderHeight);
/* 134 */     GL11.glVertex2f(x + width, y + height);
/* 135 */     GL11.glTexCoord2f(renderX + renderWidth, renderY);
/* 136 */     GL11.glVertex2f(x + width, y);
/*     */   }
/*     */   
/*     */   private void renderBitmap(int startChar, int stopChar) {
/* 140 */     BufferedImage[] fontImages = new BufferedImage[stopChar];
/* 141 */     int rowHeight = 0;
/* 142 */     int charX = 0;
/* 143 */     int charY = 0;
/*     */     
/* 145 */     for (int targetChar = startChar; targetChar < stopChar; targetChar++) {
/* 146 */       BufferedImage fontImage = drawCharToImage((char)targetChar);
/* 147 */       CharLocation fontChar = new CharLocation(charX, charY, fontImage.getWidth(), fontImage.getHeight());
/*     */       
/* 149 */       if (fontChar.height > this.fontHeight) {
/* 150 */         this.fontHeight = fontChar.height;
/*     */       }
/* 152 */       if (fontChar.height > rowHeight) {
/* 153 */         rowHeight = fontChar.height;
/*     */       }
/* 155 */       if (this.charLocations.length > targetChar) {
/*     */ 
/*     */         
/* 158 */         this.charLocations[targetChar] = fontChar;
/* 159 */         fontImages[targetChar] = fontImage;
/*     */         
/* 161 */         if ((charX += fontChar.width) > 2048) {
/*     */ 
/*     */           
/* 164 */           if (charX > this.textureWidth) {
/* 165 */             this.textureWidth = charX;
/*     */           }
/* 167 */           charX = 0;
/* 168 */           charY += rowHeight;
/* 169 */           rowHeight = 0;
/*     */         } 
/*     */       } 
/* 172 */     }  this.textureHeight = charY + rowHeight;
/* 173 */     BufferedImage bufferedImage = new BufferedImage(this.textureWidth, this.textureHeight, 2);
/* 174 */     Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/* 175 */     graphics2D.setFont(this.font);
/* 176 */     graphics2D.setColor(new Color(255, 255, 255, 0));
/* 177 */     graphics2D.fillRect(0, 0, this.textureWidth, this.textureHeight);
/* 178 */     graphics2D.setColor(Color.WHITE);
/*     */     
/* 180 */     for (int i = startChar; i < stopChar; i++) {
/* 181 */       if (fontImages[i] != null && this.charLocations[i] != null)
/*     */       {
/*     */         
/* 184 */         graphics2D.drawImage(fontImages[i], (this.charLocations[i]).x, (this.charLocations[i]).y, (ImageObserver)null);
/*     */       }
/*     */     } 
/* 187 */     this.textureID = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), bufferedImage, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private BufferedImage drawCharToImage(char ch) {
/* 192 */     Graphics2D graphics2D = (Graphics2D)(new BufferedImage(1, 1, 2)).getGraphics();
/* 193 */     graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 194 */     graphics2D.setFont(this.font);
/* 195 */     FontMetrics fontMetrics = graphics2D.getFontMetrics();
/* 196 */     int charWidth = fontMetrics.charWidth(ch) + 8;
/*     */     
/* 198 */     if (charWidth <= 8)
/* 199 */       charWidth = 7; 
/*     */     int charHeight;
/* 201 */     if ((charHeight = fontMetrics.getHeight() + 3) <= 0) {
/* 202 */       charHeight = this.font.getSize();
/*     */     }
/* 204 */     BufferedImage fontImage = new BufferedImage(charWidth, charHeight, 2);
/* 205 */     Graphics2D graphics = (Graphics2D)fontImage.getGraphics();
/* 206 */     graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 207 */     graphics.setFont(this.font);
/* 208 */     graphics.setColor(Color.WHITE);
/* 209 */     graphics.drawString(String.valueOf(ch), 3, 1 + fontMetrics.getAscent());
/* 210 */     return fontImage;
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/* 214 */     int width = 0;
/* 215 */     for (int ch : text.toCharArray()) {
/*     */       
/* 217 */       int index = (ch < this.charLocations.length) ? ch : 3;
/*     */       CharLocation fontChar;
/* 219 */       if (this.charLocations.length <= index || (fontChar = this.charLocations[index]) == null) {
/* 220 */         width = (int)(width + mc.fontRenderer.getStringWidth(String.valueOf(ch)) / 4.0D);
/*     */       }
/*     */       else {
/*     */         
/* 224 */         width = (int)(width + fontChar.width - 8.0D);
/*     */       } 
/*     */     } 
/* 227 */     return width / 2;
/*     */   }
/*     */   
/*     */   public Font getFont() {
/* 231 */     return this.font;
/*     */   }
/*     */   
/*     */   private static class CharLocation {
/*     */     private final int x;
/*     */     private final int y;
/*     */     private final int width;
/*     */     private final int height;
/*     */     
/*     */     CharLocation(int x, int y, int width, int height) {
/* 241 */       this.x = x;
/* 242 */       this.y = y;
/* 243 */       this.width = width;
/* 244 */       this.height = height;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\font\ImageAWT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
