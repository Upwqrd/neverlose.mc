/*    */ package cope.cosmos.font;
/*    */ 
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class FontCache {
/*    */   int displayList;
/*    */   long lastUsage;
/*    */   boolean deleted = false;
/*    */   
/*    */   public FontCache(int displayList, long lastUsage, boolean deleted) {
/* 11 */     this.displayList = displayList;
/* 12 */     this.lastUsage = lastUsage;
/* 13 */     this.deleted = deleted;
/*    */   }
/*    */   
/*    */   public FontCache(int displayList, long lastUsage) {
/* 17 */     this.displayList = displayList;
/* 18 */     this.lastUsage = lastUsage;
/*    */   }
/*    */   
/*    */   protected void finalize() {
/* 22 */     if (!this.deleted)
/* 23 */       GL11.glDeleteLists(this.displayList, 1); 
/*    */   }
/*    */   
/*    */   public int getDisplayList() {
/* 27 */     return this.displayList;
/*    */   }
/*    */   
/*    */   public long getLastUsage() {
/* 31 */     return this.lastUsage;
/*    */   }
/*    */   
/*    */   public boolean isDeleted() {
/* 35 */     return this.deleted;
/*    */   }
/*    */   
/*    */   public void setLastUsage(long lastUsage) {
/* 39 */     this.lastUsage = lastUsage;
/*    */   }
/*    */   
/*    */   public void setDeleted(boolean deleted) {
/* 43 */     this.deleted = deleted;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\neverlose public.jar!\cope\cosmos\font\FontCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */